"""ブラウザ（Pyodide）で通訳機の画面を動かす入り口。

実機と同じ画面のプログラム（translator/ui.py）と、PC のエミュレーター（tools/emulator.py）をそのまま使う。
ブラウザでは、画面を直接書き出せず、裏のスレッドも使えず、pygame.freetype も動かないので、次のように差し替える。

- 画面: 画像の面（Surface）に描くだけにして、JavaScript が、できた絵を canvas に写す（HeadlessDisplay）
- 文字: pygame.font で描く（WebFont）。日本語・韓国語・中国語・タイ語の書体は、使う文字だけにした小さな書体
- 入力: JavaScript が、クリックの位置とキーを tap() と key() で渡す
- 時間: JavaScript が、毎フレーム step() を呼ぶ（聞き取りの終わりなどの予約も、ここで動く）

JavaScript から呼ぶもの: start(), tap(x, y), key(キー名, shift, ctrl), step()
"""

from __future__ import annotations

import sys
from pathlib import Path

import pygame

APP = Path(__file__).resolve().parent
sys.path.insert(0, str(APP))
sys.path.insert(0, str(APP / "tools"))

WIDTH, HEIGHT = 800, 480
FONT_DIR = APP / "tools" / "fonts"

_emu = None
_display = None
# Web 版に出す相手の言語（2026-11-26）: 書体と見本の訳がそろっている 32 言語と、日本の方言 10。
# 2026-11-21 に実機へ足した 24 言語（ミャンマー語・クメール語など）は、Web の書体に文字が無い（□になる）ので出さない
WEB_LANGS = (
    "ko", "en", "zh", "yue", "th", "fr", "ru", "pt",
    "es", "de", "it", "nl", "pl", "hr", "sk", "sl", "hu", "et", "lv", "lt", "bg", "id", "vi", "ar", "hi",
    "tr", "cs", "uk", "ne", "fa", "uz", "si",
    "hok", "toh", "nag", "kyo", "osa", "hir", "tos", "fuk", "kag", "oki",
)


class WebFont:
    """pygame.freetype.Font の代わり（ui.py が使う render / render_to / get_rect だけ）。大きさごとに pygame.font.Font を作って覚える。"""

    origin = True

    def __init__(self, path, script: str = "") -> None:
        # script: 文字の組み立て（シェーピング）が要る文字の名前（"Deva" = デーヴァナーガリー、"Sinh" = シンハラ）。実機の ShapedFont と同じ
        self._path = str(path)
        self._script = script
        self._fonts: dict[int, pygame.font.Font] = {}

    def _font(self, size) -> pygame.font.Font:
        size = max(1, int(round(size or 16)))
        font = self._fonts.get(size)
        if font is None:
            font = self._fonts[size] = pygame.font.Font(self._path, size)
            if self._script:
                try:
                    font.set_script(self._script)
                except (AttributeError, pygame.error):
                    pass  # HarfBuzz の無い pygame では、組み立てずに描く
        return font

    def _text(self, text):
        return text

    def render(self, text, fgcolor=None, bgcolor=None, style=0, rotation=0, size=0):
        font = self._font(size)
        if not text:
            return pygame.Surface((1, font.get_height()), pygame.SRCALPHA), pygame.Rect(0, 0, 0, font.get_height())
        surface = font.render(self._text(text), True, fgcolor or (255, 255, 255))
        return surface, surface.get_rect()

    def get_rect(self, text, style=0, rotation=0, size=0):
        width, height = self._font(size).size(self._text(text or ""))
        return pygame.Rect(0, 0, width, height)

    def get_sized_ascender(self, size=0) -> int:
        return self._font(size).get_ascent()

    def render_to(self, surface, dest, text, fgcolor=None, bgcolor=None, style=0, rotation=0, size=0):
        # origin=True の freetype は、dest の y を「ベースライン」として扱うので、文字の上端はそこから ascent だけ上
        font = self._font(size)
        image, rect = self.render(text, fgcolor, size=size)
        top = dest[1] - font.get_ascent()
        surface.blit(image, (dest[0], top))
        return pygame.Rect(dest[0], top, rect.width, rect.height)


class WebArabicFont(WebFont):
    """アラビア文字（アラビア語・ペルシア語）。実機の ArabicFont と同じく、文字の形（つながり）と右から左の並びを描く前に直す。

    ブラウザの pygame.font は HarfBuzz で文字を組み立てるので、そのままだと、もう並べ替えた文字を
    アラビア文字としてもう一度組み立て、「ل」と「ا」を誤って 1 字（ﻻ）にしてしまう（例: بالبطاقة）。
    並べ替えたあとで「ل」のすぐ後ろ（左）に「ا」が来たところに、つなげない印（ZWNJ）を入れて防ぐ。
    本当の「لا」は、arabic_shaping がもう 1 字（ﻻ など）にしているので、ここには来ない。
    """

    _LAM = "ﻟﻠﻝﻞل"
    _ALEF = "ﺍﺎﺁﺂﺃﺄﺇﺈاآأإ"

    def _text(self, text):
        from translator.arabic_shaping import to_display

        shown = to_display(text)
        return "".join(ch + ("‌" if ch in self._LAM and nxt in self._ALEF else "") for ch, nxt in zip(shown, shown[1:] + " "))


class HeadlessDisplay:
    """画面に出さず、メモリ上の絵だけを持つ表示（translator.display の SdlDisplay の代わり）。描き直したら dirty が True になる。"""

    def __init__(self, width: int, height: int) -> None:
        self.surface = pygame.Surface((width, height), 0, 32)
        self.dirty = True

    def poll(self, timeout_sec: float):
        from translator.input_events import InputBatch

        return InputBatch()

    def present(self) -> None:
        self.dirty = True

    def close(self) -> None:
        pass


def _load_fonts(path: str, thai_path: str = "", *_other_paths: str):
    """ui.load_fonts の代わり。書体は FONT_DIR の、使う文字だけにした書体（build_web.py が作る）。

    ui.load_fonts は 2026-11-14 からラテン・アラビア・デーヴァナーガリー・シンハラの書体の場所も受け取る（*_other_paths）。
    Web 版では、その代わりに build_web.py が作った web_latin / web_arabic / web_deva / web_sinh を使う（実機と同じ言語の分け方）。
    """
    from translator.langs import AR, CS, EN, FA, FR, FUK, HI, HOK, JA, KO, NE, NEW_LANGS, OSA, PARTNER_LANGS, PT, RU, SI, TH, TR, UK, UZ, YUE, ZH
    from translator.ui import ZH_HANT

    fonts = {
        JA: WebFont(FONT_DIR / "web_jp.ttf"),
        KO: WebFont(FONT_DIR / "web_kr.ttf"),
        ZH: WebFont(FONT_DIR / "web_sc.ttf"),
        ZH_HANT: WebFont(FONT_DIR / "web_tc.ttf"),
        YUE: WebFont(FONT_DIR / "web_hk.ttf"),
        TH: WebFont(FONT_DIR / "web_thai.ttf"),
    }
    # 英語・フランス語・ロシア語・ポルトガル語と、方言（北海道弁・大阪弁・福岡弁）は、日本語の書体で描く
    for lang in (EN, FR, RU, PT, HOK, OSA, FUK):
        fonts[lang] = fonts[JA]
    # 足した言語: ラテン文字・キリル文字（ブルガリア語・ウクライナ語）は Noto Sans、アラビア語・ペルシア語・ヒンディー語・ネパール語・シンハラ語は専用の書体
    latin = WebFont(FONT_DIR / "web_latin.ttf")
    for lang in (*NEW_LANGS, TR, CS, UK, UZ):
        fonts[lang] = latin
    arabic = WebArabicFont(FONT_DIR / "web_arabic.ttf")
    devanagari = WebFont(FONT_DIR / "web_deva.ttf", "Deva")
    for lang, font in ((AR, arabic), (FA, arabic), (HI, devanagari), (NE, devanagari), (SI, WebFont(FONT_DIR / "web_sinh.ttf", "Sinh"))):
        fonts[lang] = font
    for lang in PARTNER_LANGS:
        fonts.setdefault(lang, fonts[JA])
    return fonts


def _load_phonetic_font(path: str, fallback):
    return WebFont(path) if path and Path(path).exists() else fallback


# ブラウザのキーの名前 → 通訳機の中のキーの名前（ほかの 1 文字のキーは、その文字を小文字にした名前）
_SPECIAL_KEYS = {
    "Enter": "enter",
    "Escape": "esc",
    " ": "space",
    "Tab": "tab",
    "Backspace": "backspace",
    "ArrowLeft": "left",
    "ArrowRight": "right",
    "ArrowUp": "up",
    "ArrowDown": "down",
    "PageUp": "pageup",
    "PageDown": "pagedown",
    "Delete": "delete",
}
_PUNCTUATION = {
    "-": "minus", "=": "equal", "[": "leftbrace", "]": "rightbrace", "\\": "backslash", ";": "semicolon",
    "'": "apostrophe", "`": "grave", ",": "comma", ".": "dot", "/": "slash",
}
_MODIFIER_KEYS = {"Shift", "Control", "Alt", "Meta", "CapsLock", "AltGraph"}


def start() -> None:
    """エミュレーターを作って、メニューを出す。"""
    global _emu, _display
    import emulator
    from translator import ui

    pygame.font.init()
    ui.load_fonts = _load_fonts
    ui.load_phonetic_font = _load_phonetic_font
    ui.open_display = lambda cfg: HeadlessDisplay(cfg.width, cfg.height)
    ui.limit_partner_langs(WEB_LANGS)
    _emu = emulator.Emulator(visible=False)
    _display = _emu.screen._display
    _emu.screen.open_menu()
    _emu.settle()


def tap(x: int, y: int) -> None:
    """画面を触った（canvas の座標で、0〜800 x 0〜480）。"""
    _emu.screen._tap(int(x), int(y))


def key(name: str, shift: bool = False, ctrl: bool = False) -> bool:
    """キーを打った（name はブラウザの event.key）。通訳機が使うキーなら True（ブラウザの標準の動き、たとえばスペースでの画面送りを止めてよい）。"""
    from translator.keyboard import KeyPress, key_press

    if name in _MODIFIER_KEYS:
        return False
    internal = _SPECIAL_KEYS.get(name) or _PUNCTUATION.get(name) or (name.lower() if len(name) == 1 else "")
    if not internal:
        return False
    press = key_press(internal, shift, ctrl)
    if not (press.char or ctrl):
        press = KeyPress(internal, name if len(name) == 1 else "", shift, ctrl)
    if _emu.screen._key(press):
        _emu.screen._needs_redraw = True
        return True
    return False


def step():
    """1 フレーム進める。時間が来た予約を実行して、画面が変わっていれば、新しい絵（RGBA、800 x 480 x 4 バイト）を返す。変わっていなければ None。"""
    _emu.tick()
    _emu.screen._redraw_if_changed()
    if not _display.dirty:
        return None
    _display.dirty = False
    return pygame.image.tobytes(_display.surface, "RGBA")
