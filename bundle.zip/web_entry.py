"""ブラウザ（Pyodide）で通訳機の画面を動かす入り口。

実機と同じ画面のプログラム（translator/ui.py）と、PC のエミュレーター（tools/emulator.py）をそのまま使う。
ブラウザでは、画面を直接書き出せず、裏のスレッドも使えず、pygame.freetype も動かないので、次のように差し替える。

- 画面: 画像の面（Surface）に描くだけにして、JavaScript が、できた絵を canvas に写す（HeadlessDisplay）
- 文字: pygame.font で描く（WebFont）。日本語・韓国語・中国語・タイ語の書体は、使う文字だけにした小さな書体
- 入力: JavaScript が、クリックの位置とキーを tap() と key() で渡す
- 時間: JavaScript が、毎フレーム step() を呼ぶ（聞き取りの終わりなどの予約も、ここで動く）

JavaScript から呼ぶもの: start(), tap(x, y), key(キー名, shift, ctrl), step()
"""

from __future__ import annotations

import sys
from pathlib import Path

import pygame

APP = Path(__file__).resolve().parent
sys.path.insert(0, str(APP))
sys.path.insert(0, str(APP / "tools"))

WIDTH, HEIGHT = 800, 480
FONT_DIR = APP / "tools" / "fonts"

_emu = None
_display = None


class WebFont:
    """pygame.freetype.Font の代わり（ui.py が使う render / render_to / get_rect だけ）。大きさごとに pygame.font.Font を作って覚える。"""

    origin = True

    def __init__(self, path) -> None:
        self._path = str(path)
        self._fonts: dict[int, pygame.font.Font] = {}

    def _font(self, size) -> pygame.font.Font:
        size = max(1, int(round(size or 16)))
        font = self._fonts.get(size)
        if font is None:
            font = self._fonts[size] = pygame.font.Font(self._path, size)
        return font

    def render(self, text, fgcolor=None, bgcolor=None, style=0, rotation=0, size=0):
        font = self._font(size)
        if not text:
            return pygame.Surface((1, font.get_height()), pygame.SRCALPHA), pygame.Rect(0, 0, 0, font.get_height())
        surface = font.render(text, True, fgcolor or (255, 255, 255))
        return surface, surface.get_rect()

    def get_rect(self, text, style=0, rotation=0, size=0):
        width, height = self._font(size).size(text or "")
        return pygame.Rect(0, 0, width, height)

    def get_sized_ascender(self, size=0) -> int:
        return self._font(size).get_ascent()

    def render_to(self, surface, dest, text, fgcolor=None, bgcolor=None, style=0, rotation=0, size=0):
        # origin=True の freetype は、dest の y を「ベースライン」として扱うので、文字の上端はそこから ascent だけ上
        font = self._font(size)
        image, rect = self.render(text, fgcolor, size=size)
        top = dest[1] - font.get_ascent()
        surface.blit(image, (dest[0], top))
        return pygame.Rect(dest[0], top, rect.width, rect.height)


class HeadlessDisplay:
    """画面に出さず、メモリ上の絵だけを持つ表示（translator.display の SdlDisplay の代わり）。描き直したら dirty が True になる。"""

    def __init__(self, width: int, height: int) -> None:
        self.surface = pygame.Surface((width, height), 0, 32)
        self.dirty = True

    def poll(self, timeout_sec: float):
        from translator.input_events import InputBatch

        return InputBatch()

    def present(self) -> None:
        self.dirty = True

    def close(self) -> None:
        pass


def _load_fonts(path: str, thai_path: str = ""):
    """ui.load_fonts の代わり。書体は FONT_DIR の、使う文字だけにした書体（build_web.py が作る）。"""
    from translator.langs import EN, FR, FUK, HOK, JA, KO, OSA, PT, RU, TH, YUE, ZH
    from translator.ui import ZH_HANT

    fonts = {
        JA: WebFont(FONT_DIR / "web_jp.ttf"),
        KO: WebFont(FONT_DIR / "web_kr.ttf"),
        ZH: WebFont(FONT_DIR / "web_sc.ttf"),
        ZH_HANT: WebFont(FONT_DIR / "web_tc.ttf"),
        YUE: WebFont(FONT_DIR / "web_hk.ttf"),
        TH: WebFont(FONT_DIR / "web_thai.ttf"),
    }
    # 英語・フランス語・ロシア語・ポルトガル語と、方言（北海道弁・大阪弁・福岡弁）は、日本語の書体で描く
    for lang in (EN, FR, RU, PT, HOK, OSA, FUK):
        fonts.setdefault(lang, fonts[JA])
    return fonts


def _load_phonetic_font(path: str, fallback):
    return WebFont(path) if path and Path(path).exists() else fallback


# ブラウザのキーの名前 → 通訳機の中のキーの名前（ほかの 1 文字のキーは、その文字を小文字にした名前）
_SPECIAL_KEYS = {
    "Enter": "enter",
    "Escape": "esc",
    " ": "space",
    "Tab": "tab",
    "Backspace": "backspace",
    "ArrowLeft": "left",
    "ArrowRight": "right",
    "ArrowUp": "up",
    "ArrowDown": "down",
    "PageUp": "pageup",
    "PageDown": "pagedown",
    "Delete": "delete",
}
_PUNCTUATION = {
    "-": "minus", "=": "equal", "[": "leftbrace", "]": "rightbrace", "\\": "backslash", ";": "semicolon",
    "'": "apostrophe", "`": "grave", ",": "comma", ".": "dot", "/": "slash",
}
_MODIFIER_KEYS = {"Shift", "Control", "Alt", "Meta", "CapsLock", "AltGraph"}


def start() -> None:
    """エミュレーターを作って、メニューを出す。"""
    global _emu, _display
    import emulator
    from translator import ui

    pygame.font.init()
    ui.load_fonts = _load_fonts
    ui.load_phonetic_font = _load_phonetic_font
    ui.open_display = lambda cfg: HeadlessDisplay(cfg.width, cfg.height)
    _emu = emulator.Emulator(visible=False)
    _display = _emu.screen._display
    _emu.screen.open_menu()
    _emu.settle()


def tap(x: int, y: int) -> None:
    """画面を触った（canvas の座標で、0〜800 x 0〜480）。"""
    _emu.screen._tap(int(x), int(y))


def key(name: str, shift: bool = False, ctrl: bool = False) -> bool:
    """キーを打った（name はブラウザの event.key）。通訳機が使うキーなら True（ブラウザの標準の動き、たとえばスペースでの画面送りを止めてよい）。"""
    from translator.keyboard import KeyPress, key_press

    if name in _MODIFIER_KEYS:
        return False
    internal = _SPECIAL_KEYS.get(name) or _PUNCTUATION.get(name) or (name.lower() if len(name) == 1 else "")
    if not internal:
        return False
    press = key_press(internal, shift, ctrl)
    if not (press.char or ctrl):
        press = KeyPress(internal, name if len(name) == 1 else "", shift, ctrl)
    if _emu.screen._key(press):
        _emu.screen._needs_redraw = True
        return True
    return False


def step():
    """1 フレーム進める。時間が来た予約を実行して、画面が変わっていれば、新しい絵（RGBA、800 x 480 x 4 バイト）を返す。変わっていなければ None。"""
    _emu.tick()
    _emu.screen._redraw_if_changed()
    if not _display.dirty:
        return None
    _display.dirty = False
    return pygame.image.tobytes(_display.surface, "RGBA")
