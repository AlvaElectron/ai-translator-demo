"""利用状況の記録（管理者の画面の「利用状況」）: 日ごとの、翻訳の数・訂正の数・定型文を足した数。

翻訳と訂正は、相手の言語（日本語でない方。方言は、方言ごと）の別に数える。定型文は言語を分けない。
1 日の最高温度（CPU 温度。何度まで上がったか、と、その時刻）も、同じファイルに残す。
usage_log.json（config.toml と同じフォルダ）に、次の形で保存する。400 日より古い日は消す。

    {"2026-10-23": {"translations": {"ko": 12, "en": 3}, "corrections": {"ko": 1}, "phrases": {"-": 2},
                    "max_temp": {"value": 74.6, "at": "14:05"}}}
"""

from __future__ import annotations

import json
import logging
import os
import threading
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any
from datetime import date, datetime, timedelta
from pathlib import Path

from .langs import JA

log = logging.getLogger(__name__)

FILE_NAME = "usage_log.json"
KEEP_DAYS = 400
TRANSLATIONS, CORRECTIONS, PHRASES = "translations", "corrections", "phrases"
KINDS = (TRANSLATIONS, CORRECTIONS, PHRASES)
MAX_TEMP = "max_temp"  # 1 日の最高温度（回数ではないので、KINDS には入れない）
NO_LANG = "-"  # 言語を分けない記録（定型文）
# 温度として受け付ける範囲（読み間違いで、おかしな値を最高温度にしない）
MIN_VALID_TEMP, MAX_VALID_TEMP = 0.0, 120.0


@dataclass(frozen=True)
class DayCount:
    day: date
    by_lang: dict[str, int]

    @property
    def total(self) -> int:
        return sum(self.by_lang.values())


@dataclass(frozen=True)
class TempDay:
    day: date
    value: float | None  # その日の最高温度（℃。記録がなければ None）
    at: str = ""  # そのときの時刻（"14:05"）


def usage_log_path(config_path: Path) -> Path:
    """config.toml と同じフォルダの usage_log.json。"""
    return Path(config_path).resolve().parent / FILE_NAME


def partner_lang(source: str, target: str) -> str:
    """話した言語と訳す先の言語のうち、日本語でない方（相手の言語）。日本語どうしなら日本語。"""
    return target if source == JA else source


class UsageLog:
    """翻訳・訂正・定型文の、日ごとの回数。翻訳のスレッドと画面から同時に使っても壊れないようにしてある。"""

    def __init__(self, path: Path, now: Callable[[], datetime] = datetime.now) -> None:
        self._path = Path(path)
        self._now = now
        self._lock = threading.Lock()
        self._days: dict[str, dict[str, Any]] = self._load()

    def record_translation(self, lang: str) -> None:
        self._add(TRANSLATIONS, lang)

    def record_correction(self, lang: str) -> None:
        self._add(CORRECTIONS, lang)

    def record_phrase(self) -> None:
        self._add(PHRASES, NO_LANG)

    def record_temperature(self, value: float | None) -> None:
        """今の CPU 温度を知らせる。その日のいちばん高い値より高いときだけ、最高温度を書き換える（時刻も残す）。"""
        if value is None or not MIN_VALID_TEMP < value < MAX_VALID_TEMP:
            return
        value = round(float(value), 1)
        now = self._now()
        key = now.date().isoformat()
        with self._lock:
            current = self._days.get(key, {}).get(MAX_TEMP)
            if current is not None and value <= current["value"]:
                return
            self._days.setdefault(key, {})[MAX_TEMP] = {"value": value, "at": now.strftime("%H:%M")}
            self._trim(key)
            self._save()

    def daily_max_temp(self, days: int, today: date | None = None) -> list[TempDay]:
        """today の日までの days 日の、日ごとの最高温度（古い日から順。記録のない日は value が None）。"""
        today = today or self._now().date()
        with self._lock:
            result = []
            for offset in range(days - 1, -1, -1):
                day = today - timedelta(days=offset)
                entry = self._days.get(day.isoformat(), {}).get(MAX_TEMP)
                result.append(TempDay(day, entry["value"], entry["at"]) if entry else TempDay(day, None))
            return result

    def daily(self, kind: str, days: int, today: date | None = None) -> list[DayCount]:
        """today の日までの days 日の、日ごとの回数（古い日から順。記録のない日は 0 件）。"""
        today = today or self._now().date()
        with self._lock:
            result = []
            for offset in range(days - 1, -1, -1):
                day = today - timedelta(days=offset)
                counts = self._days.get(day.isoformat(), {}).get(kind, {})
                result.append(DayCount(day, dict(counts)))
            return result

    def total(self, kind: str) -> int:
        """記録している全期間の合計。"""
        with self._lock:
            return sum(sum(day.get(kind, {}).values()) for day in self._days.values())

    def _add(self, kind: str, lang: str) -> None:
        key = self._now().date().isoformat()
        with self._lock:
            counts = self._days.setdefault(key, {}).setdefault(kind, {})
            counts[lang] = counts.get(lang, 0) + 1
            self._trim(key)
            self._save()

    def _trim(self, today_key: str) -> None:
        """_lock を持って呼ぶ。KEEP_DAYS より古い日を消す。"""
        limit = (date.fromisoformat(today_key) - timedelta(days=KEEP_DAYS)).isoformat()
        for key in [key for key in self._days if key < limit]:
            del self._days[key]

    def _load(self) -> dict[str, dict[str, Any]]:
        try:
            raw = json.loads(self._path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return {}
        except (OSError, ValueError):
            log.warning("利用状況のファイルを読めないため、使いません: %s", self._path)
            return {}
        days: dict[str, dict[str, Any]] = {}
        for key, kinds in (raw.items() if isinstance(raw, dict) else []):
            try:
                date.fromisoformat(key)
            except (TypeError, ValueError):
                continue
            if not isinstance(kinds, dict):
                continue
            for kind in KINDS:
                counts = kinds.get(kind)
                if not isinstance(counts, dict):
                    continue
                clean = {lang: n for lang, n in counts.items() if isinstance(lang, str) and isinstance(n, int) and n > 0}
                if clean:
                    days.setdefault(key, {})[kind] = clean
            peak = kinds.get(MAX_TEMP)
            if isinstance(peak, dict):
                value, at = peak.get("value"), peak.get("at", "")
                if isinstance(value, (int, float)) and not isinstance(value, bool) and MIN_VALID_TEMP < value < MAX_VALID_TEMP:
                    days.setdefault(key, {})[MAX_TEMP] = {"value": round(float(value), 1), "at": at if isinstance(at, str) else ""}
        return days

    def _save(self) -> None:
        """_lock を持って呼ぶ。書き込み途中で電源が切れても壊れないよう、別名で書いてから置き換える。"""
        temporary = self._path.with_name(self._path.name + ".tmp")
        try:
            temporary.write_text(json.dumps(self._days, ensure_ascii=False, indent=1, sort_keys=True), encoding="utf-8")
            os.replace(temporary, self._path)
        except OSError:
            log.warning("利用状況を保存できませんでした: %s", self._path, exc_info=True)
