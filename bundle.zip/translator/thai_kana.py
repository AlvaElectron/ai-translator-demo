"""タイ語を、日本語話者が読めるカタカナにする（外部ライブラリに依存しない）。

音節への分割は pythainlp（Apache 2.0）で行い、ここでは書かれた1音節（例: "ครับ"）を、タイ文字の綴りの規則で
「頭子音・母音・末子音」に分けてカタカナにする。声調は表さない。長母音は「ー」で伸ばす。
末子音は、-k・-t・-p の音は「ック」「ット」「ップ」（長母音の後は ク・ト・プ）、-n は「ン」、-m は「ム」、-ng は「ン」で書く
（どの子音で終わるかが分かるように。「ッ」だけでは、สิบ（10）と สิก の区別がつかない）。

例: สวัสดี → サ ワット ディー、ขอบคุณ → コープ クン、ภาษาไทย → パー サー タイ、ครับ → クラップ
"""

from __future__ import annotations

from collections.abc import Iterable

# 頭子音の音と、末子音としての音（"" は末子音にならない文字）
_CONSONANTS: dict[str, tuple[str, str]] = {
    "ก": ("k", "k"), "ข": ("k", "k"), "ฃ": ("k", "k"), "ค": ("k", "k"), "ฅ": ("k", "k"), "ฆ": ("k", "k"),
    "ง": ("ng", "ng"), "จ": ("ch", "t"), "ฉ": ("ch", ""), "ช": ("ch", "t"), "ซ": ("s", "t"), "ฌ": ("ch", ""),
    "ญ": ("y", "n"), "ฎ": ("d", "t"), "ฏ": ("t", "t"), "ฐ": ("t", "t"), "ฑ": ("t", "t"), "ฒ": ("t", "t"),
    "ณ": ("n", "n"), "ด": ("d", "t"), "ต": ("t", "t"), "ถ": ("t", "t"), "ท": ("t", "t"), "ธ": ("t", "t"),
    "น": ("n", "n"), "บ": ("b", "p"), "ป": ("p", "p"), "ผ": ("p", ""), "ฝ": ("f", ""), "พ": ("p", "p"),
    "ฟ": ("f", "p"), "ภ": ("p", "p"), "ม": ("m", "m"), "ย": ("y", "i"), "ร": ("r", "n"), "ล": ("l", "n"),
    "ว": ("w", "u"), "ศ": ("s", "t"), "ษ": ("s", "t"), "ส": ("s", "t"), "ห": ("h", ""), "ฬ": ("l", "n"),
    "อ": ("", ""), "ฮ": ("h", ""), "ฤ": ("r", ""),
}
# 2文字でひとつの頭子音になる組み合わせ（kr・kl・kw・pr・pl・tr など）
# ここに無い並び（ตล・สว など）は、1文字目を「子音 + a」で別に読む（ตลาด → タ ラート）
_CLUSTERS = frozenset(
    {"กร", "กล", "กว", "ขร", "ขล", "ขว", "คร", "คล", "คว", "ปร", "ปล", "พร", "พล", "ผล", "ตร", "บร", "บล", "ดร", "ฟร", "ฟล"}
)
# ห・อ が前に付いて、声調だけを変える（読まない）子音
_H_LEADS = frozenset("งญนมยรลว")

_LEADING_VOWELS = frozenset("เแโใไ")
# ใ・ไ（どちらも「アイ」と読む）。空文字が「in」で一致しないよう、タプルで持つ
_AI_VOWELS = ("ใ", "ไ")
_TONE_MARKS = frozenset("่้๊๋")
_THANTHAKHAT = "์"  # ์ : この印の付いた子音は読まない
_MAI_TAIKHU = "็"  # ็ : 母音を短くする

# 頭子音ごとの ア・イ・ウ・エ・オ段
_ROWS: dict[str, tuple[str, str, str, str, str]] = {
    "": ("ア", "イ", "ウ", "エ", "オ"),
    "k": ("カ", "キ", "ク", "ケ", "コ"),
    "ng": ("ンガ", "ンギ", "ング", "ンゲ", "ンゴ"),
    "ch": ("チャ", "チ", "チュ", "チェ", "チョ"),
    "s": ("サ", "シ", "ス", "セ", "ソ"),
    "y": ("ヤ", "イ", "ユ", "イェ", "ヨ"),
    "d": ("ダ", "ディ", "ドゥ", "デ", "ド"),
    "t": ("タ", "ティ", "トゥ", "テ", "ト"),
    "n": ("ナ", "ニ", "ヌ", "ネ", "ノ"),
    "b": ("バ", "ビ", "ブ", "ベ", "ボ"),
    "p": ("パ", "ピ", "プ", "ペ", "ポ"),
    "f": ("ファ", "フィ", "フ", "フェ", "フォ"),
    "m": ("マ", "ミ", "ム", "メ", "モ"),
    "r": ("ラ", "リ", "ル", "レ", "ロ"),
    "l": ("ラ", "リ", "ル", "レ", "ロ"),
    "w": ("ワ", "ウィ", "ウ", "ウェ", "ウォ"),
    "h": ("ハ", "ヒ", "フ", "ヘ", "ホ"),
}
_COLUMN = {"a": 0, "i": 1, "u": 2, "e": 3, "o": 4}
# 末子音（短母音の後 / 長母音の後）
_CODAS = {
    "": ("", ""),
    "k": ("ック", "ク"),
    "t": ("ット", "ト"),
    "p": ("ップ", "プ"),
    "n": ("ン", "ン"),
    "m": ("ム", "ム"),
    "ng": ("ン", "ン"),
    "i": ("イ", "イ"),
    "u": ("ウ", "ウ"),
}


def syllable_to_kana(syllable: str) -> str:
    """書かれた1音節をカタカナにする。音節の頭に余った子音（สวัส の ส）は、「サ」のように別に読む。"""
    text = _clean(syllable)
    out = []
    while text:
        kana, text = _read_one(text)
        if not kana:
            break
        out.append(kana)
    return " ".join(out)


def to_katakana(syllables: Iterable[str]) -> list[str]:
    """音節の並び（pythainlp の syllable_tokenize の結果）を、カタカナの並びにする。タイ文字以外はそのまま残す。"""
    tokens = []
    for syllable in syllables:
        if not syllable.strip():
            continue
        if any(ch in _CONSONANTS or ch in _LEADING_VOWELS for ch in syllable):
            tokens.append(syllable_to_kana(syllable) or syllable)
        else:
            tokens.append(syllable.strip())
    return tokens


def _clean(text: str) -> str:
    """声調記号を取り、「์」の付いた子音（読まない）を取る。"""
    out = []
    for ch in text:
        if ch in _TONE_MARKS:
            continue
        if ch == _THANTHAKHAT:
            if out:
                out.pop()
            continue
        out.append(ch)
    return "".join(out)


def _read_one(text: str) -> tuple[str, str]:
    """先頭の1音節を読み、(カタカナ, 残りの文字) を返す。"""
    leading = ""
    if text[0] in _LEADING_VOWELS:
        leading, text = text[0], text[1:]
    if not text or text[0] not in _CONSONANTS:
        return "", ""
    first, text = text[0], text[1:]
    onset, cluster = _CONSONANTS[first][0], ""
    if text and text[0] in _CONSONANTS:
        second = text[0]
        if first in "หอ" and (second in _H_LEADS if first == "ห" else second == "ย"):
            onset, text = _CONSONANTS[second][0], text[1:]  # หน・หม・อย の ห・อ は読まない
        elif first + second in _CLUSTERS and (text[1:2] or leading) and not (
            # ว のすぐ後が末子音なら、ว は二重子音ではなく母音「ua」（ควร → クアン、ขวด → クアット）
            second == "ว" and not leading and not _starts_vowel(text[1:])
        ) and not (
            # 前に母音が付いていて、ว で終わるなら、ว は末子音（แก้ว → ケーオ、เร็ว → レオ）
            second == "ว" and leading and not text[1:]
        ):
            cluster, text = _CONSONANTS[second][0], text[1:]
        elif not leading and text[1:2] and _starts_vowel(text[1:]) and not _is_final_pair(text):
            # 2文字目の子音の後に母音が続くので、1文字目は「子音 + a」で1音節（สนาม → ส + นาม）
            return _kana(onset, "", "a", False, ""), text
    vowel, long_, extra, text = _vowel(leading, text)
    coda = ""
    if text and text[0] in _CONSONANTS and not (leading in _AI_VOWELS):
        coda = _CONSONANTS[text[0]][1]
        text = text[1:]
        # บัตร・จักร のように、末子音の後の ร は読まない
        if text[:1] == "ร":
            text = text[1:]
    elif leading in _AI_VOWELS:
        text = text.lstrip("ย")  # ไทย の ย は読まない
    return _kana(onset, cluster, vowel, long_, coda, extra), text


def _starts_vowel(text: str) -> bool:
    return bool(text) and text[0] in "ะาำิีึืุูั็อ"


def _is_final_pair(text: str) -> bool:
    """「子音 + ร」で、ร が読まない字になる組み合わせか（บัตร の ตร）。"""
    return text[1:2] == "ร" and len(text) == 2


def _vowel(leading: str, text: str) -> tuple[str, bool, str, str]:
    """母音を読む。(ア〜オ段のどれか, 長母音か, 後ろに足すカナ, 残りの文字) を返す。"""
    if leading in _AI_VOWELS:
        return "a", False, "イ", text
    if leading == "เ":
        if text.startswith("ีย"):
            return "i", False, "ア", text[2:]
        if text.startswith("ือ"):
            return "u", False, "ア", text[2:]
        if text.startswith("าะ"):
            return "o", False, "", text[2:]
        if text.startswith("า"):
            return "a", False, "オ", text[1:]
        if text.startswith("อ"):
            return "u", True, "", text[1:]
        if text.startswith("ิ"):
            return "u", True, "", text[1:]
        if text.startswith(("ะ", _MAI_TAIKHU)):
            return "e", False, "", text[1:]
        return "e", True, "", text
    if leading == "แ":
        if text.startswith(("ะ", _MAI_TAIKHU)):
            return "e", False, "", text[1:]
        return "e", True, "", text
    if leading == "โ":
        if text.startswith("ะ"):
            return "o", False, "", text[1:]
        return "o", True, "", text
    if not text:
        return "a", False, "", text  # 母音の記号がない開音節は「a」
    mark = text[0]
    if mark == "ะ":
        return "a", False, "", text[1:]
    if mark == "ั":
        if text[1:2] == "ว":
            return "u", False, "ア", text[2:]  # ตัว → トゥア
        return "a", False, "", text[1:]
    if mark == "า":
        return "a", True, "", text[1:]
    if mark == "ำ":
        return "a", False, "ム", text[1:]
    if mark == "ิ":
        return "i", False, "", text[1:]
    if mark == "ี":
        return "i", True, "", text[1:]
    if mark == "ึ":
        return "u", False, "", text[1:]
    if mark == "ื":
        return "u", True, "", text[1:].removeprefix("อ")
    if mark == "ุ":
        return "u", False, "", text[1:]
    if mark == "ู":
        return "u", True, "", text[1:]
    if mark == "อ":
        return "o", True, "", text[1:]
    if mark == "ว" and len(text) > 1:
        return "u", False, "ア", text[1:]  # ควร → クアン
    return "o", False, "", text  # 母音の記号がない閉音節は「o」（คน → コン）


def _kana(onset: str, cluster: str, vowel: str, long_: bool, coda: str, extra: str = "") -> str:
    column = _COLUMN[vowel]
    if cluster:
        # kr・pl などは「ク + ラ」のように、1文字目をウ段で書く
        head = _ROWS.get(onset, _ROWS[""])[2] + _ROWS.get(cluster, _ROWS[""])[column]
    else:
        head = _ROWS.get(onset, _ROWS[""])[column]
    short_coda, long_coda = _CODAS.get(coda, ("", ""))
    if coda == "u" and (vowel in ("a", "e") or extra.endswith("ア")):
        short_coda = long_coda = "オ"  # ขาว → カーオ、แก้ว → ケーオ、เดียว → ディアオ（「ウ」より近い）
    return head + extra + ("ー" if long_ else "") + (long_coda if long_ else short_coda)
