"""中国語（普通話）の学習（「ガイド」の画面の「中国語学習」）の中身: 声調・声母・韻母、接客フレーズ、読む練習のクイズ、発音の判定。

ハングル学習（hangul_study.py）・英語学習（english_study.py）と同じ形にしてあり、画面（ui.py）は、どれも同じ流れで使う。
ここは pygame も音声認識も使わない（PC でそのまま試験できる）。文字は簡体字で出す（大陸の言い方）。

- 文字と発音: 声調（4 つと軽声）、声母（21）、韻母（21）。1 つごとに、ピンイン、カタカナの読み、
  日本語話者向けの発音のコツ、例の単語。
- 接客フレーズ: お店で使う短い文（日本語 → 中国語）。選んでいる業種（industries.py）の文も足す。
- 読む練習: 中国語の単語を見て、日本語の意味を選ぶ。単語は業種の用語集（industry_terms_*.py）から取る。
- 発音の判定: 認識した文と手本の近さを、音節のピンインで比べる（0〜1）。声調だけの違いは、軽く減点する。
"""

from __future__ import annotations

import random
import re
from dataclasses import dataclass

from . import chinese_kana
from .hangul_study import Question, _choices, verdict  # noqa: F401  同じ問題の形・選択肢・判定の言い方を使う

LANG = "zh"

_TONE_MARKS = {
    "a": "āáǎà", "e": "ēéěè", "i": "īíǐì", "o": "ōóǒò", "u": "ūúǔù", "ü": "ǖǘǚǜ",
}


def marked_pinyin(syllable: str) -> str:
    """数字の声調（"ma1"・"lv4"・"ma5"）を、声調記号のピンイン（mā・lǜ・ma）にする。"""
    match = re.fullmatch(r"([a-züv:]+?)([1-5])?", syllable.strip().lower())
    if not match:
        return syllable
    base, tone = match.group(1).replace("v", "ü").replace("u:", "ü"), match.group(2)
    if not tone or tone == "5":
        return base
    index = int(tone) - 1
    # 記号を付ける母音: a か e があれば、それ。ou は o。それ以外は、最後の母音（iu・ui は後ろ）
    position = -1
    for vowel in "ae":
        if vowel in base:
            position = base.index(vowel)
            break
    if position < 0:
        if "ou" in base:
            position = base.index("o")
        else:
            vowels = [i for i, ch in enumerate(base) if ch in "iouü"]
            position = vowels[-1] if vowels else -1
    if position < 0:
        return base
    return base[:position] + _TONE_MARKS[base[position]][index] + base[position + 1 :]


_CONVERTER = None  # 中国語 → カタカナ（最初に使うときに作る。pypinyin がなければ、空）


def kana_of(text: str) -> str:
    """中国語の文のカタカナの読み（画面の発音表示と同じ変換）。変換できなければ空文字。"""
    global _CONVERTER
    if _CONVERTER is None:
        from . import phonetics  # 循環を避けるため、使うときに読む

        _CONVERTER = phonetics._chinese_converter() or (lambda text: "")
    try:
        return _CONVERTER(text)
    except Exception:  # 読みの表示は、なくても学習はできる
        return ""


@dataclass(frozen=True)
class Letter:
    char: str  # b, ā, zh, ang など
    syllable: str  # 読み方を示す音節（数字の声調。例: bo1）
    hanzi: str  # その音節の漢字（読み上げる字）
    tip: str  # 発音のコツ（日本語）
    example_full: str  # 例の単語（簡体字）とピンイン（「妈妈 māma」）
    example_ja: str  # 例の単語の意味

    @property
    def example(self) -> str:
        """例の単語（簡体字だけ。読み上げ・カタカナの変換に使う）。"""
        return self.example_full.split(" ")[0]

    @property
    def example_pinyin(self) -> str:
        return " ".join(self.example_full.split(" ")[1:])

    @property
    def roman(self) -> str:
        """その音節のピンイン（声調記号つき。例: bō）。"""
        return marked_pinyin(self.syllable)

    @property
    def kana(self) -> str:
        return chinese_kana.syllable_to_kana(self.syllable) or ""

    @property
    def display(self) -> str:
        """大きく見せる文字（声母・韻母はそのまま、声調は「mā」のように音節で見せる）。"""
        return self.roman if self.char.startswith(("第", "軽")) else self.char

    @property
    def say(self) -> str:
        """押したときに読み上げる字。"""
        return self.hanzi

    @property
    def example_kana(self) -> str:
        return kana_of(self.example)


def _letters(rows: str) -> tuple[Letter, ...]:
    """「文字|音節|漢字|コツ|例|意味」を 1 行にして、改行でつなぐ。"""
    return tuple(Letter(*(part.strip() for part in line.split("|"))) for line in rows.strip().splitlines())


TONES = _letters(
    """
第1声|ma1|妈|高い音を、平らに保って伸ばす（「アー」と高く一定に）|妈妈 māma|お母さん
第2声|ma2|麻|低めから高く上げる。「えっ？」と聞き返すときの上がり方|麻烦 máfan|面倒
第3声|ma3|马|低く抑えて、下げてから、少し上げる（文末では低く下げるだけでよい）|马 mǎ|馬
第4声|ma4|骂|高いところから、一気に下げる。「コラ！」と叱るように|骂 mà|ののしる
軽声|ma5|吗|前の音節のあとに、軽く短く添える。声調はない（文末の「吗」「的」など）|吗 ma|〜ですか
"""
)

INITIALS = _letters(
    """
b|bo1|波|息を出さない「ポ」に近い清音。日本語の「バ行」ほど濁らない|爸爸 bàba|お父さん
p|po1|坡|息を強く出す「ポ」|苹果 píngguǒ|りんご
m|mo1|摸|唇を閉じて鼻から声を出す「モ」|妈妈 māma|お母さん
f|fo2|佛|上の歯を下唇に軽く当てて息を出す「フ」。日本語の「フ」と違い、唇は丸めない|飞机 fēijī|飛行機
d|de2|得|息を出さない「ト」に近い清音|大家 dàjiā|みなさん
t|te4|特|息を強く出す「ト」|天 tiān|空・天気
n|ne4|讷|舌先を上の歯ぐきに付けて、鼻から声を出す「ヌ」行|你好 nǐ hǎo|こんにちは
l|le4|勒|舌先を上の歯ぐきに付ける「ラ」行|老师 lǎoshī|先生
g|ge1|哥|息を出さない「コ」に近い清音|狗 gǒu|犬
k|ke1|科|息を強く出す「コ」|咖啡 kāfēi|コーヒー
h|he1|喝|のどの奥から息を出す「ホ」。日本語の「ハ行」よりこすれる|喝水 hē shuǐ|水を飲む
j|ji1|鸡|舌の腹を上あごに付けて「ジ」。息を出さない|酒 jiǔ|酒
q|qi1|七|j と同じ口で、息を強く出す「チ」|钱 qián|お金
x|xi1|西|舌の腹を上あごに近づけて、息だけの「シ」|谢谢 xièxie|ありがとう
zh|zhi1|知|舌先を丸めて上あごに付ける「ジ」。息を出さない|中国 Zhōngguó|中国
ch|chi1|吃|舌先を丸めて、息を強く出す「チ」|茶 chá|お茶
sh|shi1|诗|舌先を丸めて息だけの「シ」|水 shuǐ|水
r|ri4|日|舌先を丸めて、声を出す「リ」。英語の r に近い|热 rè|熱い
z|zi1|资|歯の裏で息を出さない「ツ」|早 zǎo|朝・早い
c|ci4|次|歯の裏で息を強く出す「ツ」|菜 cài|料理
s|si1|思|歯の裏で息だけの「ス」|三 sān|三
"""
)

FINALS = _letters(
    """
a|a1|啊|口を大きく開けた「アー」|妈妈 māma|お母さん
o|o1|哦|唇を丸めた「オー」|婆婆 pópo|おばあさん
e|e1|鹅|口を半分開け、唇を丸めずに「ウ」に近い「オー」|喝 hē|飲む
i|yi1|一|口を横に引いた「イー」|一 yī|一
u|wu1|五|唇を丸めて突き出した「ウー」|五 wǔ|五
ü|yu1|鱼|唇を丸めて「イ」と言う（「ユ」に近いが、口の形は変えない）|鱼 yú|魚
ai|ai1|爱|「アイ」|爱 ài|愛
ei|ei1|谁|「エイ」|谁 shéi|だれ
ao|ao1|好|「アオ」。口を大きく開けて始める|好 hǎo|良い
ou|ou1|欧|「オウ」|狗 gǒu|犬
an|an1|安|「アン」。舌先を上の歯ぐきに付けて終える|山 shān|山
en|en1|人|「エン」。舌先を上の歯ぐきに付けて終える|人 rén|人
ang|ang1|上|「アン」。舌を付けず、鼻に抜けて終える|上 shàng|上
eng|eng1|冷|「オン」。舌を付けず、鼻に抜けて終える|冷 lěng|寒い
ong|dong1|东|「オン」。唇を丸めて、鼻に抜けて終える|中 zhōng|真ん中
er|er2|二|舌先を丸める「アル」。舌を丸めて「アー」と言う|二 èr|二
ia|ya1|呀|「ヤー」（i + a）|家 jiā|家
ie|ye1|耶|「イエ」（i + e）。e は口をあまり開けない|谢 xiè|感謝する
ua|wa1|哇|「ワー」（u + a）|花 huā|花
uo|wo3|我|「ウォ」（u + o）|多 duō|多い
iu|you1|优|「ヨウ」。ピンインは iu だが、読みは「イオウ」|六 liù|六
"""
)

LETTER_GROUPS: tuple[tuple[str, str, tuple[Letter, ...]], ...] = (
    ("tone", "声調", TONES),
    ("initial", "声母（頭の音）", INITIALS),
    ("final", "韻母（あとの音）", FINALS),
)
ALL_LETTERS = tuple(letter for _, _, letters in LETTER_GROUPS for letter in letters)

# 接客フレーズ（日本語, 中国語）。お店の人が、お客様に言う言葉と、聞かれる言葉
PHRASES: tuple[tuple[str, str], ...] = (
    ("いらっしゃいませ", "欢迎光临"),
    ("ありがとうございます", "谢谢"),
    ("こちらへどうぞ", "请这边走"),
    ("少々お待ちください", "请稍等"),
    ("お待たせしました", "让您久等了"),
    ("何名様ですか？", "请问几位？"),
    ("ご注文はお決まりですか？", "请问您要点什么？"),
    ("ごゆっくりどうぞ", "请慢用"),
    ("お水はセルフサービスです", "水请自取"),
    ("ラストオーダーです", "现在是最后点单"),
    ("お会計は1,500円です", "一共1500日元"),
    ("カードが使えます", "可以刷卡"),
    ("現金のみです", "只收现金"),
    ("袋は必要ですか？", "需要袋子吗？"),
    ("お箸はお付けしますか？", "需要筷子吗？"),
    ("温めますか？", "需要加热吗？"),
    ("領収書をお渡しします", "这是您的收据"),
    ("写真撮影はご遠慮ください", "请勿拍照"),
    ("トイレはあちらです", "洗手间在那边"),
    ("パスポートを見せてください", "请出示护照"),
    ("免税の手続きができます", "可以办理免税手续"),
    ("試着室はこちらです", "试衣间在这边"),
    ("サイズはいかがですか？", "尺寸合适吗？"),
    ("在庫を確認します", "我确认一下库存"),
    ("チェックインは15時からです", "入住时间是下午三点以后"),
    ("朝食は7時からです", "早餐从七点开始"),
    ("駅はまっすぐ行って右です", "车站一直走，右边就是"),
    ("次の電車は10分後です", "下一班电车十分钟后到"),
    ("もう一度お願いします", "请您再说一遍"),
    ("大丈夫ですか？", "您没事吧？"),
    ("気をつけてお帰りください", "请路上小心"),
    ("またお越しください", "欢迎再来"),
)

_SENTENCE_JA = re.compile(r"(です|ます|ください|ませんか|ございます|お願いします|ますか)[。？]?$|[？?]$")
_HAN = re.compile(r"[一-鿿]")
_HAN_ONLY = re.compile(r"[一-鿿]{2,6}")
_ZH_COLUMN = 3  # industries の行（日本語, 韓国語, 英語, 中国語, …）の、中国語（簡体字）の列


def _all_rows() -> list[tuple[str, str]]:
    """業種の用語集の（日本語, 中国語）の組。業種の番号は問わない。"""
    from . import industries  # 循環を避けるため、使うときに読む

    pairs: list[tuple[str, str]] = []
    for rows in (*industries._COMMON_ROWS.values(), *industries._ROWS.values()):
        for row in rows:
            if len(row) > _ZH_COLUMN and row[_ZH_COLUMN]:
                pairs.append((row[0], row[_ZH_COLUMN]))
    return pairs


def industry_phrases(selected: tuple[str, ...]) -> list[tuple[str, str]]:
    """選んでいる業種の用語集にある、文の形のもの（「〜です」「〜ください」「〜ですか」）。何も選んでいなければ空。"""
    if not selected:
        return []
    from . import industries

    seen: set[str] = set()
    out: list[tuple[str, str]] = []
    categories = {industries.CATEGORY_OF[i] for i in selected if i in industries.CATEGORY_OF}
    rows = [row for c in categories for row in industries._COMMON_ROWS.get(c, ())]
    rows += [row for i in selected for row in industries._ROWS.get(i, ())]
    for row in rows:
        ja = row[0]
        zh = row[_ZH_COLUMN] if len(row) > _ZH_COLUMN else ""
        if zh and _SENTENCE_JA.search(ja) and _HAN.search(zh) and ja not in seen and len(zh) <= 30:
            seen.add(ja)
            out.append((ja, zh))
    return out


def phrase_deck(selected: tuple[str, ...] = ()) -> list[tuple[str, str]]:
    """接客フレーズの一覧（決まった文 + 選んでいる業種の文）。"""
    base = list(PHRASES)
    known = {ja for ja, _ in base}
    return base + [pair for pair in industry_phrases(selected) if pair[0] not in known]


def word_pool() -> list[tuple[str, str]]:
    """読む練習の単語（中国語, 日本語の意味）。漢字だけの短い語を使う。"""
    seen: set[str] = set()
    pool: list[tuple[str, str]] = []
    for ja, zh in _all_rows():
        if not _HAN_ONLY.fullmatch(zh) or len(ja) > 12 or _SENTENCE_JA.search(ja) or zh in seen:
            continue
        seen.add(zh)
        pool.append((zh, ja))
    for letter in ALL_LETTERS:
        word = letter.example
        if _HAN_ONLY.fullmatch(word) and word not in seen:
            seen.add(word)
            pool.append((word, letter.example_ja))
    return pool


def letter_question(rng: random.Random, groups: tuple[str, ...] = ("initial", "final")) -> Question:
    """文字の読み当て: 声母・韻母（の音節）を見て、カタカナの読みを選ぶ。"""
    pool = [letter for gid, _, letters in LETTER_GROUPS if gid in groups for letter in letters]
    letter = rng.choice(pool)
    choices, answer = _choices(letter.kana, [other.kana for other in pool], rng)
    detail = f"{letter.char}（{letter.roman}）: {letter.tip}"
    return Question(letter.hanzi, choices, answer, letter.hanzi, detail)


def word_question(rng: random.Random, pool: list[tuple[str, str]] | None = None) -> Question:
    """読む練習: 中国語の単語を見て、日本語の意味を選ぶ。"""
    pool = pool if pool is not None else word_pool()
    zh, ja = rng.choice(pool)
    choices, answer = _choices(ja, [other for _, other in pool], rng)
    reading = pinyin_of(zh) or kana_of(zh)
    detail = f"{zh}（{reading}）= {ja}" if reading else f"{zh} = {ja}"
    return Question(zh, choices, answer, zh, detail)


# --- 発音の判定 ---


def _syllables(text: str) -> list[str]:
    """文を、声調つきの音節（"ni3"）の並びにする（漢字以外は、小文字の英数字をそのまま 1 字ずつ）。pypinyin がなければ字ごと。"""
    try:
        from pypinyin import Style, lazy_pinyin
    except ImportError:
        return [ch for ch in text if _HAN.match(ch) or ch.isalnum()]
    tokens = lazy_pinyin(text, style=Style.TONE3, neutral_tone_with_five=True, v_to_u=False)
    out: list[str] = []
    for token in tokens:
        token = token.strip().lower()
        if re.fullmatch(r"[a-zü]+[1-5]", token):
            out.append(token)
        else:
            out.extend(ch for ch in token if ch.isalnum())
    return out


def pinyin_of(text: str) -> str:
    """文の声調記号つきピンイン（空白区切り。pypinyin がなければ空文字）。"""
    try:
        from pypinyin import Style, lazy_pinyin  # noqa: F401
    except ImportError:
        return ""
    return " ".join(marked_pinyin(s) if re.fullmatch(r"[a-zü]+[1-5]", s) else s for s in _syllables(text))


def _cost(x: str, y: str) -> float:
    if x == y:
        return 0.0
    if x[:-1] == y[:-1] and x[-1:].isdigit() and y[-1:].isdigit():
        return 0.4  # 音は合っていて、声調だけ違う
    return 1.0


def similarity(target: str, heard: str) -> float:
    """手本と、認識した文の近さ（0〜1）。音節ごとの編集距離で比べる（声調だけの違いは、軽く減点）。"""
    a, b = _syllables(target), _syllables(heard)
    if not a or not b:
        return 0.0
    previous = [float(j) for j in range(len(b) + 1)]
    for i, x in enumerate(a, 1):
        current = [float(i)]
        for j, y in enumerate(b, 1):
            current.append(min(previous[j] + 1, current[j - 1] + 1, previous[j - 1] + _cost(x, y)))
        previous = current
    return max(0.0, 1.0 - previous[-1] / max(len(a), len(b)))
