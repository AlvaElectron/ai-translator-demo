"""よく使う英単語の、日本でふつうに書くカタカナ（english_kana.lookup が発音記号より先に引く）。

CMU 発音辞書は、to・for・us・one などを文中の弱い発音（tə・fər・U.S.・wən）で持っているので、
規則でカタカナにすると「ティ」「ファー」「ユーエス」「ウン」のようになる。よく使う語と、お店でよく出る語は、ここで決めておく。
（2026-11-16 に作った表。alkana（GPLv2）のデータは使っていない）
"""

WORDS = {
    # 機能語
    "a": "ア", "an": "アン", "the": "ザ", "to": "トゥー", "for": "フォー", "of": "オブ", "from": "フロム", "with": "ウィズ",
    "at": "アット", "in": "イン", "on": "オン", "by": "バイ", "as": "アズ", "or": "オア", "and": "アンド", "but": "バット",
    "if": "イフ", "so": "ソー", "than": "ザン", "then": "ゼン", "that": "ザット", "this": "ジス", "these": "ジーズ",
    "those": "ゾーズ", "there": "ゼア", "here": "ヒア", "where": "ウェア", "what": "ワット", "when": "ウェン",
    "which": "ウィッチ", "who": "フー", "why": "ワイ", "how": "ハウ", "can": "キャン", "could": "クッド", "will": "ウィル",
    "would": "ウッド", "shall": "シャル", "should": "シュッド", "may": "メイ", "might": "マイト", "must": "マスト",
    "do": "ドゥー", "does": "ダズ", "did": "ディッド", "is": "イズ", "are": "アー", "was": "ワズ", "were": "ワー",
    "be": "ビー", "been": "ビーン", "have": "ハブ", "has": "ハズ", "had": "ハッド", "not": "ノット", "no": "ノー",
    "yes": "イエス", "i": "アイ", "you": "ユー", "he": "ヒー", "she": "シー", "it": "イット", "we": "ウィー",
    "they": "ゼイ", "me": "ミー", "him": "ヒム", "her": "ハー", "us": "アス", "them": "ゼム", "my": "マイ",
    "your": "ユア", "his": "ヒズ", "its": "イッツ", "our": "アワー", "their": "ゼア", "all": "オール", "any": "エニー",
    "some": "サム", "each": "イーチ", "every": "エブリ", "one": "ワン", "two": "トゥー", "three": "スリー", "four": "フォー",
    "five": "ファイブ", "six": "シックス", "seven": "セブン", "eight": "エイト", "nine": "ナイン", "ten": "テン",
    "eleven": "イレブン", "twelve": "トゥエルブ", "thirteen": "サーティーン", "fourteen": "フォーティーン",
    "fifteen": "フィフティーン", "sixteen": "シックスティーン", "seventeen": "セブンティーン", "eighteen": "エイティーン",
    "nineteen": "ナインティーン", "twenty": "トゥエンティー", "thirty": "サーティー", "forty": "フォーティー",
    "fifty": "フィフティー", "sixty": "シックスティー", "seventy": "セブンティー", "eighty": "エイティー",
    "ninety": "ナインティー", "hundred": "ハンドレッド", "thousand": "サウザンド", "million": "ミリオン",
    "first": "ファースト", "second": "セカンド", "third": "サード", "before": "ビフォア", "after": "アフター",
    "during": "デュアリング", "between": "ビトゥイーン", "about": "アバウト", "together": "トゥギャザー",
    "today": "トゥデイ", "tomorrow": "トゥモロー", "tonight": "トゥナイト", "now": "ナウ", "again": "アゲイン",
    "also": "オールソー", "only": "オンリー", "very": "ベリー", "please": "プリーズ", "thank": "サンク", "thanks": "サンクス",
    "sorry": "ソーリー", "excuse": "エクスキューズ", "hello": "ハロー", "goodbye": "グッバイ", "welcome": "ウェルカム",
    "ok": "オーケー", "okay": "オーケー", "out": "アウト", "up": "アップ", "down": "ダウン", "into": "イントゥー",
    "over": "オーバー", "under": "アンダー", "per": "パー", "more": "モア", "most": "モスト", "less": "レス",
    "much": "マッチ", "many": "メニー", "other": "アザー", "another": "アナザー", "same": "セイム", "just": "ジャスト",
    # 時間・数
    "minute": "ミニット", "minutes": "ミニッツ", "hour": "アワー", "hours": "アワーズ", "time": "タイム",
    "times": "タイムズ", "day": "デイ", "days": "デイズ", "week": "ウィーク", "limit": "リミット", "minimum": "ミニマム",
    "maximum": "マキシマム", "yen": "イェン", "dollar": "ダラー", "dollars": "ダラーズ", "price": "プライス",
    # お店
    "master": "マスター", "miss": "ミス", "maid": "メイド", "maids": "メイズ", "cafe": "カフェ", "café": "カフェ",
    "cast": "キャスト", "member": "メンバー", "staff": "スタッフ", "customer": "カスタマー", "customers": "カスタマーズ",
    "store": "ストア", "shop": "ショップ", "menu": "メニュー", "order": "オーダー", "drink": "ドリンク", "drinks": "ドリンクス",
    "food": "フード", "water": "ウォーター", "coffee": "コーヒー", "tea": "ティー", "beer": "ビア", "photo": "フォト",
    "photos": "フォトズ", "picture": "ピクチャー", "camera": "カメラ", "seat": "シート", "seats": "シーツ",
    "table": "テーブル", "counter": "カウンター", "toilet": "トイレット", "restroom": "レストルーム", "floor": "フロア",
    "card": "カード", "cards": "カード", "cash": "キャッシュ", "change": "チェンジ", "receipt": "レシート",
    "tax": "タックス", "free": "フリー", "charge": "チャージ", "service": "サービス", "information": "インフォメーション",
    "reservation": "リザベーション", "performance": "パフォーマンス", "performances": "パフォーマンシズ",
    "extension": "エクステンション", "exchange": "エクスチェンジ", "additional": "アディショナル",
    "separately": "セパレートリー", "understanding": "アンダースタンディング", "appreciate": "アプリシエイト",
    "visiting": "ビジティング", "hostess": "ホステス", "favorite": "フェイバリット", "birthday": "バースデー",
    "stage": "ステージ", "show": "ショー", "live": "ライブ", "event": "イベント", "ticket": "チケット",
    "size": "サイズ", "sale": "セール", "discount": "ディスカウント", "nice": "ナイス", "cute": "キュート",
    "omelet": "オムレツ", "omelette": "オムレツ", "pancake": "パンケーキ", "pancakes": "パンケーキ", "cake": "ケーキ",
    "station": "ステーション", "train": "トレイン", "taxi": "タクシー", "elevator": "エレベーター", "smoking": "スモーキング",
    "wifi": "ワイファイ", "password": "パスワード", "open": "オープン", "closing": "クロージング", "close": "クローズ",
    "wait": "ウェイト", "moment": "モーメント", "check": "チェック", "bill": "ビル", "home": "ホーム",
}
