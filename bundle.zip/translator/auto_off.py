"""自動で電源を切る。(1) 毎日、決めた時刻に（電源・再起動の画面で時刻を決める） (2) 15 分間、何も操作がなかったとき。pygame に依存しない。"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta

log = logging.getLogger(__name__)

STEP_MINUTES = 15  # 時刻は 15 分きざみ
DAY_MINUTES = 24 * 60
DEFAULT_MINUTES = 0  # 初期値は 0:00
# 時刻になったとき、聞き取り・翻訳の途中なら、終わるまで待つ。これだけ待っても終わらなければ、その日はやめる
GRACE = timedelta(minutes=10)
# 前に確かめてから、これより時計が進んでいた（または戻っていた）ときは、時刻をまたいだのではなく、時計が合わされたと見なす。
# 電池のない Pi は、起動の直後は前回の電源を切った時刻から始まり、ネットワークにつながったときに本当の時刻へ飛ぶ。
# これを「0:00 をまたいだ」と見ると、起動のたびに電源が切れてしまう（2026-10-11 に確認）
MAX_STEP = timedelta(minutes=2)


def format_minutes(minutes: int) -> str:
    """0 時からの分数を「0:00」「13:45」の形にする。"""
    minutes %= DAY_MINUTES
    return f"{minutes // 60}:{minutes % 60:02d}"


class AutoOff:
    """自動オフ。画面のループから due(今の時刻, 作業中か) を呼び、True が返ったら電源を切る。"""

    def __init__(self, minutes: int = DEFAULT_MINUTES, enabled: bool = True) -> None:
        self._minutes = self.normalize(minutes)
        self._enabled = enabled  # オフのあいだは、時刻になっても電源を切らない（時刻は、残しておく）
        self._last_seen: datetime | None = None  # 前に確かめたときの時刻（時刻をまたいだかどうかを見るため）
        self._pending_since: datetime | None = None  # 時刻になったが、作業中で待っている（待ち始めた時刻）

    @staticmethod
    def normalize(minutes: object) -> int:
        """保存された値を、0〜1439 の 15 分きざみにそろえる（読めなければ初期値）。"""
        if isinstance(minutes, bool) or not isinstance(minutes, int):
            return DEFAULT_MINUTES
        return (minutes % DAY_MINUTES) // STEP_MINUTES * STEP_MINUTES

    @property
    def minutes(self) -> int:
        return self._minutes

    @property
    def text(self) -> str:
        return format_minutes(self._minutes)

    @property
    def enabled(self) -> bool:
        return self._enabled

    def set_enabled(self, enabled: bool) -> None:
        self._enabled = bool(enabled)
        self._pending_since = None  # オフにしたとき、待っていた分も取り消す

    def step(self, direction: int) -> int:
        """時刻を 15 分進める（direction が正）・戻す（負）。0:00 の前は 23:45、23:45 の次は 0:00。新しい分数を返す。"""
        self._minutes = (self._minutes + (STEP_MINUTES if direction > 0 else -STEP_MINUTES)) % DAY_MINUTES
        self._pending_since = None
        return self._minutes

    def due(self, now: datetime, busy: bool = False) -> bool:
        """電源を切る時刻になったか。時刻をまたいだ瞬間（または、作業が終わるのを待ったあと）に、1 回だけ True。

        起動した直後に、すでに過ぎている時刻では切らない（時刻をまたいだのを、見たときだけ数える）。
        時計が大きく飛んだとき（起動後の時刻合わせなど）は、またいだことにしない。
        """
        previous, self._last_seen = self._last_seen, now
        if previous is not None and not (timedelta(0) <= now - previous <= MAX_STEP):
            log.info("時計が大きく変わりました（%s → %s）。時刻合わせと見なして、自動オフは数え直します", previous, now)
            self._pending_since = None
            return False
        if not self._enabled:
            self._pending_since = None
            return False
        target = now.replace(hour=self._minutes // 60, minute=self._minutes % 60, second=0, microsecond=0)
        if self._pending_since is None:
            if previous is None or not (previous < target <= now):
                return False
            self._pending_since = target
        if now - self._pending_since > GRACE:
            log.info("自動オフの時刻でしたが、作業中が続いたので、今日はやめました")
            self._pending_since = None
            return False
        if busy:
            return False
        self._pending_since = None
        log.info("自動オフの時刻（%s）になりました", self.text)
        return True


IDLE_OFF_SEC = 15 * 60  # 何も操作がないまま、これだけたつと電源を切る
IDLE_WARNING_SEC = 60  # 切る前の、この秒数だけ、画面に知らせを出す（触れば取り消せる）


class IdleOff:
    """無操作オフ。画面のループから due(今, 作業中か) を呼び、True が返ったら電源を切る。時刻は time.monotonic() の秒。"""

    def __init__(self, timeout_sec: float = IDLE_OFF_SEC, warning_sec: float = IDLE_WARNING_SEC) -> None:
        self.timeout_sec = timeout_sec
        self.warning_sec = min(warning_sec, timeout_sec)
        self._last_activity: float | None = None

    def touch(self, now: float) -> None:
        """操作があった（タップ・キー・マウス）、または作業中なので、数え直す。"""
        self._last_activity = now

    def remaining(self, now: float) -> float:
        """電源が切れるまでの秒数（数え始める前は、満タン）。"""
        if self._last_activity is None:
            self._last_activity = now
        return self.timeout_sec - (now - self._last_activity)

    def warning(self, now: float) -> int | None:
        """切る前の知らせを出す時間なら、残りの秒数（切り上げ）。そうでなければ None。"""
        left = self.remaining(now)
        if 0 < left <= self.warning_sec:
            return int(left) + (0 if left == int(left) else 1)
        return None

    def due(self, now: float, busy: bool = False) -> bool:
        """時間になったら True（作業中は、数え直して False）。"""
        if busy:
            self.touch(now)
            return False
        if self.remaining(now) > 0:
            return False
        log.info("%d 分間、操作がなかったので、電源を切ります", int(self.timeout_sec // 60))
        self.touch(now)  # 切る処理の途中で、何度も True にならないように
        return True
