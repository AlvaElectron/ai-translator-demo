"""英単語を、日本で外来語として書く形に近いカタカナにする（2026-11-16〜。alkana（GPLv2）の代わり）。

eng-to-ipa（MIT。CMU 発音辞書）で英単語を発音記号（IPA）にし、規則でカタカナにする。
カタカナの組み立ては、追加した言語のカタカナと同じ more_kana.tokens_to_kana を使う。
辞書に無い語は None を返す（呼ぶ側の phonetics.english_to_kana が、複合語に分けて引き直すか、英語のまま残す）。
"""

from __future__ import annotations

import functools
import logging
import re

from .more_kana import Tokens, tokens_to_kana

log = logging.getLogger(__name__)

# 発音記号 → 音の並び（長い方から当てはめる）
_IPA = {
    "oʊ": ["o:"], "eɪ": ["e", "i"], "aɪ": ["a", "i"], "aʊ": ["a", "u"], "ɔɪ": ["o", "i"],
    "ər": ["a:"], "ɝ": ["a:"], "ɚ": ["a:"], "ɑr": ["a:"], "ɔr": ["o:"], "ɛr": ["e", "a"], "ɪr": ["i", "a"], "ir": ["i", "a"], "ʊr": ["u", "a"], "ur": ["u", "a"],
    "ju": ["y", "u:"], "ʧ": ["ch"], "ʤ": ["j"], "tʃ": ["ch"], "dʒ": ["j"],
    "æ": ["a"], "ɑ": ["o"], "ɒ": ["o"], "ɔ": ["o"], "ə": ["a"], "ʌ": ["a"], "ɛ": ["e"], "ɪ": ["i"], "i": ["i:"],
    "u": ["u:"], "ʊ": ["u"], "e": ["e"], "o": ["o"], "a": ["a"],
    "p": ["p"], "b": ["b"], "t": ["t"], "d": ["d"], "k": ["k"], "g": ["g"], "ɡ": ["g"], "f": ["f"], "v": ["v"],
    "θ": ["s"], "ð": ["z"], "s": ["s"], "z": ["z"], "ʃ": ["sh"], "ʒ": ["zh"], "h": ["h"], "m": ["m"], "n": ["n"],
    "ŋ": ["N", "g"], "l": ["r"], "r": ["r"], "w": ["w"], "j": ["y"],
}
_LONGEST = max(len(key) for key in _IPA)
_STRESS = str.maketrans("", "", "ˈˌ.")
# 短い母音（このあとの語末の子音は「ッ」を入れて読む: cash → キャッシュ、check → チェック）
_SHORT = {"æ", "ɛ", "ɪ", "ʌ", "ɑ", "ɒ", "ɔ", "ʊ", "ə"}
_GEMINATE = {"p", "t", "k", "ʧ", "ʃ", "g", "ɡ", "d", "f", "ʤ"}
_VOWEL_SYMBOLS = set("æɑɒɔəʌɛɪiuʊeoa")


def ipa_to_kana(ipa: str) -> str:
    """1 語の発音記号を、カタカナにする。"""
    ipa = ipa.translate(_STRESS)
    # -tion・-sion（ʃən・ʒən）は「ション」「ジョン」と書く
    ipa = re.sub(r"([ʃʒ])ən\b", r"\1on", ipa)
    # 語末の -əl（table・available）は「ブル」のように「ル」だけ
    ipa = re.sub(r"əl\b", "l", ipa)
    # 語末の -ən は「ン」だけ（open → オープン）、-ət は「エット」（toilet → トイレット、omelet → オムレット）
    # （どちらも 2 音節以上の語だけ。one・what のような 1 音節の語は、そのまま読む）
    if sum(ch in _VOWEL_SYMBOLS for ch in ipa) >= 3:
        ipa = re.sub(r"(?<=[^ʃʒw])ən\b", "n", ipa)
        ipa = re.sub(r"ət\b", "ɛt", ipa)
    tokens: Tokens = []
    previous_key = ""
    i = 0
    while i < len(ipa):
        for length in range(min(_LONGEST, len(ipa) - i), 0, -1):
            key = ipa[i : i + length]
            if key in _IPA:
                last = i + length == len(ipa)
                before = ipa[i - 1] if i else ""
                # 短い母音のあとの語末の子音は「ッ」（二重母音のあとは入れない: cake → ケイク）
                # -ing の前も同じ（shopping → ショッピング、fitting → フィッティング）
                ing = ipa[i + length :] == "ɪŋ"
                if key in _GEMINATE and (last or ing) and previous_key in _SHORT:
                    tokens.append("Q")  # cash → キャッシュ
                value = list(_IPA[key])
                following = ipa[i + length] if i + length < len(ipa) else ""
                # 母音 + r のあとに母音が続くときは、r を次の母音と読む（very → ヴェリー、favorite → フェイヴァリト）
                if len(key) == 2 and key.endswith("r") and key != "ər" and following in _VOWEL_SYMBOLS:
                    value = [*_IPA[key[0]], "r"]
                elif key == "ər" and following in _VOWEL_SYMBOLS:
                    value = ["a", "r"]
                # 母音の前の i は伸ばさない（medium → ミーディアム）
                if key == "i" and following in _VOWEL_SYMBOLS:
                    value = ["i"]
                # 語末や子音の前の ɔl は「オール」（small → スモール、call → コール）
                if key == "ɔ" and following == "l" and (i + 2 >= len(ipa) or ipa[i + 2] not in _VOWEL_SYMBOLS):
                    value = ["o:"]
                # k・g + æ は「キャ」「ギャ」（cash・cast）
                if key == "æ" and before in ("k", "g", "ɡ"):
                    value = ["y", "a"]
                # 語末の ŋ 以外（thank → サンク）は「ン」だけ
                if key == "ŋ" and not last and ipa[i + 1] in "kgɡ":
                    value = ["N"]
                # 語末の r（母音のあと）は伸ばす音
                if key == "r" and last and before in _VOWEL_SYMBOLS:
                    value = [":"]
                tokens.extend(value)
                previous_key = key
                i += length
                break
        else:
            i += 1  # 知らない記号は読まない
    return tokens_to_kana(tokens)


@functools.lru_cache(maxsize=4096)
def lookup(word: str) -> str | None:
    """英単語のカタカナ。よく使う語は決めた表（english_kana_words）、それ以外は CMU 発音辞書から（無ければ None）。"""
    from .english_kana_words import WORDS

    if word in WORDS:
        return WORDS[word]
    try:
        import eng_to_ipa
    except ImportError:
        return None
    ipa = eng_to_ipa.convert(word)
    if not ipa or "*" in ipa or " " in ipa.strip():
        return None
    return ipa_to_kana(ipa) or None


def available() -> bool:
    try:
        import eng_to_ipa  # noqa: F401
    except ImportError:
        return False
    return True
