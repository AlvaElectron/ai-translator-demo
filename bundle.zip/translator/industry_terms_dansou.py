"""娯楽・夜の店（男装・執事カフェ）の用語集のデータ（2026-11-23）。書き方は industry_terms_food.py の先頭を参照。

女性のスタッフが男装して（または執事として）もてなすコンセプトカフェ。お客様は お嬢様・姫・ハニー などと呼ばれる。
キャスト・推し・チェキ・指名・執事カフェ などは glossary.py のメイドカフェ・コンカフェの語（この業種でも使う）にあるので、ここには入れない。
参考: 秋葉原・池袋などの男装カフェの公式サイトの料金・注意書き（ファーストチャージ・オートチャージ・差し入れの決まりなど）。
"""

from __future__ import annotations

DANSOU = (
    ("男装カフェ", "남장 카페", "dansou café (women dressed as men)", "男装咖啡厅", "男裝咖啡店", "คาเฟ่สาวแต่งชาย", "café dansō (femmes habillées en hommes)", "кафе дансо (девушки в мужском образе)", "café dansō (mulheres vestidas de homem)", True),
    ("男装", "남장", "dressing as a man", "男装", "男裝", "การแต่งกายเป็นผู้ชาย", "travestissement en homme", "мужской образ", "vestir-se de homem", True),
    ("男装キャスト", "남장 캐스트", "staff member dressed as a man", "男装店员", "男裝店員", "พนักงานแต่งชาย", "membre du personnel en tenue masculine", "сотрудник в мужском образе", "atendente em traje masculino", True),
    ("執事", "집사", "butler", "执事", "管家", "บัตเลอร์", "majordome", "дворецкий", "mordomo", True),
    ("王子様", "왕자님", "prince", "王子殿下", "王子", "เจ้าชาย", "prince", "принц", "príncipe", True),
    ("姫", "공주님", "princess", "公主", "公主", "เจ้าหญิง", "princesse", "принцесса", "princesa", True),
    ("旦那様", "서방님", "sir", "老爷", "老爺", "นายท่าน", "monsieur", "господин", "senhor", True),
    ("ハニー", "허니", "honey", "亲爱的", "親愛嘅", "ที่รัก", "chérie", "дорогая", "querida", True),
    ("彼氏", "남자친구", "boyfriend", "男朋友", "男朋友", "แฟนหนุ่ม", "petit ami", "парень", "namorado", True),
    ("来城", "입성", "arrival at the castle", "来城", "嚟城堡", "การมาเยือนปราสาท", "arrivée au château", "прибытие в замок", "chegada ao castelo", True),
    ("城内", "성 안", "inside the castle", "城内", "城堡入面", "ภายในปราสาท", "dans le château", "в замке", "dentro do castelo", True),
    ("ご入国", "입국", "entering the kingdom", "入国", "入境", "การเข้าสู่อาณาจักร", "entrée dans le royaume", "въезд в королевство", "entrada no reino", True),
    ("世界観", "세계관", "the concept world", "世界观", "世界觀", "โลกตามคอนเซ็ปต์", "univers du concept", "мир концепции", "universo temático", True),
    ("キャラ設定", "캐릭터 설정", "character setting", "人设", "人設", "การตั้งค่าตัวละคร", "personnage", "образ персонажа", "personagem", True),
    ("ファーストチャージ", "첫 입장료", "first cover charge", "首次入场费", "首次入場費", "ค่าเข้าครั้งแรก", "premier droit d'entrée", "первый входной сбор", "primeira taxa de entrada", True),
    ("オートチャージ", "자동 연장 요금", "automatic extension charge", "自动续费", "自動續費", "ค่าต่อเวลาอัตโนมัติ", "prolongation facturée automatiquement", "автоматическая оплата продления", "cobrança automática de prorrogação", True),
    ("ワンオーダー制", "1인 1주문제", "one-order minimum", "每人至少点一份", "每人最少點一樣", "สั่งขั้นต่ำคนละ 1 รายการ", "une commande minimum", "минимум один заказ", "pedido mínimo de um item", True),
    ("カウンター席", "카운터석", "counter seat", "吧台座位", "吧枱位", "ที่นั่งเคาน์เตอร์", "place au comptoir", "место у стойки", "assento no balcão", True),
    ("ソファー席", "소파석", "sofa seat", "沙发座", "梳化位", "ที่นั่งโซฟา", "place sur canapé", "место на диване", "assento no sofá", True),
    ("相席", "합석", "sharing a table", "拼桌", "搭枱", "การนั่งร่วมโต๊ะ", "partage de table", "общий стол", "compartilhar a mesa", True),
    ("差し入れ", "선물 반입", "gifts brought for the staff", "给店员的慰问品", "畀店員嘅手信", "ของฝากให้พนักงาน", "cadeaux apportés au personnel", "угощения и подарки для сотрудников", "presentes trazidos para os atendentes", True),
    ("手作りのもの", "손으로 만든 것", "homemade items", "手工制作的东西", "手作嘅嘢", "ของทำมือ", "objets faits maison", "самодельные вещи", "itens caseiros", True),
    ("生もの", "날음식", "perishable food", "生鲜食品", "生鮮食物", "ของสด", "denrées périssables", "скоропортящиеся продукты", "alimentos perecíveis", True),
    ("開封済みのもの", "개봉한 것", "opened items", "已开封的东西", "已開封嘅嘢", "ของที่เปิดแล้ว", "articles déjà ouverts", "вскрытые упаковки", "itens já abertos", True),
    ("身分証", "신분증", "ID", "身份证件", "身份證明文件", "บัตรประจำตัว", "pièce d'identité", "удостоверение личности", "documento de identidade", True),
    ("年齢確認", "연령 확인", "age check", "年龄确认", "年齡確認", "การตรวจสอบอายุ", "vérification de l'âge", "проверка возраста", "verificação de idade", True),
    ("連絡先の交換", "연락처 교환", "exchanging contact details", "交换联系方式", "交換聯絡方法", "การแลกช่องทางติดต่อ", "échange de coordonnées", "обмен контактами", "troca de contatos", True),
    ("出待ち", "퇴근길 기다리기", "waiting outside for the staff", "在门口等店员下班", "喺門口等店員收工", "การดักรอพนักงานหน้าร้าน", "attendre le personnel à la sortie", "поджидать сотрудников у выхода", "esperar os atendentes na saída", True),
    ("つきまとい", "스토킹", "stalking", "跟踪纠缠", "跟蹤騷擾", "การตามตื๊อ", "harcèlement", "преследование", "perseguição", True),
    ("推し活", "덕질", "supporting your favorite", "追星活动", "追星", "การเชียร์คนที่ชอบ", "soutien à son favori", "поддержка любимчика", "apoio ao seu favorito", True),
    ("お絵描きチェキ", "그림 체키", "hand-decorated cheki photo", "手绘拍立得", "手繪即影即有", "เชกิวาดรูป", "photo cheki décorée à la main", "чеки с рисунком", "cheki decorada à mão", True),
    ("ボイス", "음성 메시지", "voice message", "语音留言", "錄音留言", "ข้อความเสียง", "message vocal", "голосовое сообщение", "mensagem de voz", True),
    ("清掃料", "청소비", "cleaning fee", "清洁费", "清潔費", "ค่าทำความสะอาด", "frais de nettoyage", "плата за уборку", "taxa de limpeza", True),
    ("女性限定", "여성 전용", "women only", "仅限女性", "只限女士", "เฉพาะผู้หญิง", "réservé aux femmes", "только для женщин", "só para mulheres", True),
    ("男性のお客様", "남성 손님", "male customers", "男性顾客", "男客", "ลูกค้าผู้ชาย", "clients masculins", "гости-мужчины", "clientes homens", True),
)
