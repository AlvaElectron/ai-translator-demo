"""「ガイド」の動画を、通訳機だけで入れる・名前を変える・消す（USB メモリから / スマホから。pygame に依存しない）。

- 入れる場所は 4 つ（DESTINATIONS）: お客様用、店舗用の 操作説明・従業員用・管理者用。
- 入れるときは、隠しファイル（.importing-…）に書き、mpv で再生できるか確かめてから、
  「番号_題名.拡張子」（番号はその場所の最後の番号 + 1）に名前を変える。途中で失敗しても、一覧には出ない。
- USB メモリは udisks2（udisksctl）で読み取り専用でつなぐ。通訳アプリはサービスとして動くので、
  最初に 1 回だけ scripts/allow_usb.sh で許可を置く（Wi-Fi の allow_wifi.sh と同じやり方）。
- 通訳機のシステムの入った USB の SSD（/ や /boot/firmware がある所）は、一覧に出さない。
"""

from __future__ import annotations

import json
import logging
import os
import re
import secrets
import shutil
import subprocess
import threading
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from pathlib import Path

from .guide import CUSTOMER, STORE, VIDEO_EXTS, display_title, natural_key

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class Destination:
    key: str  # "customer"、"store/howto" など（スマホのページから送る値）
    audience: str
    folder: str  # お客様用は直下（""）
    label: str
    label_en: str


DESTINATIONS = (
    Destination("customer", CUSTOMER, "", "お客様用", "For customers"),
    Destination("store/howto", STORE, "howto", "店舗用 › 操作説明", "Store › How to use"),
    Destination("store/staff", STORE, "staff", "店舗用 › 従業員用", "Store › Staff"),
    Destination("store/admin", STORE, "admin", "店舗用 › 管理者用", "Store › Administrator"),
)
DESTINATION_BY_KEY = {destination.key: destination for destination in DESTINATIONS}

# 題名の長さの上限（文字）と、ファイル名に使えない文字
MAX_TITLE = 40
_BAD_CHARS = re.compile(r'[\\/:*?"<>|\x00-\x1f\x7f]')
_PREFIX = re.compile(r"^(\d+)[_\-. ]")
# 入れたあとも残しておく空き（バイト）。録画・ログ・更新のための余裕
RESERVE_BYTES = 2 * 1024**3
# 1 つの動画の大きさの上限（バイト）
MAX_VIDEO_BYTES = 8 * 1024**3
CHUNK = 4 * 1024 * 1024
TEMP_PREFIX = ".importing-"

# 画面と、スマホのページに出す知らせ
MSG_NO_SPACE = "空きが足りません / Not enough free space"
MSG_TOO_BIG = "動画が大きすぎます（8GB まで）/ The video is too large (max 8 GB)"
MSG_BAD_TYPE = "動画のファイルではありません（mp4・mov・mkv・webm・avi）/ Not a video file"
MSG_UNPLAYABLE = "再生できない動画です / This video cannot be played"
MSG_FAILED = "入れられませんでした / Could not add the video"
MSG_EXISTS = "同じ名前の動画があります / A video with that name already exists"
MSG_NO_TITLE = "題名を入れてください / Enter a title"


class GuideAdminError(Exception):
    """入れられなかった（画面に出す知らせを持つ）。"""


def destination_dir(root: Path, destination: Destination) -> Path:
    folder = Path(root) / destination.audience
    return folder / destination.folder if destination.folder else folder


def clean_title(text: str) -> str:
    """題名を、ファイル名に使える形にする（使えない文字は空白に。前後の空白・先頭の点を取り、長すぎれば切る）。"""
    text = _BAD_CHARS.sub(" ", str(text))
    text = re.sub(r"\s+", " ", text).strip().lstrip(".").strip()
    return text[:MAX_TITLE].strip()


def title_from_filename(name: str) -> str:
    """元のファイル名から、題名の案を作る（拡張子と、先頭の番号を取る）。"""
    return clean_title(display_title(name)) or clean_title(Path(name).stem) or "動画"


def _file_part(title: str) -> str:
    # 画面では「_」が空白に戻る（guide.display_title）
    return clean_title(title).replace(" ", "_")


def _next_number(folder: Path) -> int:
    numbers = [0]
    try:
        for entry in folder.iterdir():
            match = _PREFIX.match(entry.name)
            if match and not entry.name.startswith("."):
                numbers.append(int(match.group(1)))
    except OSError:
        pass
    return max(numbers) + 1


def new_video_path(folder: Path, title: str, ext: str) -> Path:
    """入れる動画の名前（その場所の最後の番号 + 1。同じ名前があれば番号を進める）。"""
    number = _next_number(folder)
    while True:
        path = folder / f"{number:02d}_{_file_part(title)}{ext.lower()}"
        if not path.exists():
            return path
        number += 1


def video_ext(name: str) -> str:
    """動画の拡張子（小文字）。動画でなければ GuideAdminError。"""
    ext = Path(str(name)).suffix.lower()
    if ext not in VIDEO_EXTS:
        raise GuideAdminError(MSG_BAD_TYPE)
    return ext


def check_video(path: Path, mpv: str = "mpv", timeout: float = 30.0) -> bool:
    """mpv で 1 コマだけ読んで、再生できるか確かめる（mpv が無いときは確かめずに True）。"""
    if shutil.which(mpv) is None:
        log.warning("mpv が見つからないので、動画の確認を飛ばします")
        return True
    command = [mpv, "--no-config", "--really-quiet", "--no-terminal", "--vo=null", "--ao=null", "--frames=1", str(path)]
    try:
        result = subprocess.run(command, capture_output=True, timeout=timeout, check=False)
    except (OSError, subprocess.TimeoutExpired):
        log.warning("動画を確かめられませんでした: %s", path, exc_info=True)
        return False
    return result.returncode == 0


class Progress:
    """入れている途中の様子（画面とスマホのページに出す）。別のスレッドから書き、画面が読む。"""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._version = 0
        self._busy = False
        self._fraction: float | None = None
        self._message = ""
        self._error = False

    def start(self, message: str) -> bool:
        """始める（ほかの動画を入れている最中なら False）。"""
        with self._lock:
            if self._busy:
                return False
            self._busy, self._fraction, self._message, self._error = True, 0.0, message, False
            self._version += 1
            return True

    def step(self, fraction: float) -> None:
        with self._lock:
            fraction = max(0.0, min(1.0, fraction))
            # 1% 以上変わったときだけ、画面を描き直させる
            if self._fraction is None or abs(fraction - self._fraction) >= 0.01 or fraction >= 1.0:
                self._fraction = fraction
                self._version += 1

    def finish(self, message: str, error: bool = False) -> None:
        with self._lock:
            self._busy, self._fraction, self._message, self._error = False, None, message, error
            self._version += 1

    def clear(self) -> None:
        with self._lock:
            if not self._busy:
                self._fraction, self._message, self._error = None, "", False
                self._version += 1

    def snapshot(self) -> tuple[int, bool, float | None, str, bool]:
        """（版, 入れている最中か, 進み具合 0〜1 か None, 知らせ, 失敗の知らせか）。"""
        with self._lock:
            return self._version, self._busy, self._fraction, self._message, self._error


def check_room(root: Path, destination: Destination, size: int, title: str, reserve: int | None = None) -> str:
    """入れる前の確かめ（題名・大きさ・空き）。整えた題名を返す。だめなら GuideAdminError。中身を読む前に呼べる。"""
    title = clean_title(title)
    if not title:
        raise GuideAdminError(MSG_NO_TITLE)
    if size > MAX_VIDEO_BYTES:
        raise GuideAdminError(MSG_TOO_BIG)
    folder = destination_dir(root, destination)
    folder.mkdir(parents=True, exist_ok=True)
    reserve = RESERVE_BYTES if reserve is None else reserve  # 呼ぶときの値を使う（試験で変えられるように）
    if size + reserve > shutil.disk_usage(folder).free:
        raise GuideAdminError(MSG_NO_SPACE)
    return title


def store_stream(
    chunks: Iterable[bytes],
    size: int,
    root: Path,
    destination: Destination,
    title: str,
    ext: str,
    progress: Progress | None = None,
    checker: Callable[[Path], bool] = check_video,
    reserve: int | None = None,
) -> Path:
    """chunks（動画の中身）を、destination に「番号_題名.拡張子」で入れる。失敗したら GuideAdminError（書きかけは消す）。"""
    title = check_room(root, destination, size, title, reserve)
    folder = destination_dir(root, destination)
    temp = folder / f"{TEMP_PREFIX}{secrets.token_hex(4)}{ext}"
    try:
        written = 0
        with open(temp, "wb") as out:
            for chunk in chunks:
                if not chunk:
                    continue
                written += len(chunk)
                if written > MAX_VIDEO_BYTES:
                    raise GuideAdminError(MSG_TOO_BIG)
                out.write(chunk)
                if progress is not None and size > 0:
                    progress.step(written / size)
            out.flush()
            os.fsync(out.fileno())
        if size and written != size:
            raise GuideAdminError(MSG_FAILED)
        if not checker(temp):
            raise GuideAdminError(MSG_UNPLAYABLE)
        final = new_video_path(folder, title, ext)
        os.replace(temp, final)
        log.info("動画を入れました: %s", final)
        return final
    except GuideAdminError:
        raise
    except OSError as error:
        log.exception("動画を入れられませんでした")
        raise GuideAdminError(MSG_NO_SPACE if error.errno == 28 else MSG_FAILED) from error
    finally:
        if temp.exists():
            temp.unlink(missing_ok=True)


def read_chunks(path: Path) -> Iterable[bytes]:
    with open(path, "rb") as source:
        while chunk := source.read(CHUNK):
            yield chunk


def import_file(
    source: Path,
    root: Path,
    destination: Destination,
    title: str,
    progress: Progress,
    checker: Callable[[Path], bool] = check_video,
) -> Path | None:
    """USB メモリなどの動画を入れる（progress に結果を書く。入れた動画の場所か None）。progress.start() は呼んだあとで使う。"""
    try:
        ext = video_ext(source.name)
        final = store_stream(read_chunks(source), source.stat().st_size, root, destination, title, ext, progress, checker)
    except GuideAdminError as error:
        progress.finish(str(error), error=True)
        return None
    except OSError:
        log.exception("USB メモリの動画を読めませんでした: %s", source)
        progress.finish(MSG_FAILED, error=True)
        return None
    progress.finish(f"入れました / Added: {display_title(final.name)}（{destination.label}）")
    return final


# --- 入れた動画の一覧・名前の変更・削除 ---


@dataclass(frozen=True)
class ManagedVideo:
    path: Path
    destination: Destination
    title: str


def list_videos(root: Path) -> list[ManagedVideo]:
    """4 つの場所の動画（場所の順、その中は名前の順）。"""
    videos = []
    for destination in DESTINATIONS:
        folder = destination_dir(root, destination)
        try:
            entries = sorted(folder.iterdir(), key=lambda p: natural_key(p.name))
        except OSError:
            continue
        for path in entries:
            if path.is_file() and not path.name.startswith(".") and path.suffix.lower() in VIDEO_EXTS:
                videos.append(ManagedVideo(path, destination, display_title(path.name)))
    return videos


def _inside(root: Path, path: Path) -> bool:
    try:
        Path(path).resolve().relative_to(Path(root).resolve())
    except ValueError:
        return False
    return True


def rename_video(root: Path, path: Path, title: str) -> Path:
    """動画の題名を変える（先頭の番号はそのまま）。新しい場所を返す。できなければ GuideAdminError。"""
    path = Path(path)
    title = clean_title(title)
    if not title:
        raise GuideAdminError(MSG_NO_TITLE)
    if not _inside(root, path) or not path.is_file():
        raise GuideAdminError(MSG_FAILED)
    match = _PREFIX.match(path.name)
    prefix = f"{match.group(1)}_" if match else ""
    target = path.with_name(f"{prefix}{_file_part(title)}{path.suffix.lower()}")
    if target == path:
        return path
    if target.exists():
        raise GuideAdminError(MSG_EXISTS)
    path.rename(target)
    log.info("動画の名前を変えました: %s → %s", path.name, target.name)
    return target


def delete_video(root: Path, path: Path) -> None:
    """動画を消す（guides の中のものだけ）。"""
    path = Path(path)
    if not _inside(root, path) or not path.is_file():
        raise GuideAdminError(MSG_FAILED)
    path.unlink()
    log.info("動画を消しました: %s", path)


def remove_leftovers(root: Path) -> None:
    """前に途中で止まった書きかけ（.importing-…）を消す（起動のとき）。"""
    for destination in DESTINATIONS:
        folder = destination_dir(root, destination)
        try:
            for path in folder.glob(f"{TEMP_PREFIX}*"):
                path.unlink(missing_ok=True)
        except OSError:
            pass


# --- USB メモリ ---

USB_FILESYSTEMS = frozenset({"vfat", "exfat", "ntfs", "ntfs3", "ext4", "ext3", "ext2", "hfsplus"})
SYSTEM_MOUNTS = frozenset({"/", "/boot", "/boot/firmware", "[SWAP]"})
SKIP_DIRS = frozenset({"System Volume Information", "$RECYCLE.BIN", "lost+found"})
MAX_USB_VIDEOS = 300
MAX_DEPTH = 4

MSG_USB_NONE = "USB メモリを差してください / Insert a USB stick"
MSG_USB_SEARCHING = "USB メモリを探しています… / Looking for a USB stick…"
MSG_USB_NO_VIDEOS = "USB メモリに動画が見つかりません / No videos on the USB stick"
MSG_USB_NOT_ALLOWED = (
    "USB メモリを読む許可がありません。管理者が、最初に 1 回だけ scripts/allow_usb.sh を実行してください"
    " / Not allowed to read USB sticks: run scripts/allow_usb.sh once"
)
MSG_USB_MOUNT_FAILED = "USB メモリを読めませんでした / Could not read the USB stick"


@dataclass(frozen=True)
class UsbVolume:
    device: str  # /dev/sdb1
    label: str
    fstype: str
    mountpoint: str  # つながっていなければ ""


@dataclass(frozen=True)
class UsbVideo:
    path: Path
    volume: str  # USB メモリの名前
    size: int
    relative: str  # USB メモリの中の場所（フォルダ/ファイル名）


Runner = Callable[..., subprocess.CompletedProcess]


def _mounts(node: dict) -> list[str]:
    return [m for m in (node.get("mountpoints") or [node.get("mountpoint")]) if m]


def _walk(node: dict) -> Iterable[dict]:
    yield node
    for child in node.get("children") or []:
        yield from _walk(child)


def parse_lsblk(text: str) -> list[UsbVolume]:
    """lsblk -J の結果から、USB でつながった、読める形式の領域（システムの入ったディスクは除く）。"""
    try:
        devices = json.loads(text).get("blockdevices", [])
    except (ValueError, AttributeError):
        return []
    volumes = []
    for disk in devices:
        if disk.get("type") != "disk" or (disk.get("tran") or "") != "usb":
            continue
        nodes = list(_walk(disk))
        if any(mount in SYSTEM_MOUNTS for node in nodes for mount in _mounts(node)):
            continue  # 通訳機のシステムの入った SSD
        for node in nodes:
            fstype = (node.get("fstype") or "").lower()
            if fstype not in USB_FILESYSTEMS:
                continue
            mounts = _mounts(node)
            path = node.get("path") or f"/dev/{node.get('name', '')}"
            volumes.append(UsbVolume(path, node.get("label") or node.get("name") or path, fstype, mounts[0] if mounts else ""))
    return volumes


def list_usb_volumes(runner: Runner = subprocess.run) -> list[UsbVolume]:
    command = ["lsblk", "-J", "-o", "NAME,PATH,TYPE,TRAN,FSTYPE,LABEL,MOUNTPOINTS"]
    try:
        result = runner(command, capture_output=True, text=True, timeout=10, check=False)
    except (OSError, subprocess.TimeoutExpired):
        log.warning("lsblk を実行できません", exc_info=True)
        return []
    return parse_lsblk(result.stdout or "")


def mount_volume(volume: UsbVolume, runner: Runner = subprocess.run) -> str:
    """読み取り専用でつなぐ（udisksctl）。うまくいかなければ GuideAdminError（知らせつき）。"""
    command = ["udisksctl", "mount", "--no-user-interaction", "-b", volume.device, "-o", "ro"]
    try:
        result = runner(command, capture_output=True, text=True, timeout=30, check=False)
    except (OSError, subprocess.TimeoutExpired) as error:
        raise GuideAdminError(MSG_USB_MOUNT_FAILED) from error
    if result.returncode != 0:
        detail = f"{result.stdout or ''} {result.stderr or ''}"
        log.warning("USB メモリをつなげません: %s %s", volume.device, detail.strip())
        if "NotAuthorized" in detail or "not authorized" in detail.lower():
            raise GuideAdminError(MSG_USB_NOT_ALLOWED)
        if "AlreadyMounted" in detail:
            return ""
        raise GuideAdminError(MSG_USB_MOUNT_FAILED)
    return ""


def unmount_volume(device: str, runner: Runner = subprocess.run) -> None:
    try:
        runner(["udisksctl", "unmount", "--no-user-interaction", "-b", device], capture_output=True, text=True, timeout=30, check=False)
    except (OSError, subprocess.TimeoutExpired):
        log.warning("USB メモリを外す準備ができませんでした: %s", device, exc_info=True)


def scan_videos(mountpoint: Path, volume: str, limit: int = MAX_USB_VIDEOS) -> list[UsbVideo]:
    """USB メモリの中の動画（フォルダの中も MAX_DEPTH 段まで。隠しフォルダ・システムのフォルダは見ない）。"""
    found: list[UsbVideo] = []
    base = Path(mountpoint)

    def visit(folder: Path, depth: int) -> None:
        try:
            entries = sorted(folder.iterdir(), key=lambda p: natural_key(p.name))
        except OSError:
            return
        for entry in entries:
            if len(found) >= limit or entry.name.startswith(".") or entry.name in SKIP_DIRS:
                continue
            try:
                if entry.is_dir():
                    if depth < MAX_DEPTH:
                        visit(entry, depth + 1)
                elif entry.is_file() and entry.suffix.lower() in VIDEO_EXTS:
                    relative = entry.relative_to(base).as_posix()
                    found.append(UsbVideo(entry, volume, entry.stat().st_size, relative))
            except OSError:
                continue

    visit(base, 0)
    return found


class UsbBrowser:
    """USB メモリの動画を探す（別のスレッドで。画面は version が変わったら描き直す）。"""

    def __init__(self, runner: Runner = subprocess.run) -> None:
        self._runner = runner
        self._lock = threading.Lock()
        self._version = 0
        self._videos: list[UsbVideo] = []
        self._message = ""
        self._busy = False
        self._mounted: set[str] = set()  # この画面でつないだ領域（離れるときに外す）

    def snapshot(self) -> tuple[int, bool, list[UsbVideo], str]:
        with self._lock:
            return self._version, self._busy, list(self._videos), self._message

    def _set(self, busy: bool, videos: list[UsbVideo], message: str) -> None:
        with self._lock:
            self._busy, self._videos, self._message = busy, videos, message
            self._version += 1

    def refresh(self, wait: bool = False) -> None:
        """探し直す（wait=False なら別のスレッドで）。"""
        with self._lock:
            if self._busy:
                return
            self._busy = True
            self._message = MSG_USB_SEARCHING
            self._version += 1
        if wait:
            self._scan()
        else:
            threading.Thread(target=self._scan, name="usb-scan", daemon=True).start()

    def _scan(self) -> None:
        message = ""
        try:
            volumes = list_usb_volumes(self._runner)
            if not volumes:
                self._set(False, [], MSG_USB_NONE)
                return
            for volume in volumes:
                if not volume.mountpoint:
                    try:
                        mount_volume(volume, self._runner)
                        self._mounted.add(volume.device)
                    except GuideAdminError as error:
                        message = str(error)
            volumes = list_usb_volumes(self._runner)  # つないだ場所を読み直す
            videos: list[UsbVideo] = []
            for volume in volumes:
                if volume.mountpoint:
                    videos += scan_videos(Path(volume.mountpoint), volume.label, MAX_USB_VIDEOS - len(videos))
            if not videos and not message:
                message = MSG_USB_NO_VIDEOS
            self._set(False, videos, message)
        except Exception:  # noqa: BLE001  探している途中の思わぬ失敗でも、画面は止めない
            log.exception("USB メモリを探せませんでした")
            self._set(False, [], MSG_USB_MOUNT_FAILED)

    def release(self) -> None:
        """この画面でつないだ USB メモリを外す（抜いても大丈夫にする）。"""
        with self._lock:
            mounted, self._mounted = set(self._mounted), set()
            self._videos = []
            self._version += 1
        for device in mounted:
            unmount_volume(device, self._runner)
