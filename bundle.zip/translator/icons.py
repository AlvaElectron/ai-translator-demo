"""画面に出す小さな印（マーク）: Wi-Fi・Bluetooth・音（スピーカー）・定型文（ふきだし）。

フォントに頼らず pygame の図形で描く（実機のフォントに記号が無くても同じに見えるように）。
4 倍の大きさで描いてから縮めるので、斜めの線もなめらかになる。
"""

from __future__ import annotations

import math
from functools import lru_cache

import pygame

WIFI, BLUETOOTH, SPEAKER, BUBBLE, POWER, RESTART = "wifi", "bluetooth", "speaker", "bubble", "power", "restart"
# 「使い方」（動画・スライド）の画面で使う印: 画面と再生、お客様、お店、フォルダ、再生、スライド
GUIDE, PERSON, SHOP, FOLDER, PLAY, SLIDES = "guide", "person", "shop", "folder", "play", "slides"
# 番号が要る（鍵）
LOCK = "lock"
# 業種の選択（チェックの付いた一覧）と、選んでいるしるし（チェック）
CHECKLIST, CHECK = "checklist", "check"
ICON_NAMES = (WIFI, BLUETOOTH, SPEAKER, BUBBLE, POWER, RESTART, GUIDE, PERSON, SHOP, FOLDER, PLAY, SLIDES, LOCK, CHECKLIST, CHECK)

# 図は 24 x 24 の方眼で設計し、大きさに合わせて拡大する
GRID = 24
SUPERSAMPLE = 4


def _arc_points(cx: float, cy: float, radius: float, start: float, end: float, steps: int = 24) -> list[tuple[float, float]]:
    """円弧の点（角度は度。0 = 右、90 = 下、270 = 上）。"""
    return [
        (cx + radius * math.cos(math.radians(start + (end - start) * i / steps)), cy + radius * math.sin(math.radians(start + (end - start) * i / steps)))
        for i in range(steps + 1)
    ]


def _stroke(surface: pygame.Surface, color, points: list[tuple[float, float]], width: float, scale: float) -> None:
    """丸い端の太い線（pygame の太い円弧は隙間ができるので、短い線と丸でつなぐ）。"""
    pixels = [(x * scale, y * scale) for x, y in points]
    w = max(1, round(width * scale))
    if len(pixels) > 1:
        pygame.draw.lines(surface, color, False, pixels, w)
    for x, y in pixels:
        pygame.draw.circle(surface, color, (round(x), round(y)), w // 2)


def _poly(surface: pygame.Surface, color, points: list[tuple[float, float]], scale: float) -> None:
    pygame.draw.polygon(surface, color, [(x * scale, y * scale) for x, y in points])


# 向かい合う 2 羽の小鳥（製品名「コトリア」の印。メニューの「話す人」の行の右に出す）。
# 正方形の印とは別に、横長の絵にして、2 羽のあいだを少し開ける。色は、左が緑、右が茶色、くちばしと足はだいだい色
BIRDS_CANVAS_WIDTH = 30  # 方眼の横の数（高さは GRID）。小鳥 1 羽の横幅は約 12.3
BIRD_COLORS = ((98, 186, 92), (176, 118, 66))
BIRD_BEAK_COLOR = (255, 128, 48)


def _draw_bird(surface: pygame.Surface, body_color, beak_color, scale: float, flip: bool) -> None:
    """右を向いた小鳥を、方眼の下の方に描く（flip なら、横幅の真ん中で左右を逆にして、左を向く）。

    体・頭・尾を body_color、くちばしと足を beak_color で塗り、目と翼の線は「透明」で抜く（背景が何色でも、同じに見える）。
    """

    def g(x: float, y: float) -> tuple[float, float]:
        x, y = x + 2.0, y + 6.5
        return (BIRDS_CANVAS_WIDTH - x) if flip else x, y

    def px(x: float, y: float) -> tuple[float, float]:
        gx, gy = g(x, y)
        return gx * scale, gy * scale

    _poly(surface, body_color, [g(1.8, 5.2), g(-1.0, 3.4), g(-0.5, 7.0)], scale)  # 尾
    cx, cy = px(4.6, 6.0)
    rx, ry = 3.7 * scale, 2.8 * scale
    pygame.draw.ellipse(surface, body_color, pygame.Rect(round(cx - rx), round(cy - ry), round(2 * rx), round(2 * ry)))  # 体
    hx, hy = px(7.4, 3.9)
    pygame.draw.circle(surface, body_color, (hx, hy), 2.1 * scale)  # 頭
    _poly(surface, beak_color, [g(9.2, 3.3), g(11.3, 4.2), g(9.2, 5.0)], scale)  # くちばし
    for x in (4.0, 5.5):  # 足
        _stroke(surface, beak_color, [g(x, 8.3), g(x, 10.3)], 0.8, scale)
    ex, ey = px(8.1, 3.5)
    pygame.draw.circle(surface, (0, 0, 0, 0), (ex, ey), 0.6 * scale)  # 目（透明で抜く）
    _stroke(surface, (0, 0, 0, 0), [g(2.9, 6.2), g(4.4, 7.0), g(6.2, 5.9)], 0.9, scale)  # 翼の線（透明で抜く）


@lru_cache(maxsize=8)
def birds_surface(height: int) -> pygame.Surface:
    """向かい合う 2 羽の小鳥の絵（高さ height、幅は BIRDS_CANVAS_WIDTH / GRID 倍。背景は透明）。同じ大きさは、一度だけ描く。"""
    scale = height * SUPERSAMPLE / GRID
    width = round(height * BIRDS_CANVAS_WIDTH / GRID)
    surface = pygame.Surface((width * SUPERSAMPLE, height * SUPERSAMPLE), pygame.SRCALPHA)
    for color, flip in zip(BIRD_COLORS, (False, True)):
        _draw_bird(surface, (*color, 255), (*BIRD_BEAK_COLOR, 255), scale, flip)
    return pygame.transform.smoothscale(surface, (width, height))


def _draw(name: str, surface: pygame.Surface, color, scale: float) -> None:
    def pts(*points: tuple[float, float]) -> list[tuple[float, float]]:
        return list(points)

    if name == WIFI:
        # 下から 3 本の電波と点（中心は下の真ん中）
        cx, cy = 12, 20.6
        for radius in (5.8, 10.4, 15):
            _stroke(surface, color, _arc_points(cx, cy, radius, 228, 312), 2.4, scale)
        pygame.draw.circle(surface, color, (cx * scale, cy * scale), 2.2 * scale)
    elif name == BLUETOOTH:
        # Bluetooth のルーン文字
        _stroke(surface, color, pts((6.5, 7.5), (17, 16.5), (11.5, 21.5), (11.5, 2.5), (17, 7.5), (6.5, 16.5)), 2.2, scale)
    elif name == SPEAKER:
        body = [(3, 9), (7.5, 9), (13, 4.2), (13, 19.8), (7.5, 15), (3, 15)]
        pygame.draw.polygon(surface, color, [(x * scale, y * scale) for x, y in body])
        _stroke(surface, color, _arc_points(12.5, 12, 4.6, -50, 50), 2.0, scale)
        _stroke(surface, color, _arc_points(12.5, 12, 8.6, -50, 50), 2.0, scale)
    elif name == BUBBLE:
        # ふきだし（中に文の線を 2 本）
        rect = pygame.Rect(round(2.5 * scale), round(3.5 * scale), round(19 * scale), round(13 * scale))
        pygame.draw.rect(surface, color, rect, border_radius=round(3 * scale))
        tail = [(6.5, 16), (6.5, 21.5), (12, 16)]
        pygame.draw.polygon(surface, color, [(x * scale, y * scale) for x, y in tail])
        clear = (0, 0, 0, 0)
        for y, right in ((8, 17.5), (12, 14)):
            pygame.draw.line(surface, clear, (6.5 * scale, y * scale), (right * scale, y * scale), max(1, round(1.8 * scale)))
    elif name == POWER:
        # 電源のマーク（上が欠けた輪と、縦の線）
        _stroke(surface, color, _arc_points(12, 13.2, 8, -48, 228, 40), 2.4, scale)
        _stroke(surface, color, pts((12, 3.2), (12, 11.8)), 2.4, scale)
    elif name == RESTART:
        # 再起動のマーク（ほぼ一周する矢印）
        cx, cy, radius, end = 12, 12.5, 7.6, 250
        _stroke(surface, color, _arc_points(cx, cy, radius, -45, end, 40), 2.4, scale)
        a = math.radians(end)
        px, py = cx + radius * math.cos(a), cy + radius * math.sin(a)
        tx, ty = -math.sin(a), math.cos(a)  # 進む向き（時計回り）
        nx, ny = math.cos(a), math.sin(a)  # 外向き
        head = [(px + 3.6 * tx, py + 3.6 * ty), (px - 0.6 * tx + 3.6 * nx, py - 0.6 * ty + 3.6 * ny), (px - 0.6 * tx - 3.6 * nx, py - 0.6 * ty - 3.6 * ny)]
        pygame.draw.polygon(surface, color, [(x * scale, y * scale) for x, y in head])
    elif name == GUIDE:
        # 画面（中に再生の三角）と台
        _stroke(surface, color, pts((3, 4.5), (21, 4.5), (21, 16.5), (3, 16.5), (3, 4.5)), 2.2, scale)
        _stroke(surface, color, pts((8, 20.5), (16, 20.5)), 2.2, scale)
        _poly(surface, color, [(10, 7.8), (10, 13.4), (15.2, 10.6)], scale)
    elif name == PERSON:
        # 人（頭と肩）
        pygame.draw.circle(surface, color, (12 * scale, 7.6 * scale), 4.0 * scale)
        shoulders = _arc_points(12, 21.5, 9, 180, 360, 30)
        _poly(surface, color, shoulders, scale)
    elif name == SHOP:
        # お店（日よけと、壁・入口）
        _poly(surface, color, [(2.5, 9.5), (5, 3.5), (19, 3.5), (21.5, 9.5)], scale)
        _stroke(surface, color, pts((4.5, 11.5), (4.5, 20.5), (19.5, 20.5), (19.5, 11.5)), 2.0, scale)
        _poly(surface, color, [(10, 20.5), (10, 14.5), (14, 14.5), (14, 20.5)], scale)
    elif name == FOLDER:
        _poly(surface, color, [(2.5, 5.5), (9.5, 5.5), (11.5, 8), (21.5, 8), (21.5, 19.5), (2.5, 19.5)], scale)
    elif name == PLAY:
        _poly(surface, color, [(6.5, 4), (6.5, 20), (20, 12)], scale)
    elif name == LOCK:
        # 鍵（上の半円の輪と、本体）
        _stroke(surface, color, _arc_points(12, 9.5, 4.6, 180, 360, 24) + pts((16.6, 9.5), (16.6, 11)), 2.2, scale)
        _stroke(surface, color, pts((7.4, 9.5), (7.4, 11)), 2.2, scale)
        pygame.draw.rect(surface, color, pygame.Rect(round(4.5 * scale), round(10.5 * scale), round(15 * scale), round(10.5 * scale)), border_radius=round(2 * scale))
    elif name == SLIDES:
        # 重なった 2 枚のスライド
        _stroke(surface, color, pts((7.5, 3.8), (21, 3.8), (21, 14.5), (7.5, 14.5), (7.5, 3.8)), 2.0, scale)
        _poly(surface, color, [(3, 8), (16.5, 8), (16.5, 20), (3, 20)], scale)
    elif name == CHECKLIST:
        # チェックの付いた一覧（3 行。左にチェックの小さな印、右に線）
        for y in (6, 12, 18):
            _stroke(surface, color, pts((2.6, y), (4.2, y + 1.6), (6.8, y - 1.8)), 1.8, scale)
            _stroke(surface, color, pts((10.5, y), (21.5, y)), 2.2, scale)
    elif name == CHECK:
        _stroke(surface, color, pts((4.5, 12.5), (9.5, 17.5), (19.5, 6.5)), 3.2, scale)
    else:
        raise ValueError(f"知らない印です: {name}")


@lru_cache(maxsize=64)
def icon_surface(name: str, size: int, color: tuple[int, int, int]) -> pygame.Surface:
    """size 四方の印（背景は透明）。同じ印は一度だけ描く。"""
    big = size * SUPERSAMPLE
    surface = pygame.Surface((big, big), pygame.SRCALPHA)
    _draw(name, surface, (*color, 255), big / GRID)
    return pygame.transform.smoothscale(surface, (size, size))
