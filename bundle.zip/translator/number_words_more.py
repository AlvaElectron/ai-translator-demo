"""num2words が対応していない言語の、数の読み（読み上げの前に、数字を言葉にする。spell_numbers。読み上げ（tts.py）とカタカナ（more_kana.py）が使う）。

クロアチア語・エストニア語・ブルガリア語は 0〜999,999、ヒンディー語は 0〜99,99,999 まで（2026-11-14 に足した言語）。
それより大きい数は None（数字のまま読ませる）。
お店の金額（3,300 円・12,800 円など）を読むためのもので、序数や小数には対応しない。
"""

from __future__ import annotations

import re

# --- クロアチア語 ---
_HR_UNITS = ["nula", "jedan", "dva", "tri", "četiri", "pet", "šest", "sedam", "osam", "devet", "deset", "jedanaest", "dvanaest",
             "trinaest", "četrnaest", "petnaest", "šesnaest", "sedamnaest", "osamnaest", "devetnaest"]
_HR_TENS = ["", "", "dvadeset", "trideset", "četrdeset", "pedeset", "šezdeset", "sedamdeset", "osamdeset", "devedeset"]
_HR_HUNDREDS = ["", "sto", "dvjesto", "tristo", "četiristo", "petsto", "šesto", "sedamsto", "osamsto", "devetsto"]


def _hr_below_thousand(n: int, feminine: bool = False) -> list[str]:
    words = []
    if n >= 100:
        words.append(_HR_HUNDREDS[n // 100])
        n %= 100
    if n >= 20:
        words.append(_HR_TENS[n // 10])
        n %= 10
    if n:
        word = _HR_UNITS[n]
        if feminine and n == 1:
            word = "jedna"
        elif feminine and n == 2:
            word = "dvije"
        words.append(word)
    return words


def croatian_number(n: int) -> str | None:
    """3300 → tri tisuće tristo（「tisuća」は女性名詞なので、1・2 は jedna・dvije。2〜4 は tisuće、ほかは tisuća）。"""
    if not 0 <= n < 1_000_000:
        return None
    if n == 0:
        return _HR_UNITS[0]
    thousands, rest = divmod(n, 1000)
    words = []
    if thousands == 1:
        words.append("tisuću")
    elif thousands:
        words += _hr_below_thousand(thousands, feminine=True)
        last_two, last = thousands % 100, thousands % 10
        words.append("tisuće" if 2 <= last <= 4 and not 12 <= last_two <= 14 else "tisuća")
    words += _hr_below_thousand(rest)
    return " ".join(words)


# --- エストニア語 ---
_ET_UNITS = ["null", "üks", "kaks", "kolm", "neli", "viis", "kuus", "seitse", "kaheksa", "üheksa"]


def _et_below_thousand(n: int) -> list[str]:
    words = []
    if n >= 100:
        words.append("sada" if n // 100 == 1 else _ET_UNITS[n // 100] + "sada")
        n %= 100
    if n >= 20:
        words.append(_ET_UNITS[n // 10] + "kümmend")
        n %= 10
    elif n >= 11:
        words.append(_ET_UNITS[n - 10] + "teist")
        n = 0
    elif n == 10:
        words.append("kümme")
        n = 0
    if n:
        words.append(_ET_UNITS[n])
    return words


def estonian_number(n: int) -> str | None:
    """3300 → kolm tuhat kolmsada、12800 → kaksteist tuhat kaheksasada。"""
    if not 0 <= n < 1_000_000:
        return None
    if n == 0:
        return _ET_UNITS[0]
    thousands, rest = divmod(n, 1000)
    words = []
    if thousands == 1:
        words.append("tuhat")
    elif thousands:
        words += _et_below_thousand(thousands) + ["tuhat"]
    words += _et_below_thousand(rest)
    return " ".join(words)


# --- ブルガリア語 ---
_BG_UNITS = ["нула", "едно", "две", "три", "четири", "пет", "шест", "седем", "осем", "девет", "десет", "единадесет", "дванадесет",
             "тринадесет", "четиринадесет", "петнадесет", "шестнадесет", "седемнадесет", "осемнадесет", "деветнадесет"]
_BG_TENS = ["", "", "двадесет", "тридесет", "четиридесет", "петдесет", "шестдесет", "седемдесет", "осемдесет", "деветдесет"]
_BG_HUNDREDS = ["", "сто", "двеста", "триста", "четиристотин", "петстотин", "шестстотин", "седемстотин", "осемстотин", "деветстотин"]


def _bg_parts(n: int) -> list[str]:
    """1000 未満の数の、百・十・一の部分（11〜19 は 1 つの部分）。"""
    parts = []
    if n >= 100:
        parts.append(_BG_HUNDREDS[n // 100])
        n %= 100
    if n >= 20:
        parts.append(_BG_TENS[n // 10])
        n %= 10
    if n:
        parts.append(_BG_UNITS[n])
    return parts


def _bg_join(parts: list[str]) -> str:
    """ブルガリア語は、最後の部分の前に「и」を入れる（125 → сто двадесет и пет、3300 → три хиляди и триста）。"""
    if len(parts) <= 1:
        return "".join(parts)
    return " ".join(parts[:-1]) + " и " + parts[-1]


def bulgarian_number(n: int) -> str | None:
    """3300 → три хиляди и триста、12800 → дванадесет хиляди и осемстотин、1005 → хиляда и пет。"""
    if not 0 <= n < 1_000_000:
        return None
    if n == 0:
        return _BG_UNITS[0]
    thousands, rest = divmod(n, 1000)
    parts = []
    if thousands == 1:
        parts.append("хиляда")
    elif thousands:
        parts.append(_bg_join(_bg_parts(thousands)) + " хиляди")
    parts += _bg_parts(rest)
    return _bg_join(parts)


# --- ヒンディー語 ---
# 1〜99 は、それぞれ別の語（規則で組み立てられない）。100 は सौ、1,000 は हज़ार、100,000 は लाख（インド式の位取り）
_HI_0_99 = (
    "शून्य एक दो तीन चार पाँच छह सात आठ नौ दस ग्यारह बारह तेरह चौदह पंद्रह सोलह सत्रह अठारह उन्नीस "
    "बीस इक्कीस बाईस तेईस चौबीस पच्चीस छब्बीस सत्ताईस अट्ठाईस उनतीस तीस इकतीस बत्तीस तैंतीस चौंतीस पैंतीस छत्तीस सैंतीस अड़तीस उनतालीस "
    "चालीस इकतालीस बयालीस तैंतालीस चवालीस पैंतालीस छियालीस सैंतालीस अड़तालीस उनचास पचास इक्यावन बावन तिरपन चौवन पचपन छप्पन सत्तावन अट्ठावन उनसठ "
    "साठ इकसठ बासठ तिरसठ चौंसठ पैंसठ छियासठ सड़सठ अड़सठ उनहत्तर सत्तर इकहत्तर बहत्तर तिहत्तर चौहत्तर पचहत्तर छिहत्तर सतहत्तर अठहत्तर उन्यासी "
    "अस्सी इक्यासी बयासी तिरासी चौरासी पचासी छियासी सत्तासी अट्ठासी नवासी नब्बे इक्यानवे बानवे तिरानवे चौरानवे पंचानवे छियानवे सत्तानवे अट्ठानवे निन्यानवे"
).split()


def hindi_number(n: int) -> str | None:
    """3300 → तीन हज़ार तीन सौ、12800 → बारह हज़ार आठ सौ、150000 → एक लाख पचास हज़ार（99,99,999 まで）。"""
    if not 0 <= n < 10_000_000:
        return None
    if n == 0:
        return _HI_0_99[0]
    words = []
    for unit, name in ((100_000, "लाख"), (1000, "हज़ार"), (100, "सौ")):
        count, n = divmod(n, unit)
        if count:
            words += [_HI_0_99[count], name]
    if n:
        words.append(_HI_0_99[n])
    return " ".join(words)


SPELLERS = {"hr": croatian_number, "et": estonian_number, "bg": bulgarian_number, "hi": hindi_number}


_THOUSANDS_SEPARATOR = re.compile(r"(?<=\d)[.,   ](?=\d{3}(?!\d))")
# 時刻（20:00）や小数（1,5）の一部の数字は言葉にしない（「veinte:cero」のようにならないように）
_PLAIN_NUMBER = re.compile(r"(?<![\d:.,])\d+(?![\d:]|[.,]\d)")


def spell_numbers(text: str, lang: str) -> str:
    """数字を、その言語の言葉にする（3.300 yenes → tres mil trescientos yenes）。できない言語・大きすぎる数は、そのまま返す。"""
    speller = number_speller(lang)
    if speller is None:
        return text
    previous = None
    while previous != text:  # 1.234.567 のように区切りが続くときは、繰り返して全部取る
        previous, text = text, _THOUSANDS_SEPARATOR.sub("", text)
    return _PLAIN_NUMBER.sub(lambda match: speller(int(match.group())) or match.group(), text)


def number_speller(lang: str):
    """数を言葉にする関数（無ければ None）。クロアチア語・エストニア語・ブルガリア語は自作、ほかは num2words。"""
    if lang in SPELLERS:
        return SPELLERS[lang]
    try:
        from num2words import CONVERTER_CLASSES, num2words
    except ImportError:
        return None
    if lang not in CONVERTER_CLASSES:
        return None
    return lambda n: num2words(n, lang=lang)
