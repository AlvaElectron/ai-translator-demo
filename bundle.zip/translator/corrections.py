"""訂正の一覧（管理者の画面の「訂正」）。誤訳を、決めた訳に直す。

訂正は corrections.json（config.toml と同じフォルダ）に保存する。1 つの訂正は、話した言語・その文・訳す先の言語と、
正しい訳文を持つ。同じ文（句読点・空白・大文字小文字・かなの種類の違いは同じとみなす）を同じ向きで訳すときは、
翻訳サーバーを使わず、この訳文をそのまま出す。「訳し直し」のときは、使わない（別の訳が出せるように）。

手でファイルを書き換えてもよい（書式は README の「訂正の一覧」を見る）。
"""

from __future__ import annotations

import json
import logging
import os
import threading
import unicodedata
from collections.abc import Callable
from dataclasses import dataclass, replace
from datetime import datetime
from pathlib import Path

from .langs import JA, PARTNER_LANGS

log = logging.getLogger(__name__)

FILE_NAME = "corrections.json"
MAX_CORRECTIONS = 300
_LANGS = frozenset({JA, *PARTNER_LANGS})
_DATE_FORMAT = "%Y-%m-%d %H:%M"

# add() の結果
ADDED, UPDATED, FULL, INVALID = "added", "updated", "full", "invalid"


@dataclass(frozen=True)
class Correction:
    source: str  # 話した言語
    text: str  # 話した文
    target: str  # 訳す先の言語
    translation: str  # 正しい訳文
    added: str = ""  # 登録した日時（"2026-10-13 09:30"）


def normalize(text: str) -> str:
    """比べやすい形にする: 全角・半角をそろえ、小文字にし、句読点・空白を除き、カタカナはひらがなにする。"""
    text = unicodedata.normalize("NFKC", text).lower()
    letters = (ch for ch in text if ch.isalnum() or unicodedata.category(ch).startswith("M"))
    return "".join(chr(ord(ch) - 0x60) if "ァ" <= ch <= "ヶ" else ch for ch in letters)


def corrections_path(config_path: Path) -> Path:
    """config.toml と同じフォルダの corrections.json。"""
    return Path(config_path).resolve().parent / FILE_NAME


class CorrectionBook:
    """画面の操作と、翻訳のスレッド（探す）から同時に使っても壊れないようにしてある。"""

    def __init__(self, path: Path, now: Callable[[], datetime] = datetime.now) -> None:
        self._path = Path(path)
        self._now = now
        self._lock = threading.Lock()
        self._items = self._load()

    @property
    def items(self) -> tuple[Correction, ...]:
        with self._lock:
            return tuple(self._items)

    def find(self, source: str, target: str, text: str) -> str | None:
        """同じ文を同じ向きで訳すときの、決めた訳文（なければ None）。"""
        key = normalize(text)
        if not key:
            return None
        with self._lock:
            for item in self._items:
                if item.source == source and item.target == target and normalize(item.text) == key:
                    return item.translation
        return None

    def add(self, source: str, text: str, target: str, translation: str) -> str:
        """訂正を登録する。同じ文・同じ向きがあれば、訳文を更新する（UPDATED）。いっぱいなら FULL。"""
        text, translation = text.strip(), translation.strip()
        if source not in _LANGS or target not in _LANGS or not normalize(text) or not translation:
            return INVALID
        key = normalize(text)
        with self._lock:
            for i, item in enumerate(self._items):
                if item.source == source and item.target == target and normalize(item.text) == key:
                    self._items[i] = replace(item, text=text, translation=translation, added=self._now().strftime(_DATE_FORMAT))
                    self._save()
                    return UPDATED
            if len(self._items) >= MAX_CORRECTIONS:
                return FULL
            self._items.append(Correction(source, text, target, translation, self._now().strftime(_DATE_FORMAT)))
            self._save()
            return ADDED

    def remove(self, index: int) -> None:
        with self._lock:
            if 0 <= index < len(self._items):
                del self._items[index]
                self._save()

    def _load(self) -> list[Correction]:
        try:
            raw = json.loads(self._path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return []
        except (OSError, ValueError):
            log.warning("訂正のファイルを読めないため、使いません: %s", self._path)
            return []
        items: list[Correction] = []
        for entry in raw if isinstance(raw, list) else []:
            if not isinstance(entry, dict):
                continue
            source, target = entry.get("source"), entry.get("target")
            text, translation, added = entry.get("text"), entry.get("translation"), entry.get("added", "")
            if (
                source in _LANGS
                and target in _LANGS
                and isinstance(text, str)
                and text.strip()
                and isinstance(translation, str)
                and translation.strip()
            ):
                items.append(Correction(source, text.strip(), target, translation.strip(), added if isinstance(added, str) else ""))
        return items[:MAX_CORRECTIONS]

    def _save(self) -> None:
        """_lock を持って呼ぶ。書き込み途中で電源が切れても壊れないよう、別名で書いてから置き換える。"""
        data = [
            {"source": c.source, "text": c.text, "target": c.target, "translation": c.translation, "added": c.added}
            for c in self._items
        ]
        temporary = self._path.with_name(self._path.name + ".tmp")
        try:
            temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            os.replace(temporary, self._path)
        except OSError:
            log.exception("訂正を保存できません: %s", self._path)
