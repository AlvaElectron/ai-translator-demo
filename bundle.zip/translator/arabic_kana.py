"""アラビア語のカタカナ（2026-11-23）。

アラビア語は、ふつう短い母音（a・i・u）を書かないので、つづりだけでは読みが決まらない。そこで 2 段にする。
1. 母音の記号（ハラカート）を付ける: ichkil のモデル（ONNX、約 22MB、CPU で 1 文数ミリ秒）。
   推論の部分は ichkil（MIT License、Copyright (c) 2026 Maaouia BenHamed、github.com/Ichkil/ichkil-python）の
   pipeline.py・diacritizer.py を短くしたもの。モデル（huggingface.co/ichkil/ichkil、MIT）は models/ichkil/ に置く
   （model.onnx・config.json）。無ければ、カタカナは出さない。
2. 母音の付いた字 → 音の並び → カタカナ（more_kana.tokens_to_kana）。
   話すときの読み（語末の格の母音・-un・-in は読まない休止形。-an は読む）にする。
   定冠詞 al- は、太陽文字の前では次の子音を重ねる（アッシャムス）。ء・ع の前では音を切る（アルウーラー）。
   長い ā を書かない、よく使う語（هذا ハーザー など）は表で読む。
"""

from __future__ import annotations

import json
import logging
import re
import unicodedata
from pathlib import Path

from .more_kana import Tokens, tokens_to_kana

log = logging.getLogger(__name__)

MODEL_DIR = Path(__file__).resolve().parent.parent / "models" / "ichkil"

# --- 1. 母音の記号を付ける（ichkil） ---

_AR_LETTER = re.compile(r"[ء-غف-ي]")
_AR_DIACRITIC = re.compile(r"[ؐ-ًؚ-ٰٟۖ-ۭ]")
_LABEL_TO_COMBO = (
    "", "", "َ", "ُ", "ِ", "ْ", "ّ", "َّ", "ُّ", "ِّ",
    "ً", "ٌ", "ٍ", "ًّ", "ٌّ", "ٍّ",
)
_CHAR_MAP = {"ٱ": "ا", "ی": "ي", "ک": "ك", "ہ": "ه", " ": " "}
_ZERO_WIDTH = re.compile(r"[​-‏﻿]")


def strip_diacritics(text: str) -> str:
    """モデルに渡す形（NFC・字の形をそろえる・幅のない字を消す・空白をまとめる・記号とタトウィールを消す）。"""
    text = unicodedata.normalize("NFC", text)
    text = "".join(_CHAR_MAP.get(c, c) for c in text)
    text = re.sub(r"\s+", " ", _ZERO_WIDTH.sub("", text)).strip()
    return _AR_DIACRITIC.sub("", text).replace("ـ", "")


class Diacritizer:
    """母音の記号を付ける（ichkil の ONNX モデル）。"""

    def __init__(self, model_dir: Path = MODEL_DIR, num_threads: int = 1) -> None:
        import numpy as np
        import onnxruntime as ort

        config = json.loads((model_dir / "config.json").read_text(encoding="utf-8"))
        options = ort.SessionOptions()
        options.intra_op_num_threads = num_threads
        self._np = np
        self._session = ort.InferenceSession(str(model_dir / "model.onnx"), sess_options=options,
                                             providers=["CPUExecutionProvider"])
        self._sym2id: dict[str, int] = dict(config["sym2id"])
        self._num_labels = int(config["num_tags"])
        self._max_len = int(config.get("max_seq_len", 0)) or 1024
        self._unk = int(self._sym2id.get("<unk>", 1))

    def diacritize(self, text: str) -> str:
        base = strip_diacritics(text)
        if not base:
            return text
        # 長い文は、空白のところで切ってから付ける（モデルの上限 max_seq_len）
        parts, start = [], 0
        while len(base) - start > self._max_len:
            cut = base.rfind(" ", start, start + self._max_len) + 1 or start + self._max_len
            parts.append(base[start:cut])
            start = cut
        parts.append(base[start:])
        return "".join(self._one(part) for part in parts if part)

    def _one(self, base: str) -> str:
        ids = self._np.asarray([[self._sym2id.get(ch, self._unk) for ch in base]], dtype=self._np.int64)
        (logits,) = self._session.run(["logits"], {"input_ids": ids})
        labels = logits[0].reshape(len(base), self._num_labels).argmax(axis=1)
        return "".join(ch + _LABEL_TO_COMBO[label] if _AR_LETTER.fullmatch(ch) else ch
                       for ch, label in zip(base, labels.tolist()))


# --- 2. 母音の付いた字 → カタカナ ---

FATHA, DAMMA, KASRA, SUKUN, SHADDA = "َ", "ُ", "ِ", "ْ", "ّ"
FATHATAN, DAMMATAN, KASRATAN, DAGGER_ALIF = "ً", "ٌ", "ٍ", "ٰ"
_VOWEL = {FATHA: "a", DAMMA: "u", KASRA: "i"}
_MARKS = set(_VOWEL) | {SUKUN, SHADDA, FATHATAN, DAMMATAN, KASRATAN, DAGGER_ALIF, "ٓ", "ٔ", "ٕ"}
_CONSONANTS = {
    "ب": "b", "ت": "t", "ث": "s", "ج": "j", "ح": "h", "خ": "x", "د": "d", "ذ": "z", "ر": "r", "ز": "z",
    "س": "s", "ش": "sh", "ص": "s", "ض": "d", "ط": "t", "ظ": "z", "غ": "g", "ف": "f", "ق": "k",
    "ك": "k", "ل": "r", "م": "m", "ن": "n", "ه": "h", "و": "w", "ي": "y", "پ": "p", "چ": "ch", "ڤ": "v", "گ": "g",
}
_GLOTTAL = set("ءأإؤئع")  # 子音としては読まない（母音だけ。語の中では音を切る）
# 長い ā を書かない、よく使う語（記号を除いた形 → 読み）
SPECIAL_WORDS = {
    "هذا": "ハーザー", "هذه": "ハーズィヒ", "هؤلاء": "ハーウラーイ", "ذلك": "ザーリク", "تلك": "ティルカ",
    "لكن": "ラーキン", "الله": "アッラー", "هكذا": "ハーカザー",
}
_PREFIXES = set("بلفوك")  # 語の頭に付く前置詞・接続詞（bi-・li-・fa-・wa-・ka-）
_WORD = re.compile(r"[ء-يً-ٰٕپچڤگ]+")
_PUNCTUATION = str.maketrans({"،": ",", "؟": "?", "؛": ";", "ـ": ""})


def _letters(word: str) -> list[tuple[str, set[str]]]:
    out: list[tuple[str, set[str]]] = []
    for ch in word:
        if ch in _MARKS:
            if out:
                out[-1][1].add(ch)
        else:
            out.append((ch, set()))
    return out


def _vowel_of(marks: set[str]) -> str:
    return next((_VOWEL[m] for m in (FATHA, DAMMA, KASRA) if m in marks), "")


def word_tokens(word: str) -> Tokens:
    """母音の付いた 1 語 → 音の並び。"""
    letters = _letters(word)
    n = len(letters)
    toks: Tokens = []
    prev_vowel = ""
    i = 0
    while i < n:
        ch, marks = letters[i]
        last = i == n - 1
        vowel = _vowel_of(marks)
        tanwin = next((m for m in (FATHATAN, DAMMATAN, KASRATAN) if m in marks), "")
        # 語頭の定冠詞 al-（太陽文字なら l を読まず、次の字の shadda で子音を重ねる）
        if i == 0 and ch == "ا" and n > 2 and letters[1][0] == "ل":
            toks.append("a")
            if not letters[1][1] and SHADDA in letters[2][1]:
                pass
            else:
                toks += ["r", "!"]
            prev_vowel = "a"
            i = 2
            continue
        if ch == "ا":
            if i == 0:
                toks.append(_vowel_of(marks) or "i")  # 語頭の alif（つなぎの i）
                prev_vowel = toks[-1]
            elif i == 1 and letters[0][0] in _PREFIXES and i + 1 < n and letters[i + 1][0] == "ل" and not marks and (
                SUKUN in letters[i + 1][1] or (i + 2 < n and SHADDA in letters[i + 2][1])
            ):
                # 前置詞の後の al-（bi-l-…・li-l-…）の a は読まない
                if not (i + 2 < n and SHADDA in letters[i + 2][1] and not letters[i + 1][1]):
                    toks += ["r", "!"]
                i += 2
                continue
            elif vowel:
                toks.append(vowel)  # つなぎの alif に母音が付いたもの（al-ittiṣāl）
                prev_vowel = vowel
            elif i == 1 and letters[0][0] in _PREFIXES and i + 1 < n and SUKUN in letters[i + 1][1] and prev_vowel != "a":
                pass  # 前置詞の後のつなぎの alif（bi-stikhdām）
            elif toks and toks[-1] != "N" and (toks[-1] == "!" or toks[-1][0] not in "aiu:"):
                toks.append("i")
                prev_vowel = "i"
            elif tanwin == FATHATAN or (toks and toks[-1] == "N"):
                pass  # -an の後の alif
            else:
                toks.append(":")  # 長い ā
            i += 1
            continue
        if ch == "آ":
            toks.append("a:")
            prev_vowel = "a"
            i += 1
            continue
        if ch == "ى":
            toks.append(":" if prev_vowel == "a" else "a:")
            i += 1
            continue
        if ch == "ة":
            if not last and vowel:
                toks += ["t", vowel]
            i += 1
            continue
        if ch in "وي" and not vowel and not tanwin and SHADDA not in marks:
            if prev_vowel == ("u" if ch == "و" else "i"):
                toks.append(":")  # 長い ū・ī
                i += 1
                continue
            if SUKUN in marks or last or prev_vowel == "a":
                toks.append("w" if ch == "و" else "y")  # 二重母音 aw・ay
                prev_vowel = ""
                i += 1
                continue
        if ch in _GLOTTAL and i > 0:
            toks.append("!")
        if ch in "وي" and SHADDA in marks:
            toks.append("!ウ" if ch == "و" else "!イ")
            marks = marks - {SHADDA}
            if last:
                i += 1
                continue
        cons = "" if ch in _GLOTTAL else _CONSONANTS.get(ch)
        if cons is None:
            i += 1
            continue
        if SHADDA in marks and cons:
            toks.append("Q")
        if cons:
            toks.append(cons)
        if ch == "إ" and not vowel:
            vowel = "i"
        if ch == "أ" and not vowel:
            vowel = "a"
        if last and cons in ("h", "x") and SHADDA not in marks:
            toks[-1] = "!フ"  # 語末の h・kh は「フ」
        elif cons == "x" and not vowel and not tanwin:
            toks[-1] = "!フ"
        if last:
            if tanwin == FATHATAN:
                toks += ["a", "N"]
            elif DAGGER_ALIF in marks:
                toks.append("a:")
        else:
            if vowel:
                toks.append(vowel)
            elif tanwin == FATHATAN:
                toks += ["a", "N"]
            if DAGGER_ALIF in marks:
                toks.append("a:")
        prev_vowel = vowel
        i += 1
    if toks and toks[0] == "Q":
        toks = toks[1:]
    return toks


def vocalized_to_kana(text: str) -> str:
    """母音の記号が付いたアラビア語の文 → カタカナ。"""
    def convert(match: re.Match[str]) -> str:
        word = match.group()
        bare = "".join(c for c in word if c not in _MARKS)
        kana = tokens_to_kana(word_tokens(word))
        if kana.endswith("ンン"):
            kana = kana[:-1]  # 語末の nn（يَنّ）は「ン」1 つ
        return SPECIAL_WORDS.get(bare) or kana or word

    out = _WORD.sub(convert, text.translate(_PUNCTUATION))
    return re.sub(r"\s+", " ", out).strip()


def converter():
    """アラビア語の文 → カタカナの関数（モデルが無い・読めないときは None）。"""
    if not (MODEL_DIR / "model.onnx").exists():
        log.warning("models/ichkil/model.onnx が無いため、アラビア語のカタカナは表示しません")
        return None
    try:
        diacritizer = Diacritizer()
    except Exception:
        log.exception("アラビア語の母音記号のモデルを読めません（models/ichkil）")
        return None
    from .number_words_more import spell_numbers

    return lambda text: vocalized_to_kana(diacritizer.diacritize(spell_numbers(text, "ar")))
