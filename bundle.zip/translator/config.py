"""config.toml を読み込む。"""

from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass, field, replace
from pathlib import Path

from .langs import JA, Mode
from .mic_array import FOCUS_ALL, FOCUSES

Device = int | str | None

# 音声機器の使い方: PortAudio（sounddevice）か、arecord / aplay（Bluetooth イヤホンマイクで使う）
BACKEND_PORTAUDIO = "portaudio"
BACKEND_ALSA_TOOLS = "alsa-tools"


@dataclass(frozen=True)
class AudioConfig:
    input_device: Device
    output_device: Device
    output_sample_rate: int
    playback_holdoff_sec: float
    # マイク入力を何倍に増幅するか（録音音量を最大にしても声が小さいときに上げる）
    input_gain: float = 1.0
    # スピーカー音量（1.0 = 合成音声そのまま）
    output_volume: float = 1.0
    backend: str = BACKEND_PORTAUDIO
    # スピーカーを開くか（マイクの確認 mic_check では開かない）
    output_enabled: bool = True
    # 2つのマイクで雑音を減らす機器（ReSpeaker 2-Mics Pi HAT）の名前の一部。開いたマイクの名前にこれが含まれ、
    # 2チャンネルで録音できれば、「ノイズ除去」がオンの間 mic_array.TwoMicNoiseReducer を通す。空欄なら使わない
    mic_array: str = ""
    # mic_array の減らし方: "all"（どの向きの声も残し、広がった雑音を減らす）/ "front"（正面の声だけ残す）
    mic_array_focus: str = "all"


@dataclass(frozen=True)
class VadConfig:
    model: str
    threshold: float
    min_silence_duration: float
    min_speech_duration: float
    max_speech_duration: float
    # 話し始めの取りこぼしを防ぐため、VAD が検出した位置より前の音声をこの秒数だけ足す
    pre_roll_sec: float = 0.3


# config.toml の [asr.<名前>] に書ける、1言語専用の音声認識モデルの種類
DEDICATED_ASR_ENGINES = ("moonshine", "transducer", "nemo_transducer", "nemo_canary", "nemo_ctc", "whisper")


@dataclass(frozen=True)
class AsrConfig:
    model: str
    tokens: str
    num_threads: int
    # 雑音除去（GTCRN）のモデル。空欄にすると、画面の「ノイズ除去」のボタンを押せなくする
    denoise_model: str = ""
    # 言語ごとに、SenseVoice の代わりに使うその言語専用のモデルのフォルダ。1つの言語には1種類だけ書ける。
    # Moonshine（例: {"ko": ".../moonshine-tiny-ko"}）
    moonshine: dict[str, str] = field(default_factory=dict)
    # Zipformer の transducer（例: {"ja": ".../zipformer-ja-reazonspeech"}）
    transducer: dict[str, str] = field(default_factory=dict)
    # NeMo の transducer（例: {"fr": ".../nemo-parakeet-tdt-0.6b-v3-int8"}）
    nemo_transducer: dict[str, str] = field(default_factory=dict)
    # NeMo の Canary（認識する言語を指定できる。例: {"fr": ".../nemo-canary-180m-flash-en-es-de-fr-int8"}）
    nemo_canary: dict[str, str] = field(default_factory=dict)
    # NeMo の CTC（例: {"ja": ".../nemo-parakeet-tdt_ctc-0.6b-ja"}）
    nemo_ctc: dict[str, str] = field(default_factory=dict)
    # Whisper（OpenAI、MIT ライセンス。認識する言語を指定できる。例: {"pt": ".../sherpa-onnx-whisper-small"}）
    whisper: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class LlmConfig:
    # 汎用モデル（LFM2.5）の llama-server。専用モデルに割り当てていない組み合わせで使う。
    # 日英・日韓・日中をすべて専用モデルに割り当てたら、空欄にして llama-general を止められる
    general_url: str
    enjp_url: str
    max_tokens: int
    request_timeout_sec: float
    startup_timeout_sec: float
    # Hy-MT2（日韓・日中の翻訳）の llama-server。空欄なら日韓・日中も general_url のモデルで訳す
    komt_url: str = ""
    # 使う場面。"shop"（お店の接客）なら、Hy-MT2 に場面の説明と、お店の用語集（glossary.py）の見本を渡す。
    # 空欄なら渡さない（モデルカードの指示文だけで訳す）
    scene: str = "shop"
    # ENJP-MT（enjp_url）で訳す向き。"en-ja" は英語→日本語、"ja-en" は日本語→英語。
    # 入っていない向きは Hy-MT2（komt_url）で訳す。2026-10-01 の比較で、日本語→英語は Hy-MT2（用語集つき）の方が
    # 正確（ENJP-MT は 5,000円 → 5,000 won など）、英語→日本語は ENJP-MT でも十分で約 3 倍速かったので、既定は英語→日本語だけ
    enjp_directions: tuple[str, ...] = ("en-ja",)


@dataclass(frozen=True)
class ChineseTtsConfig:
    """中国語の音声合成（VITS。AISHELL-3 で学習した 174 人の話者）。"""

    model_dir: str
    speaker_id: int = 0
    speed: float = 1.0
    # 音の設定の「声」で「女性」「男性」を選んだときの話者（大半が女性なので、男性は少ない）
    female_speaker_id: int = 138
    male_speaker_id: int = 15


@dataclass(frozen=True)
class TtsConfig:
    model_dir: str
    num_threads: int
    speaker_id: int
    num_steps: int
    speed: float
    # 音の設定の「声」で「女性」「男性」を選んだときの話者（Supertonic の話者は 0〜4 が女性、5〜9 が男性）。
    # 「標準」のときは speaker_id を使う
    female_speaker_id: int = 0
    male_speaker_id: int = 6
    # 最初の読み上げを早く始めるため、この文字数以上たまったら読点でも区切る（0 で無効）
    first_clause_chars: int = 10
    # 中国語の音声合成。None なら中国語の訳文は画面表示のみ
    chinese: ChineseTtsConfig | None = None


@dataclass(frozen=True)
class DisplayConfig:
    width: int
    height: int
    fullscreen: bool
    video_driver: str
    font: str
    show_japanese_source: bool
    # 外国語（韓国語・英語・中国語）の文の発音記号を表示するか
    show_pronunciation: bool = True
    # 起動直後に、確認用に訳文を元の言語に訳し戻して表示するか（翻訳サーバーをもう1回使う。メニューで変えられる）
    show_back_translation: bool = False
    # 発音記号（IPA・ピンイン）に使うフォント。なければ font を使う
    phonetic_font: str = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
    # タイ文字のフォント（font の Noto Sans CJK にはタイ文字がないため）。なければタイ文字は表示できない
    thai_font: str = ""


@dataclass(frozen=True)
class TranslatorConfig:
    # 起動直後の翻訳の組み合わせ（日本語 ⇔ default_partner）と、話す人の言語
    default_partner: str
    default_speaker: str = JA
    # 起動直後に訳文を読み上げるか（メニューでいつでも変えられる）
    default_speech_output: bool = False
    # 起動直後に雑音除去を行うか（「音の設定」で変えた値が user_settings.json に残り、そちらが優先される）
    default_denoise: bool = False


@dataclass(frozen=True)
class PowerSavingConfig:
    """省電力モード（電源・再起動の画面でオン・オフ）。config.toml に [power_saving] が無ければ、この既定値を使う。"""

    # 待機中に、この秒数だけ操作がなければ画面を消す
    idle_sec: float = 60.0
    # 省電力モードの間の画面の明るさ（0〜1）
    dim_level: float = 0.4
    # 画面が消えている間の CPU の速さ（本体の最高に対する割合。0 なら変えない。scripts/allow_power_mode.sh を実行しておく）
    cpu_off_ratio: float = 0.25
    # 画面が消えている間、この秒数ごとに、notice_sec 秒だけ「低消費電力モード中」のお知らせを出す（0 なら出さない）
    notice_interval_sec: float = 180.0
    notice_sec: float = 5.0


@dataclass(frozen=True)
class GuideConfig:
    """操作説明の動画・スライド（メニューの「使い方」）。config.toml に [guide] が無ければ、この既定値を使う。"""

    # 動画・スライドを置くフォルダ（config.toml のフォルダからの相対）。customer（お客様用）と store（店舗用）の 2 つのフォルダを置く
    dir: str = "guides"
    # 動画を再生するプログラム
    mpv: str = "mpv"
    # 動画の音を出すスピーカー（mpv の --audio-device の書き方。空欄 = audio.output_device の名前から探す）
    audio_device: str = ""


@dataclass(frozen=True)
class SecurityConfig:
    """暗証番号（4 桁）の最初の値。config.toml に [security] が無ければ、この値を使う。

    画面の管理者の画面で変えた番号は user_settings.json に（そのまま読めない形で）残り、こちらより優先する。
    """

    # 一般の番号: 「店舗用」「音の設定」「電源・再起動」を開くときに聞く（数字 4 つ。空欄 = 聞かない）
    general_pin: str = "1234"
    # 管理者の番号: 管理者の画面に入るときに聞く（数字 4 つ。管理者用取扱説明書に書いてある最初の番号）
    admin_pin: str = "3957"


@dataclass(frozen=True)
class ReportConfig:
    """日報（2026-11-10）: 終わった日の数（翻訳・訂正・定型文・最高温度・稼働時間）を、会社のサーバーに送る。話した内容は送らない。

    合い言葉（トークン）は config.toml には書かず、token_file（config.toml からの相対）に置く。ファイルが無ければ送らない。
    """

    enabled: bool = False
    url: str = "https://alvaelectron.com/api/report"
    device_id: str = ""
    token_file: str = "report_token"
    interval_min: float = 30.0  # 送っていない日がないかを見る間隔（分）
    days_back: int = 30  # 何日前までさかのぼって送るか


@dataclass(frozen=True)
class Config:
    audio: AudioConfig
    vad: VadConfig
    asr: AsrConfig
    llm: LlmConfig
    tts: TtsConfig
    display: DisplayConfig
    translator: TranslatorConfig
    power_saving: PowerSavingConfig = field(default_factory=PowerSavingConfig)
    guide: GuideConfig = field(default_factory=GuideConfig)
    security: SecurityConfig = field(default_factory=SecurityConfig)
    report: ReportConfig = field(default_factory=ReportConfig)


def _report_config(raw: dict, resolve) -> ReportConfig:
    report = ReportConfig(**raw)
    if report.enabled and not report.device_id.strip():
        raise ValueError("config.toml の [report] で enabled = true にするときは、device_id（本体の ID）を書いてください")
    return replace(report, token_file=resolve(report.token_file))


def load_config(path: Path) -> Config:
    path = Path(path).resolve()
    raw = tomllib.loads(path.read_text(encoding="utf-8"))

    def resolve(value: str) -> str:
        return value if not value or os.path.isabs(value) else str(path.parent / value)

    audio, vad, asr = raw["audio"], raw["vad"], raw["asr"]
    tts = dict(raw["tts"])
    chinese = tts.pop("zh", None)
    config = Config(
        audio=AudioConfig(
            input_device=parse_device(audio["input_device"]),
            output_device=parse_device(audio["output_device"]),
            output_sample_rate=audio["output_sample_rate"],
            playback_holdoff_sec=audio["playback_holdoff_sec"],
            input_gain=float(audio.get("input_gain", 1.0)),
            output_volume=float(audio.get("output_volume", 1.0)),
            mic_array=str(audio.get("mic_array", "")).strip(),
            mic_array_focus=_mic_array_focus(audio.get("mic_array_focus", FOCUS_ALL)),
        ),
        vad=VadConfig(**{**vad, "model": resolve(vad["model"])}),
        asr=AsrConfig(
            **{
                **asr,
                "model": resolve(asr["model"]),
                "tokens": resolve(asr["tokens"]),
                "denoise_model": resolve(asr.get("denoise_model", "")),
                **{
                    engine: {lang: resolve(model_dir) for lang, model_dir in asr.get(engine, {}).items()}
                    for engine in DEDICATED_ASR_ENGINES
                },
            }
        ),
        llm=LlmConfig(**raw["llm"]),
        tts=TtsConfig(
            **{
                **tts,
                "model_dir": resolve(tts["model_dir"]),
                "chinese": ChineseTtsConfig(
                    model_dir=resolve(chinese["model_dir"]),
                    speaker_id=int(chinese.get("speaker_id", 0)),
                    speed=float(chinese.get("speed", 1.0)),
                    female_speaker_id=int(chinese.get("female_speaker_id", 138)),
                    male_speaker_id=int(chinese.get("male_speaker_id", 15)),
                )
                if chinese
                else None,
            }
        ),
        display=DisplayConfig(
            **{**raw["display"], "thai_font": resolve(raw["display"].get("thai_font", ""))}
        ),
        translator=TranslatorConfig(**raw["translator"]),
        power_saving=PowerSavingConfig(**raw.get("power_saving", {})),
        guide=_guide_config(raw.get("guide", {}), resolve),
        security=_security_config(raw.get("security", {}), raw.get("guide", {})),
        report=_report_config(raw.get("report", {}), resolve),
    )
    _check_pin("general_pin", config.security.general_pin, allow_empty=True)
    _check_pin("admin_pin", config.security.admin_pin, allow_empty=False)
    if config.security.general_pin and config.security.general_pin == config.security.admin_pin:
        raise ValueError("config.toml の [security] general_pin と admin_pin は、違う番号にしてください")
    try:
        Mode(config.translator.default_partner, config.translator.default_speaker)
    except ValueError as error:
        raise ValueError(f"config.toml の [translator] が正しくありません: {error}") from None
    for lang in {lang for engine in DEDICATED_ASR_ENGINES for lang in asr.get(engine, {})}:
        engines = [f"[asr.{engine}]" for engine in DEDICATED_ASR_ENGINES if lang in asr.get(engine, {})]
        if len(engines) > 1:
            raise ValueError(f"config.toml で、{lang} の音声認識モデルが {' と '.join(engines)} の両方に書かれています")
    return config


def _guide_config(raw: dict, resolve) -> GuideConfig:
    fields = {key: value for key, value in raw.items() if key != "store_pin"}  # store_pin は [security] general_pin に移った
    fields["dir"] = resolve(str(fields.get("dir", GuideConfig.dir)))
    return GuideConfig(**fields)


def _security_config(raw: dict, guide_raw: dict) -> SecurityConfig:
    """[security] を読む。2026-10-03 の最初の版で [guide] store_pin に書いた番号は、general_pin として引き継ぐ。"""
    fields = {key: str(value).strip() for key, value in raw.items()}  # 1234 のように「"」なしで書かれても読めるように
    if "general_pin" not in fields and "store_pin" in guide_raw:
        fields["general_pin"] = str(guide_raw["store_pin"]).strip()
    return SecurityConfig(**fields)


def _check_pin(name: str, pin: str, allow_empty: bool) -> None:
    if (allow_empty and not pin) or (len(pin) == 4 and pin.isascii() and pin.isdigit()):
        return
    hint = "、または空欄（番号を聞かない）" if allow_empty else ""
    raise ValueError(f'config.toml の [security] {name} は、数字 4 つ（例 "1234"）{hint}にしてください')


def _mic_array_focus(value: str) -> str:
    if value not in FOCUSES:
        raise ValueError(f"config.toml の [audio] mic_array_focus は {' / '.join(FOCUSES)} のどちらかにしてください: {value}")
    return value


def parse_device(value: int | str) -> Device:
    """空欄は既定のデバイス、数字はデバイス番号、それ以外はデバイス名の一部として扱う。

    TOML で引用符なしの数字（input_device = 1）を書くと int になるので、そのまま番号として使う。
    """
    if isinstance(value, int):
        return value
    value = value.strip()
    if not value:
        return None
    return int(value) if value.isdigit() else value
