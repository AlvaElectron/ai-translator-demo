"""config.toml を読み込む。"""

from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass, field, replace
from pathlib import Path

from .langs import JA, PARTNER_LANGS, Mode
from .mic_array import FOCUS_ALL, FOCUSES

Device = int | str | None

# 音声機器の使い方: PortAudio（sounddevice）か、arecord / aplay（Bluetooth イヤホンマイクで使う）
BACKEND_PORTAUDIO = "portaudio"
BACKEND_ALSA_TOOLS = "alsa-tools"


@dataclass(frozen=True)
class AudioConfig:
    input_device: Device
    output_device: Device
    output_sample_rate: int
    playback_holdoff_sec: float
    # マイク入力を何倍に増幅するか（録音音量を最大にしても声が小さいときに上げる）
    input_gain: float = 1.0
    # スピーカー音量（1.0 = 合成音声そのまま）
    output_volume: float = 1.0
    # マイク本体の録音音量（amixer の段階。USB マイクなど）。マイクを開くたびに入れる（抜き挿しで 0 に戻る機器があるため）。
    # -1 なら変えない。画面の「マイク感度」（input_gain の倍率）とは別で、そちらは ×1 のまま感度を上げられる（2026-11-21）
    input_capture_volume: int = -1
    backend: str = BACKEND_PORTAUDIO
    # スピーカーを開くか（マイクの確認 mic_check では開かない）
    output_enabled: bool = True
    # 2つのマイクで雑音を減らす機器（ReSpeaker 2-Mics Pi HAT）の名前の一部。開いたマイクの名前にこれが含まれ、
    # 2チャンネルで録音できれば、「ノイズ除去」がオンの間 mic_array.TwoMicNoiseReducer を通す。空欄なら使わない
    mic_array: str = ""
    # mic_array の減らし方: "all"（どの向きの声も残し、広がった雑音を減らす）/ "front"（正面の声だけ残す）
    mic_array_focus: str = "all"
    # Bluetooth のイヤホンをつないだときの読み上げ先: "earphone"（イヤホン）/ "device"（本体のスピーカー。マイクだけイヤホン）。
    # Orange Pi 4 Pro の内蔵 Bluetooth では、イヤホンへの音がほとんど届かないため "device" にする（2026-11-22）
    bluetooth_speech_output: str = "earphone"
    # スピーカーだけ別の方式で開くとき（Bluetooth のマイク + 本体のスピーカー）。空欄なら backend と同じ
    output_backend: str = ""


@dataclass(frozen=True)
class VadConfig:
    model: str
    threshold: float
    min_silence_duration: float
    min_speech_duration: float
    max_speech_duration: float
    # 話し始めの取りこぼしを防ぐため、VAD が検出した位置より前の音声をこの秒数だけ足す
    pre_roll_sec: float = 0.3


# config.toml の [asr.<名前>] に書ける、1言語専用の音声認識モデルの種類
DEDICATED_ASR_ENGINES = ("moonshine", "transducer", "nemo_transducer", "nemo_canary", "nemo_ctc", "whisper")


@dataclass(frozen=True)
class AsrConfig:
    model: str
    tokens: str
    num_threads: int
    # 雑音除去（GTCRN）のモデル。空欄にすると、画面の「ノイズ除去」のボタンを押せなくする
    denoise_model: str = ""
    # 言語ごとに、SenseVoice の代わりに使うその言語専用のモデルのフォルダ。1つの言語には1種類だけ書ける。
    # Moonshine（例: {"ko": ".../moonshine-tiny-ko"}）
    moonshine: dict[str, str] = field(default_factory=dict)
    # Zipformer の transducer（例: {"ja": ".../zipformer-ja-reazonspeech"}）
    transducer: dict[str, str] = field(default_factory=dict)
    # NeMo の transducer（例: {"fr": ".../nemo-parakeet-tdt-0.6b-v3-int8"}）
    nemo_transducer: dict[str, str] = field(default_factory=dict)
    # NeMo の Canary（認識する言語を指定できる。例: {"fr": ".../nemo-canary-180m-flash-en-es-de-fr-int8"}）
    nemo_canary: dict[str, str] = field(default_factory=dict)
    # NeMo の CTC（例: {"ja": ".../nemo-parakeet-tdt_ctc-0.6b-ja"}）
    nemo_ctc: dict[str, str] = field(default_factory=dict)
    # Whisper（OpenAI、MIT ライセンス。認識する言語を指定できる。例: {"pt": ".../sherpa-onnx-whisper-small"}）
    whisper: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class LlmConfig:
    # 汎用モデル（LFM2.5）の llama-server。専用モデルに割り当てていない組み合わせで使う。
    # 日英・日韓・日中をすべて専用モデルに割り当てたら、空欄にして llama-general を止められる
    general_url: str
    enjp_url: str
    max_tokens: int
    request_timeout_sec: float
    startup_timeout_sec: float
    # Hy-MT2（日韓・日中の翻訳）の llama-server。空欄なら日韓・日中も general_url のモデルで訳す
    komt_url: str = ""
    # 使う場面。"shop"（お店の接客）なら、Hy-MT2 に場面の説明と、お店の用語集（glossary.py）の見本を渡す。
    # 空欄なら渡さない（モデルカードの指示文だけで訳す）
    scene: str = "shop"
    # ENJP-MT（enjp_url）で訳す向き。"en-ja" は英語→日本語、"ja-en" は日本語→英語。
    # 入っていない向きは Hy-MT2（komt_url）で訳す。2026-10-01 の比較で、日本語→英語は Hy-MT2（用語集つき）の方が
    # 正確（ENJP-MT は 5,000円 → 5,000 won など）、英語→日本語は ENJP-MT でも十分で約 3 倍速かったので、既定は英語→日本語だけ
    enjp_directions: tuple[str, ...] = ("en-ja",)
    # PLaMo 3 Translate 0.8B（Preferred Networks の翻訳専用モデル）の llama-server。空欄なら使わない（Hy-MT2 で訳す）。
    # 2026-11-14 に CM5 でお店の例文 352 文を比べ、日韓・日中は（用語集にある語が入った文を Hy-MT2 に回せば）
    # Hy-MT2 と同じくらいの質で約 2〜3 倍速かったので、日韓・日中に使う（仏・露は誤訳が多く、ポルトガル語には対応していない）
    plamo_url: str = ""
    # PLaMo で訳す、日本語の相手の言語
    # 英語も同じ日に追加（52 文すべて正しく、英語→日本語は ENJP-MT の「あなたは〜を受け入れますか？」のような直訳も無くなった）。
    # ここに入れた言語は、enjp_url（ENJP-MT）より PLaMo を先に使う。
    # タイ語・フランス語・ロシア語も同じ日にユーザーの指示で追加（約 2.5〜4 倍速いが、仏・露は Hy-MT2 より意味の誤りがやや多い）。
    # 広東語・ポルトガル語は PLaMo が対応していない
    # スペイン語・ドイツ語など 15 言語も、同じ日に足した（PLaMo だけが訳す。Hy-MT2 には送らない）
    plamo_langs: tuple[str, ...] = ("ko", "zh", "en", "th", "fr", "ru", "es", "de", "it", "nl", "pl", "hr", "sk", "sl", "hu", "et", "lv", "lt", "bg", "id", "vi", "ar", "hi", "ne", "fa", "uz", "si",
                                   "az", "be", "bn", "ca", "ceb", "eu", "gu", "he", "hy", "jv", "ka", "kk", "km", "ml", "mr", "ms", "my",
                                   "pa", "sr", "sw", "ta", "te", "tl", "ur")
    # このうち、用語集にある語が入った文も PLaMo で訳す言語（用語集は PLaMo の glossary で渡す）。
    # 入っていない言語は、用語集にある語が入った文を Hy-MT2 で訳す。2026-11-14 にお店の例文で、用語集にある語が入った
    # 中国語 37 文・韓国語 37 文が、すべて用語集どおりに訳せたので、両方とも PLaMo にした
    plamo_term_langs: tuple[str, ...] = (
        "ko", "zh", "en", "th", "fr", "ru", "es", "de", "it", "nl", "pl", "hr", "sk", "sl", "hu", "et", "lv", "lt", "bg", "id", "vi", "ar", "hi",
        "ne", "fa", "uz", "si",
    )
    # 「訳し直し」の 1・3 回目を Hy-MT2 で訳すか（既定）。False なら、訳し直しも PLaMo で、ゆらぎを上げて訳す
    # （2026-11-14 に試したが、PLaMo は自信が強く、ゆらぎを上げても同じ訳になりやすかったので、Hy-MT2 に戻した）
    plamo_retry_hymt: bool = True


@dataclass(frozen=True)
class ChineseTtsConfig:
    """中国語の音声合成（VITS。AISHELL-3 で学習した 174 人の話者）。"""

    model_dir: str
    speaker_id: int = 0
    speed: float = 1.0
    # 音の設定の「声」で「女性」「男性」を選んだときの話者（大半が女性なので、男性は少ない）
    female_speaker_id: int = 138
    male_speaker_id: int = 15
    # 読むたびの声のゆらぎ（VITS の noise_scale・noise_scale_w）。小さいほど毎回同じに、はっきり読む（0 でゆらぎなし）。
    # 2026-11-16: 既定（0.667・0.8）では、同じ文を読むたびに音が変わり、短い文がときどき崩れていた
    noise_scale: float = 0.667
    noise_scale_w: float = 0.8


@dataclass(frozen=True)
class TtsConfig:
    model_dir: str
    num_threads: int
    speaker_id: int
    num_steps: int
    speed: float
    # 音の設定の「声」で「女性」「男性」を選んだときの話者（Supertonic の話者は 0〜4 が女性、5〜9 が男性）。
    # 「標準」のときは speaker_id を使う
    female_speaker_id: int = 0
    male_speaker_id: int = 6
    # 最初の読み上げを早く始めるため、この文字数以上たまったら読点でも区切る（0 で無効）
    first_clause_chars: int = 10
    # 中国語の音声合成。None なら中国語の訳文は画面表示のみ
    chinese: ChineseTtsConfig | None = None
    # Piper（VITS）の声を使う言語と、そのモデルのフォルダ（config.toml の [tts.piper]。例: {"ne": ".../vits-piper-ne_NP-google-x_low"}）。
    # 2026-11-15 にネパール語を足した（2026-11-16 から google x_low、CC BY-SA 4.0）
    piper: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class DisplayConfig:
    width: int
    height: int
    fullscreen: bool
    video_driver: str
    font: str
    show_japanese_source: bool
    # 外国語（韓国語・英語・中国語）の文の発音記号を表示するか
    show_pronunciation: bool = True
    # 起動直後に、確認用に訳文を元の言語に訳し戻して表示するか（翻訳サーバーをもう1回使う。メニューで変えられる）
    show_back_translation: bool = False
    # 発音記号（IPA・ピンイン）に使うフォント。なければ font を使う
    phonetic_font: str = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
    # タイ文字のフォント（font の Noto Sans CJK にはタイ文字がないため）。なければタイ文字は表示できない
    thai_font: str = ""
    # スペイン語・ポーランド語など、2026-11-14 に足した言語のフォント（Noto Sans CJK には ł・č・ő などが無いため）
    latin_font: str = ""
    # アラビア語・ヒンディー語のフォント（Noto Sans Arabic・Noto Sans Devanagari。どちらも Noto Sans CJK に無い文字）
    arabic_font: str = ""
    devanagari_font: str = ""
    # シンハラ語のフォント（Noto Sans Sinhala）
    sinhala_font: str = ""


@dataclass(frozen=True)
class TranslatorConfig:
    # 起動直後の翻訳の組み合わせ（日本語 ⇔ default_partner）と、話す人の言語
    default_partner: str
    default_speaker: str = JA
    # 起動直後に訳文を読み上げるか（メニューでいつでも変えられる）
    default_speech_output: bool = False
    # 起動直後に雑音除去を行うか（「音の設定」で変えた値が user_settings.json に残り、そちらが優先される）
    default_denoise: bool = False
    # 「翻訳の組み合わせ」の画面と定型文に出す相手の言語（空 = すべて）。訳すモデルが無い言語を隠すのに使う
    # （Orange Pi 4 Pro 版は Hy-MT2 を使わないので、広東語・ポルトガル語・トルコ語・チェコ語・ウクライナ語を外す）
    partner_langs: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "partner_langs", tuple(self.partner_langs))
        unknown = [lang for lang in self.partner_langs if lang not in PARTNER_LANGS]
        if unknown:
            raise ValueError(f"config.toml の [translator] partner_langs に、知らない言語があります: {', '.join(unknown)}")
        if self.partner_langs and self.default_partner not in self.partner_langs:
            raise ValueError("config.toml の [translator] default_partner は、partner_langs の中の言語にしてください")


@dataclass(frozen=True)
class PowerSavingConfig:
    """省電力モード（電源・再起動の画面でオン・オフ）。config.toml に [power_saving] が無ければ、この既定値を使う。"""

    # 待機中に、この秒数だけ操作がなければ画面を消す
    idle_sec: float = 60.0
    # 省電力モードの間の画面の明るさ（0〜1）
    dim_level: float = 0.4
    # 画面が消えている間の CPU の速さ（本体の最高に対する割合。0 なら変えない。scripts/allow_power_mode.sh を実行しておく）
    cpu_off_ratio: float = 0.25
    # 画面が消えている間、この秒数ごとに、notice_sec 秒だけ「低消費電力モード中」のお知らせを出す（0 なら出さない）
    notice_interval_sec: float = 180.0
    notice_sec: float = 5.0


@dataclass(frozen=True)
class GuideConfig:
    """操作説明の動画・スライド（メニューの「使い方」）。config.toml に [guide] が無ければ、この既定値を使う。"""

    # 動画・スライドを置くフォルダ（config.toml のフォルダからの相対）。customer（お客様用）と store（店舗用）の 2 つのフォルダを置く
    dir: str = "guides"
    # 動画を再生するプログラム
    mpv: str = "mpv"
    # 動画の音を出すスピーカー（mpv の --audio-device の書き方。空欄 = audio.output_device の名前から探す）
    audio_device: str = ""


@dataclass(frozen=True)
class SecurityConfig:
    """暗証番号（4 桁）の最初の値。config.toml に [security] が無ければ、この値を使う。

    画面の管理者の画面で変えた番号は user_settings.json に（そのまま読めない形で）残り、こちらより優先する。
    """

    # 一般の番号: 「店舗用」「音の設定」「電源・再起動」を開くときに聞く（数字 4 つ。空欄 = 聞かない）
    general_pin: str = "1234"
    # 管理者の番号: 管理者の画面に入るときに聞く（数字 4 つ。管理者用取扱説明書に書いてある最初の番号）
    admin_pin: str = "3957"


@dataclass(frozen=True)
class ReportConfig:
    """日報（2026-11-10）: 終わった日の数（翻訳・訂正・定型文・最高温度・稼働時間）を、会社のサーバーに送る。話した内容は送らない。

    合い言葉（トークン）は config.toml には書かず、token_file（config.toml からの相対）に置く。ファイルが無ければ送らない。
    """

    enabled: bool = False
    url: str = "https://alvaelectron.com/api/report"
    device_id: str = ""
    token_file: str = "report_token"
    interval_min: float = 30.0  # 送っていない日がないかを見る間隔（分）
    days_back: int = 30  # 何日前までさかのぼって送るか


@dataclass(frozen=True)
class NpuConfig:
    """Orange Pi 4 Pro（Allwinner A733）の NPU（config.toml の [npu]）。lib が空欄なら NPU は使わない（CM5 / Pi 5）。

    NPU 用のモデル（NBG）は コトリア_OrangePi4Pro_NPU の道具で作る。ライブラリは scripts/build_npu.sh でビルドする。
    """

    # NBG を動かすライブラリ（build/npu/libkotoria_npu.so）
    lib: str = ""
    # SenseVoice（sv_int16.nb・tokens.txt・cmvn.json のフォルダ）。空欄なら SenseVoice は CPU（sherpa-onnx）
    sense_voice_dir: str = ""
    # Whisper（whisper.cpp のライブラリ build/npu/libkotoria_whisper.so と、ggml-small-q8_0.bin・wh10_int16.nb のフォルダ）。
    # 空欄なら [asr.whisper] の言語は CPU（sherpa-onnx）
    whisper_lib: str = ""
    whisper_dir: str = ""
    whisper_threads: int = 2
    # 速いコア（Orange Pi 4 Pro は 6・7 番の Cortex-A76）。Whisper の文字を出す部分は、聞き取りの間だけここで動かす
    fast_cpus: tuple[int, ...] = ()
    # Supertonic 3（duration_predictor.onnx・text_encoder.onnx・tts.json・unicode_indexer.json・voice.bin と L80/・L160/）。
    # 空欄なら読み上げは CPU（sherpa-onnx）
    supertonic_dir: str = ""

    @property
    def enabled(self) -> bool:
        return bool(self.lib)


@dataclass(frozen=True)
class Config:
    audio: AudioConfig
    vad: VadConfig
    asr: AsrConfig
    llm: LlmConfig
    tts: TtsConfig
    display: DisplayConfig
    translator: TranslatorConfig
    power_saving: PowerSavingConfig = field(default_factory=PowerSavingConfig)
    guide: GuideConfig = field(default_factory=GuideConfig)
    security: SecurityConfig = field(default_factory=SecurityConfig)
    report: ReportConfig = field(default_factory=ReportConfig)
    npu: NpuConfig = field(default_factory=NpuConfig)


def _npu_config(raw: dict, resolve) -> NpuConfig:
    fields = dict(raw)
    for key in ("lib", "sense_voice_dir", "whisper_lib", "whisper_dir", "supertonic_dir"):
        fields[key] = resolve(str(fields.get(key, "")))
    fields["fast_cpus"] = tuple(int(cpu) for cpu in fields.get("fast_cpus", ()))
    npu = NpuConfig(**fields)
    if not npu.enabled and (npu.sense_voice_dir or npu.whisper_dir or npu.supertonic_dir):
        raise ValueError("config.toml の [npu] で NPU のモデルを使うときは、lib（libkotoria_npu.so）も書いてください")
    if npu.whisper_dir and not npu.whisper_lib:
        raise ValueError("config.toml の [npu] whisper_dir を書くときは、whisper_lib（libkotoria_whisper.so）も書いてください")
    return npu


def _report_config(raw: dict, resolve) -> ReportConfig:
    report = ReportConfig(**raw)
    if report.enabled and not report.device_id.strip():
        raise ValueError("config.toml の [report] で enabled = true にするときは、device_id（本体の ID）を書いてください")
    return replace(report, token_file=resolve(report.token_file))


def load_config(path: Path) -> Config:
    path = Path(path).resolve()
    raw = tomllib.loads(path.read_text(encoding="utf-8"))

    def resolve(value: str) -> str:
        return value if not value or os.path.isabs(value) else str(path.parent / value)

    audio, vad, asr = raw["audio"], raw["vad"], raw["asr"]
    tts = dict(raw["tts"])
    chinese = tts.pop("zh", None)
    tts["piper"] = {lang: resolve(model_dir) for lang, model_dir in tts.get("piper", {}).items()}
    config = Config(
        audio=AudioConfig(
            input_device=parse_device(audio["input_device"]),
            output_device=parse_device(audio["output_device"]),
            output_sample_rate=audio["output_sample_rate"],
            playback_holdoff_sec=audio["playback_holdoff_sec"],
            input_gain=float(audio.get("input_gain", 1.0)),
            output_volume=float(audio.get("output_volume", 1.0)),
            input_capture_volume=int(audio.get("input_capture_volume", -1)),
            mic_array=str(audio.get("mic_array", "")).strip(),
            mic_array_focus=_mic_array_focus(audio.get("mic_array_focus", FOCUS_ALL)),
            bluetooth_speech_output="device" if str(audio.get("bluetooth_speech_output", "")).strip() == "device" else "earphone",
        ),
        vad=VadConfig(**{**vad, "model": resolve(vad["model"])}),
        asr=AsrConfig(
            **{
                **asr,
                "model": resolve(asr["model"]),
                "tokens": resolve(asr["tokens"]),
                "denoise_model": resolve(asr.get("denoise_model", "")),
                **{
                    engine: {lang: resolve(model_dir) for lang, model_dir in asr.get(engine, {}).items()}
                    for engine in DEDICATED_ASR_ENGINES
                },
            }
        ),
        llm=LlmConfig(**raw["llm"]),
        tts=TtsConfig(
            **{
                **tts,
                "model_dir": resolve(tts["model_dir"]),
                "chinese": ChineseTtsConfig(
                    model_dir=resolve(chinese["model_dir"]),
                    speaker_id=int(chinese.get("speaker_id", 0)),
                    speed=float(chinese.get("speed", 1.0)),
                    female_speaker_id=int(chinese.get("female_speaker_id", 138)),
                    male_speaker_id=int(chinese.get("male_speaker_id", 15)),
                    noise_scale=float(chinese.get("noise_scale", 0.667)),
                    noise_scale_w=float(chinese.get("noise_scale_w", 0.8)),
                )
                if chinese
                else None,
            }
        ),
        display=DisplayConfig(
            **{
                **raw["display"],
                "thai_font": resolve(raw["display"].get("thai_font", "")),
                "latin_font": resolve(raw["display"].get("latin_font", "")),
                "arabic_font": resolve(raw["display"].get("arabic_font", "")),
                "devanagari_font": resolve(raw["display"].get("devanagari_font", "")),
                "sinhala_font": resolve(raw["display"].get("sinhala_font", "")),
            }
        ),
        translator=TranslatorConfig(**raw["translator"]),
        power_saving=PowerSavingConfig(**raw.get("power_saving", {})),
        guide=_guide_config(raw.get("guide", {}), resolve),
        security=_security_config(raw.get("security", {}), raw.get("guide", {})),
        report=_report_config(raw.get("report", {}), resolve),
        npu=_npu_config(raw.get("npu", {}), resolve),
    )
    _check_pin("general_pin", config.security.general_pin, allow_empty=True)
    _check_pin("admin_pin", config.security.admin_pin, allow_empty=False)
    if config.security.general_pin and config.security.general_pin == config.security.admin_pin:
        raise ValueError("config.toml の [security] general_pin と admin_pin は、違う番号にしてください")
    try:
        Mode(config.translator.default_partner, config.translator.default_speaker)
    except ValueError as error:
        raise ValueError(f"config.toml の [translator] が正しくありません: {error}") from None
    for lang in {lang for engine in DEDICATED_ASR_ENGINES for lang in asr.get(engine, {})}:
        engines = [f"[asr.{engine}]" for engine in DEDICATED_ASR_ENGINES if lang in asr.get(engine, {})]
        if len(engines) > 1:
            raise ValueError(f"config.toml で、{lang} の音声認識モデルが {' と '.join(engines)} の両方に書かれています")
    return config


def _guide_config(raw: dict, resolve) -> GuideConfig:
    fields = {key: value for key, value in raw.items() if key != "store_pin"}  # store_pin は [security] general_pin に移った
    fields["dir"] = resolve(str(fields.get("dir", GuideConfig.dir)))
    return GuideConfig(**fields)


def _security_config(raw: dict, guide_raw: dict) -> SecurityConfig:
    """[security] を読む。2026-10-03 の最初の版で [guide] store_pin に書いた番号は、general_pin として引き継ぐ。"""
    fields = {key: str(value).strip() for key, value in raw.items()}  # 1234 のように「"」なしで書かれても読めるように
    if "general_pin" not in fields and "store_pin" in guide_raw:
        fields["general_pin"] = str(guide_raw["store_pin"]).strip()
    return SecurityConfig(**fields)


def _check_pin(name: str, pin: str, allow_empty: bool) -> None:
    if (allow_empty and not pin) or (len(pin) == 4 and pin.isascii() and pin.isdigit()):
        return
    hint = "、または空欄（番号を聞かない）" if allow_empty else ""
    raise ValueError(f'config.toml の [security] {name} は、数字 4 つ（例 "1234"）{hint}にしてください')


def _mic_array_focus(value: str) -> str:
    if value not in FOCUSES:
        raise ValueError(f"config.toml の [audio] mic_array_focus は {' / '.join(FOCUSES)} のどちらかにしてください: {value}")
    return value


def parse_device(value: int | str) -> Device:
    """空欄は既定のデバイス、数字はデバイス番号、それ以外はデバイス名の一部として扱う。

    TOML で引用符なしの数字（input_device = 1）を書くと int になるので、そのまま番号として使う。
    """
    if isinstance(value, int):
        return value
    value = value.strip()
    if not value:
        return None
    return int(value) if value.isdigit() else value
