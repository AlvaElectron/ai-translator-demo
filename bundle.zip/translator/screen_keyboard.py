"""画面に出すキーボード（通訳の画面の「文字入力」）: 言語ごとのキーの並びと、押したときの入力（pygame に依存しない）。

打った文字は、物理キーボードと同じ keyboard.TextEntry に渡す。キーを押したことにして KeyPress を作るので、
ローマ字 → ひらがな、2ボル式のハングル、ケドマニー、ЙЦУКЕН の組み立ては、物理キーボードと同じ規則で行われる。

- 日本語・英語・フランス語・ポルトガル語: QWERTY（日本語はローマ字で打つとひらがなになる）
- 韓国語: 2ボル式（QWERTY の位置に字母が並ぶ。Shift で濃音）
- タイ語: ケドマニー（Shift で 2 段目の文字）
- ロシア語: ЙЦУКЕН
- 数字・記号は「?123」で切り替える（どの言語でも同じ。日本語だけ、、。ー？！「」が先頭に並ぶ）
- 中国語・広東語は打てない（空の配列を返す）
"""

from __future__ import annotations

import unicodedata
from dataclasses import dataclass

from .keyboard import (
    _DUBEOLSIK,
    _DUBEOLSIK_SHIFT,
    RUSSIAN_KEYMAP,
    THAI_KEYMAP,
    KeyPress,
    can_type,
    key_press,
)
from .langs import JA, KO, RU, TH, speech_lang

# キーの動き
KEY, SHIFT, SYMBOLS, BACKSPACE, SEND, CLOSE = "key", "shift", "symbols", "backspace", "send", "close"
SYMBOLS_LABEL, LETTERS_LABEL = "?123", "文字"
SEND_LABEL, CLOSE_LABEL, SPACE_LABEL = "送信 Send", "戻る Back", "空白 Space"

# 日本語の句読点などは、字の枠の隅に小さく描かれているので、キーの真ん中に見えるよう、字の形の中心にそろえて描く
CENTERED_LABELS = frozenset("、。ー？！「」")

# 言語ごとの、物理キーの名前の並び（上の段から。1 段目は数字の段）
_LATIN_ROWS = (tuple("1234567890"), tuple("qwertyuiop"), tuple("asdfghjkl"), tuple("zxcvbnm"))
_THAI_ROWS = (
    ("1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "minus", "equal"),
    ("q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "leftbrace", "rightbrace"),
    ("a", "s", "d", "f", "g", "h", "j", "k", "l", "semicolon", "apostrophe"),
    ("z", "x", "c", "v", "b", "n", "m", "comma", "dot", "slash"),
)
_RUSSIAN_ROWS = (
    ("grave", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
    ("q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "leftbrace", "rightbrace"),
    ("a", "s", "d", "f", "g", "h", "j", "k", "l", "semicolon", "apostrophe"),
    ("z", "x", "c", "v", "b", "n", "m", "comma", "dot"),
)
_ROWS = {TH: _THAI_ROWS, RU: _RUSSIAN_ROWS}

# 数字・記号の段（どの言語でも、押すと、その文字を打つ）。日本語は、先頭に、。ー？！「」を並べる
_SYMBOL_ROWS = ("1234567890", "!?@#$%&*()", "-_=+/:;'\"", "~^|\\[]{}<>")
# 日本語: (表示する文字, 押すキーの文字)。ローマ字の規則で、, . - ? ! [ ] は 、。ー？！「」になる
_JA_SYMBOL_ROWS = (
    tuple((c, c) for c in "1234567890"),
    (("、", ","), ("。", "."), ("ー", "-"), ("？", "?"), ("！", "!"), ("「", "["), ("」", "]"), ("(", "("), (")", ")"), ("/", "/")),
    tuple((c, c) for c in "@#$%&*+=:;"),
    tuple((c, c) for c in "_'\"~<>|^\\"),
)
# 下の段の「,」「.」（日本語では、。と表示する）
_COMMA, _PERIOD = (",", ","), (".", ".")
_JA_COMMA, _JA_PERIOD = ("、", ","), ("。", ".")


@dataclass(frozen=True)
class Key:
    label: str
    action: str = KEY
    press: KeyPress | None = None
    # 幅の比（1 = 文字のキー 1 つ分）
    weight: float = 1.0


@dataclass(frozen=True)
class Row:
    keys: tuple[Key, ...]
    # True なら、段の幅いっぱいに並べる（幅の比で分ける）。False なら、文字のキーの幅で、真ん中にそろえる
    fill: bool = False


def text_press(char: str) -> KeyPress:
    """文字そのものを打つ（数字・記号。どの言語の組み立てでも、そのまま入力される）。"""
    return KeyPress("text", char)


def columns(lang: str, symbols: bool = False) -> int:
    """文字のキーの幅を決める、いちばん長い段のキーの数（それより短い段は、真ん中にそろえる）。"""
    lang = speech_lang(lang)
    if symbols or lang not in _ROWS:
        return 10
    return max(len(row) for row in _ROWS[lang])


def layout(lang: str, shift: bool = False, symbols: bool = False) -> tuple[Row, ...]:
    """5 段のキー（文字の 4 段と、下の操作の 1 段）。打てない言語は空。"""
    if not can_type(lang):
        return ()
    lang = speech_lang(lang)  # 北海道弁は日本語のキー配列
    rows = _symbol_rows(lang) if symbols else _letter_rows(lang, shift)
    return (*rows, _bottom_row(lang, symbols))


def label_for(lang: str, name: str, shift: bool) -> str:
    """物理キー name に、その言語の配列で並ぶ文字（Shift のときは Shift を押したときの文字）。"""
    lang = speech_lang(lang)
    if lang == KO and name in _DUBEOLSIK:
        # Shift で濃音（ㅃ ㅉ ㄸ ㄲ ㅆ）と ㅒ ㅖ になる。ほかの字母は、Shift を押しても同じ
        return _DUBEOLSIK_SHIFT.get(name.upper(), _DUBEOLSIK[name]) if shift else _DUBEOLSIK[name]
    if lang == TH and name in THAI_KEYMAP:
        label = THAI_KEYMAP[name][1 if shift else 0]
        # 母音・声調の記号は、単独では読みにくいので、点線の丸（◌）に付けて出す
        return "◌" + label if unicodedata.category(label) == "Mn" else label
    if lang == RU and name in RUSSIAN_KEYMAP:
        letter = RUSSIAN_KEYMAP[name]
        return letter.upper() if shift else letter
    return name.upper() if shift and name.isalpha() else name


def _letter_rows(lang: str, shift: bool) -> tuple[Row, ...]:
    rows = []
    names_rows = _ROWS.get(lang, _LATIN_ROWS)
    for index, names in enumerate(names_rows):
        keys = []
        for name in names:
            # 数字の段は、Shift を押しても数字のまま（記号は「?123」で打つ）。タイ語は、この段にも文字が並ぶ
            digit = name.isdigit() and lang != TH
            label = label_for(lang, name, shift and not digit)
            keys.append(Key(label, KEY, key_press(name, shift and not digit)))
        if index == len(names_rows) - 1:
            # 最後の段: 左に Shift、右に 1 文字消す（残りの幅を半分ずつ）
            side = (columns(lang) - len(keys)) / 2
            keys = [Key("Shift", SHIFT, weight=side), *keys, Key("削除", BACKSPACE, weight=side)]
            rows.append(Row(tuple(keys), fill=True))
        else:
            rows.append(Row(tuple(keys)))
    return tuple(rows)


def _symbol_rows(lang: str) -> tuple[Row, ...]:
    source = _JA_SYMBOL_ROWS if lang == JA else tuple(tuple((c, c) for c in row) for row in _SYMBOL_ROWS)
    rows = []
    for index, pairs in enumerate(source):
        keys = [Key(label, KEY, text_press(char)) for label, char in pairs]
        if index == len(source) - 1:
            keys.append(Key("削除", BACKSPACE, weight=max(1.0, 10 - len(keys))))
            rows.append(Row(tuple(keys), fill=True))
        else:
            rows.append(Row(tuple(keys)))
    return tuple(rows)


def _bottom_row(lang: str, symbols: bool) -> Row:
    comma, period = (_JA_COMMA, _JA_PERIOD) if lang == JA else (_COMMA, _PERIOD)
    return Row(
        (
            Key(LETTERS_LABEL if symbols else SYMBOLS_LABEL, SYMBOLS, weight=1.6),
            Key(comma[0], KEY, text_press(comma[1])),
            Key(SPACE_LABEL, KEY, key_press("space"), weight=3.4),
            Key(period[0], KEY, text_press(period[1])),
            Key(SEND_LABEL, SEND, weight=2.2),
            Key(CLOSE_LABEL, CLOSE, weight=1.6),
        ),
        fill=True,
    )
