"""入力機器（タッチ画面・マウス・キーボード）の見分け方と、イベントの読み方（pygame・evdev に依存しない）。"""

from __future__ import annotations

from dataclasses import dataclass, field

from .keyboard import MODIFIERS, KeyPress, key_press

Taps = list[tuple[int, int]]

# Linux の入力イベントの番号（linux/input-event-codes.h。evdev の無い PC でもテストできるよう、ここに書く）
EV_KEY, EV_REL, EV_ABS, EV_SYN = 1, 2, 3, 0
REL_X, REL_Y = 0, 1
ABS_X, ABS_Y, ABS_MT_POSITION_X, ABS_MT_POSITION_Y, ABS_MT_TRACKING_ID = 0, 1, 0x35, 0x36, 0x39
BTN_LEFT, BTN_TOUCH = 0x110, 0x14A
KEY_A, KEY_Z, KEY_SPACE = 30, 44, 57
TOUCH, MOUSE, KEYBOARD = "touch", "mouse", "keyboard"

# マウスのポインター（矢印）の形。先端が (0, 0)
_POINTER_SHAPE = ((0, 0), (0, 17), (4, 13), (7, 20), (10, 19), (7, 12), (12, 12))
# evdev のキーの名前のうち、別の名前で扱うもの（テンキーの Enter も Enter）
_KEY_ALIASES = {"kpenter": "enter"}


@dataclass
class InputBatch:
    """1回の読み取りで届いた入力。"""

    taps: Taps = field(default_factory=list)
    keys: list[KeyPress] = field(default_factory=list)
    # マウスのポインターが動いた（または消えた）ので、描き直す必要がある
    pointer_moved: bool = False
    quit: bool = False


def classify_device(capabilities: dict) -> set[str]:
    """入力機器の種類（タッチ画面・マウス・キーボード）。capabilities は evdev の InputDevice.capabilities()。

    HDMI の入力（vc4-hdmi）は相対移動を持つが左ボタンが無く、スピーカーフォンの音量ボタンは文字キーが無いので、
    どちらも除く。
    """
    keys = set(capabilities.get(EV_KEY, []))
    rel = set(capabilities.get(EV_REL, []))
    axes = {entry[0] if isinstance(entry, tuple) else entry for entry in capabilities.get(EV_ABS, [])}
    roles = set()
    if {ABS_X, ABS_Y} <= axes or {ABS_MT_POSITION_X, ABS_MT_POSITION_Y} <= axes:
        roles.add(TOUCH)
    if {REL_X, REL_Y} <= rel and BTN_LEFT in keys:
        roles.add(MOUSE)
    if {KEY_A, KEY_Z, KEY_SPACE} <= keys:
        roles.add(KEYBOARD)
    return roles


def key_name(evdev_name) -> str:
    """evdev のキーの名前（"KEY_A"。別名があると一覧）を、KeyPress の名前（"a"）にする。"""
    if isinstance(evdev_name, (list, tuple)):
        evdev_name = evdev_name[0] if evdev_name else ""
    name = str(evdev_name).removeprefix("KEY_").lower()
    return _KEY_ALIASES.get(name, name)


class _DeviceReader:
    """1つの機器のイベントを、タップ・ポインターの移動・キーに変える。"""

    def __init__(self, hub: InputHub, device, roles: set[str]) -> None:
        self._hub = hub
        self._roles = roles
        self._x_range, self._y_range = hub._touch_range(device) if TOUCH in roles else (None, None)
        self._x = self._y = 0
        self._touched = False
        self._dx = self._dy = 0
        self._held: set[str] = set()

    def handle(self, type_: int, code: int, value: int) -> None:
        if type_ == EV_ABS and TOUCH in self._roles:
            if code in (ABS_X, ABS_MT_POSITION_X):
                self._x = value
            elif code in (ABS_Y, ABS_MT_POSITION_Y):
                self._y = value
            elif code == ABS_MT_TRACKING_ID and value >= 0:
                self._touched = True
        elif type_ == EV_REL and MOUSE in self._roles:
            if code == REL_X:
                self._dx += value
            elif code == REL_Y:
                self._dy += value
        elif type_ == EV_KEY:
            self._key(code, value)
        elif type_ == EV_SYN:
            if self._touched:
                # 指が触れたフレームの座標がそろった時点で、1回のタップとして扱う。触ったらポインターは消す
                self._touched = False
                self._hub._set_pointer_visible(False)
                self._hub._tap((_scale(self._x, *self._x_range), _scale(self._y, *self._y_range)))
            if self._dx or self._dy:
                self._hub._move_pointer(self._dx, self._dy)
                self._dx = self._dy = 0

    def _key(self, code: int, value: int) -> None:
        if code == BTN_TOUCH:
            if value == 1 and TOUCH in self._roles:
                self._touched = True
            return
        if code == BTN_LEFT:
            if value == 1 and MOUSE in self._roles:
                self._hub._click()
            return
        if KEYBOARD not in self._roles:
            return
        name = self._hub._key_name(code)
        if name in MODIFIERS:
            if value:
                self._held.add(name)
            else:
                self._held.discard(name)
            return
        if value in (1, 2):  # 押した・押し続けて繰り返した
            shift = bool(self._held & {"leftshift", "rightshift"})
            ctrl = bool(self._held & {"leftctrl", "rightctrl"})
            self._hub._key(key_press(name, shift, ctrl))


def _scale(value: int, low: int, high: int, size: int) -> int:
    if high <= low:
        return 0
    return max(0, min(size - 1, round((value - low) * (size - 1) / (high - low))))
