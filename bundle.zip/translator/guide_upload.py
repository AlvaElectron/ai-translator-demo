"""スマホから「ガイド」の動画を送ってもらう、小さなウェブサーバー（店舗用の「動画の追加・管理」→「スマホから」の画面を開いている間だけ動く）。

- 画面の QR コードには「http://<通訳機の IP>:<ポート>/<合い言葉>/」が入る。合い言葉は開くたびに変わるので、
  画面を見られる人（店舗用の番号を入れた人）だけが送れる。画面を閉じるとサーバーも止まる。
- 送るのは、同じ Wi-Fi（LAN）につないだスマホのブラウザから。ページで動画・入れる場所・題名を選び、PUT で中身をそのまま送る
  （multipart にしないので、大きな動画でもメモリを使わず、少しずつ書ける）。
- 1 度に受け取るのは 1 つだけ（入れている最中に別の動画が来たら、待ってもらう）。
"""

from __future__ import annotations

import html
import json
import logging
import secrets
import socket
import threading
from collections.abc import Callable
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from . import guide_admin
from .guide import display_title

log = logging.getLogger(__name__)

DEFAULT_PORT = 8765
PORT_TRIES = 10
READ_CHUNK = 1024 * 1024
# 断るときに読み捨てる中身の上限（これより大きければ、読まずに切る。スマホのページは、送る前に形式を確かめる）。
# 動画 1 本分まで読み捨てる（空きが足りないときなどに、スマホに理由を伝えるため）
DRAIN_LIMIT = 2 * 1024**3

MSG_NO_NETWORK = "Wi-Fi か LAN につないでください / Connect to Wi-Fi or LAN"
MSG_BUSY = "ほかの動画を入れています。終わってから送ってください / Another video is being added. Try again later"
MSG_RECEIVING = "受け取っています… / Receiving…"


def lan_address() -> str:
    """LAN での自分の IP アドレス（つながっていなければ ""）。UDP の connect は、実際には何も送らない。"""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.connect(("192.0.2.1", 80))
            address = sock.getsockname()[0]
    except OSError:
        return ""
    return "" if address.startswith("127.") or address == "0.0.0.0" else address


def qr_matrix(text: str) -> list[list[bool]] | None:
    """QR コードの白黒（True = 黒）。segno が入っていなければ None（画面には URL だけを出す）。"""
    try:
        import segno
    except ImportError:
        return None
    code = segno.make(text, error="m", micro=False)
    return [[bool(cell) for cell in row] for row in code.matrix]


def page_html(token: str) -> str:
    """スマホに出すページ（日本語・英語）。"""
    options = "".join(
        f'<option value="{html.escape(d.key)}">{html.escape(d.label)} / {html.escape(d.label_en)}</option>'
        for d in guide_admin.DESTINATIONS
    )
    exts = ",".join(sorted(guide_admin.VIDEO_EXTS))
    return f"""<!doctype html>
<html lang="ja"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>コトリア 動画を送る</title>
<style>
body{{font-family:system-ui,-apple-system,"Hiragino Sans","Yu Gothic",sans-serif;margin:0;padding:16px;background:#16191f;color:#eef0f3;line-height:1.5}}
h1{{font-size:20px;margin:0 0 4px}} p.sub{{color:#aab4be;margin:0 0 16px;font-size:14px}}
label{{display:block;margin:14px 0 6px;font-weight:600}} small{{color:#aab4be;font-weight:400}}
input,select,button{{width:100%;box-sizing:border-box;font-size:17px;padding:12px;border-radius:10px;border:1px solid #3a4250;background:#222831;color:#eef0f3}}
button{{background:#2e8c64;border:0;font-weight:700;margin-top:20px}} button:disabled{{background:#3a4250;color:#8892a0}}
progress{{width:100%;height:18px;margin-top:16px}} #msg{{margin-top:12px;font-size:16px;white-space:pre-wrap}}
.err{{color:#ff9a3c}} .ok{{color:#7fd6a8}}
</style></head><body>
<h1>コトリアに動画を送る</h1><p class="sub">Send a video to Kotoria</p>
<label>1. 動画 <small>/ Video ({html.escape(exts)})</small></label>
<input id="file" type="file" accept="video/*,{html.escape(exts)}">
<label>2. 入れる場所 <small>/ Where</small></label>
<select id="dest">{options}</select>
<label>3. 題名 <small>/ Title（画面に出る名前）</small></label>
<input id="title" maxlength="{guide_admin.MAX_TITLE}" placeholder="例: お店の紹介">
<button id="send">送る / Send</button>
<progress id="bar" max="100" value="0" hidden></progress>
<div id="msg"></div>
<script>
const file=document.getElementById('file'), title=document.getElementById('title'), dest=document.getElementById('dest');
const send=document.getElementById('send'), bar=document.getElementById('bar'), msg=document.getElementById('msg');
file.addEventListener('change',()=>{{ if(file.files[0]&&!title.value) title.value=file.files[0].name.replace(/\\.[^.]+$/,'').slice(0,{guide_admin.MAX_TITLE}); }});
function show(text,cls){{ msg.textContent=text; msg.className=cls||''; }}
send.addEventListener('click',()=>{{
  const f=file.files[0];
  if(!f){{ show('動画を選んでください / Choose a video','err'); return; }}
  const ext=(f.name.match(/\\.[^.]+$/)||[''])[0].toLowerCase();
  if(!'{html.escape(exts)}'.split(',').includes(ext)){{ show('{html.escape(guide_admin.MSG_BAD_TYPE)}','err'); return; }}
  if(!title.value.trim()){{ show('題名を入れてください / Enter a title','err'); return; }}
  const q=new URLSearchParams({{dest:dest.value,title:title.value,name:f.name}});
  const x=new XMLHttpRequest();
  x.open('PUT','upload?'+q.toString());
  x.upload.onprogress=e=>{{ if(e.lengthComputable){{ bar.value=Math.round(e.loaded*100/e.total); show('送っています… / Sending… '+bar.value+'%'); }} }};
  x.onload=()=>{{ send.disabled=false; let r={{}}; try{{ r=JSON.parse(x.responseText); }}catch(e){{}}
    if(x.status===200&&r.ok){{ bar.value=100; show('入れました / Added: '+r.title+'\\n続けて送れます / You can send another','ok'); file.value=''; title.value=''; }}
    else show((r.error||('エラー / Error '+x.status)),'err'); }};
  x.onerror=()=>{{ send.disabled=false; show('送れませんでした。同じ Wi-Fi か、コトリアの画面が開いているか確かめてください / Failed to send','err'); }};
  send.disabled=true; bar.hidden=false; bar.value=0; show('送っています… / Sending…');
  x.send(f);
}});
</script></body></html>"""


class UploadServer:
    """スマホから動画を受け取るサーバー。start() で動かし、stop() で止める。"""

    def __init__(
        self,
        root: Path,
        progress: guide_admin.Progress,
        port: int = DEFAULT_PORT,
        checker: Callable[[Path], bool] = guide_admin.check_video,
        address: Callable[[], str] = lan_address,
    ) -> None:
        self._root = Path(root)
        self._progress = progress
        self._port = port
        self._checker = checker
        self._address = address
        self._server: ThreadingHTTPServer | None = None
        self._thread: threading.Thread | None = None
        self._token = ""
        self.url = ""
        self.error = ""

    @property
    def running(self) -> bool:
        return self._server is not None

    def start(self) -> bool:
        """動かす（もう動いていれば何もしない）。URL は self.url、動かせなければ self.error。"""
        if self._server is not None:
            return True
        self.url, self.error = "", ""
        address = self._address()
        if not address:
            self.error = MSG_NO_NETWORK
            return False
        self._token = secrets.token_urlsafe(9)
        handler = self._handler_class()
        for port in range(self._port, self._port + PORT_TRIES):
            try:
                server = ThreadingHTTPServer(("0.0.0.0", port), handler)
            except OSError:
                continue
            server.daemon_threads = True
            self._server = server
            self._thread = threading.Thread(target=server.serve_forever, name="guide-upload", daemon=True)
            self._thread.start()
            self.url = f"http://{address}:{port}/{self._token}/"
            log.info("スマホからの動画の受け取りを始めました: %s", self.url)
            return True
        self.error = "受け取りの準備ができませんでした / Could not start the receiver"
        return False

    def stop(self) -> None:
        server, self._server = self._server, None
        if server is None:
            return
        server.shutdown()
        server.server_close()
        self._token, self.url = "", ""
        log.info("スマホからの動画の受け取りを止めました")

    def _handler_class(self) -> type[BaseHTTPRequestHandler]:
        owner = self

        class Handler(BaseHTTPRequestHandler):
            server_version = "Kotoria"

            def log_message(self, format: str, *args) -> None:  # noqa: A002  標準の書き方に合わせる
                log.debug("upload: " + format, *args)

            def _route(self) -> tuple[str, dict[str, list[str]]]:
                parsed = urlparse(self.path)
                prefix = f"/{owner._token}/"
                if not owner._token or not parsed.path.startswith(prefix):
                    return "", {}
                return parsed.path[len(prefix) :], parse_qs(parsed.query)

            def _send(self, status: int, body: bytes, kind: str) -> None:
                self.send_response(status)
                self.send_header("Content-Type", kind)
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(body)

            def _json(self, status: int, data: dict) -> None:
                self._send(status, json.dumps(data, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

            def _refuse(self, status: int, error: str) -> None:
                """送られてきた中身を読み捨ててから断る（読まずに返すと、スマホ側では「切れた」としか分からない）。"""
                try:
                    left = int(self.headers.get("Content-Length", "0"))
                except ValueError:
                    left = 0
                if 0 < left <= DRAIN_LIMIT:
                    while left > 0:
                        chunk = self.rfile.read(min(READ_CHUNK, left))
                        if not chunk:
                            break
                        left -= len(chunk)
                else:
                    self.close_connection = True
                self._json(status, {"ok": False, "error": error})

            def do_GET(self) -> None:  # noqa: N802  http.server の名前
                name, _query = self._route()
                if name == "" and urlparse(self.path).path == f"/{owner._token}/" and owner._token:
                    self._send(200, page_html(owner._token).encode("utf-8"), "text/html; charset=utf-8")
                else:
                    self._send(404, b"not found", "text/plain")

            def do_PUT(self) -> None:  # noqa: N802
                name, query = self._route()
                if name != "upload":
                    self._refuse(404, "not found")
                    return
                destination = guide_admin.DESTINATION_BY_KEY.get((query.get("dest") or [""])[0])
                title = (query.get("title") or [""])[0]
                filename = (query.get("name") or [""])[0]
                try:
                    length = int(self.headers.get("Content-Length", ""))
                except ValueError:
                    length = -1
                if destination is None or length <= 0:
                    self._refuse(400, guide_admin.MSG_FAILED)
                    return
                try:
                    ext = guide_admin.video_ext(filename)
                    guide_admin.check_room(owner._root, destination, length, title)  # 中身を受け取る前に断れるものは断る
                except guide_admin.GuideAdminError as error:
                    self._refuse(400, str(error))
                    return
                if not owner._progress.start(MSG_RECEIVING):
                    self._refuse(409, MSG_BUSY)
                    return

                def chunks():
                    left = length
                    while left > 0:
                        chunk = self.rfile.read(min(READ_CHUNK, left))
                        if not chunk:
                            break
                        left -= len(chunk)
                        yield chunk

                try:
                    final = guide_admin.store_stream(
                        chunks(), length, owner._root, destination, title, ext, owner._progress, owner._checker
                    )
                except guide_admin.GuideAdminError as error:
                    owner._progress.finish(str(error), error=True)
                    self.close_connection = True  # 読み残しがあるかもしれないので、つなぎ直してもらう
                    self._json(400, {"ok": False, "error": str(error)})
                    return
                except Exception:  # noqa: BLE001  思わぬ失敗でも「入れている最中」のままにしない
                    log.exception("スマホからの動画を入れられませんでした")
                    owner._progress.finish(guide_admin.MSG_FAILED, error=True)
                    self.close_connection = True
                    self._json(500, {"ok": False, "error": guide_admin.MSG_FAILED})
                    return
                shown = display_title(final.name)
                owner._progress.finish(f"入れました / Added: {shown}（{destination.label}）")
                self._json(200, {"ok": True, "title": shown, "where": destination.label})

        return Handler
