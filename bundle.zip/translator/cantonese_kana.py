"""広東語の粤拼（Jyutping）を、日本語話者が読めるカタカナにする（外部ライブラリに依存しない）。

漢字から粤拼への変換は ToJyutping（BSD 2-Clause）で行い、ここでは粤拼の1音節をカタカナにする。
声調は表さない。長い母音（aa、開音節の e・o・i・u など）は「ー」で伸ばし、
-p・-t・-k で終わる入声は「ップ」「ット」「ック」（長い母音の後は プ・ト・ク）、-m は「ム」、-n・-ng は「ン」で書く
（どの子音で終わるかが分かるように。十 sap → サップ、七 cat → チャット、六 luk → ロック、八 baat → バート）。

例: nei5 hou2（你好）→ ネイ ホウ、hoeng1 gong2（香港）→ ヒョン ゴン、gwong2 dung1 waa2（廣東話）→ グォン ドン ワー
"""

from __future__ import annotations

import re
from collections.abc import Iterable

# 声母ごとの ア・イ・ウ・エ・オ段
_ROWS: dict[str, tuple[str, str, str, str, str]] = {
    "": ("ア", "イ", "ウ", "エ", "オ"),
    "b": ("バ", "ビ", "ブ", "ベ", "ボ"),
    "p": ("パ", "ピ", "プ", "ペ", "ポ"),
    "m": ("マ", "ミ", "ム", "メ", "モ"),
    "f": ("ファ", "フィ", "フ", "フェ", "フォ"),
    "d": ("ダ", "ディ", "ドゥ", "デ", "ド"),
    "t": ("タ", "ティ", "トゥ", "テ", "ト"),
    "n": ("ナ", "ニ", "ヌ", "ネ", "ノ"),
    "l": ("ラ", "リ", "ル", "レ", "ロ"),
    "g": ("ガ", "ギ", "グ", "ゲ", "ゴ"),
    "k": ("カ", "キ", "ク", "ケ", "コ"),
    "ng": ("ンガ", "ンギ", "ング", "ンゲ", "ンゴ"),
    "h": ("ハ", "ヒ", "フ", "ヘ", "ホ"),
    "gw": ("グァ", "グィ", "グ", "グェ", "グォ"),
    "kw": ("クァ", "クィ", "ク", "クェ", "クォ"),
    "w": ("ワ", "ウィ", "ウ", "ウェ", "ウォ"),
    "z": ("ジャ", "ジ", "ジュ", "ジェ", "ジョ"),
    "c": ("チャ", "チ", "チュ", "チェ", "チョ"),
    "s": ("サ", "シ", "ス", "セ", "ソ"),
    "j": ("ヤ", "イ", "ユ", "イェ", "ヨ"),
}
_VOWEL_INDEX = {"a": 0, "i": 1, "u": 2, "e": 3, "o": 4}
# 「yu」（書 syu、住 zyu）と「oe」（香 hoeng、想 soeng）は、拗音で書く
_YU = {"": "ユ", "z": "ジュ", "c": "チュ", "s": "シュ", "j": "ユ", "g": "ギュ", "k": "キュ", "h": "ヒュ",
       "l": "リュ", "n": "ニュ", "d": "デュ", "t": "テュ", "gw": "グュ", "kw": "キュ"}
_YO = {"": "ヨ", "z": "ジョ", "c": "チョ", "s": "ショ", "j": "ヨ", "g": "ギョ", "k": "キョ", "h": "ヒョ",
       "l": "リョ", "n": "ニョ", "d": "ディョ", "t": "ティョ"}
_CODAS = {"": "", "i": "イ", "u": "ウ", "m": "ム", "n": "ン", "ng": "ン", "p": "プ", "t": "ト", "k": "ク"}
# 開音節のときに伸ばす母音（広東語の開音節は長母音）
_LONG_OPEN = frozenset({"aa", "e", "o", "oe", "i", "u", "yu"})

_SYLLABLE = re.compile(r"^(gw|kw|ng|[bpmfdtnlgkhwzcsj])?(aa|oe|eo|yu|a|e|i|o|u)(ng|[iumnptk])?([1-6])?$")


def jyutping_to_kana(syllable: str) -> str | None:
    """粤拼の1音節（例: "hoeng1"）をカタカナにする。粤拼でなければ None。"""
    syllable = syllable.strip().lower()
    toneless = syllable.rstrip("123456")
    if toneless == "m":  # 唔
        return "ム"
    if toneless == "ng":  # 五・吳
        return "ン"
    match = _SYLLABLE.match(syllable)
    if not match:
        return None
    initial, nucleus, coda = match.group(1) or "", match.group(2), match.group(3) or ""
    if nucleus == "yu":
        head = _YU.get(initial, _ROWS[initial][2])
    elif nucleus == "oe":
        head = _YO.get(initial, _ROWS[initial][4])
    elif nucleus == "eo":
        head = _ROWS[initial][4]  # 水 seoi → ソイ、出 ceot → チョット
    elif nucleus == "u" and coda in ("ng", "k"):
        head = _ROWS[initial][4]  # 東 dung → ドン、六 luk → ロック（[oŋ]・[ok] と発音する）
    else:
        head = _ROWS[initial][_VOWEL_INDEX[nucleus[0]]]
    long_mark = "ー" if nucleus == "aa" or (not coda and nucleus in _LONG_OPEN) else ""
    # 短い母音の後の入声は、つまる音（ッ）を入れる
    stop = "ッ" if coda in ("p", "t", "k") and not long_mark else ""
    return head + long_mark + stop + _CODAS[coda]


def to_katakana(pairs: Iterable[tuple[str, str | None]]) -> list[str]:
    """(文字, 粤拼) の並び（ToJyutping.get_jyutping_list の結果）を、音節ごとのカタカナにする。

    粤拼のない文字（句読点・数字・英字）はそのまま残す。
    """
    tokens = []
    for char, jyutping in pairs:
        if not jyutping:
            tokens.append(char)
            continue
        # 1文字に複数の読みがあるときは空白で区切られている。最初の読みを使う
        kana = jyutping_to_kana(jyutping.split()[0])
        tokens.append(kana if kana else char)
    return tokens
