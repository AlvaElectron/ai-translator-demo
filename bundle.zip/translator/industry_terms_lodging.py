"""宿泊施設（ホテル・旅館・民宿・ゲストハウス）の用語集のデータ。書き方は industry_terms_food.py の先頭を参照。"""

from __future__ import annotations

# 宿泊施設に共通
LODGING_COMMON = (
    ("チェックイン", "체크인", "check-in", "入住", "入住", "เช็คอิน", "check-in", "заселение", "check-in", True),
    ("チェックアウト", "체크아웃", "check-out", "退房", "退房", "เช็คเอาท์", "check-out", "выезд", "check-out", True),
    ("ご宿泊", "숙박", "your stay", "住宿", "住宿", "การเข้าพัก", "votre séjour", "проживание", "hospedagem", True),
    ("ご予約のお名前", "예약하신 성함", "the name on the reservation", "预约的姓名", "預約姓名", "ชื่อที่ใช้จอง", "nom de la réservation", "имя, на которое сделана бронь", "nome da reserva", True),
    ("パスポート", "여권", "passport", "护照", "護照", "หนังสือเดินทาง", "passeport", "паспорт", "passaporte"),
    ("宿泊者名簿", "숙박자 명부", "guest registration form", "住宿登记表", "住宿登記表", "แบบฟอร์มลงทะเบียนผู้เข้าพัก", "fiche de renseignements", "анкета гостя", "ficha de hóspede", True),
    ("宿泊税", "숙박세", "accommodation tax", "住宿税", "住宿稅", "ภาษีที่พัก", "", "налог на проживание", "taxa de hospedagem", True),
    ("朝食", "조식", "breakfast", "早餐", "早餐", "อาหารเช้า", "petit-déjeuner", "завтрак", "café da manhã", True),
    ("夕食", "석식", "dinner", "晚餐", "晚餐", "อาหารเย็น", "dîner", "ужин", "jantar", True),
    ("素泊まり", "숙박만", "a stay without meals", "仅住宿不含餐", "只住宿不包餐", "พักอย่างเดียวไม่รวมอาหาร", "séjour sans repas", "проживание без питания", "hospedagem sem refeições", True),
    ("一泊二食付き", "1박 2식 포함", "one night with dinner and breakfast", "一晚含两餐", "一晚包兩餐", "พัก 1 คืน รวมอาหารเย็นและเช้า", "une nuit avec dîner et petit-déjeuner", "одна ночь с ужином и завтраком", "uma noite com jantar e café da manhã", True),
    ("お部屋の鍵", "방 열쇠", "the room key", "房间钥匙", "房間鎖匙", "กุญแจห้อง", "clé de la chambre", "ключ от номера", "chave do quarto", True),
    ("ルームキー", "룸 키", "room key", "房卡", "房卡", "คีย์การ์ด", "clé de chambre", "ключ-карта", "chave do quarto", True),
    ("大浴場", "대욕장", "the large public bath", "大浴场", "大浴場", "ห้องอาบน้ำรวมขนาดใหญ่", "grand bain public", "большая общественная баня", "banho público", True),
    ("貴重品", "귀중품", "valuables", "贵重物品", "貴重物品", "ของมีค่า", "objets de valeur", "ценные вещи", "objetos de valor", True),
    ("お荷物をお預かりします", "짐을 맡아 드리겠습니다", "we will keep your luggage", "我们帮您保管行李", "我哋幫你保管行李", "ขอรับฝากสัมภาระไว้ให้ค่ะ", "nous gardons vos bagages", "мы сохраним ваш багаж", "guardaremos a sua bagagem", True),
    ("お部屋の準備ができ次第", "객실 준비가 되는 대로", "as soon as the room is ready", "房间一准备好", "房間一準備好", "เมื่อห้องพร้อมแล้ว", "dès que la chambre est prête", "как только номер будет готов", "assim que o quarto estiver pronto"),
    ("Wi-Fiのパスワード", "와이파이 비밀번호", "the Wi-Fi password", "Wi-Fi 密码", "Wi-Fi 密碼", "รหัสผ่าน Wi-Fi", "mot de passe du Wi-Fi", "пароль от Wi-Fi", "senha do Wi-Fi", True),
    ("非常口", "비상구", "emergency exit", "紧急出口", "緊急出口", "ทางออกฉุกเฉิน", "sortie de secours", "запасной выход", "saída de emergência"),
    ("門限", "통금 시간", "curfew", "门禁时间", "門禁時間", "เวลาปิดประตู", "heure limite de rentrée", "комендантский час", "horário limite de entrada", True),
)

HOTEL = (
    ("シングルルーム", "싱글룸", "single room", "单人间", "單人房", "ห้องเดี่ยว", "chambre simple", "одноместный номер", "quarto individual", True),
    ("ダブルルーム", "더블룸", "double room", "大床房", "雙人大床房", "ห้องเตียงคู่", "chambre double", "двухместный номер с одной кроватью", "quarto de casal", True),
    ("ツインルーム", "트윈룸", "twin room", "双床房", "雙床房", "ห้องเตียงแฝด", "chambre à lits jumeaux", "двухместный номер с двумя кроватями", "quarto com duas camas", True),
    ("禁煙ルーム", "금연 객실", "non-smoking room", "禁烟房", "禁煙房", "ห้องปลอดบุหรี่", "chambre non-fumeur", "номер для некурящих", "quarto para não fumantes", True),
    ("喫煙ルーム", "흡연 객실", "smoking room", "吸烟房", "吸煙房", "ห้องสูบบุหรี่ได้", "chambre fumeur", "номер для курящих", "quarto para fumantes", True),
    ("モーニングコール", "모닝콜", "wake-up call", "叫醒服务", "晨呼服務", "บริการโทรปลุก", "réveil téléphonique", "звонок-будильник", "serviço de despertar", True),
    ("ルームサービス", "룸서비스", "room service", "客房送餐服务", "客房服務", "รูมเซอร์วิส", "service d'étage", "обслуживание номеров", "serviço de quarto", True),
    ("コンシェルジュ", "컨시어지", "concierge", "礼宾", "禮賓", "คอนเซียร์จ", "concierge", "консьерж", "concierge", True),
    ("フロント", "프런트 데스크", "front desk", "前台", "前台", "แผนกต้อนรับ", "réception", "стойка регистрации", "recepção", True),
    ("ベルボーイ", "벨보이", "bellboy", "行李员", "行李員", "พนักงานยกกระเป๋า", "bagagiste", "носильщик", "carregador de malas"),
    ("アメニティ", "어메니티", "amenities", "客房用品", "客房用品", "ของใช้ในห้องพัก", "articles de toilette", "туалетные принадлежности", "amenidades", True),
    ("バスタオル", "목욕 수건", "bath towel", "浴巾", "浴巾", "ผ้าขนหนูอาบน้ำ", "serviette de bain", "банное полотенце", "toalha de banho", True),
    ("ドライヤー", "헤어드라이어", "hair dryer", "吹风机", "風筒", "ไดร์เป่าผม", "sèche-cheveux", "фен", "secador de cabelo", True),
    ("加湿器", "가습기", "humidifier", "加湿器", "加濕機", "เครื่องเพิ่มความชื้น", "humidificateur", "увлажнитель воздуха", "umidificador", True),
    ("延泊", "숙박 연장", "extending your stay", "延长住宿", "延長住宿", "การพักต่อ", "prolonger le séjour", "продление проживания", "prorrogar a estadia", True),
    ("宅配便", "택배", "parcel delivery", "快递", "速遞", "พัสดุ", "colis", "посылка", "encomenda", True),
    ("自動精算機", "자동 정산기", "automatic payment machine", "自助结算机", "自助結賬機", "เครื่องชำระเงินอัตโนมัติ", "borne de paiement automatique", "автомат для оплаты", "máquina de pagamento automático", True),
)

RYOKAN = (
    ("旅館", "료칸", "ryokan (Japanese inn)", "日式旅馆", "日式旅館", "เรียวกัง (โรงแรมสไตล์ญี่ปุ่น)", "ryokan (auberge japonaise)", "рёкан (японская гостиница)", "ryokan (pousada tradicional japonesa)", True),
    ("仲居", "객실 담당 직원", "the staff member who looks after your room", "负责您客房的服务员", "負責你房間嘅服務員", "พนักงานดูแลห้องพัก", "personne qui s'occupe de votre chambre", "сотрудница, обслуживающая ваш номер", "atendente responsável pelo seu quarto"),
    ("女将", "여관 안주인", "the proprietress of the inn", "老板娘", "老闆娘", "เจ้าของเรียวกัง (โอคามิ)", "patronne de l'auberge", "хозяйка гостиницы", "proprietária da pousada", True),
    ("浴衣", "유카타", "yukata (cotton kimono)", "浴衣", "浴衣", "ยูกาตะ (กิโมโนผ้าฝ้าย)", "yukata (kimono de coton)", "юката (хлопковое кимоно)", "yukata (quimono de algodão)", True),
    ("布団", "이불", "futon bedding", "被褥", "被鋪", "ฟูก", "futon", "футон", "futon", True),
    ("布団を敷きます", "이불을 깔아 드리겠습니다", "I will lay out your futon", "我来为您铺被褥", "我嚟幫你鋪被", "ขอปูที่นอนให้นะคะ", "je vais préparer votre futon", "я постелю вам футон", "vou arrumar o seu futon", True),
    ("畳", "다다미", "tatami mat", "榻榻米", "榻榻米", "เสื่อทาทามิ", "tatami", "татами", "tatame", True),
    ("スリッパ", "슬리퍼", "slippers", "拖鞋", "拖鞋", "รองเท้าแตะ", "chaussons", "тапочки", "chinelos", True),
    ("畳の上ではスリッパを脱いでください", "다다미 위에서는 슬리퍼를 벗어 주세요", "please take off your slippers on the tatami", "在榻榻米上请脱掉拖鞋", "喺榻榻米上面請除咗拖鞋", "กรุณาถอดรองเท้าแตะเมื่อขึ้นเสื่อทาทามิค่ะ", "veuillez enlever vos chaussons sur le tatami", "на татами снимайте, пожалуйста, тапочки", "tire os chinelos ao pisar no tatame"),
    ("温泉", "온천", "hot spring", "温泉", "溫泉", "ออนเซ็น (บ่อน้ำพุร้อน)", "source thermale (onsen)", "горячий источник (онсэн)", "fonte termal (onsen)", True),
    ("露天風呂", "노천탕", "open-air bath", "露天温泉", "露天溫泉", "บ่ออาบน้ำกลางแจ้ง", "bain en plein air", "открытая купальня", "banho ao ar livre", True),
    ("貸切風呂", "대절 욕탕", "private bath for rent", "包场浴池", "包場浴池", "ห้องอาบน้ำส่วนตัวแบบเหมา", "bain privatif", "частная купальня", "banho privativo reservado", True),
    ("入れ墨", "문신", "tattoos", "纹身", "紋身", "รอยสัก", "tatouages", "татуировки", "tatuagens", True),
    ("タオル", "수건", "towel", "毛巾", "毛巾", "ผ้าขนหนู", "serviette", "полотенце", "toalha"),
    ("かけ流し", "원천 흘려보내기 방식", "hot spring water flowing freely without recirculation", "源泉直接流入", "源泉直接流入", "น้ำพุร้อนไหลตลอดไม่หมุนเวียน", "eau de source qui s'écoule en continu", "вода течёт напрямую из источника", "água termal que corre sem recirculação"),
    ("懐石料理", "가이세키 요리", "kaiseki cuisine (multi-course Japanese meal)", "怀石料理", "懷石料理", "อาหารไคเซกิ", "cuisine kaiseki (repas japonais en plusieurs services)", "кайсэки (многосерийный японский ужин)", "culinária kaiseki (refeição japonesa em vários pratos)", True),
    ("お食事の時間", "식사 시간", "meal time", "用餐时间", "用餐時間", "เวลารับประทานอาหาร", "heure du repas", "время приёма пищи", "horário da refeição", True),
    ("朝食は7時からです", "조식은 7시부터입니다", "breakfast is from 7 o'clock", "早餐从7点开始", "早餐由七點開始", "อาหารเช้าเริ่มตั้งแต่ 7 โมงเช้าค่ะ", "le petit-déjeuner commence à 7 heures", "завтрак с 7 часов", "o café da manhã é a partir das 7 horas"),
)

MINPAKU = (
    ("民宿", "민박", "minshuku (family-run guesthouse)", "民宿", "民宿", "มินชูกุ (บ้านพักแบบครอบครัว)", "minshuku (pension familiale)", "минсюку (семейная гостиница)", "minshuku (pousada familiar)", True),
    ("民泊", "민박", "a private home rental", "民宿（私人住宅出租）", "民宿（私人住宅出租）", "ที่พักส่วนตัว (บ้านเช่า)", "location d'un logement privé", "аренда частного жилья", "aluguel de casa particular", True),
    ("ご家族で経営しています", "가족이 운영하고 있습니다", "this is run by our family", "这里由我们一家人经营", "呢度由我哋一家人經營", "เราเป็นธุรกิจครอบครัวค่ะ", "nous sommes une entreprise familiale", "мы семейное заведение", "somos um negócio de família"),
    ("ゴミの分別", "쓰레기 분리배출", "sorting trash", "垃圾分类", "垃圾分類", "การแยกขยะ", "tri des déchets", "сортировка мусора", "separação do lixo", True),
    ("燃えるゴミ", "타는 쓰레기", "burnable trash", "可燃垃圾", "可燃垃圾", "ขยะเผาได้", "déchets combustibles", "горючие отходы", "lixo combustível", True),
    ("燃えないゴミ", "타지 않는 쓰레기", "non-burnable trash", "不可燃垃圾", "不可燃垃圾", "ขยะเผาไม่ได้", "déchets non combustibles", "негорючие отходы", "lixo não combustível", True),
    ("資源ゴミ", "재활용 쓰레기", "recyclable trash", "可回收垃圾", "可回收垃圾", "ขยะรีไซเคิล", "déchets recyclables", "вторсырьё", "lixo reciclável", True),
    ("夜10時以降はお静かに", "밤 10시 이후에는 조용히 해 주세요", "please be quiet after 10 p.m.", "晚上十点以后请保持安静", "晚上十點後請保持安靜", "หลัง 4 ทุ่มกรุณาเงียบด้วยค่ะ", "veuillez faire silence après 22 heures", "после 22:00 просим соблюдать тишину", "por favor, silêncio depois das 22 horas", True),
    ("近隣の方のご迷惑", "이웃에 폐가 되는 일", "disturbing the neighbors", "打扰邻居", "騷擾鄰居", "รบกวนเพื่อนบ้าน", "déranger les voisins", "беспокойство соседей", "incomodar os vizinhos"),
    ("鍵の受け渡し", "열쇠 전달", "handing over the key", "交接钥匙", "交收鎖匙", "การส่งมอบกุญแจ", "remise des clés", "передача ключа", "entrega da chave", True),
    ("キーボックス", "키 박스", "key box", "钥匙盒", "鎖匙箱", "กล่องใส่กุญแจ", "boîte à clés", "сейф для ключей", "caixa de chaves", True),
)

GUESTHOUSE = (
    ("ゲストハウス", "게스트하우스", "guesthouse", "青年旅舍", "旅舍", "เกสต์เฮาส์", "auberge de jeunesse", "гостевой дом", "hostel", True),
    ("ドミトリー", "도미토리", "dormitory room", "多人间宿舍", "多人房", "ห้องรวม (โดมิทอรี)", "dortoir", "общий номер", "quarto compartilhado", True),
    ("共用スペース", "공용 공간", "common area", "公共区域", "公共空間", "พื้นที่ส่วนกลาง", "espace commun", "общая зона", "área comum", True),
    ("共用キッチン", "공용 주방", "shared kitchen", "公用厨房", "公用廚房", "ครัวส่วนกลาง", "cuisine commune", "общая кухня", "cozinha compartilhada", True),
    ("シャワールーム", "샤워실", "shower room", "淋浴间", "沖涼房", "ห้องอาบน้ำ", "salle de douche", "душевая", "banheiro com chuveiro", True),
    ("洗濯機", "세탁기", "washing machine", "洗衣机", "洗衣機", "เครื่องซักผ้า", "", "стиральная машина", "máquina de lavar", True),
    ("乾燥機", "건조기", "dryer", "烘干机", "乾衣機", "เครื่องอบผ้า", "sèche-linge", "сушильная машина", "secadora", True),
    ("コインランドリー", "코인 세탁방", "coin laundry", "投币洗衣房", "自助洗衣店", "ร้านซักผ้าหยอดเหรียญ", "laverie automatique", "прачечная самообслуживания", "lavanderia de moedas", True),
    ("ロッカー", "사물함", "locker", "储物柜", "儲物櫃", "ล็อกเกอร์", "casier", "шкафчик", "armário", True),
    ("2段ベッド", "2층 침대", "bunk bed", "双层床", "雙層床", "เตียงสองชั้น", "lits superposés", "двухъярусная кровать", "beliche", True),
    ("男女別の部屋", "남녀 분리 객실", "separate rooms for men and women", "男女分开的房间", "男女分開嘅房間", "ห้องแยกชายหญิง", "chambre réservée aux hommes ou aux femmes", "", "quartos separados para homens e mulheres", True),
    ("ベッドのリネン", "침대 시트", "bed linen", "床单被套", "床單被套", "ผ้าปูที่นอน", "linge de lit", "постельное бельё", "roupa de cama", True),
    ("消灯時間", "소등 시간", "lights-out time", "熄灯时间", "熄燈時間", "เวลาปิดไฟ", "heure d'extinction des lumières", "время отбоя", "horário de apagar as luzes", True),
    ("イベント", "이벤트", "events", "活动", "活動", "กิจกรรม", "événements", "мероприятия", "eventos"),
)
