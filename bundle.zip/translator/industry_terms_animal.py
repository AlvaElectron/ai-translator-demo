"""動物カフェ（猫・犬・猛禽類・うさぎ・爬虫類・小動物・小鳥・カワウソ・ブタ）の用語集のデータ（2026-11-24）。
書き方は industry_terms_food.py の先頭を参照。

1 文字の語（猫・犬・鳥・蛇 など）は、ほかの言葉の中にも見つかって見本に混ざるので入れない（「猫カフェ」のように 2 文字以上で）。
「噛む」「引っかく」は、お客様が言う形（噛まれた・引っかかれた）で入れる。
"""

from __future__ import annotations

ANIMAL_COMMON = (
    ("動物カフェ", "동물 카페", "animal café", "动物咖啡馆", "動物咖啡店", "คาเฟ่สัตว์", "café animalier", "кафе с животными", "café de animais", True),
    ("触れ合い", "교감 체험", "interacting with the animals", "互动体验", "互動體驗", "การเล่นกับสัตว์", "contact avec les animaux", "общение с животными", "interação com os animais", True),
    ("手指消毒", "손 소독", "hand sanitizing", "手部消毒", "手部消毒", "การฆ่าเชื้อมือ", "désinfection des mains", "дезинфекция рук", "higienização das mãos", True),
    ("消毒液", "소독액", "hand sanitizer", "消毒液", "消毒液", "เจลล้างมือ", "gel désinfectant", "антисептик", "álcool em gel", True),
    ("おやつ", "간식", "animal treats", "零食", "小食", "ขนมสัตว์", "friandises pour les animaux", "лакомство для животных", "petiscos para os animais", True),
    ("抱っこ", "안아 보기", "holding the animal", "抱抱", "攬住", "การอุ้ม", "prendre l'animal dans les bras", "взять на руки", "pegar no colo", True),
    ("フラッシュ撮影", "플래시 촬영", "flash photography", "闪光灯拍摄", "閃光燈影相", "การถ่ายรูปด้วยแฟลช", "photo avec flash", "съёмка со вспышкой", "fotografia com flash", True),
    ("動物アレルギー", "동물 알레르기", "animal allergy", "动物过敏", "動物敏感", "อาการแพ้สัตว์", "allergie aux animaux", "аллергия на животных", "alergia a animais", True),
    ("保護者同伴", "보호자 동반", "accompanied by a parent or guardian", "需监护人陪同", "需要家長陪同", "ต้องมีผู้ปกครองมาด้วย", "accompagné d'un parent", "в сопровождении взрослых", "acompanhado de um responsável", True),
    ("コロコロ", "돌돌이 클리너", "lint roller", "粘毛滚筒", "黐毛轆", "ลูกกลิ้งเก็บขน", "rouleau adhésif", "липкий ролик для одежды", "rolo tira-pelos", True),
    ("噛まれた", "물렸어요", "I was bitten", "被咬了", "俾咬咗", "โดนกัด", "j'ai été mordu", "меня укусили", "fui mordido", True),
    ("引っかかれた", "할퀴었어요", "I was scratched", "被抓伤了", "俾抓傷咗", "โดนข่วน", "j'ai été griffé", "меня поцарапали", "fui arranhado", True),
    ("体調", "컨디션", "the animal's health", "身体状况", "身體狀況", "สุขภาพของสัตว์", "état de santé", "самочувствие", "estado de saúde", True),
    ("入れ替え制", "교대제", "taking turns", "轮流制", "輪流制", "ระบบผลัดเปลี่ยน", "par roulement", "посменно", "sistema de revezamento", True),
    ("延長料金", "연장 요금", "extension fee", "延长费用", "延長收費", "ค่าต่อเวลา", "supplément de prolongation", "плата за продление", "taxa de prorrogação", True),
    ("ワンドリンク付き", "음료 1잔 포함", "one drink included", "含一杯饮品", "包一杯飲品", "รวมเครื่องดื่ม 1 แก้ว", "une boisson comprise", "один напиток включён", "uma bebida inclusa", True),
)

CAT = (
    ("猫カフェ", "고양이 카페", "cat café", "猫咖啡馆", "貓咖啡店", "คาเฟ่แมว", "bar à chats", "котокафе", "café de gatos", True),
    ("猫じゃらし", "고양이 낚싯대", "cat teaser toy", "逗猫棒", "逗貓棒", "ไม้ล่อแมว", "canne à pêche pour chat", "дразнилка для кошек", "varinha para gatos", True),
    ("キャットタワー", "캣타워", "cat tower", "猫爬架", "貓爬架", "คอนโดแมว", "arbre à chat", "кошачий комплекс", "arranhador vertical", True),
    ("しっぽ", "꼬리", "tail", "尾巴", "尾巴", "หาง", "queue", "хвост", "rabo", True),
    ("ひげ", "수염", "whiskers", "胡须", "鬚", "หนวด", "moustaches", "усы", "bigodes", True),
)
DOG = (
    ("犬カフェ", "강아지 카페", "dog café", "狗狗咖啡馆", "狗狗咖啡店", "คาเฟ่หมา", "café canin", "кафе с собаками", "café de cachorros", True),
    ("リード", "목줄", "leash", "牵引绳", "狗帶", "สายจูง", "laisse", "поводок", "guia", True),
    ("お散歩", "산책", "walk", "散步", "散步", "การพาเดินเล่น", "promenade", "прогулка", "passeio", True),
    ("首輪", "목걸이", "collar", "项圈", "頸圈", "ปลอกคอ", "collier", "ошейник", "coleira", True),
    ("小型犬", "소형견", "small dog", "小型犬", "細狗", "สุนัขพันธุ์เล็ก", "petit chien", "маленькая собака", "cachorro pequeno", True),
    ("大型犬", "대형견", "large dog", "大型犬", "大狗", "สุนัขพันธุ์ใหญ่", "grand chien", "крупная собака", "cachorro grande", True),
)
RAPTOR = (
    ("猛禽類カフェ", "맹금류 카페", "bird of prey café", "猛禽咖啡馆", "猛禽咖啡店", "คาเฟ่นกล่าเหยื่อ", "café des rapaces", "кафе с хищными птицами", "café de aves de rapina", True),
    ("フクロウカフェ", "부엉이 카페", "owl café", "猫头鹰咖啡馆", "貓頭鷹咖啡店", "คาเฟ่นกฮูก", "café des chouettes", "кафе с совами", "café de corujas", True),
    ("猛禽類", "맹금류", "birds of prey", "猛禽", "猛禽", "นกล่าเหยื่อ", "rapaces", "хищные птицы", "aves de rapina", True),
    ("フクロウ", "올빼미", "owl", "猫头鹰", "貓頭鷹", "นกฮูก", "chouette", "сова", "coruja", True),
    ("ミミズク", "부엉이", "horned owl", "角鸮", "角鴞", "นกเค้าแมวหูยาว", "hibou", "филин", "corujão", True),
    ("タカ", "매", "hawk", "鹰", "鷹", "เหยี่ยว", "faucon", "ястреб", "gavião", True),
    ("ハヤブサ", "송골매", "falcon", "隼", "隼", "เหยี่ยวเพเรกริน", "faucon pèlerin", "сокол", "falcão", True),
    ("グローブ", "장갑", "falconry glove", "护手套", "護手套", "ถุงมือรับนก", "gant de fauconnier", "перчатка сокольника", "luva de falcoaria", True),
)
RABBIT = (
    ("うさぎカフェ", "토끼 카페", "rabbit café", "兔子咖啡馆", "兔仔咖啡店", "คาเฟ่กระต่าย", "café des lapins", "кафе с кроликами", "café de coelhos", True),
    ("うさぎ", "토끼", "rabbit", "兔子", "兔仔", "กระต่าย", "lapin", "кролик", "coelho", True),
    ("牧草", "건초", "hay", "牧草", "牧草", "หญ้าแห้ง", "foin", "сено", "feno", True),
    ("ケージ", "케이지", "cage", "笼子", "籠", "กรง", "cage", "клетка", "gaiola", True),
)
REPTILE = (
    ("爬虫類カフェ", "파충류 카페", "reptile café", "爬虫类咖啡馆", "爬蟲類咖啡店", "คาเฟ่สัตว์เลื้อยคลาน", "café des reptiles", "кафе с рептилиями", "café de répteis", True),
    ("爬虫類", "파충류", "reptiles", "爬虫类", "爬蟲類", "สัตว์เลื้อยคลาน", "reptiles", "рептилии", "répteis", True),
    ("ヘビ", "뱀", "snake", "蛇", "蛇", "งู", "serpent", "змея", "cobra", True),
    ("トカゲ", "도마뱀", "lizard", "蜥蜴", "蜥蜴", "กิ้งก่า", "lézard", "ящерица", "lagarto", True),
    ("カメ", "거북", "turtle", "乌龟", "龜", "เต่า", "tortue", "черепаха", "tartaruga", True),
    ("ヤモリ", "도마뱀붙이", "gecko", "壁虎", "壁虎", "ตุ๊กแก", "gecko", "геккон", "lagartixa", True),
    ("脱皮", "탈피", "shedding skin", "蜕皮", "脫皮", "การลอกคราบ", "mue", "линька", "troca de pele", True),
)
SMALL_ANIMAL = (
    ("小動物カフェ", "소동물 카페", "small animal café", "小动物咖啡馆", "小動物咖啡店", "คาเฟ่สัตว์เล็ก", "café des petits animaux", "кафе с маленькими животными", "café de pequenos animais", True),
    ("ハリネズミ", "고슴도치", "hedgehog", "刺猬", "刺蝟", "เม่นแคระ", "hérisson", "ёжик", "ouriço", True),
    ("チンチラ", "친칠라", "chinchilla", "龙猫", "龍貓", "ชินชิล่า", "chinchilla", "шиншилла", "chinchila", True),
    ("モモンガ", "날다람쥐", "flying squirrel", "鼯鼠", "飛鼠", "กระรอกบิน", "écureuil volant", "летяга", "esquilo-voador", True),
    ("ハムスター", "햄스터", "hamster", "仓鼠", "倉鼠", "แฮมสเตอร์", "hamster", "хомяк", "hamster", True),
    ("手袋", "장갑", "gloves", "手套", "手套", "ถุงมือ", "gants", "перчатки", "luvas", True),
)
BIRD = (
    ("小鳥カフェ", "작은 새 카페", "bird café", "小鸟咖啡馆", "雀仔咖啡店", "คาเฟ่นกเล็ก", "café des oiseaux", "кафе с птичками", "café de passarinhos", True),
    ("インコ", "잉꼬", "parakeet", "鹦鹉", "鸚鵡", "นกแก้ว", "perruche", "попугай", "periquito", True),
    ("オカメインコ", "왕관앵무", "cockatiel", "玄凤鹦鹉", "玄鳳鸚鵡", "นกค็อกคาเทล", "calopsitte", "корелла", "calopsita", True),
    ("文鳥", "문조", "Java sparrow", "文鸟", "文鳥", "นกกระจอกชวา", "padda", "рисовка", "pardal-de-java", True),
)
OTTER = (
    ("カワウソカフェ", "수달 카페", "otter café", "水獭咖啡馆", "水獺咖啡店", "คาเฟ่นาก", "café des loutres", "кафе с выдрами", "café de lontras", True),
    ("カワウソ", "수달", "otter", "水獭", "水獺", "นาก", "loutre", "выдра", "lontra", True),
    ("水槽", "수조", "water tank", "水槽", "水缸", "ตู้น้ำ", "bassin", "аквариум", "tanque de água", True),
    ("握手", "악수", "handshake", "握手", "握手", "การจับมือ", "poignée de main", "рукопожатие", "aperto de mão", True),
)
PIG = (
    ("ブタカフェ", "미니돼지 카페", "pig café", "猪咖啡馆", "豬仔咖啡店", "คาเฟ่หมู", "café des cochons", "кафе с минипигами", "café de porquinhos", True),
    ("マイクロブタ", "마이크로 돼지", "micro pig", "迷你猪", "迷你豬", "หมูแคระ", "cochon miniature", "минипиг", "miniporco", True),
    ("ブランケット", "담요", "blanket", "毯子", "毯", "ผ้าห่ม", "couverture", "плед", "manta", True),
    ("スリッパ", "슬리퍼", "slippers", "拖鞋", "拖鞋", "รองเท้าแตะ", "chaussons", "тапочки", "chinelos", True),
)
