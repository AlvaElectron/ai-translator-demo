"""言語ごとの国旗（ボタンや文の左に出す小さな旗）。

フォントの絵文字に頼らず、pygame の図形で描く（実機のフォントに国旗が無くても同じに見えるように）。
4 倍の大きさで描いてから縮めるので、斜めの線や円もなめらかになる。縦横の比は 3:2。

- 日本語 = 日本、韓国語 = 韓国、英語 = 左にイギリス・右にアメリカ（2026-11-22。11-22 夜に 1 枚にくっつけるのをやめ、別々の 2 枚の旗にした）、中国語（簡体字）= 中国、中国語（台湾の繁体字）= 台湾、
  広東語 = 香港、タイ語 = タイ、フランス語 = フランス、ロシア語 = ロシア、ポルトガル語 = ブラジル、
  北海道弁 = 北海道旗（青い地に七稜星）、大阪弁 = 大阪市旗ふうの旗（澪標）、福岡弁 = 福岡市旗ふうの旗（太陽）
- 2026-11-14 に足した言語: スペイン語 = スペイン、ドイツ語 = ドイツ、イタリア語 = イタリア、オランダ語 = オランダ、ポーランド語 = ポーランド、
  クロアチア語 = クロアチア、スロバキア語 = スロバキア、スロベニア語 = スロベニア、ハンガリー語 = ハンガリー、エストニア語 = エストニア、
  ラトビア語 = ラトビア、リトアニア語 = リトアニア、ブルガリア語 = ブルガリア、インドネシア語 = インドネシア、ベトナム語 = ベトナム、
  アラビア語 = アラブ首長国連邦（形が単純で、日本に来る湾岸諸国の人が多い）、ヒンディー語 = インド、
  2026-11-15: トルコ語 = トルコ、チェコ語 = チェコ、ウクライナ語 = ウクライナ、ネパール語 = ネパール（明るい灰色の地に描く）、
  ペルシア語 = イラン、ウズベク語 = ウズベキスタン、シンハラ語 = スリランカ（紋章は単純な形）
  2026-11-21: アゼルバイジャン語 = アゼルバイジャン、ベラルーシ語 = ベラルーシ、ベンガル語 = バングラデシュ、
  カタルーニャ語 = カタルーニャ（州の旗）、バスク語 = バスク（州の旗）、ヘブライ語 = イスラエル、アルメニア語 = アルメニア、
  ジョージア語 = ジョージア、カザフ語 = カザフスタン、クメール語 = カンボジア、マレー語 = マレーシア、ミャンマー語 = ミャンマー、
  セルビア語 = セルビア、スワヒリ語 = タンザニア、ウルドゥー語 = パキスタン、タガログ語・セブアノ語 = フィリピン、
  ジャワ語 = インドネシア、グジャラート語・マラーティー語・パンジャブ語・タミル語・テルグ語・マラヤーラム語 = インド
- 英語の旗（イギリスとアメリカの 2 枚）は _SIDE_BY_SIDE_FLAGS で決める。1 枚の旗にするときは、そこから消して _FLAG_DRAWERS に足す
"""

from __future__ import annotations

import math
from functools import lru_cache

import pygame

# 旗の名前（言語のコードと同じ。中国語の台湾の旗だけ "zh-hant"）
JP, KR, US, CN, TW, HK, TH, FR, RU, BR = "ja", "ko", "en", "zh", "zh-hant", "yue", "th", "fr", "ru", "pt"
HOKKAIDO, OSAKA, FUKUOKA, NAGOYA, KYOTO = "hok", "osa", "fuk", "nag", "kyo"
HIROSHIMA, OKINAWA, TOHOKU, KAGOSHIMA, TOSA = "hir", "oki", "toh", "kag", "tos"
FLAG_NAMES = (JP, KR, US, CN, TW, HK, TH, FR, RU, BR, HOKKAIDO, OSAKA, FUKUOKA, NAGOYA, KYOTO,
              HIROSHIMA, OKINAWA, TOHOKU, KAGOSHIMA, TOSA,
              "es", "de", "it", "nl", "pl", "hr", "sk", "sl", "hu", "et", "lv", "lt", "bg", "id", "vi", "ar", "hi",
              "tr", "cs", "uk", "ne", "fa", "uz", "si",
              "az", "be", "bn", "ca", "eu", "he", "hy", "ka", "kk", "km", "ms", "my", "sr", "sw", "tl", "ur")
# ほかの言語と同じ旗を使う言語（インドの諸言語はインド、ジャワ語はインドネシア、セブアノ語はフィリピン）
_SHARED_FLAGS = {"gu": "hi", "ml": "hi", "mr": "hi", "pa": "hi", "ta": "hi", "te": "hi", "jv": "id", "ceb": "tl"}

ASPECT = (3, 2)
SUPERSAMPLE = 4
RED, WHITE, BLUE, BLACK = (205, 38, 52), (255, 255, 255), (36, 62, 140), (20, 20, 20)
BORDER = (120, 126, 138)


def flag_name(lang: str, traditional: bool = False) -> str:
    """言語のコードに対応する旗の名前（中国語を台湾の繁体字で表示しているときは台湾の旗）。"""
    return TW if lang == CN and traditional else _SHARED_FLAGS.get(lang, lang)


def _star(cx: float, cy: float, radius: float, turn: float = -90.0, points: int = 5) -> list[tuple[float, float]]:
    """星の形の頂点。turn は最初の頂点の向き（度。-90 = 真上）。"""
    inner = radius * (0.382 if points == 5 else 0.5)
    result = []
    for i in range(points * 2):
        r = radius if i % 2 == 0 else inner
        angle = math.radians(turn + i * 180 / points)
        result.append((cx + r * math.cos(angle), cy + r * math.sin(angle)))
    return result


def _fill(surface: pygame.Surface, color, rect: tuple[float, float, float, float], u: float) -> None:
    x, y, w, h = rect
    pygame.draw.rect(surface, color, pygame.Rect(round(x * u), round(y * u), round(w * u) + 1, round(h * u) + 1))


def _poly(surface: pygame.Surface, color, points, u: float) -> None:
    pygame.draw.polygon(surface, color, [(x * u, y * u) for x, y in points])


def _disc(surface: pygame.Surface, color, cx: float, cy: float, radius: float, u: float) -> None:
    pygame.draw.circle(surface, color, (round(cx * u), round(cy * u)), max(1, round(radius * u)))


def _japan(s: pygame.Surface, u: float) -> None:
    s.fill(WHITE)
    _disc(s, RED, 1.5, 1.0, 0.6, u)


def _korea(s: pygame.Surface, u: float) -> None:
    """太極旗: 白地に、真ん中の太極（赤と青）と、四すみの卦（乾・坤・坎・離）。"""
    s.fill(WHITE)
    cx, cy, r = 1.5, 1.0, 0.5
    # 太極: 赤が上、青が下。仕切りの線は旗の対角線（右上と左下を結ぶ向き）に傾ける
    tilt = math.atan2(-2, 3)
    _disc(s, BLUE, cx, cy, r, u)
    upper = [(cx + r * math.cos(tilt - math.pi + math.pi * i / 48), cy + r * math.sin(tilt - math.pi + math.pi * i / 48)) for i in range(49)]
    _poly(s, RED, upper, u)
    dx, dy = (r / 2) * math.cos(tilt), (r / 2) * math.sin(tilt)
    _disc(s, BLUE, cx + dx, cy + dy, r / 2, u)  # 赤い側にくい込む青
    _disc(s, RED, cx - dx, cy - dy, r / 2, u)  # 青い側にくい込む赤
    # 四すみの卦（三本の棒）。棒は旗の中心と角を結ぶ線に直角で、中心に向かって 3 本並ぶ。
    # 左上 = 乾（━ ━ ━）、右下 = 坤（╌ ╌ ╌）、右上 = 坎（╌ ━ ╌）、左下 = 離（━ ╌ ━）。╌ は真ん中が切れた棒
    thick, gap, length, split, distance = 0.1, 0.065, 0.54, 0.12, 1.02
    unit = math.hypot(3, 2)
    for sx, sy, pattern in ((-1, -1, "###"), (1, 1, "..."), (1, -1, ".#."), (-1, 1, "#.#")):
        ax, ay = sx * 3 / unit, sy * 2 / unit  # 中心から角へ向かう向き
        bx, by = -ay, ax  # 棒の長さの向き（ax, ay に直角）
        px, py = cx + distance * ax, cy + distance * ay
        for index, kind in enumerate(pattern):
            offset = (index - 1) * (thick + gap)
            mx, my = px + offset * ax, py + offset * ay
            spans = ((-length / 2, length / 2),) if kind == "#" else ((-length / 2, -split / 2), (split / 2, length / 2))
            for start, end in spans:
                corners = [
                    (mx + bx * a + ax * c, my + by * a + ay * c)
                    for a, c in ((start, -thick / 2), (end, -thick / 2), (end, thick / 2), (start, thick / 2))
                ]
                _poly(s, BLACK, corners, u)


def _usa(s: pygame.Surface, u: float) -> None:
    stripe = 2 / 13
    for i in range(13):
        _fill(s, RED if i % 2 == 0 else WHITE, (0, i * stripe, 3, stripe), u)
    canton_w, canton_h = 1.2, stripe * 7
    _fill(s, BLUE, (0, 0, canton_w, canton_h), u)
    for row in range(4):
        for col in range(5 if row % 2 == 0 else 4):
            x = 0.12 + col * 0.225 + (0.1125 if row % 2 else 0)
            _disc(s, WHITE, x, 0.12 + row * 0.2, 0.045, u)


def _uk(s: pygame.Surface, u: float) -> None:
    """イギリス: 紺の地に、白と赤の斜めの十字（聖アンドリュー・聖パトリック）と、白い縁の赤い十字（聖ジョージ）。"""
    navy, red = (1, 33, 105), (200, 16, 46)
    s.fill(navy)
    for a, b in (((0, 0), (3, 2)), ((0, 2), (3, 0))):
        pygame.draw.line(s, WHITE, (a[0] * u, a[1] * u), (b[0] * u, b[1] * u), max(1, round(0.4 * u)))
        pygame.draw.line(s, red, (a[0] * u, a[1] * u), (b[0] * u, b[1] * u), max(1, round(0.13 * u)))
    _fill(s, WHITE, (1.27, 0, 0.46, 2), u)
    _fill(s, WHITE, (0, 0.77, 3, 0.46), u)
    _fill(s, red, (1.36, 0, 0.28, 2), u)
    _fill(s, red, (0, 0.86, 3, 0.28), u)


def _china(s: pygame.Surface, u: float) -> None:
    s.fill(RED)
    yellow = (255, 222, 0)
    _poly(s, yellow, _star(0.5, 0.5, 0.3), u)
    for x, y, turn in ((1.0, 0.2, -70), (1.2, 0.4, -30), (1.2, 0.7, 10), (1.0, 0.9, 40)):
        _poly(s, yellow, _star(x, y, 0.1, turn), u)


def _taiwan(s: pygame.Surface, u: float) -> None:
    s.fill(RED)
    _fill(s, BLUE, (0, 0, 1.5, 1.0), u)
    cx, cy = 0.75, 0.5
    _poly(s, WHITE, _star(cx, cy, 0.34, -90, 12), u)
    _disc(s, BLUE, cx, cy, 0.17, u)
    _disc(s, WHITE, cx, cy, 0.13, u)


def _hongkong(s: pygame.Surface, u: float) -> None:
    s.fill(RED)
    cx, cy = 1.5, 1.0
    for i in range(5):
        a = math.radians(-90 + i * 72)
        # 五枚の花びら（円を少しずらして重ねる）。中心に向かって細くなるよう、外側に円を置く
        _disc(s, WHITE, cx + 0.2 * math.cos(a), cy + 0.2 * math.sin(a), 0.17, u)
    _disc(s, RED, cx, cy, 0.06, u)


def _thailand(s: pygame.Surface, u: float) -> None:
    s.fill(RED)
    _fill(s, WHITE, (0, 1 / 3, 3, 4 / 3), u)
    _fill(s, (36, 40, 100), (0, 2 / 3, 3, 2 / 3), u)


def _france(s: pygame.Surface, u: float) -> None:
    _fill(s, BLUE, (0, 0, 1.0, 2), u)
    _fill(s, WHITE, (1.0, 0, 1.0, 2), u)
    _fill(s, RED, (2.0, 0, 1.0, 2), u)


def _russia(s: pygame.Surface, u: float) -> None:
    _fill(s, WHITE, (0, 0, 3, 2 / 3), u)
    _fill(s, (0, 57, 166), (0, 2 / 3, 3, 2 / 3), u)
    _fill(s, (213, 43, 30), (0, 4 / 3, 3, 2 / 3), u)


def _brazil(s: pygame.Surface, u: float) -> None:
    """ブラジル: 緑の地に黄色のひし形、青い円と白い帯。"""
    s.fill((0, 155, 58))
    _poly(s, (254, 221, 0), [(1.5, 0.17), (2.78, 1.0), (1.5, 1.83), (0.22, 1.0)], u)
    cx, cy, radius = 1.5, 1.0, 0.5
    layer = pygame.Surface(s.get_size(), pygame.SRCALPHA)
    _disc(layer, (0, 39, 118), cx, cy, radius, u)
    band = pygame.Surface(s.get_size(), pygame.SRCALPHA)
    # 白い帯は、円の中を左下から右上へ、ゆるく弧を描く
    points = [(cx - 0.5 + 1.0 * t / 20, cy + 0.12 - 0.34 * math.sin(math.pi * t / 20 * 0.62 + 0.1) + 0.0) for t in range(21)]
    pygame.draw.lines(band, WHITE, False, [(x * u, y * u) for x, y in points], max(2, round(0.085 * u)))
    clip = pygame.Surface(s.get_size(), pygame.SRCALPHA)
    _disc(clip, WHITE, cx, cy, radius, u)
    band.blit(clip, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    layer.blit(band, (0, 0))
    s.blit(layer, (0, 0))


def _horizontal(*colors: tuple[int, int, int], weights: tuple[float, ...] | None = None):
    """横縞の旗（上から colors の順。weights は帯の太さの比）を描く関数を作る。"""
    weights = weights or (1.0,) * len(colors)
    total = sum(weights)

    def draw(s: pygame.Surface, u: float) -> None:
        top = 0.0
        for color, weight in zip(colors, weights):
            height = 2 * weight / total
            _fill(s, color, (0, top, 3, height), u)
            top += height

    return draw


def _vertical(*colors: tuple[int, int, int]):
    """縦縞の旗（左から colors の順。帯は同じ太さ）を描く関数を作る。"""

    def draw(s: pygame.Surface, u: float) -> None:
        width = 3 / len(colors)
        for i, color in enumerate(colors):
            _fill(s, color, (i * width, 0, width, 2), u)

    return draw


def _with_shield(stripes, shield):
    """横縞の上に、左寄りの盾（紋章を単純にしたもの）を重ねる旗（スロバキア・スロベニア・クロアチア）。"""

    def draw(s: pygame.Surface, u: float) -> None:
        stripes(s, u)
        shield(s, u)

    return draw


def _shield_outline(s: pygame.Surface, u: float, cx: float, top: float, width: float, height: float, color) -> list[tuple[float, float]]:
    points = [(cx - width / 2, top), (cx + width / 2, top), (cx + width / 2, top + height * 0.6), (cx, top + height), (cx - width / 2, top + height * 0.6)]
    _poly(s, color, points, u)
    return points


def _slovakia_shield(s: pygame.Surface, u: float) -> None:
    """スロバキアの盾（赤い盾に白い二重十字、下に青い三つの丘）を単純にしたもの。"""
    cx, top, w, h = 1.05, 0.45, 0.8, 1.1
    _shield_outline(s, u, cx, top - 0.04, w + 0.08, h + 0.08, WHITE)
    _shield_outline(s, u, cx, top, w, h, (238, 28, 37))
    _fill(s, WHITE, (cx - 0.05, top + 0.12, 0.1, 0.62), u)
    _fill(s, WHITE, (cx - 0.22, top + 0.25, 0.44, 0.08), u)
    _fill(s, WHITE, (cx - 0.3, top + 0.45, 0.6, 0.08), u)
    for dx in (-0.2, 0.0, 0.2):
        _disc(s, (11, 78, 162), cx + dx, top + 0.86, 0.13, u)


def _slovenia_shield(s: pygame.Surface, u: float) -> None:
    """スロベニアの盾（青い盾に白い山と、黄色い三つの星）を単純にしたもの（旗の左上に置く）。"""
    cx, top, w, h = 0.8, 0.28, 0.5, 0.66
    _shield_outline(s, u, cx, top - 0.03, w + 0.06, h + 0.06, (237, 28, 36))
    _shield_outline(s, u, cx, top, w, h, (0, 92, 165))
    _poly(s, WHITE, [(cx - 0.2, top + 0.45), (cx - 0.07, top + 0.27), (cx, top + 0.36), (cx + 0.07, top + 0.27), (cx + 0.2, top + 0.45)], u)
    for dx, dy in ((-0.1, 0.08), (0.1, 0.08), (0.0, 0.15)):
        _poly(s, (255, 221, 0), _star(cx + dx, top + dy, 0.045, points=6), u)


def _croatia_shield(s: pygame.Surface, u: float) -> None:
    """クロアチアの盾（赤と白の市松模様）を単純にしたもの（旗の中央に置く）。"""
    cx, top, size = 1.5, 0.45, 0.13
    for row in range(5):
        for col in range(5):
            color = (255, 0, 0) if (row + col) % 2 == 0 else WHITE
            _fill(s, color, (cx - 2.5 * size + col * size, top + row * size, size, size), u)


def _uae(s: pygame.Surface, u: float) -> None:
    """アラブ首長国連邦: 緑・白・黒の横縞と、左の赤い縦の帯（アラビア語の旗として使う）。"""
    _horizontal((0, 115, 47), WHITE, BLACK)(s, u)
    _fill(s, (255, 0, 0), (0, 0, 0.75, 2), u)


def _india(s: pygame.Surface, u: float) -> None:
    """インド: サフラン・白・緑の横縞と、真ん中の紺の法輪（24 本の輻）。"""
    _horizontal((255, 153, 51), WHITE, (19, 136, 8))(s, u)
    navy = (0, 0, 128)
    cx, cy, radius = 1.5, 1.0, 0.27
    pygame.draw.circle(s, navy, (round(cx * u), round(cy * u)), round(radius * u), max(1, round(0.04 * u)))
    for i in range(24):
        angle = math.radians(i * 15)
        pygame.draw.line(s, navy, (cx * u, cy * u), ((cx + radius * math.cos(angle)) * u, (cy + radius * math.sin(angle)) * u), max(1, round(0.015 * u)))
    _disc(s, navy, cx, cy, 0.05, u)


def _crescent(s: pygame.Surface, u: float, cx: float, cy: float, radius: float, shift: float, color, background) -> None:
    """三日月（color の円に、少しずらした background の円を重ねる）。"""
    _disc(s, color, cx, cy, radius, u)
    _disc(s, background, cx + shift, cy, radius * 0.8, u)


def _turkey(s: pygame.Surface, u: float) -> None:
    """トルコ: 赤い地に、白い三日月と星。"""
    red = (227, 10, 23)
    s.fill(red)
    _crescent(s, u, 1.05, 1.0, 0.5, 0.13, WHITE, red)
    _poly(s, WHITE, _star(1.62, 1.0, 0.17, turn=180), u)


def _czech(s: pygame.Surface, u: float) -> None:
    """チェコ: 上が白、下が赤、左から真ん中まで青い三角形。"""
    _horizontal(WHITE, (215, 20, 26))(s, u)
    _poly(s, (17, 69, 126), [(0, 0), (1.5, 1.0), (0, 2)], u)


def _nepal(s: pygame.Surface, u: float) -> None:
    """ネパール: 長方形ではない旗（二つの三角形を重ねた形。青い縁、赤い地、白い月と太陽）を、明るい灰色の地に描く。"""
    s.fill((225, 228, 232))
    blue, crimson = (0, 56, 147), (220, 20, 60)
    for outline, color in ((0.07, blue), (0.0, crimson)):
        _poly(s, color, [(0.8 + outline, 0.08 + outline * 1.4), (2.1 - outline * 2.6, 0.95 - outline), (0.8 + outline, 0.95 - outline)], u)
        _poly(s, color, [(0.8 + outline, 0.78 + outline * 1.4), (2.1 - outline * 2.6, 1.92 - outline), (0.8 + outline, 1.92 - outline)], u)
    _crescent(s, u, 1.12, 0.62, 0.16, -0.06, WHITE, crimson)
    _poly(s, WHITE, _star(1.12, 1.5, 0.18, points=12), u)


def _iran(s: pygame.Surface, u: float) -> None:
    """イラン: 緑・白・赤の横縞と、真ん中の赤い紋章（単純な形）。"""
    _horizontal((35, 159, 64), WHITE, (218, 0, 0))(s, u)
    red = (218, 0, 0)
    pygame.draw.circle(s, red, (round(1.5 * u), round(1.0 * u)), round(0.2 * u), max(1, round(0.05 * u)))
    _fill(s, red, (1.47, 0.78, 0.06, 0.44), u)


def _uzbekistan(s: pygame.Surface, u: float) -> None:
    """ウズベキスタン: 青・白・緑の横縞（間に細い赤）と、左上の白い三日月と星。"""
    blue = (0, 153, 181)
    _horizontal(blue, WHITE, (30, 181, 58))(s, u)
    _fill(s, (206, 17, 38), (0, 2 / 3 - 0.03, 3, 0.06), u)
    _fill(s, (206, 17, 38), (0, 4 / 3 - 0.03, 3, 0.06), u)
    _crescent(s, u, 0.35, 0.33, 0.22, 0.08, WHITE, blue)
    for i in range(3):
        _poly(s, WHITE, _star(0.75 + i * 0.2, 0.33, 0.06), u)


def _sri_lanka(s: pygame.Surface, u: float) -> None:
    """スリランカ: 黄色の縁、左に緑とオレンジの縦の帯、右に赤茶の地と黄色の獅子（単純な形）。"""
    s.fill((255, 190, 41))
    _fill(s, (0, 83, 78), (0.1, 0.1, 0.35, 1.8), u)
    _fill(s, (255, 126, 0), (0.45, 0.1, 0.35, 1.8), u)
    maroon = (141, 32, 41)
    _fill(s, maroon, (0.9, 0.1, 2.0, 1.8), u)
    _disc(s, (255, 190, 41), 1.9, 1.0, 0.42, u)
    _fill(s, (255, 190, 41), (1.55, 1.2, 0.7, 0.35), u)


def _vietnam(s: pygame.Surface, u: float) -> None:
    s.fill((218, 37, 29))
    _poly(s, (255, 255, 0), _star(1.5, 1.0, 0.6), u)


_SPAIN = _horizontal((170, 21, 27), (241, 191, 0), (170, 21, 27), weights=(1, 2, 1))
_GERMANY = _horizontal(BLACK, (221, 0, 0), (255, 206, 0))
_ITALY = _vertical((0, 146, 70), WHITE, (206, 43, 55))
_NETHERLANDS = _horizontal((174, 28, 40), WHITE, (33, 70, 139))
_POLAND = _horizontal(WHITE, (220, 20, 60))
_HUNGARY = _horizontal((206, 41, 57), WHITE, (71, 112, 80))
_ESTONIA = _horizontal((0, 114, 206), BLACK, WHITE)
_LATVIA = _horizontal((158, 48, 57), WHITE, (158, 48, 57), weights=(2, 1, 2))
_LITHUANIA = _horizontal((253, 185, 19), (0, 106, 68), (193, 39, 45))
_BULGARIA = _horizontal(WHITE, (0, 150, 110), (214, 38, 18))
_INDONESIA = _horizontal((206, 17, 38), WHITE)
_SLOVAKIA = _with_shield(_horizontal(WHITE, (11, 78, 162), (238, 28, 37)), _slovakia_shield)
_SLOVENIA = _with_shield(_horizontal(WHITE, (0, 92, 165), (237, 28, 36)), _slovenia_shield)
_CROATIA = _with_shield(_horizontal((255, 0, 0), WHITE, (23, 23, 150)), _croatia_shield)


def _hokkaido(s: pygame.Surface, u: float) -> None:
    """北海道旗: 青い地に、赤い七稜星（白い縁どり）。"""
    s.fill((0, 60, 150))
    _poly(s, WHITE, _star(1.5, 1.0, 0.82, points=7), u)
    _poly(s, (205, 38, 52), _star(1.5, 1.0, 0.6, points=7), u)


def _osaka(s: pygame.Surface, u: float) -> None:
    """大阪（大阪市旗ふう）: 青い地に、白い澪標（水路の目印の杭）。"""
    s.fill((0, 70, 150))
    _fill(s, WHITE, (1.4, 0.3, 0.2, 1.4), u)
    _fill(s, WHITE, (1.05, 0.55, 0.9, 0.14), u)
    _fill(s, WHITE, (1.05, 0.95, 0.9, 0.14), u)
    _fill(s, WHITE, (0.9, 1.4, 1.2, 0.14), u)


def _fukuoka(s: pygame.Surface, u: float) -> None:
    """福岡（福岡市旗ふう）: 白い地に、青い太陽（輪と放射状の光）。"""
    s.fill(WHITE)
    blue = (0, 80, 160)
    for i in range(8):
        angle = math.radians(i * 45)
        _poly(
            s,
            blue,
            [
                (1.5 + 0.55 * math.cos(angle - 0.12), 1.0 + 0.55 * math.sin(angle - 0.12)),
                (1.5 + 0.9 * math.cos(angle), 1.0 + 0.9 * math.sin(angle)),
                (1.5 + 0.55 * math.cos(angle + 0.12), 1.0 + 0.55 * math.sin(angle + 0.12)),
            ],
            u,
        )
    _disc(s, blue, 1.5, 1.0, 0.45, u)
    _disc(s, WHITE, 1.5, 1.0, 0.25, u)


def _nagoya(s: pygame.Surface, u: float) -> None:
    """名古屋（名古屋市章の丸八ふう）: 白い地に、えんじ色の輪と「八」。"""
    s.fill(WHITE)
    red = (150, 30, 45)
    _disc(s, red, 1.5, 1.0, 0.78, u)
    _disc(s, WHITE, 1.5, 1.0, 0.62, u)
    # 「八」: 上が近く、下に開く 2 本の払い
    _poly(s, red, [(1.29, 0.6), (1.43, 0.6), (1.24, 1.36), (1.06, 1.36)], u)
    _poly(s, red, [(1.71, 0.6), (1.57, 0.6), (1.76, 1.36), (1.94, 1.36)], u)


def _kyoto(s: pygame.Surface, u: float) -> None:
    """京都（京紫の旗ふう）: 京紫の地に、白い六角形の輪と、中に白い丸。"""
    purple = (100, 40, 120)
    s.fill(purple)
    hexagon = lambda r: [(1.5 + r * math.cos(math.radians(60 * i - 90)), 1.0 + r * math.sin(math.radians(60 * i - 90))) for i in range(6)]  # noqa: E731
    _poly(s, WHITE, hexagon(0.72), u)
    _poly(s, purple, hexagon(0.56), u)
    _disc(s, WHITE, 1.5, 1.0, 0.2, u)


# --- 2026-11-25 に足した方言の印（本物の県旗・市旗ではなく、その土地を表す簡単な絵） ---
def _hiroshima(s: pygame.Surface, u: float) -> None:
    """広島（宮島の鳥居ふう）: 白い地に、朱色の鳥居（上の反った笠木・貫・2 本の柱）。"""
    s.fill(WHITE)
    red = (215, 55, 40)
    _poly(s, red, [(0.55, 0.38), (2.45, 0.38), (2.3, 0.56), (0.7, 0.56)], u)  # 笠木（両端が少し上がった形）
    _fill(s, red, (0.85, 0.8, 1.3, 0.12), u)  # 貫
    _fill(s, red, (1.02, 0.56, 0.16, 1.1), u)  # 柱
    _fill(s, red, (1.82, 0.56, 0.16, 1.1), u)
    _fill(s, red, (1.44, 0.56, 0.12, 0.24), u)  # 額束


def _okinawa(s: pygame.Surface, u: float) -> None:
    """沖縄（県旗ふう）: 白い地に、赤い輪と、中に白い丸。"""
    s.fill(WHITE)
    _disc(s, (200, 30, 40), 1.5, 1.0, 0.7, u)
    _disc(s, WHITE, 1.5, 1.0, 0.5, u)


def _tohoku(s: pygame.Surface, u: float) -> None:
    """東北（仙台。伊達の兜の三日月ふう）: 紺の地に、上が開いた金の三日月。"""
    navy = (25, 35, 80)
    s.fill(navy)
    _disc(s, (225, 180, 50), 1.5, 0.95, 0.7, u)
    _disc(s, navy, 1.5, 0.7, 0.66, u)


def _kagoshima(s: pygame.Surface, u: float) -> None:
    """鹿児島（桜島ふう）: 空と海の地に、灰色の山と白い噴煙。"""
    _horizontal((120, 180, 230), (120, 180, 230), (20, 80, 150))(s, u)
    _poly(s, (95, 95, 105), [(0.45, 1.45), (1.25, 0.75), (1.75, 0.75), (2.55, 1.45)], u)
    _disc(s, WHITE, 1.5, 0.55, 0.22, u)
    _disc(s, WHITE, 1.78, 0.4, 0.18, u)


def _tosa(s: pygame.Surface, u: float) -> None:
    """土佐（高知の海と太陽ふう）: 青い海の地に、黄色い太陽と白い波 2 本。"""
    s.fill((10, 95, 150))
    _disc(s, (250, 200, 40), 1.5, 0.7, 0.42, u)
    _fill(s, WHITE, (0.3, 1.25, 2.4, 0.12), u)
    _fill(s, WHITE, (0.6, 1.55, 1.8, 0.12), u)


# --- 2026-11-21 に足した言語の旗（紋章・模様は単純な形） ---
def _azerbaijan(s: pygame.Surface, u: float) -> None:
    """アゼルバイジャン: 青・赤・緑の横縞と、真ん中の白い三日月と八つの角の星。"""
    red = (239, 51, 64)
    _horizontal((0, 181, 226), red, (80, 158, 47))(s, u)
    _crescent(s, u, 1.4, 1.0, 0.3, 0.08, WHITE, red)
    _poly(s, WHITE, _star(1.78, 1.0, 0.13, points=8), u)


def _belarus(s: pygame.Surface, u: float) -> None:
    """ベラルーシ: 赤（上 2/3）と緑の横縞、左の白い帯に赤い模様（ひし形）。"""
    _horizontal((200, 49, 62), (0, 122, 61), weights=(2.0, 1.0))(s, u)
    _fill(s, WHITE, (0, 0, 0.33, 2), u)
    for i in range(8):
        cy = 0.125 + i * 0.25
        _poly(s, (200, 49, 62), [(0.165, cy - 0.1), (0.27, cy), (0.165, cy + 0.1), (0.06, cy)], u)


def _bangladesh(s: pygame.Surface, u: float) -> None:
    """バングラデシュ: 緑の地に、少し左寄りの赤い円。"""
    s.fill((0, 106, 78))
    _disc(s, (244, 42, 65), 1.35, 1.0, 0.6, u)


def _catalonia(s: pygame.Surface, u: float) -> None:
    """カタルーニャ（カタルーニャ語）: 黄色の地に赤い 4 本の横縞。"""
    s.fill((252, 221, 9))
    for i in range(4):
        _fill(s, (218, 18, 26), (0, (2 * i + 1) * 2 / 9, 3, 2 / 9), u)


def _philippines(s: pygame.Surface, u: float) -> None:
    """フィリピン（タガログ語・セブアノ語）: 青と赤の横縞と、左の白い三角形に黄色の太陽と星。"""
    _horizontal((0, 56, 168), (206, 17, 38))(s, u)
    _poly(s, WHITE, [(0, 0), (1.73, 1.0), (0, 2)], u)
    yellow = (252, 209, 22)
    _poly(s, yellow, _star(0.55, 1.0, 0.24, points=8), u)
    _disc(s, yellow, 0.55, 1.0, 0.12, u)
    for x, y in ((0.13, 0.2), (0.13, 1.8), (1.45, 1.0)):
        _poly(s, yellow, _star(x, y, 0.08), u)


def _basque(s: pygame.Surface, u: float) -> None:
    """バスク（バスク語）: 赤い地に、緑の斜めの十字と白い十字。"""
    s.fill((213, 43, 30))
    green = (0, 154, 68)
    pygame.draw.line(s, green, (0, 0), (3 * u, 2 * u), max(1, round(0.28 * u)))
    pygame.draw.line(s, green, (0, 2 * u), (3 * u, 0), max(1, round(0.28 * u)))
    _fill(s, WHITE, (1.38, 0, 0.24, 2), u)
    _fill(s, WHITE, (0, 0.88, 3, 0.24), u)


def _israel(s: pygame.Surface, u: float) -> None:
    """イスラエル（ヘブライ語）: 白い地に青い 2 本の横縞と、真ん中の青いダビデの星（線の三角形 2 つ）。"""
    s.fill(WHITE)
    blue = (0, 56, 184)
    _fill(s, blue, (0, 0.2, 3, 0.3), u)
    _fill(s, blue, (0, 1.5, 3, 0.3), u)
    width = max(1, round(0.07 * u))
    for turn in (-90, 90):
        points = [(1.5 + 0.42 * math.cos(math.radians(turn + i * 120)), 1.0 + 0.42 * math.sin(math.radians(turn + i * 120))) for i in range(3)]
        pygame.draw.polygon(s, blue, [(x * u, y * u) for x, y in points], width)


def _georgia(s: pygame.Surface, u: float) -> None:
    """ジョージア: 白い地に赤い大きな十字と、四隅の小さな赤い十字。"""
    s.fill(WHITE)
    red = (255, 0, 0)
    _fill(s, red, (1.3, 0, 0.4, 2), u)
    _fill(s, red, (0, 0.8, 3, 0.4), u)
    for cx, cy in ((0.65, 0.4), (2.35, 0.4), (0.65, 1.6), (2.35, 1.6)):
        _fill(s, red, (cx - 0.05, cy - 0.2, 0.1, 0.4), u)
        _fill(s, red, (cx - 0.2, cy - 0.05, 0.4, 0.1), u)


def _kazakhstan(s: pygame.Surface, u: float) -> None:
    """カザフスタン: 空色の地に、金色の太陽と鷲（単純な形）と、左の金色の模様の帯。"""
    s.fill((0, 175, 202))
    gold = (254, 197, 0)
    _poly(s, gold, _star(1.55, 0.8, 0.42, points=32), u)
    _disc(s, (0, 175, 202), 1.55, 0.8, 0.3, u)
    _disc(s, gold, 1.55, 0.8, 0.25, u)
    _poly(s, gold, [(0.95, 1.25), (1.55, 1.45), (2.15, 1.25), (1.55, 1.65)], u)
    _fill(s, gold, (0.12, 0.1, 0.1, 1.8), u)


def _cambodia(s: pygame.Surface, u: float) -> None:
    """カンボジア（クメール語）: 青・赤・青の横縞と、真ん中の白いアンコール・ワット（単純な形）。"""
    _horizontal((3, 46, 161), (224, 0, 37), (3, 46, 161), weights=(1.0, 2.0, 1.0))(s, u)
    _fill(s, WHITE, (0.95, 1.2, 1.1, 0.2), u)
    for cx, top in ((1.15, 0.85), (1.5, 0.65), (1.85, 0.85)):
        _poly(s, WHITE, [(cx - 0.12, 1.2), (cx - 0.12, top + 0.15), (cx, top), (cx + 0.12, top + 0.15), (cx + 0.12, 1.2)], u)


def _malaysia(s: pygame.Surface, u: float) -> None:
    """マレーシア: 赤と白の 14 本の横縞と、左上の紺の四角に黄色の三日月と星。"""
    for i in range(14):
        _fill(s, (204, 0, 1) if i % 2 == 0 else WHITE, (0, i * 2 / 14, 3, 2 / 14), u)
    navy = (1, 0, 102)
    _fill(s, navy, (0, 0, 1.5, 8 / 7), u)
    yellow = (255, 204, 0)
    _crescent(s, u, 0.6, 0.57, 0.38, 0.1, yellow, navy)
    _poly(s, yellow, _star(1.12, 0.57, 0.22, points=14), u)


def _myanmar(s: pygame.Surface, u: float) -> None:
    """ミャンマー: 黄・緑・赤の横縞と、真ん中の白い大きな星。"""
    _horizontal((254, 203, 0), (52, 178, 51), (234, 40, 57))(s, u)
    _poly(s, WHITE, _star(1.5, 1.08, 0.72), u)


def _serbia(s: pygame.Surface, u: float) -> None:
    """セルビア: 赤・青・白の横縞と、左寄りの赤い盾に白い十字（紋章を単純にしたもの）。"""
    _horizontal((198, 54, 60), (12, 64, 118), WHITE)(s, u)
    red = (198, 54, 60)
    _poly(s, (237, 185, 46), [(0.62, 0.42), (1.42, 0.42), (1.42, 1.25), (1.02, 1.6), (0.62, 1.25)], u)
    _poly(s, red, [(0.7, 0.5), (1.34, 0.5), (1.34, 1.2), (1.02, 1.5), (0.7, 1.2)], u)
    _fill(s, WHITE, (0.97, 0.58, 0.1, 0.8), u)
    _fill(s, WHITE, (0.76, 0.85, 0.52, 0.1), u)


def _tanzania(s: pygame.Surface, u: float) -> None:
    """タンザニア（スワヒリ語）: 左上が緑、右下が青で、左下から右上への黒い斜めの帯（黄色の縁）。"""
    s.fill((0, 163, 221))
    _poly(s, (30, 181, 58), [(0, 0), (3, 0), (0, 2)], u)
    pygame.draw.line(s, (252, 209, 22), (0, 2 * u), (3 * u, 0), max(1, round(0.62 * u)))
    pygame.draw.line(s, BLACK, (0, 2 * u), (3 * u, 0), max(1, round(0.44 * u)))


def _pakistan(s: pygame.Surface, u: float) -> None:
    """パキスタン（ウルドゥー語）: 左の白い帯と、緑の地に白い三日月と星。"""
    green = (1, 65, 28)
    s.fill(green)
    _fill(s, WHITE, (0, 0, 0.75, 2), u)
    _crescent(s, u, 1.9, 1.05, 0.5, 0.15, WHITE, green)
    _poly(s, WHITE, _star(2.25, 0.8, 0.15, turn=-60), u)


_FLAG_DRAWERS = {HOKKAIDO: _hokkaido, OSAKA: _osaka, FUKUOKA: _fukuoka, NAGOYA: _nagoya, KYOTO: _kyoto, HIROSHIMA: _hiroshima, OKINAWA: _okinawa, TOHOKU: _tohoku, KAGOSHIMA: _kagoshima, TOSA: _tosa, JP: _japan, KR: _korea, CN: _china, TW: _taiwan, HK: _hongkong, TH: _thailand, FR: _france, RU: _russia, BR: _brazil,
                 # 2026-11-14 に足した言語（旗は、その言語を主に話す国のもの。紋章は単純な形にしてある）
                 "es": _SPAIN, "de": _GERMANY, "it": _ITALY, "nl": _NETHERLANDS, "pl": _POLAND, "hr": _CROATIA, "sk": _SLOVAKIA,
                 "sl": _SLOVENIA, "hu": _HUNGARY, "et": _ESTONIA, "lv": _LATVIA, "lt": _LITHUANIA, "bg": _BULGARIA, "id": _INDONESIA, "vi": _vietnam,
                 "ar": _uae, "hi": _india,
                 # 2026-11-15 に足した言語
                 "tr": _turkey, "cs": _czech, "uk": _horizontal((0, 87, 183), (255, 215, 0)), "ne": _nepal, "fa": _iran,
                 "uz": _uzbekistan, "si": _sri_lanka,
                 # 2026-11-21 に足した言語
                 "az": _azerbaijan, "be": _belarus, "bn": _bangladesh, "ca": _catalonia, "eu": _basque, "he": _israel,
                 "hy": _horizontal((217, 0, 18), (0, 51, 160), (242, 168, 0)), "ka": _georgia, "kk": _kazakhstan, "km": _cambodia,
                 "ms": _malaysia, "my": _myanmar, "sr": _serbia, "sw": _tanzania, "tl": _philippines, "ur": _pakistan}


# 2 枚の旗を、すき間をあけて横に並べる言語（英語 = 左にイギリス・右にアメリカ）
_SIDE_BY_SIDE_FLAGS = {US: (_uk, _usa)}
SIDE_BY_SIDE_EACH = 0.85  # 1 枚の幅（width に対する割合）。高さはほかの旗の 85%。2 枚並べると、ほかの旗よりかなり横長になる（11-22 夜にユーザーの希望で 0.62→0.85）
SIDE_BY_SIDE_GAP = 0.1  # 2 枚の間のすき間（width に対する割合）


def flag_width(name: str, width: int) -> int:
    """旗を幅 width で描いたときの、実際の幅（2 枚並べる旗だけ width より広い）。"""
    if name not in _SIDE_BY_SIDE_FLAGS:
        return width
    each, gap = _side_by_side_sizes(width)
    return each * 2 + gap


def width_to_fit(name: str, width: int, room: int) -> int:
    """旗の実際の幅が room に収まるように、width を小さくする（文の左の印のような、幅の決まった場所に描くとき）。"""
    while width > 6 and flag_width(name, width) > room:
        width -= 1
    return width


def _side_by_side_sizes(width: int) -> tuple[int, int]:
    return max(3, round(width * SIDE_BY_SIDE_EACH)), max(2, round(width * SIDE_BY_SIDE_GAP))


@lru_cache(maxsize=256)
def flag_surface(name: str, width: int) -> pygame.Surface:
    """幅 width（高さは 2/3）の旗。角を少し丸くして、うすい枠を付ける。同じ旗は一度だけ描く。
    英語だけは、イギリスとアメリカの 2 枚を並べる（幅は flag_width、高さはほかの旗と同じ）。"""
    pair = _SIDE_BY_SIDE_FLAGS.get(name)
    if pair is not None:
        return _side_by_side(pair, width)
    drawer = _FLAG_DRAWERS.get(name)
    if drawer is None:
        raise ValueError(f"知らない旗です: {name}")
    return _finish(drawer, width)


def _finish(drawer, width: int) -> pygame.Surface:
    """drawer で 4 倍の大きさに描いて、角を丸くし、枠を付けて、幅 width に縮める。"""
    height = round(width * ASPECT[1] / ASPECT[0])
    big_w, big_h = width * SUPERSAMPLE, height * SUPERSAMPLE
    flag = pygame.Surface((big_w, big_h), pygame.SRCALPHA)
    drawer(flag, big_w / 3)  # 旗は 3 x 2 の座標で設計する
    radius = round(min(big_w, big_h) * 0.12)
    mask = pygame.Surface((big_w, big_h), pygame.SRCALPHA)
    pygame.draw.rect(mask, (255, 255, 255, 255), mask.get_rect(), border_radius=radius)
    flag.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    pygame.draw.rect(flag, (*BORDER, 255), flag.get_rect(), width=max(1, SUPERSAMPLE), border_radius=radius)
    return pygame.transform.smoothscale(flag, (width, height))


def _side_by_side(drawers, width: int) -> pygame.Surface:
    """2 枚の旗（それぞれ角を丸くして枠を付ける）を、すき間をあけて横に並べる。高さはほかの旗と同じ。"""
    height = round(width * ASPECT[1] / ASPECT[0])
    each, gap = _side_by_side_sizes(width)
    surface = pygame.Surface((each * 2 + gap, height), pygame.SRCALPHA)
    left, right = (_finish(drawer, each) for drawer in drawers)
    top = (height - left.get_height()) // 2
    surface.blit(left, (0, top))
    surface.blit(right, (each + gap, top))
    return surface


# --- 「翻訳の組み合わせ」の画面の、地域のボタンの印（2026-11-21。11-22 に世界地図はやめ、EU と日本の方言だけにした） ---
REGION_ICON_NAMES = ("eu", "dialects")


def _eu(s: pygame.Surface, u: float) -> None:
    """EU の旗: 青い地に、金色の 12 の星を輪に並べる。"""
    s.fill((0, 51, 153))
    for i in range(12):
        angle = math.radians(i * 30)
        _poly(s, (255, 204, 0), _star(1.5 + 0.62 * math.cos(angle), 1.0 + 0.62 * math.sin(angle), 0.11), u)


_REGION_DRAWERS = {"eu": _eu, "dialects": _japan}


def has_region_icon(region: str) -> bool:
    return region in _REGION_DRAWERS


@lru_cache(maxsize=32)
def region_icon(region: str, width: int) -> pygame.Surface:
    """地域のボタンの印（幅 width、縦横 3:2。角を少し丸くして、うすい枠を付ける。旗と同じ描き方）。"""
    drawer = _REGION_DRAWERS.get(region)
    if drawer is None:
        raise ValueError(f"印の無い地域です: {region}")
    return _finish(drawer, width)
