"""言語ごとの国旗（ボタンや文の左に出す小さな旗）。

フォントの絵文字に頼らず、pygame の図形で描く（実機のフォントに国旗が無くても同じに見えるように）。
4 倍の大きさで描いてから縮めるので、斜めの線や円もなめらかになる。縦横の比は 3:2。

- 日本語 = 日本、韓国語 = 韓国、英語 = アメリカ、中国語（簡体字）= 中国、中国語（台湾の繁体字）= 台湾、
  広東語 = 香港、タイ語 = タイ、フランス語 = フランス、ロシア語 = ロシア、ポルトガル語 = ブラジル、
  北海道弁 = 北海道旗（青い地に七稜星）、大阪弁 = 大阪市旗ふうの旗（澪標）、福岡弁 = 福岡市旗ふうの旗（太陽）
- 英語の旗を変えるときは LANGUAGE_FLAGS の "en" を、"uk" などに書き換える（旗は _FLAG_DRAWERS に足す）
"""

from __future__ import annotations

import math
from functools import lru_cache

import pygame

# 旗の名前（言語のコードと同じ。中国語の台湾の旗だけ "zh-hant"）
JP, KR, US, CN, TW, HK, TH, FR, RU, BR = "ja", "ko", "en", "zh", "zh-hant", "yue", "th", "fr", "ru", "pt"
HOKKAIDO, OSAKA, FUKUOKA = "hok", "osa", "fuk"
FLAG_NAMES = (JP, KR, US, CN, TW, HK, TH, FR, RU, BR, HOKKAIDO, OSAKA, FUKUOKA)

ASPECT = (3, 2)
SUPERSAMPLE = 4
RED, WHITE, BLUE, BLACK = (205, 38, 52), (255, 255, 255), (36, 62, 140), (20, 20, 20)
BORDER = (120, 126, 138)


def flag_name(lang: str, traditional: bool = False) -> str:
    """言語のコードに対応する旗の名前（中国語を台湾の繁体字で表示しているときは台湾の旗）。"""
    return TW if lang == CN and traditional else lang


def _star(cx: float, cy: float, radius: float, turn: float = -90.0, points: int = 5) -> list[tuple[float, float]]:
    """星の形の頂点。turn は最初の頂点の向き（度。-90 = 真上）。"""
    inner = radius * (0.382 if points == 5 else 0.5)
    result = []
    for i in range(points * 2):
        r = radius if i % 2 == 0 else inner
        angle = math.radians(turn + i * 180 / points)
        result.append((cx + r * math.cos(angle), cy + r * math.sin(angle)))
    return result


def _fill(surface: pygame.Surface, color, rect: tuple[float, float, float, float], u: float) -> None:
    x, y, w, h = rect
    pygame.draw.rect(surface, color, pygame.Rect(round(x * u), round(y * u), round(w * u) + 1, round(h * u) + 1))


def _poly(surface: pygame.Surface, color, points, u: float) -> None:
    pygame.draw.polygon(surface, color, [(x * u, y * u) for x, y in points])


def _disc(surface: pygame.Surface, color, cx: float, cy: float, radius: float, u: float) -> None:
    pygame.draw.circle(surface, color, (round(cx * u), round(cy * u)), max(1, round(radius * u)))


def _japan(s: pygame.Surface, u: float) -> None:
    s.fill(WHITE)
    _disc(s, RED, 1.5, 1.0, 0.6, u)


def _korea(s: pygame.Surface, u: float) -> None:
    """太極旗: 白地に、真ん中の太極（赤と青）と、四すみの卦（乾・坤・坎・離）。"""
    s.fill(WHITE)
    cx, cy, r = 1.5, 1.0, 0.5
    # 太極: 赤が上、青が下。仕切りの線は旗の対角線（右上と左下を結ぶ向き）に傾ける
    tilt = math.atan2(-2, 3)
    _disc(s, BLUE, cx, cy, r, u)
    upper = [(cx + r * math.cos(tilt - math.pi + math.pi * i / 48), cy + r * math.sin(tilt - math.pi + math.pi * i / 48)) for i in range(49)]
    _poly(s, RED, upper, u)
    dx, dy = (r / 2) * math.cos(tilt), (r / 2) * math.sin(tilt)
    _disc(s, BLUE, cx + dx, cy + dy, r / 2, u)  # 赤い側にくい込む青
    _disc(s, RED, cx - dx, cy - dy, r / 2, u)  # 青い側にくい込む赤
    # 四すみの卦（三本の棒）。棒は旗の中心と角を結ぶ線に直角で、中心に向かって 3 本並ぶ。
    # 左上 = 乾（━ ━ ━）、右下 = 坤（╌ ╌ ╌）、右上 = 坎（╌ ━ ╌）、左下 = 離（━ ╌ ━）。╌ は真ん中が切れた棒
    thick, gap, length, split, distance = 0.1, 0.065, 0.54, 0.12, 1.02
    unit = math.hypot(3, 2)
    for sx, sy, pattern in ((-1, -1, "###"), (1, 1, "..."), (1, -1, ".#."), (-1, 1, "#.#")):
        ax, ay = sx * 3 / unit, sy * 2 / unit  # 中心から角へ向かう向き
        bx, by = -ay, ax  # 棒の長さの向き（ax, ay に直角）
        px, py = cx + distance * ax, cy + distance * ay
        for index, kind in enumerate(pattern):
            offset = (index - 1) * (thick + gap)
            mx, my = px + offset * ax, py + offset * ay
            spans = ((-length / 2, length / 2),) if kind == "#" else ((-length / 2, -split / 2), (split / 2, length / 2))
            for start, end in spans:
                corners = [
                    (mx + bx * a + ax * c, my + by * a + ay * c)
                    for a, c in ((start, -thick / 2), (end, -thick / 2), (end, thick / 2), (start, thick / 2))
                ]
                _poly(s, BLACK, corners, u)


def _usa(s: pygame.Surface, u: float) -> None:
    stripe = 2 / 13
    for i in range(13):
        _fill(s, RED if i % 2 == 0 else WHITE, (0, i * stripe, 3, stripe), u)
    canton_w, canton_h = 1.2, stripe * 7
    _fill(s, BLUE, (0, 0, canton_w, canton_h), u)
    for row in range(4):
        for col in range(5 if row % 2 == 0 else 4):
            x = 0.12 + col * 0.225 + (0.1125 if row % 2 else 0)
            _disc(s, WHITE, x, 0.12 + row * 0.2, 0.045, u)


def _china(s: pygame.Surface, u: float) -> None:
    s.fill(RED)
    yellow = (255, 222, 0)
    _poly(s, yellow, _star(0.5, 0.5, 0.3), u)
    for x, y, turn in ((1.0, 0.2, -70), (1.2, 0.4, -30), (1.2, 0.7, 10), (1.0, 0.9, 40)):
        _poly(s, yellow, _star(x, y, 0.1, turn), u)


def _taiwan(s: pygame.Surface, u: float) -> None:
    s.fill(RED)
    _fill(s, BLUE, (0, 0, 1.5, 1.0), u)
    cx, cy = 0.75, 0.5
    _poly(s, WHITE, _star(cx, cy, 0.34, -90, 12), u)
    _disc(s, BLUE, cx, cy, 0.17, u)
    _disc(s, WHITE, cx, cy, 0.13, u)


def _hongkong(s: pygame.Surface, u: float) -> None:
    s.fill(RED)
    cx, cy = 1.5, 1.0
    for i in range(5):
        a = math.radians(-90 + i * 72)
        # 五枚の花びら（円を少しずらして重ねる）。中心に向かって細くなるよう、外側に円を置く
        _disc(s, WHITE, cx + 0.2 * math.cos(a), cy + 0.2 * math.sin(a), 0.17, u)
    _disc(s, RED, cx, cy, 0.06, u)


def _thailand(s: pygame.Surface, u: float) -> None:
    s.fill(RED)
    _fill(s, WHITE, (0, 1 / 3, 3, 4 / 3), u)
    _fill(s, (36, 40, 100), (0, 2 / 3, 3, 2 / 3), u)


def _france(s: pygame.Surface, u: float) -> None:
    _fill(s, BLUE, (0, 0, 1.0, 2), u)
    _fill(s, WHITE, (1.0, 0, 1.0, 2), u)
    _fill(s, RED, (2.0, 0, 1.0, 2), u)


def _russia(s: pygame.Surface, u: float) -> None:
    _fill(s, WHITE, (0, 0, 3, 2 / 3), u)
    _fill(s, (0, 57, 166), (0, 2 / 3, 3, 2 / 3), u)
    _fill(s, (213, 43, 30), (0, 4 / 3, 3, 2 / 3), u)


def _brazil(s: pygame.Surface, u: float) -> None:
    """ブラジル: 緑の地に黄色のひし形、青い円と白い帯。"""
    s.fill((0, 155, 58))
    _poly(s, (254, 221, 0), [(1.5, 0.17), (2.78, 1.0), (1.5, 1.83), (0.22, 1.0)], u)
    cx, cy, radius = 1.5, 1.0, 0.5
    layer = pygame.Surface(s.get_size(), pygame.SRCALPHA)
    _disc(layer, (0, 39, 118), cx, cy, radius, u)
    band = pygame.Surface(s.get_size(), pygame.SRCALPHA)
    # 白い帯は、円の中を左下から右上へ、ゆるく弧を描く
    points = [(cx - 0.5 + 1.0 * t / 20, cy + 0.12 - 0.34 * math.sin(math.pi * t / 20 * 0.62 + 0.1) + 0.0) for t in range(21)]
    pygame.draw.lines(band, WHITE, False, [(x * u, y * u) for x, y in points], max(2, round(0.085 * u)))
    clip = pygame.Surface(s.get_size(), pygame.SRCALPHA)
    _disc(clip, WHITE, cx, cy, radius, u)
    band.blit(clip, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    layer.blit(band, (0, 0))
    s.blit(layer, (0, 0))


def _hokkaido(s: pygame.Surface, u: float) -> None:
    """北海道旗: 青い地に、赤い七稜星（白い縁どり）。"""
    s.fill((0, 60, 150))
    _poly(s, WHITE, _star(1.5, 1.0, 0.82, points=7), u)
    _poly(s, (205, 38, 52), _star(1.5, 1.0, 0.6, points=7), u)


def _osaka(s: pygame.Surface, u: float) -> None:
    """大阪（大阪市旗ふう）: 青い地に、白い澪標（水路の目印の杭）。"""
    s.fill((0, 70, 150))
    _fill(s, WHITE, (1.4, 0.3, 0.2, 1.4), u)
    _fill(s, WHITE, (1.05, 0.55, 0.9, 0.14), u)
    _fill(s, WHITE, (1.05, 0.95, 0.9, 0.14), u)
    _fill(s, WHITE, (0.9, 1.4, 1.2, 0.14), u)


def _fukuoka(s: pygame.Surface, u: float) -> None:
    """福岡（福岡市旗ふう）: 白い地に、青い太陽（輪と放射状の光）。"""
    s.fill(WHITE)
    blue = (0, 80, 160)
    for i in range(8):
        angle = math.radians(i * 45)
        _poly(
            s,
            blue,
            [
                (1.5 + 0.55 * math.cos(angle - 0.12), 1.0 + 0.55 * math.sin(angle - 0.12)),
                (1.5 + 0.9 * math.cos(angle), 1.0 + 0.9 * math.sin(angle)),
                (1.5 + 0.55 * math.cos(angle + 0.12), 1.0 + 0.55 * math.sin(angle + 0.12)),
            ],
            u,
        )
    _disc(s, blue, 1.5, 1.0, 0.45, u)
    _disc(s, WHITE, 1.5, 1.0, 0.25, u)


_FLAG_DRAWERS = {HOKKAIDO: _hokkaido, OSAKA: _osaka, FUKUOKA: _fukuoka, JP: _japan, KR: _korea, US: _usa, CN: _china, TW: _taiwan, HK: _hongkong, TH: _thailand, FR: _france, RU: _russia, BR: _brazil}


@lru_cache(maxsize=64)
def flag_surface(name: str, width: int) -> pygame.Surface:
    """幅 width（高さは 2/3）の旗。角を少し丸くして、うすい枠を付ける。同じ旗は一度だけ描く。"""
    drawer = _FLAG_DRAWERS.get(name)
    if drawer is None:
        raise ValueError(f"知らない旗です: {name}")
    height = round(width * ASPECT[1] / ASPECT[0])
    big_w, big_h = width * SUPERSAMPLE, height * SUPERSAMPLE
    flag = pygame.Surface((big_w, big_h), pygame.SRCALPHA)
    drawer(flag, big_w / 3)  # 旗は 3 x 2 の座標で設計する
    radius = round(min(big_w, big_h) * 0.12)
    mask = pygame.Surface((big_w, big_h), pygame.SRCALPHA)
    pygame.draw.rect(mask, (255, 255, 255, 255), mask.get_rect(), border_radius=radius)
    flag.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    pygame.draw.rect(flag, (*BORDER, 255), flag.get_rect(), width=max(1, SUPERSAMPLE), border_radius=radius)
    return pygame.transform.smoothscale(flag, (width, height))
