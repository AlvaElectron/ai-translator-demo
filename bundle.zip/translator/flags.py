"""言語ごとの国旗（ボタンや文の左に出す小さな旗）。

フォントの絵文字に頼らず、pygame の図形で描く（実機のフォントに国旗が無くても同じに見えるように）。
4 倍の大きさで描いてから縮めるので、斜めの線や円もなめらかになる。縦横の比は 3:2。

- 日本語 = 日本、韓国語 = 韓国、英語 = アメリカ、中国語（簡体字）= 中国、中国語（台湾の繁体字）= 台湾、
  広東語 = 香港、タイ語 = タイ、フランス語 = フランス、ロシア語 = ロシア、ポルトガル語 = ブラジル、
  北海道弁 = 北海道旗（青い地に七稜星）、大阪弁 = 大阪市旗ふうの旗（澪標）、福岡弁 = 福岡市旗ふうの旗（太陽）
- 2026-11-14 に足した言語: スペイン語 = スペイン、ドイツ語 = ドイツ、イタリア語 = イタリア、オランダ語 = オランダ、ポーランド語 = ポーランド、
  クロアチア語 = クロアチア、スロバキア語 = スロバキア、スロベニア語 = スロベニア、ハンガリー語 = ハンガリー、エストニア語 = エストニア、
  ラトビア語 = ラトビア、リトアニア語 = リトアニア、ブルガリア語 = ブルガリア、インドネシア語 = インドネシア、ベトナム語 = ベトナム、
  アラビア語 = アラブ首長国連邦（形が単純で、日本に来る湾岸諸国の人が多い）、ヒンディー語 = インド、
  2026-11-15: トルコ語 = トルコ、チェコ語 = チェコ、ウクライナ語 = ウクライナ、ネパール語 = ネパール（明るい灰色の地に描く）、
  ペルシア語 = イラン、ウズベク語 = ウズベキスタン、シンハラ語 = スリランカ（紋章は単純な形）
- 英語の旗を変えるときは LANGUAGE_FLAGS の "en" を、"uk" などに書き換える（旗は _FLAG_DRAWERS に足す）
"""

from __future__ import annotations

import math
from functools import lru_cache

import pygame

# 旗の名前（言語のコードと同じ。中国語の台湾の旗だけ "zh-hant"）
JP, KR, US, CN, TW, HK, TH, FR, RU, BR = "ja", "ko", "en", "zh", "zh-hant", "yue", "th", "fr", "ru", "pt"
HOKKAIDO, OSAKA, FUKUOKA = "hok", "osa", "fuk"
FLAG_NAMES = (JP, KR, US, CN, TW, HK, TH, FR, RU, BR, HOKKAIDO, OSAKA, FUKUOKA,
              "es", "de", "it", "nl", "pl", "hr", "sk", "sl", "hu", "et", "lv", "lt", "bg", "id", "vi", "ar", "hi",
              "tr", "cs", "uk", "ne", "fa", "uz", "si")

ASPECT = (3, 2)
SUPERSAMPLE = 4
RED, WHITE, BLUE, BLACK = (205, 38, 52), (255, 255, 255), (36, 62, 140), (20, 20, 20)
BORDER = (120, 126, 138)


def flag_name(lang: str, traditional: bool = False) -> str:
    """言語のコードに対応する旗の名前（中国語を台湾の繁体字で表示しているときは台湾の旗）。"""
    return TW if lang == CN and traditional else lang


def _star(cx: float, cy: float, radius: float, turn: float = -90.0, points: int = 5) -> list[tuple[float, float]]:
    """星の形の頂点。turn は最初の頂点の向き（度。-90 = 真上）。"""
    inner = radius * (0.382 if points == 5 else 0.5)
    result = []
    for i in range(points * 2):
        r = radius if i % 2 == 0 else inner
        angle = math.radians(turn + i * 180 / points)
        result.append((cx + r * math.cos(angle), cy + r * math.sin(angle)))
    return result


def _fill(surface: pygame.Surface, color, rect: tuple[float, float, float, float], u: float) -> None:
    x, y, w, h = rect
    pygame.draw.rect(surface, color, pygame.Rect(round(x * u), round(y * u), round(w * u) + 1, round(h * u) + 1))


def _poly(surface: pygame.Surface, color, points, u: float) -> None:
    pygame.draw.polygon(surface, color, [(x * u, y * u) for x, y in points])


def _disc(surface: pygame.Surface, color, cx: float, cy: float, radius: float, u: float) -> None:
    pygame.draw.circle(surface, color, (round(cx * u), round(cy * u)), max(1, round(radius * u)))


def _japan(s: pygame.Surface, u: float) -> None:
    s.fill(WHITE)
    _disc(s, RED, 1.5, 1.0, 0.6, u)


def _korea(s: pygame.Surface, u: float) -> None:
    """太極旗: 白地に、真ん中の太極（赤と青）と、四すみの卦（乾・坤・坎・離）。"""
    s.fill(WHITE)
    cx, cy, r = 1.5, 1.0, 0.5
    # 太極: 赤が上、青が下。仕切りの線は旗の対角線（右上と左下を結ぶ向き）に傾ける
    tilt = math.atan2(-2, 3)
    _disc(s, BLUE, cx, cy, r, u)
    upper = [(cx + r * math.cos(tilt - math.pi + math.pi * i / 48), cy + r * math.sin(tilt - math.pi + math.pi * i / 48)) for i in range(49)]
    _poly(s, RED, upper, u)
    dx, dy = (r / 2) * math.cos(tilt), (r / 2) * math.sin(tilt)
    _disc(s, BLUE, cx + dx, cy + dy, r / 2, u)  # 赤い側にくい込む青
    _disc(s, RED, cx - dx, cy - dy, r / 2, u)  # 青い側にくい込む赤
    # 四すみの卦（三本の棒）。棒は旗の中心と角を結ぶ線に直角で、中心に向かって 3 本並ぶ。
    # 左上 = 乾（━ ━ ━）、右下 = 坤（╌ ╌ ╌）、右上 = 坎（╌ ━ ╌）、左下 = 離（━ ╌ ━）。╌ は真ん中が切れた棒
    thick, gap, length, split, distance = 0.1, 0.065, 0.54, 0.12, 1.02
    unit = math.hypot(3, 2)
    for sx, sy, pattern in ((-1, -1, "###"), (1, 1, "..."), (1, -1, ".#."), (-1, 1, "#.#")):
        ax, ay = sx * 3 / unit, sy * 2 / unit  # 中心から角へ向かう向き
        bx, by = -ay, ax  # 棒の長さの向き（ax, ay に直角）
        px, py = cx + distance * ax, cy + distance * ay
        for index, kind in enumerate(pattern):
            offset = (index - 1) * (thick + gap)
            mx, my = px + offset * ax, py + offset * ay
            spans = ((-length / 2, length / 2),) if kind == "#" else ((-length / 2, -split / 2), (split / 2, length / 2))
            for start, end in spans:
                corners = [
                    (mx + bx * a + ax * c, my + by * a + ay * c)
                    for a, c in ((start, -thick / 2), (end, -thick / 2), (end, thick / 2), (start, thick / 2))
                ]
                _poly(s, BLACK, corners, u)


def _usa(s: pygame.Surface, u: float) -> None:
    stripe = 2 / 13
    for i in range(13):
        _fill(s, RED if i % 2 == 0 else WHITE, (0, i * stripe, 3, stripe), u)
    canton_w, canton_h = 1.2, stripe * 7
    _fill(s, BLUE, (0, 0, canton_w, canton_h), u)
    for row in range(4):
        for col in range(5 if row % 2 == 0 else 4):
            x = 0.12 + col * 0.225 + (0.1125 if row % 2 else 0)
            _disc(s, WHITE, x, 0.12 + row * 0.2, 0.045, u)


def _china(s: pygame.Surface, u: float) -> None:
    s.fill(RED)
    yellow = (255, 222, 0)
    _poly(s, yellow, _star(0.5, 0.5, 0.3), u)
    for x, y, turn in ((1.0, 0.2, -70), (1.2, 0.4, -30), (1.2, 0.7, 10), (1.0, 0.9, 40)):
        _poly(s, yellow, _star(x, y, 0.1, turn), u)


def _taiwan(s: pygame.Surface, u: float) -> None:
    s.fill(RED)
    _fill(s, BLUE, (0, 0, 1.5, 1.0), u)
    cx, cy = 0.75, 0.5
    _poly(s, WHITE, _star(cx, cy, 0.34, -90, 12), u)
    _disc(s, BLUE, cx, cy, 0.17, u)
    _disc(s, WHITE, cx, cy, 0.13, u)


def _hongkong(s: pygame.Surface, u: float) -> None:
    s.fill(RED)
    cx, cy = 1.5, 1.0
    for i in range(5):
        a = math.radians(-90 + i * 72)
        # 五枚の花びら（円を少しずらして重ねる）。中心に向かって細くなるよう、外側に円を置く
        _disc(s, WHITE, cx + 0.2 * math.cos(a), cy + 0.2 * math.sin(a), 0.17, u)
    _disc(s, RED, cx, cy, 0.06, u)


def _thailand(s: pygame.Surface, u: float) -> None:
    s.fill(RED)
    _fill(s, WHITE, (0, 1 / 3, 3, 4 / 3), u)
    _fill(s, (36, 40, 100), (0, 2 / 3, 3, 2 / 3), u)


def _france(s: pygame.Surface, u: float) -> None:
    _fill(s, BLUE, (0, 0, 1.0, 2), u)
    _fill(s, WHITE, (1.0, 0, 1.0, 2), u)
    _fill(s, RED, (2.0, 0, 1.0, 2), u)


def _russia(s: pygame.Surface, u: float) -> None:
    _fill(s, WHITE, (0, 0, 3, 2 / 3), u)
    _fill(s, (0, 57, 166), (0, 2 / 3, 3, 2 / 3), u)
    _fill(s, (213, 43, 30), (0, 4 / 3, 3, 2 / 3), u)


def _brazil(s: pygame.Surface, u: float) -> None:
    """ブラジル: 緑の地に黄色のひし形、青い円と白い帯。"""
    s.fill((0, 155, 58))
    _poly(s, (254, 221, 0), [(1.5, 0.17), (2.78, 1.0), (1.5, 1.83), (0.22, 1.0)], u)
    cx, cy, radius = 1.5, 1.0, 0.5
    layer = pygame.Surface(s.get_size(), pygame.SRCALPHA)
    _disc(layer, (0, 39, 118), cx, cy, radius, u)
    band = pygame.Surface(s.get_size(), pygame.SRCALPHA)
    # 白い帯は、円の中を左下から右上へ、ゆるく弧を描く
    points = [(cx - 0.5 + 1.0 * t / 20, cy + 0.12 - 0.34 * math.sin(math.pi * t / 20 * 0.62 + 0.1) + 0.0) for t in range(21)]
    pygame.draw.lines(band, WHITE, False, [(x * u, y * u) for x, y in points], max(2, round(0.085 * u)))
    clip = pygame.Surface(s.get_size(), pygame.SRCALPHA)
    _disc(clip, WHITE, cx, cy, radius, u)
    band.blit(clip, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    layer.blit(band, (0, 0))
    s.blit(layer, (0, 0))


def _horizontal(*colors: tuple[int, int, int], weights: tuple[float, ...] | None = None):
    """横縞の旗（上から colors の順。weights は帯の太さの比）を描く関数を作る。"""
    weights = weights or (1.0,) * len(colors)
    total = sum(weights)

    def draw(s: pygame.Surface, u: float) -> None:
        top = 0.0
        for color, weight in zip(colors, weights):
            height = 2 * weight / total
            _fill(s, color, (0, top, 3, height), u)
            top += height

    return draw


def _vertical(*colors: tuple[int, int, int]):
    """縦縞の旗（左から colors の順。帯は同じ太さ）を描く関数を作る。"""

    def draw(s: pygame.Surface, u: float) -> None:
        width = 3 / len(colors)
        for i, color in enumerate(colors):
            _fill(s, color, (i * width, 0, width, 2), u)

    return draw


def _with_shield(stripes, shield):
    """横縞の上に、左寄りの盾（紋章を単純にしたもの）を重ねる旗（スロバキア・スロベニア・クロアチア）。"""

    def draw(s: pygame.Surface, u: float) -> None:
        stripes(s, u)
        shield(s, u)

    return draw


def _shield_outline(s: pygame.Surface, u: float, cx: float, top: float, width: float, height: float, color) -> list[tuple[float, float]]:
    points = [(cx - width / 2, top), (cx + width / 2, top), (cx + width / 2, top + height * 0.6), (cx, top + height), (cx - width / 2, top + height * 0.6)]
    _poly(s, color, points, u)
    return points


def _slovakia_shield(s: pygame.Surface, u: float) -> None:
    """スロバキアの盾（赤い盾に白い二重十字、下に青い三つの丘）を単純にしたもの。"""
    cx, top, w, h = 1.05, 0.45, 0.8, 1.1
    _shield_outline(s, u, cx, top - 0.04, w + 0.08, h + 0.08, WHITE)
    _shield_outline(s, u, cx, top, w, h, (238, 28, 37))
    _fill(s, WHITE, (cx - 0.05, top + 0.12, 0.1, 0.62), u)
    _fill(s, WHITE, (cx - 0.22, top + 0.25, 0.44, 0.08), u)
    _fill(s, WHITE, (cx - 0.3, top + 0.45, 0.6, 0.08), u)
    for dx in (-0.2, 0.0, 0.2):
        _disc(s, (11, 78, 162), cx + dx, top + 0.86, 0.13, u)


def _slovenia_shield(s: pygame.Surface, u: float) -> None:
    """スロベニアの盾（青い盾に白い山と、黄色い三つの星）を単純にしたもの（旗の左上に置く）。"""
    cx, top, w, h = 0.8, 0.28, 0.5, 0.66
    _shield_outline(s, u, cx, top - 0.03, w + 0.06, h + 0.06, (237, 28, 36))
    _shield_outline(s, u, cx, top, w, h, (0, 92, 165))
    _poly(s, WHITE, [(cx - 0.2, top + 0.45), (cx - 0.07, top + 0.27), (cx, top + 0.36), (cx + 0.07, top + 0.27), (cx + 0.2, top + 0.45)], u)
    for dx, dy in ((-0.1, 0.08), (0.1, 0.08), (0.0, 0.15)):
        _poly(s, (255, 221, 0), _star(cx + dx, top + dy, 0.045, points=6), u)


def _croatia_shield(s: pygame.Surface, u: float) -> None:
    """クロアチアの盾（赤と白の市松模様）を単純にしたもの（旗の中央に置く）。"""
    cx, top, size = 1.5, 0.45, 0.13
    for row in range(5):
        for col in range(5):
            color = (255, 0, 0) if (row + col) % 2 == 0 else WHITE
            _fill(s, color, (cx - 2.5 * size + col * size, top + row * size, size, size), u)


def _uae(s: pygame.Surface, u: float) -> None:
    """アラブ首長国連邦: 緑・白・黒の横縞と、左の赤い縦の帯（アラビア語の旗として使う）。"""
    _horizontal((0, 115, 47), WHITE, BLACK)(s, u)
    _fill(s, (255, 0, 0), (0, 0, 0.75, 2), u)


def _india(s: pygame.Surface, u: float) -> None:
    """インド: サフラン・白・緑の横縞と、真ん中の紺の法輪（24 本の輻）。"""
    _horizontal((255, 153, 51), WHITE, (19, 136, 8))(s, u)
    navy = (0, 0, 128)
    cx, cy, radius = 1.5, 1.0, 0.27
    pygame.draw.circle(s, navy, (round(cx * u), round(cy * u)), round(radius * u), max(1, round(0.04 * u)))
    for i in range(24):
        angle = math.radians(i * 15)
        pygame.draw.line(s, navy, (cx * u, cy * u), ((cx + radius * math.cos(angle)) * u, (cy + radius * math.sin(angle)) * u), max(1, round(0.015 * u)))
    _disc(s, navy, cx, cy, 0.05, u)


def _crescent(s: pygame.Surface, u: float, cx: float, cy: float, radius: float, shift: float, color, background) -> None:
    """三日月（color の円に、少しずらした background の円を重ねる）。"""
    _disc(s, color, cx, cy, radius, u)
    _disc(s, background, cx + shift, cy, radius * 0.8, u)


def _turkey(s: pygame.Surface, u: float) -> None:
    """トルコ: 赤い地に、白い三日月と星。"""
    red = (227, 10, 23)
    s.fill(red)
    _crescent(s, u, 1.05, 1.0, 0.5, 0.13, WHITE, red)
    _poly(s, WHITE, _star(1.62, 1.0, 0.17, turn=180), u)


def _czech(s: pygame.Surface, u: float) -> None:
    """チェコ: 上が白、下が赤、左から真ん中まで青い三角形。"""
    _horizontal(WHITE, (215, 20, 26))(s, u)
    _poly(s, (17, 69, 126), [(0, 0), (1.5, 1.0), (0, 2)], u)


def _nepal(s: pygame.Surface, u: float) -> None:
    """ネパール: 長方形ではない旗（二つの三角形を重ねた形。青い縁、赤い地、白い月と太陽）を、明るい灰色の地に描く。"""
    s.fill((225, 228, 232))
    blue, crimson = (0, 56, 147), (220, 20, 60)
    for outline, color in ((0.07, blue), (0.0, crimson)):
        _poly(s, color, [(0.8 + outline, 0.08 + outline * 1.4), (2.1 - outline * 2.6, 0.95 - outline), (0.8 + outline, 0.95 - outline)], u)
        _poly(s, color, [(0.8 + outline, 0.78 + outline * 1.4), (2.1 - outline * 2.6, 1.92 - outline), (0.8 + outline, 1.92 - outline)], u)
    _crescent(s, u, 1.12, 0.62, 0.16, -0.06, WHITE, crimson)
    _poly(s, WHITE, _star(1.12, 1.5, 0.18, points=12), u)


def _iran(s: pygame.Surface, u: float) -> None:
    """イラン: 緑・白・赤の横縞と、真ん中の赤い紋章（単純な形）。"""
    _horizontal((35, 159, 64), WHITE, (218, 0, 0))(s, u)
    red = (218, 0, 0)
    pygame.draw.circle(s, red, (round(1.5 * u), round(1.0 * u)), round(0.2 * u), max(1, round(0.05 * u)))
    _fill(s, red, (1.47, 0.78, 0.06, 0.44), u)


def _uzbekistan(s: pygame.Surface, u: float) -> None:
    """ウズベキスタン: 青・白・緑の横縞（間に細い赤）と、左上の白い三日月と星。"""
    blue = (0, 153, 181)
    _horizontal(blue, WHITE, (30, 181, 58))(s, u)
    _fill(s, (206, 17, 38), (0, 2 / 3 - 0.03, 3, 0.06), u)
    _fill(s, (206, 17, 38), (0, 4 / 3 - 0.03, 3, 0.06), u)
    _crescent(s, u, 0.35, 0.33, 0.22, 0.08, WHITE, blue)
    for i in range(3):
        _poly(s, WHITE, _star(0.75 + i * 0.2, 0.33, 0.06), u)


def _sri_lanka(s: pygame.Surface, u: float) -> None:
    """スリランカ: 黄色の縁、左に緑とオレンジの縦の帯、右に赤茶の地と黄色の獅子（単純な形）。"""
    s.fill((255, 190, 41))
    _fill(s, (0, 83, 78), (0.1, 0.1, 0.35, 1.8), u)
    _fill(s, (255, 126, 0), (0.45, 0.1, 0.35, 1.8), u)
    maroon = (141, 32, 41)
    _fill(s, maroon, (0.9, 0.1, 2.0, 1.8), u)
    _disc(s, (255, 190, 41), 1.9, 1.0, 0.42, u)
    _fill(s, (255, 190, 41), (1.55, 1.2, 0.7, 0.35), u)


def _vietnam(s: pygame.Surface, u: float) -> None:
    s.fill((218, 37, 29))
    _poly(s, (255, 255, 0), _star(1.5, 1.0, 0.6), u)


_SPAIN = _horizontal((170, 21, 27), (241, 191, 0), (170, 21, 27), weights=(1, 2, 1))
_GERMANY = _horizontal(BLACK, (221, 0, 0), (255, 206, 0))
_ITALY = _vertical((0, 146, 70), WHITE, (206, 43, 55))
_NETHERLANDS = _horizontal((174, 28, 40), WHITE, (33, 70, 139))
_POLAND = _horizontal(WHITE, (220, 20, 60))
_HUNGARY = _horizontal((206, 41, 57), WHITE, (71, 112, 80))
_ESTONIA = _horizontal((0, 114, 206), BLACK, WHITE)
_LATVIA = _horizontal((158, 48, 57), WHITE, (158, 48, 57), weights=(2, 1, 2))
_LITHUANIA = _horizontal((253, 185, 19), (0, 106, 68), (193, 39, 45))
_BULGARIA = _horizontal(WHITE, (0, 150, 110), (214, 38, 18))
_INDONESIA = _horizontal((206, 17, 38), WHITE)
_SLOVAKIA = _with_shield(_horizontal(WHITE, (11, 78, 162), (238, 28, 37)), _slovakia_shield)
_SLOVENIA = _with_shield(_horizontal(WHITE, (0, 92, 165), (237, 28, 36)), _slovenia_shield)
_CROATIA = _with_shield(_horizontal((255, 0, 0), WHITE, (23, 23, 150)), _croatia_shield)


def _hokkaido(s: pygame.Surface, u: float) -> None:
    """北海道旗: 青い地に、赤い七稜星（白い縁どり）。"""
    s.fill((0, 60, 150))
    _poly(s, WHITE, _star(1.5, 1.0, 0.82, points=7), u)
    _poly(s, (205, 38, 52), _star(1.5, 1.0, 0.6, points=7), u)


def _osaka(s: pygame.Surface, u: float) -> None:
    """大阪（大阪市旗ふう）: 青い地に、白い澪標（水路の目印の杭）。"""
    s.fill((0, 70, 150))
    _fill(s, WHITE, (1.4, 0.3, 0.2, 1.4), u)
    _fill(s, WHITE, (1.05, 0.55, 0.9, 0.14), u)
    _fill(s, WHITE, (1.05, 0.95, 0.9, 0.14), u)
    _fill(s, WHITE, (0.9, 1.4, 1.2, 0.14), u)


def _fukuoka(s: pygame.Surface, u: float) -> None:
    """福岡（福岡市旗ふう）: 白い地に、青い太陽（輪と放射状の光）。"""
    s.fill(WHITE)
    blue = (0, 80, 160)
    for i in range(8):
        angle = math.radians(i * 45)
        _poly(
            s,
            blue,
            [
                (1.5 + 0.55 * math.cos(angle - 0.12), 1.0 + 0.55 * math.sin(angle - 0.12)),
                (1.5 + 0.9 * math.cos(angle), 1.0 + 0.9 * math.sin(angle)),
                (1.5 + 0.55 * math.cos(angle + 0.12), 1.0 + 0.55 * math.sin(angle + 0.12)),
            ],
            u,
        )
    _disc(s, blue, 1.5, 1.0, 0.45, u)
    _disc(s, WHITE, 1.5, 1.0, 0.25, u)


_FLAG_DRAWERS = {HOKKAIDO: _hokkaido, OSAKA: _osaka, FUKUOKA: _fukuoka, JP: _japan, KR: _korea, US: _usa, CN: _china, TW: _taiwan, HK: _hongkong, TH: _thailand, FR: _france, RU: _russia, BR: _brazil,
                 # 2026-11-14 に足した言語（旗は、その言語を主に話す国のもの。紋章は単純な形にしてある）
                 "es": _SPAIN, "de": _GERMANY, "it": _ITALY, "nl": _NETHERLANDS, "pl": _POLAND, "hr": _CROATIA, "sk": _SLOVAKIA,
                 "sl": _SLOVENIA, "hu": _HUNGARY, "et": _ESTONIA, "lv": _LATVIA, "lt": _LITHUANIA, "bg": _BULGARIA, "id": _INDONESIA, "vi": _vietnam,
                 "ar": _uae, "hi": _india,
                 # 2026-11-15 に足した言語
                 "tr": _turkey, "cs": _czech, "uk": _horizontal((0, 87, 183), (255, 215, 0)), "ne": _nepal, "fa": _iran,
                 "uz": _uzbekistan, "si": _sri_lanka}


@lru_cache(maxsize=64)
def flag_surface(name: str, width: int) -> pygame.Surface:
    """幅 width（高さは 2/3）の旗。角を少し丸くして、うすい枠を付ける。同じ旗は一度だけ描く。"""
    drawer = _FLAG_DRAWERS.get(name)
    if drawer is None:
        raise ValueError(f"知らない旗です: {name}")
    height = round(width * ASPECT[1] / ASPECT[0])
    big_w, big_h = width * SUPERSAMPLE, height * SUPERSAMPLE
    flag = pygame.Surface((big_w, big_h), pygame.SRCALPHA)
    drawer(flag, big_w / 3)  # 旗は 3 x 2 の座標で設計する
    radius = round(min(big_w, big_h) * 0.12)
    mask = pygame.Surface((big_w, big_h), pygame.SRCALPHA)
    pygame.draw.rect(mask, (255, 255, 255, 255), mask.get_rect(), border_radius=radius)
    flag.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    pygame.draw.rect(flag, (*BORDER, 255), flag.get_rect(), width=max(1, SUPERSAMPLE), border_radius=radius)
    return pygame.transform.smoothscale(flag, (width, height))
