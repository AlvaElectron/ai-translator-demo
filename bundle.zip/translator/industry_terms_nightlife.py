"""娯楽・夜の店のうち、カラオケとバーの用語集のデータ（書き方は industry_terms_food.py の先頭を参照）。

メイドカフェ・コンカフェ・キャバクラの用語は、すでに glossary.py の JA_TERMS にある（2026-10-08〜10 に追加した約 190 語）。
industries.py が、その語をメイドカフェ・コンカフェ・キャバクラのどれを選んだときに使うかを決める。
"""

from __future__ import annotations

KARAOKE = (
    ("カラオケ", "노래방", "karaoke", "卡拉OK", "卡拉OK", "คาราโอเกะ", "karaoké", "караоке", "karaokê", True),
    ("フリータイム", "프리 타임", "free time", "畅唱", "任唱", "ฟรีไทม์", "forfait temps libre", "безлимитное время", "tempo livre", True),
    ("30分単位", "30분 단위", "30-minute increments", "按30分钟为单位", "以30分鐘為單位", "หน่วยละ 30 นาที", "par tranche de 30 minutes", "блоками по 30 минут", "intervalos de 30 minutos", True),
    ("延長なさいますか", "연장하시겠어요?", "Would you like to extend?", "要延长吗？", "要唔要延長？", "ต่อเวลาไหมคะ", "Souhaitez-vous prolonger ?", "Хотите продлить?", "Gostaria de prorrogar?"),
    ("終了10分前", "종료 10분 전", "10 minutes before the end", "结束前10分钟", "結束前10分鐘", "อีก 10 นาทีจะหมดเวลา", "10 minutes avant la fin", "за 10 минут до окончания", "", True),
    ("お部屋", "룸", "room", "包间", "包廂", "ห้อง", "salle", "комната", "sala", True),
    ("ご案内するお部屋は304号室です", "안내해 드릴 방은 304호입니다", "your room is number 304", "您的包间是304号房", "你嘅包廂係304號房", "ห้องของท่านคือห้อง 304 ค่ะ", "votre salle est la numéro 304", "ваша комната — номер 304", "a sua sala é a número 304", True),
    ("デンモク", "전자 리모컨", "song search remote", "点歌遥控器", "點歌遙控器", "รีโมตค้นหาเพลง", "télécommande de recherche de chansons", "пульт для выбора песен", "controle de busca de músicas", True),
    ("曲を入れる", "곡 예약", "selecting a song", "点歌", "點歌", "เลือกเพลง", "choisir une chanson", "выбор песни", "escolher uma música", True),
    ("曲の予約", "곡 예약", "reserving a song", "预约歌曲", "預約歌曲", "การจองเพลง", "réservation de chanson", "заказ песни", "reserva de música", True),
    ("マイク", "마이크", "microphone", "麦克风", "咪", "ไมโครโฟน", "micro", "микрофон", "microfone", True),
    ("キーを上げて", "키를 올려 주세요", "raise the key", "把调升高", "將調升高", "ปรับคีย์ให้สูงขึ้น", "montez la tonalité", "повысьте тональность", "aumente o tom", True),
    ("キーを下げて", "키를 내려 주세요", "lower the key", "把调降低", "將調降低", "ปรับคีย์ให้ต่ำลง", "baissez la tonalité", "понизьте тональность", "abaixe o tom", True),
    ("採点機能", "채점 기능", "scoring feature", "评分功能", "評分功能", "ฟังก์ชันให้คะแนน", "fonction de notation", "функция оценки", "função de pontuação", True),
    ("ドリンクオーダー", "음료 주문", "ordering drinks", "点饮料", "點飲品", "สั่งเครื่องดื่ม", "commande de boissons", "заказ напитков", "pedido de bebidas", True),
    ("ワンドリンクオーダー制", "음료 1잔 이상 주문 필수", "one drink minimum", "每人至少点一杯饮料", "每人最少叫一杯飲品", "ต้องสั่งเครื่องดื่มอย่างน้อยหนึ่งแก้ว", "une boisson minimum par personne", "минимум один напиток на человека", "consumo mínimo de uma bebida", True),
    ("持ち込み禁止", "외부 음식 반입 금지", "outside food and drinks are not allowed", "禁止自带食物和饮料", "禁止自帶食物同飲品", "ห้ามนำอาหารและเครื่องดื่มจากภายนอกเข้ามา", "il est interdit d'apporter de la nourriture et des boissons de l'extérieur", "приносить еду и напитки с собой запрещено", "é proibido trazer comida e bebida de fora", True),
    ("会員カード", "회원 카드", "membership card", "会员卡", "會員卡", "บัตรสมาชิก", "carte de membre", "карта участника", "cartão de membro", True),
    ("学生証", "학생증", "student ID", "学生证", "學生證", "บัตรนักศึกษา", "carte d'étudiant", "студенческий билет", "carteirinha de estudante", True),
    ("学割", "학생 할인", "student discount", "学生折扣", "學生折扣", "ส่วนลดนักเรียน", "tarif étudiant", "студенческая скидка", "desconto para estudantes", True),
    ("お忘れ物", "두고 가신 물건", "left-behind items", "遗留物品", "遺留物品", "ของที่ลืม", "objets oubliés", "забытые вещи", "itens esquecidos", True),
)

BAR = (
    ("バー", "바", "bar", "酒吧", "酒吧", "บาร์", "bar", "бар", "bar", True),
    ("カウンター席", "바 좌석", "bar counter seat", "吧台座位", "吧枱座位", "ที่นั่งเคาน์เตอร์", "place au comptoir", "место у барной стойки", "lugar no balcão", True),
    ("テーブル席", "테이블석", "table seat", "餐桌座位", "餐枱座位", "ที่นั่งโต๊ะ", "place à une table", "место за столиком", "lugar na mesa", True),
    ("バーテンダー", "바텐더", "bartender", "调酒师", "調酒師", "บาร์เทนเดอร์", "barman", "бармен", "bartender", True),
    ("お通し", "기본 안주", "table snack (otoshi)", "开胃小菜", "開胃小食", "ของว่างประจำโต๊ะ (โอโตชิ)", "amuse-bouche (otoshi)", "закуска к столу (отоси)", "petisco da casa (otoshi)", True),
    ("チャージ料金", "자릿세", "cover charge", "入场费", "入場費", "ค่าเข้าร้าน", "droit d'entrée", "плата за вход", "taxa de entrada", True),
    ("ウイスキー", "위스키", "whisky", "威士忌", "威士忌", "วิสกี้", "whisky", "виски", "uísque", True),
    ("ハイボール", "하이볼", "highball (whisky and soda)", "威士忌苏打", "威士忌梳打", "ไฮบอล", "highball (whisky soda)", "хайбол (виски с содовой)", "highball (uísque com soda)", True),
    ("ジントニック", "진 토닉", "gin and tonic", "金汤力", "金湯尼", "จินโทนิก", "gin tonic", "джин-тоник", "gin tônica", True),
    ("モヒート", "모히토", "mojito", "莫吉托", "莫吉托", "โมฮิโต้", "mojito", "мохито", "mojito", True),
    ("カシスオレンジ", "카시스 오렌지", "cassis orange", "黑加仑橙汁鸡尾酒", "黑加侖橙汁雞尾酒", "คาสซิสออเรนจ์", "cassis orange", "кассис-оранж", "cassis com laranja", True),
    ("ノンアルコール", "무알코올", "non-alcoholic", "无酒精", "無酒精", "ไม่มีแอลกอฮอล์", "sans alcool", "безалкогольный", "sem álcool", True),
    ("おつまみ", "안주", "snacks to go with drinks", "下酒小菜", "小食", "กับแกล้ม", "amuse-bouches pour accompagner les boissons", "закуски к напиткам", "petiscos para acompanhar a bebida", True),
    ("ボトルキープ", "보틀 키핑", "bottle keep (storing a bottle for your next visit)", "寄存酒瓶", "寄存酒瓶", "ฝากขวด", "garder une bouteille (pour la prochaine visite)", "хранение бутылки", "guardar uma garrafa (para a próxima visita)", True),
    ("ボトルの有効期限", "보틀 보관 기간", "how long a kept bottle lasts", "寄存酒瓶的有效期限", "寄存酒瓶嘅有效期", "ระยะเวลาการฝากขวด", "durée de conservation de la bouteille", "срок хранения бутылки", "validade da garrafa guardada", True),
    ("お酒を飲まれる方", "술을 드시는 분", "people who drink alcohol", "饮酒的客人", "飲酒嘅客人", "ผู้ที่ดื่มแอลกอฮอล์", "personnes qui boivent de l'alcool", "те, кто пьёт алкоголь", "quem for beber álcool", True),
    ("20歳未満の方", "20세 미만인 분", "people under 20", "未满20岁的人", "未滿20歲嘅人", "ผู้ที่อายุต่ำกว่า 20 ปี", "personnes de moins de 20 ans", "лица младше 20 лет", "menores de 20 anos", True),
    ("お酒はご提供できません", "술은 제공해 드릴 수 없습니다", "we cannot serve alcohol", "不能提供酒类", "唔可以提供酒類", "ไม่สามารถเสิร์ฟแอลกอฮอล์ได้ค่ะ", "nous ne pouvons pas servir d'alcool", "мы не можем подавать алкоголь", "não podemos servir bebida alcoólica", True),
    ("身分証明書", "신분증", "identification", "身份证明", "身份證明", "เอกสารยืนยันตัวตน", "pièce d'identité", "удостоверение личности", "documento de identidade", True),
    ("年齢確認", "연령 확인", "age verification", "年龄确认", "年齡確認", "การยืนยันอายุ", "vérification de l'âge", "подтверждение возраста", "verificação de idade", True),
    ("本日のおすすめ", "오늘의 추천", "today's recommendation", "今日推荐", "今日推介", "เมนูแนะนำวันนี้", "recommandation du jour", "рекомендация на сегодня", "sugestão de hoje", True),
    ("飲み過ぎにご注意ください", "과음에 주의해 주세요", "please be careful not to drink too much", "请注意不要饮酒过量", "請注意唔好飲酒過量", "โปรดระวังอย่าดื่มมากเกินไปนะคะ", "veuillez ne pas trop boire", "пожалуйста, не пейте слишком много", "cuidado para não beber demais", True),
    ("お水をお持ちします", "물을 가져다 드리겠습니다", "I will bring you some water", "我给您拿水来", "我幫你拎水嚟", "ขอนำน้ำมาให้นะคะ", "je vais vous apporter de l'eau", "я принесу вам воды", "vou trazer água", True),
    ("ラストオーダー", "주문 마감", "last order", "最后点单", "最後點單", "รับออเดอร์สุดท้าย", "dernière commande", "последний заказ", "último pedido", True),
)
