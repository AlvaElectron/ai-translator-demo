"""2 つのマイクの雑音除去（ブラウザ版では使わない）。設定の読み込みに要る定数だけ。"""
FOCUS_ALL = "all"
FOCUS_FRONT = "front"
FOCUSES = (FOCUS_ALL, FOCUS_FRONT)
