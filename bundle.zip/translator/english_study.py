"""英語の学習（「ガイド」の画面の「英語学習」）の中身: 文字と発音、接客フレーズ、読む練習のクイズ、発音の判定。

ハングル学習（hangul_study.py）と同じ形にしてあり、画面（ui.py）は、どちらも同じ流れで使う。
ここは pygame も音声認識も使わない（PC でそのまま試験できる）。

- 文字と発音: 母音の文字・子音の文字・つづりの音（th・sh・ee など）。1 つごとに、カタカナの読み（文字の名前、
  つづりは音）、日本語話者向けの発音のコツ、例の単語。
- 接客フレーズ: お店で使う短い文（日本語 → 英語）。選んでいる業種（industries.py）の文も足す。
- 読む練習: 英語の単語を見て、日本語の意味を選ぶ。単語は業種の用語集（industry_terms_*.py）から取る。
- 発音の判定: 認識した文と手本の近さ（字ごとの編集距離）を 0〜1 で返す。
"""

from __future__ import annotations

import random
import re
from dataclasses import dataclass

from .hangul_study import Question, _choices, verdict  # noqa: F401  同じ問題の形・選択肢・判定の言い方を使う

LANG = "en"

_ONES = (
    "zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen"
).split()
_TENS = "_ _ twenty thirty forty fifty sixty seventy eighty ninety".split()
_NUMBER_LABEL = re.compile(r"(?:room|no\.?|number|#|flight|gate|seat|table|platform|track|bus)\s*$", re.IGNORECASE)
_NUMBER = re.compile(r"(?<![\w.:/])(\d{1,3}(?:,\d{3})+|\d+)(?![\d:/]|\.\d)")


def _words_below_thousand(n: int) -> str:
    parts: list[str] = []
    if n >= 100:
        parts.append(f"{_ONES[n // 100]} hundred")
        n %= 100
    if n >= 20:
        parts.append(_TENS[n // 10] + (f"-{_ONES[n % 10]}" if n % 10 else ""))
    elif n or not parts:
        parts.append(_ONES[n])
    return " ".join(parts)


def number_to_words(n: int) -> str:
    """整数を英語の words にする（1500 → "one thousand five hundred"）。"and" は入れない（アメリカ式）。"""
    if n < 0:
        return "minus " + number_to_words(-n)
    if n < 1000:
        return _words_below_thousand(n)
    parts: list[str] = []
    for size, name in ((10**9, "billion"), (10**6, "million"), (10**3, "thousand")):
        if n >= size:
            parts.append(f"{_words_below_thousand(n // size)} {name}")
            n %= size
    if n:
        parts.append(_words_below_thousand(n))
    return " ".join(parts)


def spell_numbers(text: str) -> str:
    """英文の数字を、読み方（words）にする: "1,500 yen" / "1,500yen" → "one thousand five hundred yen"。
    時刻（10:30）・小数（2.5）・日付（10/13）・電話番号（数字の並び）・部屋番号（room 101）は、そのまま。10 桁以上も、そのまま。
    """

    def replace(match: re.Match[str]) -> str:
        digits = match.group(1).replace(",", "")
        if len(digits) > 9:
            return match.group(0)
        before = match.string[: match.start()]
        after_text = match.string[match.end() :]
        # 番号の読み方（部屋・電話）は、数としては読まない
        if _NUMBER_LABEL.search(before) or re.match(r"[ -]\d", after_text) or re.search(r"\d[ -]$", before):
            return match.group(0)
        words = number_to_words(int(digits))
        after = match.string[match.end() : match.end() + 1]
        return words + (" " if after.isalpha() else "")  # 「1,500yen」の数字と文字の間に空白を入れる

    return _NUMBER.sub(replace, text)

_KANA_CONVERTER = None  # 英語 → カタカナ（最初に使うときに作る。alkana がなければ、IPA のまま）


def kana_of(text: str) -> str:
    """英語の文のカタカナの読み（画面の発音表示と同じ変換）。変換できなければ空文字。"""
    global _KANA_CONVERTER
    if _KANA_CONVERTER is None:
        from . import phonetics  # 循環を避けるため、使うときに読む

        _KANA_CONVERTER = phonetics._english_converter() or (lambda text: "")
    try:
        return _KANA_CONVERTER(text)
    except Exception:  # 読みの表示は、なくても学習はできる
        return ""


@dataclass(frozen=True)
class Letter:
    char: str  # A, th, ee など
    roman: str  # 発音記号（IPA）
    kana: str  # カタカナの読み（文字は名前、つづりは音）
    tip: str  # 発音のコツ（日本語）
    example: str  # 例の単語
    example_ja: str  # 例の単語の意味

    @property
    def display(self) -> str:
        """大きく見せる文字（文字は「Aa」のように大文字と小文字を並べる。「th（息）」のような区別の注は付けない）。"""
        name = self.char.split("（")[0]
        return f"{name}{name.lower()}" if len(name) == 1 else name

    @property
    def syllable(self) -> str:
        return self.display

    @property
    def say(self) -> str:
        """押したときに読み上げる文。文字は「A. apple.」（名前と例の単語）、つづりは例の単語だけ。"""
        if len(self.char) == 1:
            return f"{self.char}. {self.example}."
        return self.example

    @property
    def example_kana(self) -> str:
        return kana_of(self.example)


def _letters(rows: str) -> tuple[Letter, ...]:
    """「文字|IPA|カタカナ|コツ|例|意味」を 1 行にして、改行でつなぐ。"""
    return tuple(Letter(*(part.strip() for part in line.split("|"))) for line in rows.strip().splitlines())


VOWELS = _letters(
    """
A|/eɪ/|エイ|名前は「エイ」。単語では「ア」（apple）や「エイ」（cake）になる|apple|りんご
E|/iː/|イー|名前は「イー」。単語では「エ」（egg）がいちばん多い|egg|たまご
I|/aɪ/|アイ|名前は「アイ」。単語では「イ」（ink）や「アイ」（ice）になる|ice|氷
O|/oʊ/|オウ|名前は「オウ」。単語では「オ」（orange）や「オウ」（open）になる|orange|オレンジ
U|/juː/|ユー|名前は「ユー」。単語では「ア」（umbrella）や「ユー」（use）になる|umbrella|傘
"""
)

CONSONANTS = _letters(
    """
B|/biː/|ビー|唇をしっかり閉じて、息を弾ませる「ブ」|book|本
C|/siː/|スィー|e・i・y の前は「ス」（city）、それ以外は「ク」（cat）|cat|ねこ
D|/diː/|ディー|舌先を上の歯ぐきに付けて「ド」|dog|犬
F|/ɛf/|エフ|上の歯を下唇に軽く当てて、息を出す「フ」。日本語の「フ」と違い、唇は丸めない|fish|魚
G|/dʒiː/|ジー|のどの奥で「グ」（go）。e・i の前は「ジ」（gym）のこともある|go|行く
H|/eɪtʃ/|エイチ|息だけの「ハ」。のどから息を出す|hat|ぼうし
J|/dʒeɪ/|ジェイ|唇を少し丸めて「ジャ」|juice|ジュース
K|/keɪ/|ケイ|息を出す「ク」。k の次の n は読まない（know）|key|鍵
L|/ɛl/|エル|舌先を上の歯ぐきに付けたまま「ル」。日本語の「ラ行」とは違う|lemon|レモン
M|/ɛm/|エム|唇を閉じて鼻から声を出す「ム」|milk|牛乳
N|/ɛn/|エヌ|舌先を上の歯ぐきに付けて鼻から声を出す「ヌ」|name|名前
P|/piː/|ピー|唇を閉じて、息を強く出す「プ」|pen|ペン
Q|/kjuː/|キュー|いつも u と一緒で「クウ」（queen）|queen|女王
R|/ɑːr/|アール|舌を丸めて、どこにも付けない「ル」。日本語の「ラ行」とは違う|rice|ご飯
S|/ɛs/|エス|息だけの「ス」|sun|太陽
T|/tiː/|ティー|舌先を上の歯ぐきに付けて、息を出す「トゥ」|tea|お茶
V|/viː/|ヴィー|上の歯を下唇に軽く当てて、声を出す「ヴ」。b とは違う|very|とても
W|/ˈdʌbəl juː/|ダブリュー|唇を丸めて「ウ」。日本語の「ワ」より唇を突き出す|water|水
X|/ɛks/|エックス|「クス」（box）。語頭では「ズ」（xylophone）|box|箱
Y|/waɪ/|ワイ|語頭は「ヤ」（yes）。語末は「イ」「アイ」（happy・my）|yes|はい
Z|/ziː/|ズィー|声を出す「ズ」。s の「ス」に声を足した音|zoo|動物園
"""
)

SPELLINGS = _letters(
    """
sh|/ʃ/|シュ|唇を丸めて「シュ」。息を長く出す|shop|お店
ch|/tʃ/|チ|「チ」。唇を丸めて、息を強く出す|cheese|チーズ
th（息）|/θ/|ス|舌先を上下の歯の間に軽くはさんで、息だけ出す。日本語の「サ行」ではない|thank|ありがとう
th（声）|/ð/|ズ|舌先を歯の間にはさんで、声を出す。日本語の「ザ行」ではない|this|これ
ng|/ŋ/|ン（グ）|鼻に抜ける「ン」。語末の g は、はっきり読まない|king|王様
ck|/k/|ク|「ク」。k と同じ音|black|黒
wh|/w/|ウ|唇を丸めて「ウ」。h は読まない|white|白
qu|/kw/|クウ|「クウ」。q はいつも u と一緒|quick|速い
ee|/iː/|イー|長い「イー」。口を横に引く|green|緑
ea|/iː/|イー|長い「イー」（例外もある: bread は「エ」）|tea|お茶
oo|/uː/|ウー|唇を丸めて長い「ウー」。短い音（book）もある|moon|月
ou|/aʊ/|アウ|「アウ」。口を大きく開けて始める|house|家
ai|/eɪ/|エイ|「エイ」。ay も同じ音|rain|雨
oa|/oʊ/|オウ|「オウ」。口を丸めて始める|boat|ボート
ar|/ɑːr/|アー|口を大きく開けた「アー」。r は舌を丸めるだけ|car|車
or|/ɔːr/|オー|唇を丸めた「オー」。r は舌を丸めるだけ|door|ドア
ir|/ɜːr/|アー|口をあまり開けない「アー」。ur・er も同じ音|bird|鳥
tion|/ʃən/|シュン|語末の「シュン」。直前の音節に強勢が来る|station|駅
"""
)

LETTER_GROUPS: tuple[tuple[str, str, tuple[Letter, ...]], ...] = (
    ("vowel", "母音の文字", VOWELS),
    ("consonant", "子音の文字", CONSONANTS),
    ("spelling", "つづりの音", SPELLINGS),
)
ALL_LETTERS = tuple(letter for _, _, letters in LETTER_GROUPS for letter in letters)

# 接客フレーズ（日本語, 英語）。お店の人が、お客様に言う言葉と、聞かれる言葉
PHRASES: tuple[tuple[str, str], ...] = (
    ("いらっしゃいませ", "Welcome."),
    ("ありがとうございます", "Thank you very much."),
    ("こちらへどうぞ", "This way, please."),
    ("少々お待ちください", "Please wait a moment."),
    ("お待たせしました", "Thank you for waiting."),
    ("何名様ですか？", "How many people?"),
    ("ご注文はお決まりですか？", "Are you ready to order?"),
    ("ごゆっくりどうぞ", "Please take your time."),
    ("お水はセルフサービスです", "Water is self-service."),
    ("ラストオーダーです", "This is the last order."),
    ("お会計は1,500円です", "The total is 1,500 yen."),
    ("カードが使えます", "You can pay by card."),
    ("現金のみです", "We accept cash only."),
    ("袋は必要ですか？", "Would you like a bag?"),
    ("お箸はお付けしますか？", "Would you like chopsticks?"),
    ("温めますか？", "Would you like it heated?"),
    ("領収書をお渡しします", "Here is your receipt."),
    ("写真撮影はご遠慮ください", "Please do not take photos."),
    ("トイレはあちらです", "The restroom is over there."),
    ("パスポートを見せてください", "May I see your passport?"),
    ("免税の手続きができます", "We can do the tax-free procedure."),
    ("試着室はこちらです", "The fitting room is here."),
    ("サイズはいかがですか？", "How is the size?"),
    ("在庫を確認します", "I will check the stock."),
    ("チェックインは15時からです", "Check-in starts at three p.m."),
    ("朝食は7時からです", "Breakfast starts at seven a.m."),
    ("駅はまっすぐ行って右です", "Go straight, and the station is on the right."),
    ("次の電車は10分後です", "The next train is in ten minutes."),
    ("もう一度お願いします", "Could you say that again, please?"),
    ("大丈夫ですか？", "Are you all right?"),
    ("気をつけてお帰りください", "Please be careful on your way home."),
    ("またお越しください", "Please come again."),
)

_SENTENCE_JA = re.compile(r"(です|ます|ください|ませんか|ございます|お願いします|ますか)[。？]?$|[？?]$")
_LATIN = re.compile(r"[A-Za-z]")


def _all_rows() -> list[tuple[str, str]]:
    """業種の用語集の（日本語, 英語）の組。業種の番号は問わない。"""
    from . import industries  # 循環を避けるため、使うときに読む

    pairs: list[tuple[str, str]] = []
    for rows in (*industries._COMMON_ROWS.values(), *industries._ROWS.values()):
        for row in rows:
            if len(row) > 2 and row[2]:
                pairs.append((row[0], row[2]))
    return pairs


def industry_phrases(selected: tuple[str, ...]) -> list[tuple[str, str]]:
    """選んでいる業種の用語集にある、文の形のもの（「〜です」「〜ください」「〜ですか」）。何も選んでいなければ空。"""
    if not selected:
        return []
    from . import industries

    seen: set[str] = set()
    out: list[tuple[str, str]] = []
    categories = {industries.CATEGORY_OF[i] for i in selected if i in industries.CATEGORY_OF}
    rows = [row for c in categories for row in industries._COMMON_ROWS.get(c, ())]
    rows += [row for i in selected for row in industries._ROWS.get(i, ())]
    for row in rows:
        ja, en = row[0], row[2] if len(row) > 2 else ""
        if en and _SENTENCE_JA.search(ja) and _LATIN.search(en) and ja not in seen and len(en) <= 60:
            seen.add(ja)
            out.append((ja, en))
    return out


def phrase_deck(selected: tuple[str, ...] = ()) -> list[tuple[str, str]]:
    """接客フレーズの一覧（決まった文 + 選んでいる業種の文）。"""
    base = list(PHRASES)
    known = {ja for ja, _ in base}
    deck = base + [pair for pair in industry_phrases(selected) if pair[0] not in known]
    # 数字は、読み方（words）で見せる（「1,500 yen」→「one thousand five hundred yen」）。手本と発音の判定を、そろえるため
    return [(ja, spell_numbers(en)) for ja, en in deck]


def word_pool() -> list[tuple[str, str]]:
    """読む練習の単語（英語, 日本語の意味）。短い名詞や用語だけを使う。"""
    seen: set[str] = set()
    pool: list[tuple[str, str]] = []
    for ja, en in _all_rows():
        if len(en) > 16 or len(ja) > 12 or _SENTENCE_JA.search(ja):
            continue
        if not re.fullmatch(r"[A-Za-z][A-Za-z '\-]*", en) or en.lower() in seen:
            continue
        seen.add(en.lower())
        pool.append((en, ja))
    for letter in ALL_LETTERS:
        if letter.example.lower() not in seen:
            seen.add(letter.example.lower())
            pool.append((letter.example, letter.example_ja))
    return pool


def letter_question(rng: random.Random, groups: tuple[str, ...] = ("vowel", "consonant", "spelling")) -> Question:
    """文字の読み当て: 文字・つづりを見て、カタカナの読みを選ぶ。"""
    pool = [letter for gid, _, letters in LETTER_GROUPS if gid in groups for letter in letters]
    letter = rng.choice(pool)
    choices, answer = _choices(letter.kana, [other.kana for other in pool], rng)
    detail = f"{letter.char}: {letter.tip}"  # 発音記号（IPA）は、答えの説明の書体で出ないことがあるので、書かない
    return Question(letter.display, choices, answer, letter.say, detail)


def word_question(rng: random.Random, pool: list[tuple[str, str]] | None = None) -> Question:
    """読む練習: 英語の単語を見て、日本語の意味を選ぶ。"""
    pool = pool if pool is not None else word_pool()
    en, ja = rng.choice(pool)
    choices, answer = _choices(ja, [other for _, other in pool], rng)
    reading = kana_of(en)
    detail = f"{en}（{reading}）= {ja}" if reading else f"{en} = {ja}"
    return Question(en, choices, answer, en, detail)


# --- 発音の判定 ---


def _letters_of(text: str) -> str:
    """英字と数字だけ、小文字にして残す（記号・空白・大文字小文字の違いは比べない）。"""
    return "".join(ch for ch in spell_numbers(text).lower() if ch.isalnum())


def similarity(target: str, heard: str) -> float:
    """手本と、認識した文の近さ（0〜1）。字ごとの編集距離で比べる。"""
    a, b = _letters_of(target), _letters_of(heard)
    if not a or not b:
        return 0.0
    previous = list(range(len(b) + 1))
    for i, x in enumerate(a, 1):
        current = [i]
        for j, y in enumerate(b, 1):
            current.append(min(previous[j] + 1, current[j - 1] + 1, previous[j - 1] + (x != y)))
        previous = current
    return max(0.0, 1.0 - previous[-1] / max(len(a), len(b)))
