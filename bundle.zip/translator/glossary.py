"""お店の接客の用語集（Hy-MT2 の「用語の指定」に使う）。

訳す文にこの用語が入っていたら、指示文に「参考下面的翻译：試着室 翻译成 탈의실」のような見本を足す
（Hy-MT2 のモデルカードにある、用語を指定するときの書き方）。小さいモデルなので、お店の言葉を
一般の意味で訳してしまう（試着室 → 실험실「実験室」、2,000円のお返し → refund「払い戻し」、
暗証番号 → code de confirmation など。2026-10-01 に Pi で 364 文を試して確認）。見本を足すと直る。

JA_TERMS: 日本語 → 各言語。日本語から訳すときに使う（長い語から先に探す）。見本がなくても正しく訳せる言語は省く
（「ご遠慮ください → 请勿」を渡すと、中国語訳が「在店内进行饮食活动时，请勿」のように途中で切れた）。
TO_JA_TERMS: 各言語の語 → 日本語。お客様の言葉を日本語に訳すときに使う（大文字・小文字は区別しない）。
"""

from __future__ import annotations

import re

from .langs import EN, FR, JA, KO, PT, RU, TH, YUE, ZH

# 日本語 → 韓国語・英語・中国語（簡体字）・広東語・タイ語・フランス語・ロシア語
JA_TERMS: dict[str, dict[str, str]] = {
    "いらっしゃいませ": {
        KO: "어서 오세요", EN: "Welcome", ZH: "欢迎光临", YUE: "歡迎光臨",
        TH: "ยินดีต้อนรับ", FR: "Bonjour, bienvenue", RU: "Добро пожаловать",
        PT: "Seja bem-vindo",
    },
    "ごゆっくりご覧ください": {
        KO: "천천히 둘러보세요", EN: "Please take your time and look around", ZH: "请慢慢看", YUE: "慢慢睇",
        TH: "เชิญเลือกชมตามสบาย", FR: "Prenez votre temps pour regarder", RU: "Смотрите не спеша",
        PT: "Fique à vontade para olhar",
    },
    "お待たせいたしました": {
        KO: "오래 기다리셨어요", EN: "Thank you for waiting", ZH: "让您久等了", YUE: "要你等咗咁耐",
        TH: "ขอโทษที่ให้รอ", FR: "Merci d'avoir patienté", RU: "Спасибо за ожидание",
        PT: "Obrigado por aguardar",
    },
    "お待たせしました": {
        KO: "오래 기다리셨어요", EN: "Thank you for waiting", ZH: "让您久等了", YUE: "要你等咗咁耐",
        TH: "ขอโทษที่ให้รอ", FR: "Merci d'avoir patienté", RU: "Спасибо за ожидание",
        PT: "Obrigado por aguardar",
    },
    "ICカードにチャージ": {
        KO: "교통카드에 충전", EN: "adding money to the IC card", ZH: "给交通卡充值", YUE: "增值交通卡",
        TH: "เติมเงินบัตรโดยสาร", FR: "recharger la carte IC", RU: "пополнение карты IC",
        PT: "carregar o cartão IC",
    },
    "天ぷら": {
        KO: "튀김", EN: "tempura", ZH: "天妇罗", YUE: "天婦羅",
        TH: "เทมปุระ", FR: "tempura", RU: "тэмпура",
        PT: "tempura",
    },
    "枝豆": {
        KO: "풋콩", EN: "edamame", ZH: "毛豆", YUE: "毛豆",
        TH: "ถั่วแระต้ม", FR: "edamame", RU: "эдамамэ",
        PT: "edamame",
    },
    "お箸": {
        KO: "젓가락", EN: "chopsticks", ZH: "筷子", YUE: "筷子",
        TH: "ตะเกียบ", FR: "baguettes", RU: "палочки для еды",
        PT: "pauzinhos",
    },
    "新宿": {
        KO: "신주쿠", EN: "Shinjuku", ZH: "新宿", YUE: "新宿",
        TH: "ชินจูกุ", FR: "Shinjuku", RU: "Синдзюку",
        PT: "Shinjuku",
    },
    "何名様": {
        KO: "몇 분", EN: "how many people in your party", ZH: "几位", YUE: "幾位",
        TH: "กี่ท่าน", FR: "combien de personnes", RU: "сколько человек",
        PT: "quantas pessoas",
    },
    "試着室": {
        KO: "탈의실", EN: "fitting room", ZH: "试衣间", YUE: "試身室",
        TH: "ห้องลองเสื้อ", FR: "cabine d'essayage", RU: "примерочная",
        PT: "provador",
    },
    "試着": {
        KO: "입어 보기", EN: "try on", ZH: "试穿", YUE: "試身",
        TH: "ลองสวม", FR: "essayage", RU: "примерить",
        PT: "experimentar",
    },
    "一点限り": {
        KO: "하나밖에 없는 상품", EN: "the only one left", ZH: "仅此一件", YUE: "得返一件",
        TH: "มีเพียงชิ้นเดียว", FR: "pièce unique", RU: "единственный экземпляр",
        PT: "última peça",
    },
    "新商品": {
        KO: "신상품", EN: "new item", ZH: "新品", YUE: "新貨",
        TH: "สินค้าใหม่", FR: "nouveauté", RU: "новинка",
        PT: "novidade",
    },
    "売り切れ": {
        KO: "품절", EN: "sold out", ZH: "售罄", YUE: "賣晒",
        TH: "ขายหมดแล้ว", FR: "épuisé", RU: "распродано",
        PT: "esgotado",
    },
    "在庫": {
        KO: "재고", EN: "stock", ZH: "库存", YUE: "存貨",
        TH: "สินค้าในสต็อก", FR: "stock", RU: "наличие на складе",
        PT: "estoque",
    },
    "税込み": {
        KO: "세금 포함", EN: "including tax", ZH: "含税", YUE: "連稅",
        TH: "รวมภาษีแล้ว", FR: "toutes taxes comprises", RU: "с учётом налога",
        PT: "com impostos incluídos",
    },
    "税込": {
        KO: "세금 포함", EN: "including tax", ZH: "含税", YUE: "連稅",
        TH: "รวมภาษีแล้ว", FR: "toutes taxes comprises", RU: "с учётом налога",
        PT: "com impostos incluídos",
    },
    "税抜き": {
        KO: "세금 별도", EN: "excluding tax", ZH: "不含税", YUE: "未連稅",
        TH: "ไม่รวมภาษี", FR: "hors taxes", RU: "без учёта налога",
        PT: "sem impostos",
    },
    "免税": {
        KO: "면세", EN: "tax-free", ZH: "免税", YUE: "免稅",
        TH: "ปลอดภาษี", FR: "détaxe", RU: "такс-фри",
        PT: "isento de impostos",
    },
    "円": {
        KO: "엔", EN: "yen", ZH: "日元", YUE: "日圓",
        TH: "เยน", FR: "yens", RU: "иен",
        PT: "ienes",
    },
    "お買い上げ": {
        KO: "구매", EN: "purchase", ZH: "购买", YUE: "購買",
        TH: "การซื้อ", FR: "achat", RU: "покупка",
        PT: "compra",
    },
    "一括払い": {
        KO: "일시불", EN: "a single payment (no installments)", ZH: "一次性付款（不分期）", YUE: "一次過付款（唔分期）",
        TH: "ชำระเต็มจำนวนครั้งเดียว", FR: "paiement en une seule fois", RU: "оплата одним платежом (без рассрочки)",
        PT: "pagamento à vista",
    },
    "分割払い": {
        KO: "할부", EN: "installments", ZH: "分期付款", YUE: "分期付款",
        TH: "ผ่อนชำระ", FR: "paiement en plusieurs fois", RU: "рассрочка",
        PT: "parcelado",
    },
    "クレジットカード": {
        KO: "신용카드", EN: "credit card", ZH: "信用卡", YUE: "信用卡",
        TH: "บัตรเครดิต", FR: "carte de crédit", RU: "кредитная карта",
        PT: "cartão de crédito",
    },
    "カード": {
        KO: "카드", EN: "card", ZH: "卡", YUE: "卡",
        TH: "บัตร", FR: "carte", RU: "карта",
        PT: "cartão",
    },
    "暗証番号": {
        KO: "비밀번호", EN: "PIN", ZH: "密码", YUE: "密碼",
        TH: "รหัส PIN", FR: "code PIN", RU: "ПИН-код",
        PT: "senha",
    },
    "サイン": {
        KO: "서명", ZH: "签名", YUE: "簽名",
        TH: "เซ็นชื่อ",  # 英・仏・露は見本なしの方が自然（見本を渡すと「give me the sign」「donner votre signer」になった）
    },
    "お預かりします": {
        KO: "받았어요", EN: "I have received", ZH: "收您", YUE: "收你",
        TH: "รับเงินมา", FR: "j'ai reçu", RU: "получаю от вас",
        PT: "recebi",
    },
    "のお返しです": {
        KO: "거스름돈입니다", EN: "here is your change", ZH: "找零", YUE: "找返你",
        TH: "เงินทอน", FR: "voici votre monnaie", RU: "ваша сдача",
        PT: "aqui está o seu troco",
    },
    "お釣り": {
        KO: "거스름돈", EN: "change", ZH: "找零", YUE: "找續",
        TH: "เงินทอน", FR: "monnaie", RU: "сдача",
        PT: "troco",
    },
    "レシート": {
        KO: "영수증", EN: "receipt", ZH: "小票", YUE: "收據",
        TH: "ใบเสร็จ", FR: "ticket de caisse", RU: "чек",
        PT: "cupom fiscal",
    },
    "領収書": {
        KO: "영수증", EN: "receipt", ZH: "发票", YUE: "收據",
        TH: "ใบเสร็จรับเงิน", FR: "reçu", RU: "квитанция",
        PT: "recibo",
    },
    "袋": {
        KO: "봉투", EN: "bag", ZH: "袋子", YUE: "膠袋",
        TH: "ถุง", FR: "sac", RU: "пакет",
        PT: "sacola",
    },
    "有料": {
        KO: "유료", EN: "there is a charge", ZH: "收费", YUE: "要收錢",
        TH: "มีค่าใช้จ่าย", FR: "payant", RU: "платный",
        PT: "é cobrado",
    },
    "お包み": {
        KO: "포장", EN: "wrap", ZH: "包装", YUE: "包裝",
        TH: "ห่อ", FR: "emballer", RU: "упаковать",
        PT: "embrulhar",
    },
    "日本製": {
        KO: "일본산", EN: "made in Japan", ZH: "日本制造", YUE: "日本製",
        TH: "ผลิตในญี่ปุ่น", FR: "fabriqué au Japon", RU: "сделано в Японии",
        PT: "fabricado no Japão",
    },
    "電子レンジ": {
        KO: "전자레인지", EN: "microwave", ZH: "微波炉", YUE: "微波爐",
        TH: "ไมโครเวฟ", FR: "micro-ondes", RU: "микроволновая печь",
        PT: "micro-ondas",
    },
    "賞味期限": {
        KO: "유통기한", EN: "best-before date", ZH: "保质期", YUE: "最佳食用日期",
        TH: "ควรบริโภคก่อน", FR: "date de consommation", RU: "срок годности",
        PT: "melhor antes de",
    },
    "消費期限": {
        KO: "소비기한", EN: "use-by date", ZH: "保质期", YUE: "食用期限",
        TH: "วันหมดอายุ", FR: "date limite de consommation", RU: "срок годности",
        PT: "prazo de validade",
    },
    "返品": {
        KO: "반품", EN: "return", ZH: "退货", YUE: "退貨",
        TH: "คืนสินค้า", FR: "retour", RU: "возврат товара",
        PT: "devolução",
    },
    "交換": {
        KO: "교환", EN: "exchange", ZH: "换货", YUE: "換貨",
        TH: "เปลี่ยนสินค้า", FR: "échange", RU: "обмен",
        PT: "troca",
    },
    "セール品": {
        KO: "세일 상품", EN: "sale items", ZH: "特价商品", YUE: "減價貨品",
        TH: "สินค้าลดราคา", FR: "articles soldés", RU: "товары со скидкой",
        PT: "itens em promoção",
    },
    "お一人様": {
        KO: "1인당", EN: "per person", ZH: "每人", YUE: "每位",
        TH: "ต่อท่าน", FR: "par personne", RU: "на одного человека",
        PT: "por pessoa",
    },
    "営業": {
        KO: "영업", EN: "open", ZH: "营业", YUE: "營業",
        TH: "เปิดทำการ", FR: "ouvert", RU: "работаем",
        PT: "aberto",
    },
    "エレベーター": {
        KO: "엘리베이터", EN: "elevator", ZH: "电梯", YUE: "升降機",
        TH: "ลิฟต์", FR: "ascenseur", RU: "лифт",
        PT: "elevador",
    },
    "写真撮影": {
        KO: "사진 촬영", EN: "taking photos", ZH: "拍照", YUE: "影相",
        TH: "การถ่ายรูป", FR: "prendre des photos", RU: "фотографировать",
        PT: "tirar fotos",
    },
    "飲食": {
        KO: "음식물 섭취", EN: "eating and drinking", ZH: "饮食", YUE: "飲食",
        TH: "การรับประทานอาหารและเครื่องดื่ม", FR: "manger et boire", RU: "есть и пить",
        PT: "comer e beber",
    },
    "ご遠慮ください": {
        KO: "삼가 주세요", EN: "please refrain from",
        TH: "กรุณางด", FR: "merci de ne pas", RU: "просим не",
        PT: "por favor, evite",
    },
    "またのお越しをお待ちしております": {
        KO: "또 방문해 주세요", EN: "We hope to see you again", ZH: "欢迎再次光临", YUE: "歡迎再嚟",
        TH: "หวังว่าจะได้ต้อนรับอีกครั้ง", FR: "Au plaisir de vous revoir", RU: "Будем рады видеть вас снова",
        PT: "Esperamos você de novo",
    },
    # --- メイドカフェ・コンカフェ・キャバクラ（2026-10-08。韓国語と英語だけ。2026-10-08 に Pi で 176 文を試して確認） ---
    "おかえりなさいませ、ご主人様": {KO: "어서 오세요, 주인님", EN: "Welcome home, Master", ZH: "欢迎回来，主人", YUE: "歡迎回嚟，主人", TH: "ยินดีต้อนรับกลับบ้านค่ะ นายท่าน", FR: "Bienvenue à la maison, Maître", RU: "С возвращением домой, Господин", PT: "Bem-vindo de volta, Mestre"},
    "おかえりなさいませご主人様": {KO: "어서 오세요, 주인님", EN: "Welcome home, Master", ZH: "欢迎回来，主人", YUE: "歡迎回嚟，主人", TH: "ยินดีต้อนรับกลับบ้านค่ะ นายท่าน", FR: "Bienvenue à la maison, Maître", RU: "С возвращением домой, Господин", PT: "Bem-vindo de volta, Mestre"},
    "お帰りなさいませ、ご主人様": {KO: "어서 오세요, 주인님", EN: "Welcome home, Master", ZH: "欢迎回来，主人", YUE: "歡迎回嚟，主人", TH: "ยินดีต้อนรับกลับบ้านค่ะ นายท่าน", FR: "Bienvenue à la maison, Maître", RU: "С возвращением домой, Господин", PT: "Bem-vindo de volta, Mestre"},
    "お帰りなさいませご主人様": {KO: "어서 오세요, 주인님", EN: "Welcome home, Master", ZH: "欢迎回来，主人", YUE: "歡迎回嚟，主人", TH: "ยินดีต้อนรับกลับบ้านค่ะ นายท่าน", FR: "Bienvenue à la maison, Maître", RU: "С возвращением домой, Господин", PT: "Bem-vindo de volta, Mestre"},
    "おかえりなさいませ、お嬢様": {KO: "어서 오세요, 아가씨", EN: "Welcome home, Miss", ZH: "欢迎回来，大小姐", YUE: "歡迎回嚟，小姐", TH: "ยินดีต้อนรับกลับบ้านค่ะ คุณหนู", FR: "Bienvenue à la maison, Mademoiselle", RU: "С возвращением домой, Госпожа", PT: "Bem-vinda de volta, Senhorita"},
    "おかえりなさいませお嬢様": {KO: "어서 오세요, 아가씨", EN: "Welcome home, Miss", ZH: "欢迎回来，大小姐", YUE: "歡迎回嚟，小姐", TH: "ยินดีต้อนรับกลับบ้านค่ะ คุณหนู", FR: "Bienvenue à la maison, Mademoiselle", RU: "С возвращением домой, Госпожа", PT: "Bem-vinda de volta, Senhorita"},
    "お帰りなさいませ、お嬢様": {KO: "어서 오세요, 아가씨", EN: "Welcome home, Miss", ZH: "欢迎回来，大小姐", YUE: "歡迎回嚟，小姐", TH: "ยินดีต้อนรับกลับบ้านค่ะ คุณหนู", FR: "Bienvenue à la maison, Mademoiselle", RU: "С возвращением домой, Госпожа", PT: "Bem-vinda de volta, Senhorita"},
    "お帰りなさいませお嬢様": {KO: "어서 오세요, 아가씨", EN: "Welcome home, Miss", ZH: "欢迎回来，大小姐", YUE: "歡迎回嚟，小姐", TH: "ยินดีต้อนรับกลับบ้านค่ะ คุณหนู", FR: "Bienvenue à la maison, Mademoiselle", RU: "С возвращением домой, Госпожа", PT: "Bem-vinda de volta, Senhorita"},
    "おかえりなさいませ": {KO: "어서 오세요", EN: "Welcome home", ZH: "欢迎回来", YUE: "歡迎回嚟", TH: "ยินดีต้อนรับกลับบ้านค่ะ", FR: "Bienvenue à la maison", RU: "С возвращением домой", PT: "Bem-vindo de volta"},
    "お帰りなさいませ": {KO: "어서 오세요", EN: "Welcome home", ZH: "欢迎回来", YUE: "歡迎回嚟", TH: "ยินดีต้อนรับกลับบ้านค่ะ", FR: "Bienvenue à la maison", RU: "С возвращением домой", PT: "Bem-vindo de volta"},
    "ご出国": {KO: "출국", EN: "departure", ZH: "出国", YUE: "出國", TH: "ออกนอกประเทศ", FR: "départ du pays", RU: "отъезд из страны", PT: "partida do país"},
    "めいどりーみんハイパー": {KO: "메이드리밍 하이퍼", EN: "Maidreamin Hyper", ZH: "Maidreamin Hyper", YUE: "Maidreamin Hyper", TH: "Maidreamin Hyper", FR: "Maidreamin Hyper", RU: "Maidreamin Hyper", PT: "Maidreamin Hyper"},
    "メイドリーミンハイパー": {KO: "메이드리밍 하이퍼", EN: "Maidreamin Hyper", ZH: "Maidreamin Hyper", YUE: "Maidreamin Hyper", TH: "Maidreamin Hyper", FR: "Maidreamin Hyper", RU: "Maidreamin Hyper", PT: "Maidreamin Hyper"},
    "めいどりーみん": {KO: "메이드리밍", EN: "Maidreamin", ZH: "Maidreamin", YUE: "Maidreamin", TH: "Maidreamin", FR: "Maidreamin", RU: "Maidreamin", PT: "Maidreamin"},
    "メイドリーミン": {KO: "메이드리밍", EN: "Maidreamin", ZH: "Maidreamin", YUE: "Maidreamin", TH: "Maidreamin", FR: "Maidreamin", RU: "Maidreamin", PT: "Maidreamin"},
    "ドリームタイム": {KO: "드림타임", EN: "Dream Time", ZH: "Dream Time", YUE: "Dream Time", TH: "Dream Time", FR: "Dream Time", RU: "Dream Time", PT: "Dream Time"},
    "ドリタイ": {KO: "드림타임", EN: "Dream Time", ZH: "Dream Time", YUE: "Dream Time", TH: "Dream Time", FR: "Dream Time", RU: "Dream Time", PT: "Dream Time"},
    # --- その 2（2026-10-08。80 文の 2 回目の試験で見つかった誤訳） ---
    "お一人様でのご来店ですか": {KO: "혼자 오셨나요?", EN: "Are you visiting alone?", ZH: "您是一位来的吗？", YUE: "你係一位嚟嘅嗎？", TH: "มาคนเดียวหรือคะ", FR: "Vous venez seul(e) ?", RU: "Вы пришли один/одна?", PT: "Veio sozinho(a)?"},
    "ただいま満席": {KO: "지금 자리가 없어서", EN: "we have no seats available right now", ZH: "现在已经满座", YUE: "而家滿座", TH: "ตอนนี้ที่นั่งเต็มแล้ว", FR: "nous sommes complets pour le moment", RU: "сейчас все места заняты", PT: "estamos lotados no momento"},
    "お荷物とコートをお預かりします": {KO: "짐과 코트를 맡아 드릴게요", EN: "I will take your bag and coat", ZH: "我帮您保管行李和外套", YUE: "我幫你保管行李同外套", TH: "ขอรับฝากกระเป๋าและเสื้อโค้ทค่ะ", FR: "Je vais garder vos bagages et votre manteau", RU: "Я возьму на хранение ваши вещи и пальто", PT: "Vou guardar sua bagagem e seu casaco"},
    "パンケーキ": {KO: "팬케이크", ZH: "松饼", YUE: "班戟", TH: "แพนเค้ก", FR: "pancake", RU: "панкейк", PT: "panqueca"},
    "魔法をかけますね": {KO: "마법을 걸어 드릴게요", EN: "I'll cast a magic spell", ZH: "施魔法", YUE: "施魔法", TH: "ขอร่ายเวทมนตร์ให้นะคะ", FR: "Je vais lancer un sort magique", RU: "Я наколдую для вас", PT: "Vou lançar um feitiço mágico"},
    "ご主人様": {KO: "주인", EN: "Master", ZH: "主人", YUE: "主人", TH: "นายท่าน", FR: "Maître", RU: "Господин", PT: "Mestre"},  # 韓国語は「주인님」と見本を渡すと「주인님님」、渡さないと「남편님」（夫）になるので、「주인」にした
    "コースター": {KO: "코스터", ZH: "杯垫", YUE: "杯墊", TH: "ที่รองแก้ว", FR: "dessous de verre", RU: "подставка", PT: "porta-copos"},
    "焼酎": {KO: "소주", ZH: "烧酒", YUE: "燒酒", TH: "โชชู", FR: "shochu", RU: "сётю", PT: "shochu"},
    "水割り": {KO: "물 탄 술(미즈와리)", EN: "with water", ZH: "兑水", YUE: "兌水", TH: "ผสมน้ำ", FR: "allongé à l'eau", RU: "разбавленный водой", PT: "com água"},
    "ロック": {KO: "온더록", EN: "on the rocks", ZH: "加冰", YUE: "加冰", TH: "ใส่น้ำแข็ง", FR: "sur glace", RU: "со льдом", PT: "com gelo"},
    # ポルトガル語の取り違えの見本（2026-10-12 の全言語チェックで確認。「お飲み物」が refrigerantes（清涼飲料）、「お休み」が férias（休暇））
    # 「買って来て欲しい」は、してもらう側ではなく、してあげる側の言い方（「何か買って来て欲しいものがありますか？」＝ 私が買ってきますが、何かありますか）。
    # 韓国語が「무엇을 사가져다 주실 수 있나요?」（何かを買ってきてもらえますか）と、向きが逆になった（2026-10-12 に確認）
    "何か買って来て欲しいものがありますか": {KO: "사다 드릴 게 있으세요?", EN: "Is there anything you would like me to buy for you?", ZH: "有什么需要我帮您买的吗？", YUE: "有冇嘢要我幫你買呀？", TH: "มีอะไรให้ฉันซื้อมาให้ไหมคะ", FR: "Y a-t-il quelque chose que vous aimeriez que je vous achète ?", RU: "Могу я что-нибудь купить для вас?", PT: "Quer que eu compre alguma coisa para você?"},
    "何か買って来て欲しいものはありますか": {KO: "사다 드릴 게 있으세요?", EN: "Is there anything you would like me to buy for you?", ZH: "有什么需要我帮您买的吗？", YUE: "有冇嘢要我幫你買呀？", TH: "มีอะไรให้ฉันซื้อมาให้ไหมคะ", FR: "Y a-t-il quelque chose que vous aimeriez que je vous achète ?", RU: "Могу я что-нибудь купить для вас?", PT: "Quer que eu compre alguma coisa para você?"},
    "何か買って来てほしいものがありますか": {KO: "사다 드릴 게 있으세요?", EN: "Is there anything you would like me to buy for you?", ZH: "有什么需要我帮您买的吗？", YUE: "有冇嘢要我幫你買呀？", TH: "มีอะไรให้ฉันซื้อมาให้ไหมคะ", FR: "Y a-t-il quelque chose que vous aimeriez que je vous achète ?", RU: "Могу я что-нибудь купить для вас?", PT: "Quer que eu compre alguma coisa para você?"},
    "何か買って来てほしいものはありますか": {KO: "사다 드릴 게 있으세요?", EN: "Is there anything you would like me to buy for you?", ZH: "有什么需要我帮您买的吗？", YUE: "有冇嘢要我幫你買呀？", TH: "มีอะไรให้ฉันซื้อมาให้ไหมคะ", FR: "Y a-t-il quelque chose que vous aimeriez que je vous achète ?", RU: "Могу я что-нибудь купить для вас?", PT: "Quer que eu compre alguma coisa para você?"},
    "何か買ってきて欲しいものがありますか": {KO: "사다 드릴 게 있으세요?", EN: "Is there anything you would like me to buy for you?", ZH: "有什么需要我帮您买的吗？", YUE: "有冇嘢要我幫你買呀？", TH: "มีอะไรให้ฉันซื้อมาให้ไหมคะ", FR: "Y a-t-il quelque chose que vous aimeriez que je vous achète ?", RU: "Могу я что-нибудь купить для вас?", PT: "Quer que eu compre alguma coisa para você?"},
    "何か買ってきて欲しいものはありますか": {KO: "사다 드릴 게 있으세요?", EN: "Is there anything you would like me to buy for you?", ZH: "有什么需要我帮您买的吗？", YUE: "有冇嘢要我幫你買呀？", TH: "มีอะไรให้ฉันซื้อมาให้ไหมคะ", FR: "Y a-t-il quelque chose que vous aimeriez que je vous achète ?", RU: "Могу я что-нибудь купить для вас?", PT: "Quer que eu compre alguma coisa para você?"},
    "何か買ってきてほしいものがありますか": {KO: "사다 드릴 게 있으세요?", EN: "Is there anything you would like me to buy for you?", ZH: "有什么需要我帮您买的吗？", YUE: "有冇嘢要我幫你買呀？", TH: "มีอะไรให้ฉันซื้อมาให้ไหมคะ", FR: "Y a-t-il quelque chose que vous aimeriez que je vous achète ?", RU: "Могу я что-нибудь купить для вас?", PT: "Quer que eu compre alguma coisa para você?"},
    "何か買ってきてほしいものはありますか": {KO: "사다 드릴 게 있으세요?", EN: "Is there anything you would like me to buy for you?", ZH: "有什么需要我帮您买的吗？", YUE: "有冇嘢要我幫你買呀？", TH: "มีอะไรให้ฉันซื้อมาให้ไหมคะ", FR: "Y a-t-il quelque chose que vous aimeriez que je vous achète ?", RU: "Могу я что-нибудь купить для вас?", PT: "Quer que eu compre alguma coisa para você?"},
    # 「〜を買ってきます」は、「買いに行って、戻ってくる」。「持ってきます（가져다 드릴게요）」と、取り違えた（韓国語・ロシア語・ポルトガル語。2026-10-12）
    "これから食べ物を買ってきます": {KO: "지금 음식을 사 올게요", EN: "I'll go and buy some food now", ZH: "我这就去买点吃的", YUE: "我而家去買啲嘢食", TH: "ตอนนี้จะไปซื้ออาหารมาแล้วนะคะ", FR: "Je vais acheter de la nourriture maintenant", RU: "Сейчас схожу куплю еду", PT: "Vou comprar comida agora"},
    "これから飲み物を買ってきます": {KO: "지금 음료를 사 올게요", EN: "I'll go and buy some drinks now", ZH: "我这就去买点喝的", YUE: "我而家去買啲飲嘢", TH: "ตอนนี้จะไปซื้อเครื่องดื่มมาแล้วนะคะ", FR: "Je vais acheter des boissons maintenant", RU: "Сейчас схожу куплю напитки", PT: "Vou comprar bebidas agora"},    "食べ物を買ってきます": {KO: "음식을 사 올게요", EN: "I'll go and buy some food", ZH: "我去买点吃的", YUE: "我去買啲嘢食", TH: "ไปซื้ออาหารมาแล้วนะคะ", FR: "Je vais acheter de la nourriture", RU: "Схожу куплю еду", PT: "Vou comprar comida"},
    "飲み物を買ってきます": {KO: "음료를 사 올게요", EN: "I'll go and buy some drinks", ZH: "我去买点喝的", YUE: "我去買啲飲嘢", TH: "ไปซื้อเครื่องดื่มมาแล้วนะคะ", FR: "Je vais acheter des boissons", RU: "Схожу куплю напитки", PT: "Vou comprar bebidas"},
    "ご飯を買ってきます": {KO: "밥을 사 올게요", EN: "I'll go and buy some food", ZH: "我去买点饭", YUE: "我去買飯", TH: "ไปซื้อข้าวมาแล้วนะคะ", FR: "Je vais acheter à manger", RU: "Схожу куплю поесть", PT: "Vou comprar comida"},
    "お弁当を買ってきます": {KO: "도시락을 사 올게요", EN: "I'll go and buy a bento", ZH: "我去买便当", YUE: "我去買飯盒", TH: "ไปซื้อข้าวกล่องมาแล้วนะคะ", FR: "Je vais acheter un bento", RU: "Схожу куплю бэнто", PT: "Vou comprar um bentô"},    "お飲み物": {PT: "bebidas"},
    "お休みです": {PT: "está de folga"},
    "お席にご案内いたします": {PT: "Vou levá-lo ao seu lugar"},
    "こちらへどうぞ": {PT: "por aqui, por favor"},
    "特典としてコースターがもらえます": {PT: "você ganha um porta-copos de brinde"},    # かな（カタカナ）の外来語が、そのまま訳文に残ると、検査で不正になる（広東語の「カクテル」。2026-10-12）
    "カクテル": {KO: "칵테일", EN: "cocktail", ZH: "鸡尾酒", YUE: "雞尾酒", TH: "ค็อกเทล", FR: "cocktail", RU: "коктейль", PT: "coquetel"},
    "ボーイ": {KO: "웨이터", EN: "waiter", ZH: "服务员", YUE: "侍應", TH: "พนักงานชาย", FR: "serveur", RU: "официант", PT: "garçom"},
    "フルーツの盛り合わせ": {KO: "과일 모둠 접시", EN: "fruit platter", ZH: "水果拼盘", YUE: "生果拼盤", TH: "ผลไม้รวม", FR: "assortiment de fruits", RU: "фруктовая тарелка", PT: "prato de frutas"},
    "じゃんけん": {KO: "가위바위보", EN: "rock-paper-scissors", ZH: "猜拳", YUE: "猜拳", TH: "เป่ายิ้งฉุบ", FR: "pierre-feuille-ciseaux", RU: "камень-ножницы-бумага", PT: "jokenpô"},
    "撮影": {KO: "촬영", EN: "photography", ZH: "拍摄", YUE: "拍攝", TH: "ถ่ายภาพ", FR: "photographie", RU: "фотосъёмка", PT: "fotografia"},
    "しつこいお誘い": {KO: "집요한 권유", EN: "persistent solicitation", ZH: "纠缠不休的邀约", YUE: "糾纏不休嘅邀請", TH: "การชวนอย่างตื๊อ", FR: "sollicitations insistantes", RU: "навязчивые приглашения", PT: "convites insistentes"},
    "お気をつけてお出かけください": {KO: "조심히 다녀오세요", EN: "Please take care out there", ZH: "请路上小心", YUE: "請路上小心", TH: "เดินทางโดยสวัสดิภาพนะคะ", FR: "Faites attention en sortant", RU: "Будьте осторожны в пути", PT: "Tenha cuidado ao sair"},
    "お会いできるのを楽しみにしています": {KO: "또 뵙기를 기대할게요", EN: "I look forward to seeing you again", ZH: "期待再次见到您", YUE: "期待再見到你", TH: "รอพบคุณอีกครั้งนะคะ", FR: "J'attends avec impatience de vous revoir", RU: "С нетерпением жду новой встречи", PT: "Espero ver você de novo"},
    "退店していただきます": {KO: "퇴장해 주셔야 합니다", EN: "you will be asked to leave", ZH: "我们会请您离店", YUE: "我哋會請你離店", TH: "จะต้องขอให้ออกจากร้าน", FR: "vous serez prié de quitter l'établissement", RU: "вас попросят покинуть заведение", PT: "você será convidado a se retirar"},
    "アフター": {KO: "2차(애프터)", EN: "an outing after work (\"after\")", ZH: "下班后的约会（After）", YUE: "放工後嘅約會（After）", TH: "การนัดหลังเลิกงาน (After)", FR: "sortie après le travail (« after »)", RU: "встреча после работы («афтер»)", PT: "passeio depois do trabalho (\"after\")"},
    "同伴のご予約": {KO: "동반 출근 예약", EN: "dohan (going to the club together) reservation", ZH: "同伴入店的预约", YUE: "同伴入場嘅預約", TH: "การจองเข้าร้านพร้อมกัน (โดฮัน)", FR: "réservation de dohan (venir ensemble au club)", RU: "бронь «дохан» (приход в клуб вместе)", PT: "reserva de dohan (chegar ao clube juntos)"},
    "指名の変更": {KO: "지명 변경", EN: "changing your request", ZH: "更换指名", YUE: "更改指名", TH: "เปลี่ยนคนที่เลือก", FR: "changement de personne demandée", RU: "смена выбранной девушки", PT: "troca da pessoa escolhida"},
    "指名の女の子": {KO: "지명하신 아가씨", EN: "your requested hostess", ZH: "您指名的小姐", YUE: "你指名嘅小姐", TH: "สาวที่คุณเลือก", FR: "jeune hôtesse que vous avez demandée", RU: "выбранная вами девушка", PT: "a anfitriã que você escolheu"},
    "お会計に間違いはございませんか": {KO: "계산에 틀린 부분은 없으신가요?", EN: "Is there anything wrong with the bill?", ZH: "账单有没有错误？", YUE: "賬單有冇錯？", TH: "บิลถูกต้องไหมคะ", FR: "L'addition est-elle correcte ?", RU: "В счёте всё верно?", PT: "Está tudo certo com a conta?"},
    "お会計は、お帰りの際にレジでお願いします": {KO: "계산은 돌아가실 때 계산대에서 해 주세요", EN: "Please pay at the register when you leave", ZH: "请在离开时到收银台结账", YUE: "請喺離開時去收銀處結賬", TH: "กรุณาชำระเงินที่แคชเชียร์ตอนกลับค่ะ", FR: "Veuillez régler à la caisse en partant", RU: "Пожалуйста, оплатите на кассе при выходе", PT: "Por favor, pague no caixa ao sair"},
    "ご注文は以上でよろしいですか": {KO: "주문은 이상으로 괜찮으신가요?", EN: "Is that everything for your order?", ZH: "您的点单就这些吗？", YUE: "你嘅點餐就係咁多嗎？", TH: "สั่งเท่านี้ใช่ไหมคะ", FR: "C'est tout pour votre commande ?", RU: "Это всё, что вы хотите заказать?", PT: "É só isso no seu pedido?"},
    "整理券": {KO: "번호표", EN: "numbered ticket", ZH: "号码牌", YUE: "號碼牌", TH: "บัตรคิว", FR: "ticket numéroté", RU: "номерок", PT: "senha de atendimento"},
    "ご入店": {KO: "입장", EN: "entry", ZH: "入店", YUE: "入店", TH: "การเข้าร้าน", FR: "entrer", RU: "вход", PT: "entrada"},
    "貸切": {KO: "대관", EN: "private event", ZH: "包场", YUE: "包場", TH: "เหมาร้าน (งานส่วนตัว)", FR: "privatisation", RU: "закрытое мероприятие", PT: "evento privado"},
    # --- キャバクラ用語（2026-10-09。公開の用語集（バイトルの「夜のお仕事キーワード」ほか）で語を調べ、接客の会話に出そうな語を選んだ。訳は自分たちで付けた） ---
    "お通し": {KO: "기본 안주(오토시)", EN: "table snack (otoshi)", ZH: "开胃小菜", YUE: "開胃小食", TH: "ของว่างประจำโต๊ะ (โอโตชิ)", FR: "petit amuse-bouche (otoshi)", RU: "закуска к столу (отоси)", PT: "petisco da casa (otoshi)"},
    "チャーム": {KO: "안주", EN: "complimentary snack", ZH: "小零食", YUE: "小食", TH: "ของแกล้ม", FR: "amuse-bouche", RU: "закуска", PT: "petisco de cortesia"},
    "割り物": {KO: "섞는 음료", EN: "mixers", ZH: "调酒饮料", YUE: "兌酒飲品", TH: "เครื่องดื่มผสม", FR: "boissons pour allonger", RU: "напитки для разбавления", PT: "mixers"},  # 「믹서」「믹서용 음료」だと、訳が「민」と崩れる文があった。「섞는 음료」は、試した 3 文とも正しかった
    "ハウスボトル": {KO: "하우스 보틀(기본 제공 술)", EN: "house bottle", ZH: "店内基本用酒", YUE: "店內基本用酒", TH: "เหล้าประจำร้าน", FR: "bouteille de la maison", RU: "бутылка заведения", PT: "garrafa da casa"},
    "ネームプレート": {KO: "이름표", EN: "name tag", ZH: "名牌", YUE: "名牌", TH: "ป้ายชื่อ", FR: "plaque nominative", RU: "именная табличка", PT: "etiqueta com o nome"},
    "持ち込み": {KO: "반입", EN: "bringing in outside food or drink", ZH: "自带", YUE: "自帶", TH: "การนำเข้ามา", FR: "apport de l'extérieur", RU: "вносить с собой", PT: "trazer comida ou bebida de fora"},
    "店外でのお付き合い": {KO: "가게 밖에서의 만남", EN: "meeting outside the club", ZH: "店外的私下往来", YUE: "店外嘅私下往來", TH: "การนัดพบนอกร้าน", FR: "rencontres en dehors du club", RU: "встречи вне заведения", PT: "encontros fora do clube"},
    "源氏名": {KO: "활동명", EN: "stage name", ZH: "艺名", YUE: "藝名", TH: "ชื่อในการทำงาน", FR: "nom de scène", RU: "сценическое имя", PT: "nome artístico"},
    "黒服": {KO: "남자 직원", EN: "floor staff", ZH: "男性工作人员", YUE: "男性職員", TH: "พนักงานชาย", FR: "personnel de salle", RU: "персонал зала", PT: "equipe de salão"},
    "キャッシャー": {KO: "계산대", EN: "cashier", ZH: "收银台", YUE: "收銀處", TH: "แคชเชียร์", FR: "caisse", RU: "касса", PT: "caixa"},
    "チェンジ": {KO: "교체", EN: "a change", ZH: "更换", YUE: "更換", TH: "เปลี่ยนตัว", FR: "changement", RU: "замена", PT: "troca"},
    "席替え": {KO: "아가씨 교대", EN: "hostess rotation", ZH: "换小姐", YUE: "轉枱", TH: "การสลับสาว", FR: "changement de place des hôtesses", RU: "смена девушек", PT: "troca de anfitriãs"},
    "飲み直し": {KO: "새 세트로 다시 마시기", EN: "starting a new set", ZH: "重新开一个套餐续喝", YUE: "重新開一個套餐再飲", TH: "เริ่มเซ็ตใหม่เพื่อดื่มต่อ", FR: "recommencer un nouveau set", RU: "начать новый сет", PT: "começar um novo set"},
    "ヘルプ": {KO: "보조 아가씨(헬프)", EN: "an assisting hostess", ZH: "协助的小姐", YUE: "幫手嘅小姐", TH: "สาวผู้ช่วย", FR: "hôtesse d'assistance", RU: "помогающая девушка", PT: "uma anfitriã de apoio"},
    "店外": {KO: "가게 밖", EN: "outside the club", ZH: "店外", YUE: "店外", TH: "นอกร้าน", FR: "en dehors du club", RU: "вне заведения", PT: "fora do clube"},
    "ご新規": {KO: "처음 오신 손님", EN: "first-time customer", ZH: "首次来店的客人", YUE: "首次到訪嘅客人", TH: "ลูกค้าใหม่", FR: "nouveau client", RU: "новый гость", PT: "cliente novo"},
    "フリー": {KO: "지명 없음(프리)", EN: "no nomination (\"free\")", ZH: "不指名（自由）", YUE: "唔指名（Free）", TH: "ไม่ระบุตัว (ฟรี)", FR: "sans demande particulière (« free »)", RU: "без выбора девушки («фри»)", PT: "sem escolha de anfitriã (\"free\")"},
    "客引き": {KO: "호객 행위", EN: "touts", ZH: "拉客", YUE: "拉客", TH: "การชักชวนลูกค้าตามถนน", FR: "rabatteurs", RU: "зазывалы", PT: "aliciadores"},
    "ラストまで": {KO: "마감 시간까지", EN: "until closing time", ZH: "到营业结束", YUE: "到營業結束", TH: "จนถึงปิดร้าน", FR: "jusqu'à la fermeture", RU: "до закрытия", PT: "até o fechamento"},
    "チャージ": {KO: "입장료(차지)", EN: "cover charge", ZH: "入场费", YUE: "入場費", TH: "ค่าเข้าร้าน", FR: "droit d'entrée", RU: "плата за вход", PT: "taxa de entrada"},
    "サービス料": {KO: "서비스 요금", EN: "service charge", ZH: "服务费", YUE: "服務費", TH: "ค่าบริการ", FR: "frais de service", RU: "плата за обслуживание", PT: "a taxa de serviço"},
    # --- メイドカフェ用語（2026-10-10。公開の用語集（メイドカフェ運営会社の FAQ、紹介サイト）で語を調べ、接客の会話に出そうな語を選んだ。訳は自分たちで付けた） ---
    "メイドカフェ": {KO: "메이드 카페", EN: "maid café", ZH: "女仆咖啡厅", YUE: "女僕咖啡店", TH: "เมดคาเฟ่", FR: "maid café", RU: "мейд-кафе", PT: "maid café"},
    "メイド喫茶": {KO: "메이드 카페", EN: "maid café", ZH: "女仆咖啡厅", YUE: "女僕咖啡店", TH: "เมดคาเฟ่", FR: "maid café", RU: "мейд-кафе", PT: "maid café"},
    "コンカフェ": {KO: "콘셉트 카페", EN: "concept café", ZH: "主题咖啡厅", YUE: "主題咖啡店", TH: "คอนเซ็ปต์คาเฟ่", FR: "café à thème", RU: "тематическое кафе", PT: "café temático"},
    "キャバクラ": {KO: "캬바쿠라", EN: "cabaret club (kyabakura)", ZH: "陪酒俱乐部（キャバクラ）", YUE: "陪酒夜總會", TH: "คาบาเรต์คลับ (คยาบาคุระ)", FR: "cabaret-club (kyabakura)", RU: "кабаре-клуб (кябакура)", PT: "clube de hostess (kyabakura)"},
    "お給仕": {KO: "서빙", EN: "service", ZH: "服务", YUE: "服務", TH: "การบริการ", FR: "service", RU: "обслуживание", PT: "serviço"},
    "お出かけ": {KO: "외출", EN: "going out", ZH: "出门", YUE: "出門", TH: "ออกไปข้างนอก", FR: "sortie", RU: "выход", PT: "saída"},
    "お屋敷": {KO: "저택", EN: "mansion", ZH: "宅邸", YUE: "大宅", TH: "คฤหาสน์", FR: "manoir", RU: "особняк", PT: "mansão"},
    "お出迎え": {KO: "맞이", EN: "greeting", ZH: "迎接", YUE: "迎接", TH: "การต้อนรับ", FR: "accueil", RU: "встреча", PT: "recepção"},
    "お見送り": {KO: "배웅", EN: "seeing you off", ZH: "送行", YUE: "送行", TH: "การส่งออกประตู", FR: "raccompagnement", RU: "проводы", PT: "acompanhar na saída"},
    "お絵描き": {KO: "그림 그리기", EN: "drawing", ZH: "画画", YUE: "畫畫", TH: "การวาดรูป", FR: "dessin", RU: "рисование", PT: "desenho"},
    "お絵かき": {KO: "그림 그리기", EN: "drawing", ZH: "画画", YUE: "畫畫", TH: "การวาดรูป", FR: "dessin", RU: "рисование", PT: "desenho"},
    "愛込め": {KO: "사랑을 담는 주문(아이코메)", EN: "a love-infused spell (aikome)", ZH: "注入爱意的魔法（Aikome）", YUE: "注入愛意嘅魔法（Aikome）", TH: "เวทมนตร์ใส่ความรัก (ไอโคเมะ)", FR: "sort chargé d'amour (aikome)", RU: "заклинание с любовью («айкомэ»)", PT: "feitiço cheio de amor (aikome)"},
    "ミュージックチャージ": {KO: "뮤직 차지", EN: "music charge", ZH: "音乐费", YUE: "音樂費", TH: "ค่าดนตรี", FR: "supplément musique", RU: "плата за музыку", PT: "taxa de música"},
    "お家賃": {KO: "입장료(오야치)", EN: "entrance fee (called \"rent\")", ZH: "入场费（称为「房租」）", YUE: "入場費（叫做「租金」）", TH: "ค่าเข้าร้าน (เรียกว่า \"ค่าเช่า\")", FR: "droit d'entrée (appelé « loyer »)", RU: "плата за вход (называется «арендой»)", PT: "taxa de entrada (chamada de \"aluguel\")"},
    "お楽しみ会": {KO: "깜짝 이벤트", EN: "surprise event", ZH: "惊喜活动", YUE: "驚喜活動", TH: "กิจกรรมเซอร์ไพรส์", FR: "événement surprise", RU: "сюрприз-мероприятие", PT: "evento surpresa"},
    "萌えちゃーじ": {KO: "메이드 휴식 시간", EN: "maid rest time", ZH: "女仆休息时间", YUE: "女僕休息時間", TH: "เวลาพักของเมด", FR: "pause des maids", RU: "перерыв мейд", PT: "intervalo das maids"},
    "メイド長にご用件をお伝えください": {KO: "메이드장에게 용건을 말씀해 주세요", EN: "Please tell the head maid what you need", ZH: "请把需求告诉女仆长", YUE: "請將需要話俾女僕長知", TH: "กรุณาแจ้งธุระกับหัวหน้าเมด", FR: "Veuillez dire à la cheffe des maids ce dont vous avez besoin", RU: "Пожалуйста, скажите старшей мейд, что вам нужно", PT: "Por favor, diga à chefe das maids o que você precisa"},
    "生誕祭": {KO: "생일 이벤트", EN: "birthday event", ZH: "生日活动", YUE: "生日活動", TH: "งานวันเกิด", FR: "événement d'anniversaire", RU: "праздник по случаю дня рождения", PT: "evento de aniversário"},
    "新人メイド": {KO: "신입 메이드", EN: "new maid", ZH: "新人女仆", YUE: "新人女僕", TH: "เมดฝึกหัด", FR: "nouvelle maid", RU: "новая мейд", PT: "maid novata"},
    "メイド長": {KO: "메이드장", EN: "head maid", ZH: "女仆长", YUE: "女僕長", TH: "หัวหน้าเมด", FR: "cheffe des maids", RU: "старшая мейд", PT: "chefe das maids"},
    "ブロマイド": {KO: "브로마이드", EN: "bromide (photo print)", ZH: "偶像照片", YUE: "偶像相片", TH: "ภาพโปรโมต", FR: "photo-souvenir imprimée", RU: "фотооткрытка", PT: "foto impressa (bromide)"},
    "グッズ": {KO: "굿즈", EN: "merchandise", ZH: "周边商品", YUE: "周邊商品", TH: "สินค้าที่ระลึก", FR: "produits dérivés", RU: "сувениры", PT: "produtos exclusivos"},
    "ポイントカード": {KO: "포인트 카드", EN: "point card", ZH: "积分卡", YUE: "積分卡", TH: "บัตรสะสมแต้ม", FR: "carte de points", RU: "бонусная карта", PT: "cartão de pontos"},
    "席料": {KO: "자릿세", EN: "seating charge", ZH: "座位费", YUE: "座位費", TH: "ค่าที่นั่ง", FR: "frais de place", RU: "плата за место", PT: "taxa de assento"},
    # --- コンカフェ用語（2026-10-10。公開の紹介記事（fun-japan、タウンワークマガジン、ニコニコ大百科）で語を調べ、接客の会話に出そうな語を選んだ。訳は自分たちで付けた） ---
    "執事カフェ": {KO: "집사 카페", EN: "butler café", ZH: "执事咖啡厅", YUE: "執事咖啡店", TH: "บัตเลอร์คาเฟ่", FR: "café de majordomes", RU: "кафе с дворецкими", PT: "café de mordomos"},
    "男装カフェ": {KO: "남장 카페", EN: "café where the staff dress in men's clothes", ZH: "男装咖啡厅", YUE: "男裝咖啡店", TH: "คาเฟ่ที่พนักงานแต่งชุดผู้ชาย", FR: "café où le personnel s'habille en homme", RU: "кафе, где персонал одет в мужскую одежду", PT: "café em que a equipe se veste de homem"},
    "地雷系": {KO: "지뢰계(어두운 귀여움 패션)", EN: "jirai-kei (dark cute fashion)", ZH: "地雷系（暗黑可爱风）", YUE: "地雷系（暗黑可愛風）", TH: "สไตล์จิไรเคย์ (แฟชั่นน่ารักแนวดาร์ก)", FR: "style jirai-kei (mode mignonne et sombre)", RU: "стиль дзирай-кэй (тёмная милая мода)", PT: "estilo jirai-kei (moda fofa e sombria)"},
    "量産型": {KO: "양산형(프릴과 리본의 걸리시 패션)", EN: "ryōsangata (girly frilly fashion)", ZH: "量产型（蕾丝缎带少女风）", YUE: "量產型（蕾絲絲帶少女風）", TH: "สไตล์เรียวซังงาตะ (แฟชั่นสาวหวานระบาย)", FR: "style ryōsangata (mode girly à volants)", RU: "стиль рёсангата (девичья мода с рюшами)", PT: "estilo ryosangata (moda fofa cheia de babados)"},
    "推し活": {KO: "최애 응원 활동(오시카츠)", EN: "supporting your favorite cast member", ZH: "应援喜欢的成员", YUE: "應援鍾意嘅成員", TH: "การสนับสนุนคนโปรด (โอชิคัตสึ)", FR: "soutenir son favori", RU: "поддержка любимого участника", PT: "apoiar o seu favorito"},  # 「oshi-katsu (…)」と書くと、訳に説明が 2 回出た
    "推し変": {KO: "최애 변경", EN: "switching your oshi", ZH: "更换应援对象", YUE: "轉換應援對象", TH: "เปลี่ยนคนโปรด", FR: "changer de favori", RU: "смена любимого участника", PT: "trocar de favorito"},
    "担当キャスト": {KO: "담당 캐스트", EN: "your cast member", ZH: "负责的成员", YUE: "負責嘅成員", TH: "แคสต์ผู้ดูแลคุณ", FR: "votre cast attitré", RU: "ваш закреплённый участник", PT: "seu integrante da cast"},
    "チェキ飯": {KO: "음식과 함께 찍는 체키", EN: "a Cheki photo with your food", ZH: "与餐点合拍的拍立得", YUE: "同餐點合拍嘅即影即有", TH: "ถ่ายเชคิกับอาหาร", FR: "photo Cheki avec votre plat", RU: "Чеки с вашим блюдом", PT: "foto Cheki com a sua comida"},
    "シャンパンコール": {KO: "샴페인 콜", EN: "champagne call (a celebratory cheer for a champagne order)", ZH: "香槟祝酒（点香槟时的庆祝欢呼）", YUE: "香檳慶祝（叫香檳時嘅歡呼）", TH: "แชมเปญคอล (เสียงเชียร์ฉลองเมื่อสั่งแชมเปญ)", FR: "champagne call (acclamation lors d'une commande de champagne)", RU: "шампань-колл (торжественные возгласы при заказе шампанского)", PT: "champagne call (um brinde animado ao pedir champanhe)"},
    "出入り禁止": {KO: "출입 금지", EN: "banned from the store", ZH: "禁止入店", YUE: "禁止入店", TH: "ห้ามเข้าร้าน", FR: "interdit d'entrée", RU: "вход запрещён", PT: "proibido de entrar"},
    "出禁": {KO: "출입 금지", EN: "banned from the store", ZH: "禁止入店", YUE: "禁止入店", TH: "ห้ามเข้าร้าน", FR: "interdit d'entrée", RU: "вход запрещён", PT: "proibido de entrar"},
    "常連": {KO: "단골", EN: "regular", ZH: "常客", YUE: "常客", TH: "ลูกค้าประจำ", FR: "habitué", RU: "постоянный клиент", PT: "cliente frequente"},
    "キャッチ": {KO: "호객", EN: "touting", ZH: "拉客", YUE: "拉客", TH: "การเรียกลูกค้า", FR: "racolage", RU: "зазывание", PT: "aliciamento"},
    "アニソン": {KO: "애니송", EN: "anime songs", ZH: "动漫歌曲", YUE: "動漫歌曲", TH: "เพลงอนิเมะ", FR: "chansons d'anime", RU: "песни из аниме", PT: "músicas de anime"},
    "スタンプカード": {KO: "스탬프 카드", EN: "stamp card", ZH: "集章卡", YUE: "儲印卡", TH: "บัตรสะสมแสตมป์", FR: "carte de fidélité à tampons", RU: "карта со штампами", PT: "cartão de carimbos"},
    "来店特典": {KO: "방문 특전", EN: "visit bonus", ZH: "来店礼", YUE: "到店禮品", TH: "ของแถมเมื่อมาร้าน", FR: "cadeau de visite", RU: "подарок за посещение", PT: "brinde de visita"},
    "限定メニュー": {KO: "한정 메뉴", EN: "limited-edition menu", ZH: "限定菜单", YUE: "限定餐牌", TH: "เมนูจำกัด", FR: "menu en édition limitée", RU: "лимитированное меню", PT: "cardápio de edição limitada"},
    "コラボドリンク": {KO: "콜라보 음료", EN: "collaboration drink", ZH: "联名饮品", YUE: "聯名飲品", TH: "เครื่องดื่มคอลแลบ", FR: "boisson de collaboration", RU: "напиток-коллаборация", PT: "bebida colaborativa"},
    "連絡先の交換": {KO: "연락처 교환", EN: "exchanging contact information", ZH: "交换联系方式", YUE: "交換聯絡方式", TH: "การแลกเปลี่ยนข้อมูลติดต่อ", FR: "échange de coordonnées", RU: "обмен контактами", PT: "troca de contatos"},
    "ポイント": {EN: "loyalty points", ZH: "积分", YUE: "積分", TH: "แต้มสะสม", FR: "points de fidélité", RU: "бонусные баллы", PT: "pontos de fidelidade"},  # 「ポイントは…」が「The point is…」（要点は）になった
    # --- 2026-10-10 全言語の見直しで足した語（フランス語などで、意味が取り違えられた表現） ---
    "卒業": {KO: "졸업", EN: "graduate", ZH: "毕业（离开成员行列）", YUE: "畢業（離開成員行列）", TH: "จบการเป็นแคสต์ (กราดูเอต)", FR: "quitter le cast (« graduation »)", RU: "покидает коллектив («выпуск»)", PT: "sair da cast (\"graduação\")"},
    "シャンパンタワー": {KO: "샴페인 타워", EN: "champagne tower", ZH: "香槟塔", YUE: "香檳塔", TH: "แชมเปญทาวเวอร์", FR: "tour de champagne (pyramide de coupes)", RU: "башня из шампанского", PT: "torre de champanhe"},
    "お荷物": {FR: "affaires", RU: "вещи", PT: "pertences"},
    "カゴ": {ZH: "篮子", YUE: "籃", TH: "ตะกร้า", FR: "panier", RU: "корзина", PT: "cesta"},
    "体調はいかがですか": {KO: "컨디션은 어떠세요?", EN: "How are you feeling?", ZH: "您感觉怎么样？", YUE: "你感覺點樣？", TH: "รู้สึกเป็นอย่างไรบ้างคะ", FR: "Comment vous sentez-vous ?", RU: "Как вы себя чувствуете?", PT: "Como você está se sentindo?"},
    "お足元にお気をつけください": {KO: "바닥을 조심하세요", EN: "Please watch your step", ZH: "请小心脚下", YUE: "請小心腳下", TH: "ระวังพื้นด้วยนะคะ", FR: "Faites attention où vous mettez les pieds", RU: "Осторожно, смотрите под ноги", PT: "Cuidado onde pisa"},
    "お帰りの際は": {KO: "돌아가실 때는", EN: "when you leave", ZH: "离开时", YUE: "離開嗰陣", TH: "เมื่อกลับ", FR: "au moment de partir", RU: "при уходе", PT: "ao sair"},
    "初めてのご帰宅ですか": {KO: "처음 방문하시는 건가요?", EN: "Is this your first visit?", ZH: "您是第一次来吗？", YUE: "你係咪第一次嚟？", TH: "มาครั้งแรกใช่ไหมคะ", FR: "C'est votre première visite ?", RU: "Вы у нас впервые?", PT: "É a sua primeira visita?"},
    "本日はご帰宅ありがとうございました": {KO: "오늘 방문해 주셔서 감사합니다", EN: "Thank you for visiting today", ZH: "感谢您今天的光临", YUE: "多謝你今日嚟", TH: "ขอบคุณที่มาวันนี้ค่ะ", FR: "Merci de votre visite aujourd'hui", RU: "Спасибо, что пришли сегодня", PT: "Obrigado pela visita hoje"},
    "またのお帰りをお待ちしております": {KO: "또 와 주세요", EN: "We look forward to seeing you again", ZH: "期待您再次光临", YUE: "期待你再嚟", TH: "รอต้อนรับอีกครั้งนะคะ", FR: "Au plaisir de vous revoir", RU: "Будем рады видеть вас снова", PT: "Esperamos você de novo"},
    "延長はいかがなさいますか": {KO: "연장하시겠어요?", EN: "Would you like an extension?", ZH: "要延长吗？", YUE: "要唔要延長？", TH: "ต่อเวลาไหมคะ", FR: "Souhaitez-vous prolonger ?", RU: "Хотите продлить?", PT: "Gostaria de prorrogar?"},
    # --- 2026-10-10 最後の確認で足した語 ---
    "ご指名はございますか": {KO: "지명하실 분 계신가요?", EN: "Would you like to request someone?", ZH: "您有想指名的小姐吗？", YUE: "你有冇想指名嘅小姐？", TH: "คุณต้องการเลือกสาวไหมคะ", FR: "Souhaitez-vous demander quelqu'un ?", RU: "Хотите выбрать девушку?", PT: "Gostaria de escolher alguém?"},
    "ソフトドリンク": {KO: "소프트 드링크", EN: "soft drinks", ZH: "软饮料", YUE: "無酒精飲品", TH: "เครื่องดื่มที่ไม่มีแอลกอฮอล์", FR: "boissons sans alcool", RU: "безалкогольные напитки", PT: "bebidas sem álcool"},
    "スタッフにお声がけください": {KO: "직원에게 말씀해 주세요", EN: "please let the staff know", ZH: "请告知工作人员", YUE: "請同員工講一聲", TH: "กรุณาแจ้งพนักงานค่ะ", FR: "veuillez en informer le personnel", RU: "обратитесь к персоналу", PT: "avise a equipe"},
    "キャストへのプレゼントは、スタッフにお渡しください": {KO: "캐스트에게 줄 선물은 직원에게 전달해 주세요", EN: "Please hand gifts for the cast to the staff", ZH: "给成员的礼物请交给工作人员", YUE: "俾成員嘅禮物請交俾員工", TH: "ของขวัญสำหรับแคสต์ กรุณาส่งให้พนักงาน", FR: "Les cadeaux pour le cast sont à remettre au personnel", RU: "Подарки для сотрудницы передайте персоналу", PT: "Os presentes para a cast devem ser entregues à equipe"},
    "本日の出勤キャスト": {PT: "integrantes da cast que estão trabalhando hoje"},
    "ご一緒に「萌え萌えキュン」をお願いします": {KO: "함께 모에모에큥을 부탁드려요", EN: "Please say \"moe moe kyun\" together with us", ZH: "请和我们一起说“moe moe kyun”", YUE: "請同我哋一齊講「moe moe kyun」", TH: "ขอให้ร่วมกันพูด “moe moe kyun” ด้วยกันนะคะ", FR: "Dites avec nous « moe moe kyun », s'il vous plaît", RU: "Пожалуйста, скажите вместе с нами «moe moe kyun»", PT: "Vamos fazer juntos o \"moe moe kyun\", por favor"},
    "しつこいお誘いは、お断りしています": {PT: "Não aceitamos convites insistentes"},
    "お帰りいただく場合があります": {PT: "podem ser convidados a se retirar"},
    "デミグラスソース": {PT: "molho demi-glace"},
    "お時間が近づいてまいりました": {PT: "O seu tempo está acabando"},
    "ラストオーダー": {PT: "último pedido"},
    "SNS": {EN: "social media", ZH: "社交媒体", YUE: "社交媒體", TH: "โซเชียลมีเดีย", FR: "réseaux sociaux", RU: "соцсети", PT: "redes sociais"},
    "メイド": {ZH: "女仆", YUE: "女僕", TH: "เมด", FR: "maid", RU: "мейд", PT: "maid"},
    "同伴のお客様": {KO: "동반 출근 손님", EN: "dohan customer", ZH: "同伴入店的客人", YUE: "同伴入場嘅客人", TH: "ลูกค้าที่มาแบบโดฮัน", FR: "client venu en dohan (avec une hôtesse)", RU: "гость, пришедший по «дохану»", PT: "cliente que veio de dohan (com uma anfitriã)"},
    "女の子が、エレベーターまでお見送りします": {ZH: "小姐会送您到电梯口", YUE: "小姐會送你到升降機口", PT: "A anfitriã vai acompanhar você até o elevador"},
    "初めてのご帰宅": {EN: "your first visit"},
    "飲み放題": {KO: "음료 무제한", EN: "all-you-can-drink", ZH: "畅饮", YUE: "任飲", TH: "ดื่มได้ไม่อั้น", FR: "boissons à volonté", RU: "безлимитные напитки", PT: "bebida à vontade"},
    "初回のお客様": {KO: "처음 방문하신 손님", EN: "first-time customers", ZH: "首次来店的客人", YUE: "首次到訪嘅客人", TH: "ลูกค้าครั้งแรก", FR: "nouveaux clients", RU: "гости, пришедшие впервые", PT: "clientes de primeira vez"},
    "ドリンクのおかわりはいかがですか": {KO: "음료 리필은 어떠세요?", EN: "How about a drink refill?", ZH: "要再来一杯饮料吗？", YUE: "要唔要再嚟一杯飲品？", TH: "ขอเครื่องดื่มเพิ่มไหมคะ", FR: "Souhaitez-vous une autre boisson ?", RU: "Хотите ещё напиток?", PT: "Que tal mais uma bebida?"},
    "女の子をおつけします": {KO: "아가씨를 보내 드리다", EN: "I will send a hostess to your table", ZH: "我会安排小姐过来", YUE: "我會安排小姐過嚟", TH: "จะส่งสาวไปที่โต๊ะนะคะ", FR: "Je vais vous envoyer une jeune hôtesse", RU: "Я пришлю к вам девушку", PT: "Vou mandar uma anfitriã para a sua mesa"},
    "いってらっしゃいませ": {KO: "다녀오세요", EN: "Have a nice day", ZH: "路上小心", YUE: "路上小心", TH: "เดินทางปลอดภัยนะคะ", FR: "Bonne journée", RU: "Хорошего дня", PT: "Tenha um bom dia"},
    "お嬢様": {KO: "아가씨", EN: "Miss", ZH: "大小姐", YUE: "小姐", TH: "คุณหนู", FR: "Mademoiselle", RU: "Госпожа", PT: "Senhorita"},
    "ご帰宅": {KO: "방문"},  # 英語は見本なしの方が自然（見本を渡すと「first visit to visit」になった）
    "ワンドリンク制": {KO: "음료 1잔 주문 필수", EN: "one drink minimum", ZH: "每人至少点一杯饮料", YUE: "每人最少叫一杯飲品", TH: "ต้องสั่งเครื่องดื่มอย่างน้อยหนึ่งแก้ว", FR: "une boisson minimum par personne", RU: "минимум один напиток на человека", PT: "consumo mínimo de uma bebida"},
    "オムライス": {KO: "오므라이스", EN: "omurice (omelet rice)", ZH: "蛋包饭", YUE: "蛋包飯", TH: "ข้าวห่อไข่", FR: "omurice (omelette au riz)", RU: "омурайс (омлет с рисом)", PT: "omurice (omelete com arroz)"},
    "ケチャップ": {KO: "케첩", EN: "ketchup", ZH: "番茄酱", YUE: "茄汁", TH: "ซอสมะเขือเทศ", FR: "ketchup", RU: "кетчуп", PT: "ketchup"},
    "おまじない": {KO: "주문", EN: "magic spell", ZH: "魔法咒语", YUE: "魔法咒語", TH: "คาถา", FR: "sort magique", RU: "заклинание", PT: "feitiço mágico"},
    "萌え萌えキュン": {KO: "모에모에큥", EN: "moe moe kyun", ZH: "moe moe kyun", YUE: "moe moe kyun", TH: "moe moe kyun", FR: "moe moe kyun", RU: "moe moe kyun", PT: "moe moe kyun"},
    "ツーショット": {KO: "투샷", EN: "two-shot", ZH: "双人合照", YUE: "雙人合照", TH: "ถ่ายสองคน", FR: "photo à deux", RU: "фото вдвоём", PT: "foto a dois"},
    "チェキ": {KO: "체키(즉석 사진)", EN: "Cheki (instant photo)", ZH: "拍立得（Cheki）", YUE: "即影即有（Cheki）", TH: "เชคิ (ภาพถ่ายฟิล์มทันที)", FR: "Cheki (photo instantanée)", RU: "Чеки (моментальное фото)", PT: "Cheki (foto instantânea)"},
    "場内指名": {KO: "장내 지명", EN: "in-house nomination", ZH: "场内指名", YUE: "場內指名", TH: "เลือกสาวในร้าน", FR: "demande en salle", RU: "выбор девушки в зале", PT: "escolha no salão"},
    "本指名": {KO: "본 지명", EN: "regular nomination", ZH: "正式指名", YUE: "正式指名", TH: "ระบุตัวเป็นหลัก", FR: "demande officielle", RU: "основной выбор", PT: "escolha oficial"},
    "指名料": {KO: "지명료", EN: "nomination fee", ZH: "指名费", YUE: "指名費", TH: "ค่าเลือกตัว", FR: "frais de demande", RU: "плата за выбор девушки", PT: "a taxa de escolha"},
    "ご指名": {KO: "지명", EN: "request", ZH: "指名", YUE: "指名", TH: "การเลือกตัว", FR: "demande", RU: "выбор", PT: "escolha"},
    "キャストドリンク": {KO: "캐스트 드링크", EN: "cast drink", ZH: "请成员喝的饮料", YUE: "請成員飲嘅飲品", TH: "เครื่องดื่มสำหรับแคสต์", FR: "boisson pour un membre du cast", RU: "угощение для девушки", PT: "bebida para a cast"},
    "キャスト": {KO: "캐스트", EN: "cast member", ZH: "成员", YUE: "成員", TH: "แคสต์", FR: "membre du cast", RU: "сотрудница", PT: "integrante da cast"},
    "推しのキャスト": {KO: "최애 캐스트", EN: "favorite cast member", ZH: "最喜欢的成员", YUE: "最鍾意嘅成員", TH: "แคสต์ที่ชอบที่สุด", FR: "membre du cast préféré", RU: "любимая сотрудница", PT: "integrante da cast favorito"},
    "ライブ": {KO: "라이브 공연", EN: "live performance", ZH: "现场演出", YUE: "現場表演", TH: "การแสดงสด", FR: "spectacle live", RU: "живое выступление", PT: "show ao vivo"},
    "推し": {KO: "최애", EN: "favorite", ZH: "最喜欢的成员", YUE: "最鍾意嘅成員", TH: "คนที่ชอบที่สุด (โอชิ)", FR: "favori(te)", RU: "фаворит(ка)", PT: "favorito"},
    "ボトルのキープ": {KO: "보틀 키핑", EN: "bottle keep (storing a bottle for your next visit)", ZH: "寄存酒瓶", YUE: "寄存酒瓶", TH: "ฝากขวด", FR: "garder une bouteille (pour la prochaine visite)", RU: "хранение бутылки", PT: "guardar uma garrafa (para a próxima visita)"},
    "ボトルをキープ": {KO: "보틀 키핑", EN: "bottle keep (storing a bottle for your next visit)", ZH: "寄存酒瓶", YUE: "寄存酒瓶", TH: "ฝากขวด", FR: "garder une bouteille (pour la prochaine visite)", RU: "хранение бутылки", PT: "guardar uma garrafa (para a próxima visita)"},
    "女の子": {KO: "아가씨", EN: "hostess", ZH: "小姐", YUE: "小姐", TH: "สาว ๆ", FR: "jeune hôtesse", RU: "девушка", PT: "anfitriã"},
    "同伴": {KO: "동반", EN: "dohan (going to the club together)", ZH: "同伴入店", YUE: "同伴入場", TH: "โดฮัน (มาร้านด้วยกัน)", FR: "dohan (venir ensemble au club)", RU: "«дохан» (приход в клуб вместе)", PT: "dohan (chegar ao clube juntos)"},
    "セット料金": {KO: "세트 요금", EN: "set price", ZH: "套餐价", YUE: "套餐價", TH: "ค่าเซ็ต", FR: "forfait", RU: "стоимость сета", PT: "valor do set"},
    "延長なさいますか": {KO: "연장하시겠어요?", EN: "Would you like to extend?", ZH: "要延长吗？", YUE: "要唔要延長？", TH: "ต่อเวลาไหมคะ", FR: "Souhaitez-vous prolonger ?", RU: "Хотите продлить?", PT: "Gostaria de prorrogar?"},
    "延長": {KO: "연장", EN: "extension", ZH: "延长", YUE: "延長", TH: "ต่อเวลา", FR: "prolongation", RU: "продление", PT: "prorrogação"},
    "お席料": {KO: "자릿세", EN: "seating charge", ZH: "座位费", YUE: "座位費", TH: "ค่าที่นั่ง", FR: "frais de place", RU: "плата за место", PT: "taxa de assento"},
    "テーブルチャージ": {KO: "테이블 차지", EN: "table charge", ZH: "桌位费", YUE: "枱費", TH: "ค่าโต๊ะ", FR: "frais de table", RU: "плата за столик", PT: "taxa de mesa"},
    "ペンライト": {KO: "펜라이트", EN: "light stick", ZH: "荧光棒", YUE: "螢光棒", TH: "แท่งไฟ", FR: "bâton lumineux", RU: "светящаяся палочка", PT: "bastão de luz"},
    "触れないでください": {KO: "만지지 말아 주세요", EN: "Please do not touch", ZH: "请勿触碰", YUE: "請勿觸碰", TH: "กรุณาอย่าสัมผัส", FR: "Veuillez ne pas toucher", RU: "Пожалуйста, не прикасайтесь", PT: "Por favor, não toque"},
    "お会計はこちらでお願いします": {KO: "계산은 여기서 부탁드립니다", EN: "Please pay here", ZH: "请在这里结账", YUE: "請喺呢度結賬", TH: "กรุณาชำระเงินที่นี่ค่ะ", FR: "Veuillez payer ici", RU: "Пожалуйста, оплатите здесь", PT: "Por favor, pague aqui"},
}

# 「3点まで」の「点」（品物の数）。数字の後の「点」だけを品物の数として扱う
# 「〜を買ってきます」「〜を買ってきましょうか」（買いに行って、戻ってくる）。「持ってきます」と取り違えやすいので、
# 品物ごとに、8 言語の見本を作る（2026-10-12 に、食べ物で、韓国語・ロシア語・ポルトガル語が「持ってくる」と訳した）。
# 品物: 日本語 → (韓国語（助詞つき）, 英語, 中国語, 広東語, タイ語, フランス語, ロシア語（対格）, ポルトガル語)
_ERRAND_ITEMS = {
    "水": ("물을", "some water", "水", "水", "น้ำ", "de l'eau", "воду", "água"),
    "お水": ("물을", "some water", "水", "水", "น้ำ", "de l'eau", "воду", "água"),
    "お茶": ("차를", "some tea", "茶", "茶", "ชา", "du thé", "чай", "chá"),
    "コーヒー": ("커피를", "some coffee", "咖啡", "咖啡", "กาแฟ", "du café", "кофе", "café"),
    "ジュース": ("주스를", "some juice", "果汁", "果汁", "น้ำผลไม้", "du jus", "сок", "suco"),
    "お菓子": ("과자를", "some snacks", "零食", "零食", "ขนม", "des friandises", "сладости", "doces"),
    "お土産": ("기념품을", "some souvenirs", "伴手礼", "手信", "ของฝาก", "des souvenirs", "сувениры", "lembrancinhas"),
    "おにぎり": ("주먹밥을", "some rice balls", "饭团", "飯團", "ข้าวปั้น", "des onigiris", "онигири", "onigiris"),
    "パン": ("빵을", "some bread", "面包", "麵包", "ขนมปัง", "du pain", "хлеб", "pão"),
    "薬": ("약을", "some medicine", "药", "藥", "ยา", "des médicaments", "лекарство", "remédio"),
    "傘": ("우산을", "an umbrella", "雨伞", "遮", "ร่ม", "un parapluie", "зонт", "um guarda-chuva"),
    "タバコ": ("담배를", "some cigarettes", "烟", "煙", "บุหรี่", "des cigarettes", "сигареты", "cigarros"),
}
_ERRAND_LANGS = (KO, EN, ZH, YUE, TH, FR, RU, PT)


def _errand_terms() -> dict[str, dict[str, str]]:
    terms: dict[str, dict[str, str]] = {}
    for word, (ko, en, zh, yue, th, fr, ru, pt) in _ERRAND_ITEMS.items():
        buy = {
            KO: f"{ko} 사 올게요", EN: f"I'll go and buy {en}", ZH: f"我去买{zh}", YUE: f"我去買{yue}",
            TH: f"ไปซื้อ{th}มาแล้วนะคะ", FR: f"Je vais acheter {fr}", RU: f"Схожу куплю {ru}", PT: f"Vou comprar {pt}",
        }
        offer = {
            KO: f"{ko} 사다 드릴까요?", EN: f"Shall I go and buy {en} for you?", ZH: f"要我去买{zh}吗？", YUE: f"要唔要我去買{yue}呀？",
            TH: f"ให้ไปซื้อ{th}มาให้ไหมคะ", FR: f"Voulez-vous que j'aille acheter {fr} ?", RU: f"Сходить купить {ru} для вас?",
            PT: f"Quer que eu compre {pt} para você?",
        }
        now = {**buy, KO: f"지금 {ko} 사 올게요", EN: f"I'll go and buy {en} now", RU: f"Сейчас схожу куплю {ru}", PT: f"Vou comprar {pt} agora"}
        for key, value in ((f"{word}を買ってきます", buy), (f"これから{word}を買ってきます", now), (f"{word}を買ってきましょうか", offer)):
            terms[key] = value
    return terms


for _key, _value in _errand_terms().items():
    JA_TERMS.setdefault(_key, _value)  # 上で、手で書いた見本があれば、そちらを使う

# 音声認識は、漢字ではなく、ひらがな・カタカナで出すことが多い（「もえもえきゅん」「モエモエキュン」）。
# 漢字の「萌え萌えキュン」にしか見本がないと、「엄마 엄마키운」のような誤訳になる（2026-10-12）。
# 「萌え」を「燃え」と聞き違えた形も、同じ見本に結びつける。
_MOE = JA_TERMS["萌え萌えキュン"]
MOE_VARIANT_KEYS: tuple[str, ...] = tuple(
    _head + _tail
    for _head in ("萌え萌え", "もえもえ", "モエモエ", "萌えもえ", "萌えモエ", "燃え燃え", "もえ萌え")
    for _tail in ("キュン", "きゅん", "ｷｭﾝ")
    if _head + _tail != "萌え萌えキュン"
)
for _key in MOE_VARIANT_KEYS:
    JA_TERMS.setdefault(_key, _MOE)


_ITEMS = re.compile(r"(\d+)点")
_ITEM_WORDS = {KO: "{n}개", EN: "{n} items", ZH: "{n}件", YUE: "{n}件", TH: "{n} ชิ้น", FR: "{n} articles", RU: "{n} вещи"}

# 各言語の語 → 日本語（お客様の言葉を訳すとき）
TO_JA_TERMS: dict[str, dict[str, str]] = {
    KO: {
        "면세": "免税", "영수증": "レシート", "탈의실": "試着室", "입어 봐도": "試着しても", "포장": "包装",
        "자릿세": "席料", "지명비": "指名料", "지명": "指名", "계산해 주세요": "お会計をお願いします", "체키": "チェキ",
        "캐스트": "キャスト", "키핑할 수 있어요": "ボトルキープできますか",
        "하우스 보틀": "ハウスボトル", "아가씨 교체": "チェンジ", "입장료": "入場料", "기본 안주": "お通し", "이름표": "ネームプレート", "처음 왔": "初めて来た",
        "동반": "同伴", "애프터": "アフター", "노래방": "カラオケ",
        "샴페인 콜": "シャンパンコール", "단골": "常連", "스탬프 카드": "スタンプカード", "방문 특전": "来店特典", "한정 메뉴": "限定メニュー",
        "출입 금지": "出入り禁止", "지뢰계": "地雷系", "집사 카페": "執事カフェ", "담당 캐스트": "担当キャスト",
        "최애": "推し", "생일 이벤트": "生誕祭", "굿즈": "グッズ", "브로마이드": "ブロマイド", "모에모에큥": "萌え萌えキュン", "모에모에 큥": "萌え萌えキュン", "모에 모에 큥": "萌え萌えキュン", "모에모에 쿤": "萌え萌えキュン", "뮤직 차지": "ミュージックチャージ", "다시 앉히고": "もう一度席につけて指名したい", "따로따로 계산": "別会計", "계산서": "お会計の伝票", "콜라보": "コラボ",
    },
    EN: {
        "tax refund": "免税", "tax-free": "免税", "try this on": "試着する", "gift-wrap": "プレゼント包装", "restroom": "お手洗い",
        "seating charge": "席料", "nomination fee": "指名料", "nominate": "指名", "cast member": "キャスト", "cheki": "チェキ",
        "keep a bottle": "ボトルをキープする", "check, please": "お会計をお願いします", "set price": "セット料金",
        "extend": "延長", "house bottle": "ハウスボトル", "cover charge": "チャージ", "name tag": "ネームプレート", "otoshi": "お通し",
        "champagne call": "シャンパンコール", "stamp card": "スタンプカード", "butler cafe": "執事カフェ", "butler café": "執事カフェ",
        "limited menu": "限定メニュー", "regular customer": "常連のお客様", "banned from": "出入り禁止", "jirai": "地雷系",
        "music charge": "ミュージックチャージ", "birthday event": "生誕祭", "favorite maid": "推しのメイド", "goods": "グッズ", "bromide": "ブロマイド",
        "change the girl": "女の子をチェンジする", "change hostess": "女の子をチェンジする", "dohan": "同伴", "new customer": "ご新規", "bottle keep": "ボトルキープ", "split the bill": "お会計を別々にする", "sit with her again": "もう一度彼女を席につけて指名したい",
        "change my request": "指名を変更する", "working today": "今日出勤している", "here alone": "一人で来ました",
        "moe moe kyun": "萌え萌えキュン", "moe-moe-kyun": "萌え萌えキュン", "moe moe kyunn": "萌え萌えキュン",
        "whiskey with water": "ウイスキーの水割り", "order a drink": "ドリンクを注文する", "point card": "ポイントカード",
    },
    ZH: {"下午": "午後", "上午": "午前", "退税": "免税", "试穿": "試着", "尺码": "サイズ", "支付宝": "アリペイ", "微信支付": "WeChat Pay", "袋子": "袋", "指名费": "指名料", "座位费": "席料", "拍立得": "チェキ", "积分卡": "ポイントカード", "集章卡": "スタンプカード", "同伴": "同伴", "入场费": "入場料", "账单": "お会計", "结账": "お会計", "可以和她合拍": "彼女と一緒に撮ってもいいですか", "可以寄存酒瓶": "ボトルをキープできますか"},
    YUE: {"下晝": "午後", "上晝": "午前", "下午": "午後", "上午": "午前", "退稅": "免税", "試身": "試着", "碼": "サイズ", "指名費": "指名料", "座位費": "席料", "即影即有": "チェキ", "積分卡": "ポイントカード", "儲印卡": "スタンプカード", "入場費": "入場料", "賬單": "お会計", "結賬": "お会計", "可唔可以同佢影": "彼女と一緒に撮ってもいいですか", "可唔可以寄存酒瓶": "ボトルをキープできますか"},
    TH: {"คืนภาษี": "免税", "ห่อของขวัญ": "プレゼント包装", "ไซส์": "サイズ", "เชคิ": "チェキ", "บัตรสะสมแต้ม": "ポイントカード", "ฝากขวด": "ボトルをキープする", "โดฮัน": "同伴", "ค่าที่นั่ง": "席料", "เช็คบิล": "お会計", "คิดเงิน": "お会計", "ถ่ายเชคิกับเธอ": "彼女とチェキを撮ってもいいですか"},
    FR: {"détaxe": "免税", "essayer": "試着する", "carte bancaire": "カード", "cartes bancaires": "カード", "paquet cadeau": "プレゼント包装", "cheki": "チェキ", "dohan": "同伴", "carte de points": "ポイントカード", "garder une bouteille": "ボトルをキープする", "droit d'entrée": "入場料", "carte de fidélité": "スタンプカード", "l'addition": "お会計", "prendre un cheki avec elle": "彼女とチェキを撮ってもいいですか", "je voudrais demander cette hôtesse": "この女性を指名したいです"},
    RU: {"такс-фри": "免税", "примерить": "試着する", "примерочная": "試着室", "упаковать как подарок": "プレゼント包装", "чеки": "チェキ", "дохан": "同伴", "бонусная карта": "ポイントカード", "хранение бутылки": "ボトルをキープする", "плата за вход": "入場料", "счёт, пожалуйста": "お会計をお願いします", "сделать чеки с ней": "彼女とチェキを撮ってもいいですか"},
    PT: {"cheki": "チェキ", "dohan": "同伴", "moe moe kyun": "萌え萌えキュン", "cartão de pontos": "ポイントカード", "guardar uma garrafa": "ボトルをキープする", "taxa de entrada": "入場料", "cartão de carimbos": "スタンプカード", "a conta": "お会計", "tirar um cheki com ela": "彼女とチェキを撮ってもいいですか", "eu quero escolher essa moça": "この女性を指名したいです", "pode guardar a minha garrafa aqui": "ここに私のボトルをキープできますか", "isento de impostos": "免税", "provador": "試着室", "taxa de assento": "席料", "taxa de escolha": "指名料", "champagne call": "シャンパンコール"},
}

# 「萌え萌えキュン」は、どの言語でも、ローマ字（moe moe kyun）で書かれる／聞き取られる。訳し戻しで「モエモエクス」にならないよう見本を付ける
for _lang in (ZH, YUE, TH, FR, RU):
    TO_JA_TERMS[_lang].setdefault("moe moe kyun", "萌え萌えキュン")


# メニューの「業種」で選んだ業種の用語（industries.py が set_active_terms で渡す）。None なら上の JA_TERMS・TO_JA_TERMS の全部を使う
_active: tuple[dict[str, dict[str, str]], dict[str, dict[str, str]], list[str]] | None = None


def set_active_terms(ja_terms: dict[str, dict[str, str]] | None, to_ja_terms: dict[str, dict[str, str]] | None) -> None:
    """使う用語集を差し替える（None は「全部」）。翻訳のスレッドと同時に呼ばれてもよい（まとめて 1 回で入れ替える）。"""
    global _active
    if ja_terms is None or to_ja_terms is None:
        _active = None
    else:
        _active = (ja_terms, to_ja_terms, sorted(ja_terms, key=len, reverse=True))


try:  # tools/make_ja_readings.py が作る表。なければ、読みでは探さない
    from .ja_readings import READINGS as _READINGS
except ImportError:  # pragma: no cover
    _READINGS = {}

_KATA_TO_HIRA = {code: code - 0x60 for code in range(0x30A1, 0x30F7)}  # ァ〜ヶ → ぁ〜ゖ（1 文字ずつ。長さは変わらない）


def _fold(text: str) -> str:
    """カタカナをひらがなにそろえる（「モエモエキュン」と「もえもえきゅん」を同じにする）。文字数は変えない。"""
    return text.translate(_KATA_TO_HIRA)


def find_terms(text: str, source: str, target: str) -> list[tuple[str, str]]:
    """text（source の言語）に入っている用語と、その target の言語での訳（文に出てくる順）。"""
    found: list[tuple[int, str, str]] = []
    active = _active
    ja_terms = JA_TERMS if active is None else active[0]
    to_ja_terms = TO_JA_TERMS if active is None else active[1]
    if source == JA:
        taken: list[tuple[int, int]] = []
        # 音声認識は、漢字ではなくかなで出すことがある（「もえもえきゅん」「ごしゅじんさま」）。
        # 探す前に、カタカナをひらがなにそろえ（文字数は変わらない）、漢字まじりの語は、読み（ひらがな）でも探す。
        folded = _fold(text)
        # 長い語から探し、すでに見つけた語の一部（「試着室」の中の「試着」など）は数えない
        ordered = sorted(ja_terms, key=len, reverse=True) if active is None else active[2]
        for term in ordered:
            translation = ja_terms[term].get(target)
            if translation is None:
                continue
            candidates = [_fold(term)]
            reading = _READINGS.get(term)
            if reading and reading not in candidates:
                candidates.append(reading)
            hit = None
            for candidate in candidates:
                position = folded.find(candidate)
                while position >= 0:
                    end = position + len(candidate)
                    if not any(position < t_end and t_start < end for t_start, t_end in taken):
                        hit = (position, end)
                        break
                    position = folded.find(candidate, position + 1)
                if hit:
                    break
            if hit:
                start, end = hit
                taken.append(hit)
                # モデルに見せる語は、文に出ている形（かなのとき、かなのまま）にする
                found.append((start, text[start:end], translation))
        word = _ITEM_WORDS.get(target)
        if word is not None:
            for match in _ITEMS.finditer(text):
                found.append((match.start(), match.group(), word.format(n=match.group(1))))
    elif target == JA:
        lowered = text.lower()
        for term, translation in to_ja_terms.get(source, {}).items():
            index = lowered.find(term.lower())
            if index >= 0:
                found.append((index, term, translation))
    found.sort()
    return [(term, translation) for _, term, translation in found]
