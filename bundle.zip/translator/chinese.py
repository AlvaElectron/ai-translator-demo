"""中国語の簡体字と繁体字（台湾）の変換（OpenCC）。

翻訳と音声認識は簡体字で行い、台湾の人向けに画面に出すときだけ繁体字に変える。
- 訳文（相手に見せる文）は、字だけでなく語彙も台湾式にする（出租车→計程車、软件→軟體、信息→資訊 など）。
- 原文（台湾の人が話した言葉）は、本人の言葉を置き換えないよう、字だけを変える。
中国語の読み上げモデル（AISHELL-3）は簡体字の辞書で学習しているので、読み上げと発音記号には、
台湾の語彙のまま字だけを簡体字に戻した文（計程車→计程车）を使う。こうすると画面の語と音声が一致する。
"""

from __future__ import annotations

import logging
import threading

log = logging.getLogger(__name__)

# メニューで選ぶ中国語の書き方
SIMPLIFIED = "hans"  # 簡体字（中国大陸）
TRADITIONAL = "hant"  # 繁体字（台湾）
SCRIPTS = (SIMPLIFIED, TRADITIONAL)

# OpenCC の変換設定
_TO_TAIWAN_WORDS = "s2twp"  # 簡体字 → 台湾の繁体字（語彙も台湾式に）
_TO_TAIWAN_CHARS = "s2tw"  # 簡体字 → 台湾の繁体字（字だけ）
_TO_MAINLAND_WORDS = "tw2sp"  # 台湾の繁体字 → 簡体字（語彙も大陸式に）
_TO_SIMPLIFIED_CHARS = "tw2s"  # 台湾の繁体字 → 簡体字（字だけ。語彙は台湾式のまま）
_TO_HONG_KONG = "s2hk"  # 簡体字 → 香港の繁体字（広東語の表示。すでに繁体字ならそのまま）

_lock = threading.Lock()
_converters: dict[str, object] = {}
_unavailable = False


def to_traditional(text: str, taiwan_words: bool = True) -> str:
    """簡体字を台湾の繁体字にする。taiwan_words なら語彙も台湾式にする（変換できないときはそのまま返す）。"""
    return _convert(text, _TO_TAIWAN_WORDS if taiwan_words else _TO_TAIWAN_CHARS)


def to_simplified(text: str, mainland_words: bool = True) -> str:
    """台湾の繁体字を簡体字に戻す。mainland_words なら語彙も大陸式にする（変換できないときはそのまま返す）。"""
    return _convert(text, _TO_MAINLAND_WORDS if mainland_words else _TO_SIMPLIFIED_CHARS)


def to_hongkong(text: str) -> str:
    """広東語を香港の繁体字にする（音声認識が簡体字で書いたときのため。変換できないときはそのまま返す）。"""
    return _convert(text, _TO_HONG_KONG)


def for_speech(text: str) -> str:
    """画面の台湾の繁体字を、読み上げ・発音記号用の簡体字にする（語彙は台湾式のまま。計程車→计程车）。"""
    return to_simplified(text, mainland_words=False)


def taiwan_speech(text: str) -> str:
    """訳文（大陸の簡体字）を、台湾の語彙で読み上げるための簡体字にする（出租车→计程车）。"""
    return for_speech(to_traditional(text))


def _convert(text: str, config: str) -> str:
    if not text:
        return text
    converter = _converter(config)
    return converter.convert(text) if converter is not None else text


def _converter(config: str):
    global _unavailable
    with _lock:
        if config not in _converters and not _unavailable:
            try:
                import opencc

                _converters[config] = opencc.OpenCC(config)
            except Exception:
                # 入っていなくても通訳は続けられる（繁体字を選んでも簡体字のまま表示する）
                _unavailable = True
                log.exception("OpenCC を使えないため、中国語は簡体字のまま表示します（pip install opencc）")
        return _converters.get(config)
