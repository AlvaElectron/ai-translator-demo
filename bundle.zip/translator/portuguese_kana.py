"""ブラジル式のポルトガル語を、日本語話者が読めるカタカナにする（外部ライブラリに依存しない）。

つづりから発音を決める規則で変換する。ブラジルの発音に合わせてある:
- 語末の o は「ウ」、語末の e は「イ」（de → ジ、parte → パルチ）。t・d は i の前で「チ」「ジ」になる
- r は語頭・rr・n/l/s の後では「ハ行」（rua → フア）、母音の間では「ラ行」。語末の l は「ウ」（Brasil → ブラズィウ）
- 鼻母音 ã・õ・ão・ãe・õe、nh（ニャ行）・lh（リャ行）・ch（シャ行）・qu・gu・ç などのつづり
- 子音が続くときは母音を補う（obrigado → オブリガードゥ、advogado → アジヴォガードゥ）
よく使う不規則な語（você・não・tem など）は辞書で直接引く。自動変換なので、実際の発音とは少し違う。

例: Onde fica o banheiro? → オンジ フィカ ウ バニェイル ?
"""

from __future__ import annotations

import re
import unicodedata

# 規則どおりに読まない語、または規則より確実な語
_WORDS = {
    "a": "ア", "as": "アス", "o": "ウ", "os": "ウス", "e": "イ", "é": "エ", "de": "ジ", "do": "ドゥ", "dos": "ドゥス",
    "da": "ダ", "das": "ダス", "em": "エイン", "um": "ウン", "uma": "ウマ", "não": "ナウン", "sim": "スィン", "por": "ポル",
    "para": "パラ", "pra": "プラ", "com": "コン", "que": "キ", "você": "ヴォセー", "vocês": "ヴォセース", "tem": "テイン",
    "têm": "テイン", "bem": "ベイン", "também": "タンベイン", "obrigado": "オブリガードゥ", "obrigada": "オブリガーダ",
    "ok": "オーケー", "wifi": "ウィフィ", "táxi": "タクシー", "taxi": "タクシー", "hotel": "オテウ", "eu": "エウ", "mais": "マイス",
    "muito": "ムイント", "muita": "ムイント", "tudo": "トゥードゥ", "favor": "ファヴォール", "olá": "オラー", "oi": "オイ",
    "dois": "ドイス", "três": "トレス", "cem": "セイン", "mil": "ミウ", "meu": "メウ", "seu": "セウ", "são": "サウン",
    "quanto": "クアントゥ", "quando": "クアンドゥ", "onde": "オンジ", "esse": "エッスィ", "essa": "エッサ", "isso": "イッスゥ",
}

_VOWELS = "aeiouáàâãéêíóôõúü"
# 語末の e・o（強勢のない）は、「イ」「ウ」と読む。次の文字が続く複数形（-es・-os）も同じ
_ACUTE_OR_CIRCUMFLEX = "áâéêíóôú"
# 子音ごとの a・e・i・o・u の段
_ROWS: dict[str, tuple[str, str, str, str, str]] = {
    "": ("ア", "エ", "イ", "オ", "ウ"),
    "p": ("パ", "ペ", "ピ", "ポ", "プ"),
    "b": ("バ", "ベ", "ビ", "ボ", "ブ"),
    "t": ("タ", "テ", "チ", "ト", "トゥ"),
    "d": ("ダ", "デ", "ジ", "ド", "ドゥ"),
    "k": ("カ", "ケ", "キ", "コ", "ク"),
    "g": ("ガ", "ゲ", "ギ", "ゴ", "グ"),
    "f": ("ファ", "フェ", "フィ", "フォ", "フ"),
    "v": ("ヴァ", "ヴェ", "ヴィ", "ヴォ", "ヴ"),
    "s": ("サ", "セ", "スィ", "ソ", "ス"),
    "z": ("ザ", "ゼ", "ズィ", "ゾ", "ズ"),
    "x": ("シャ", "シェ", "シ", "ショ", "シュ"),
    "j": ("ジャ", "ジェ", "ジ", "ジョ", "ジュ"),
    "m": ("マ", "メ", "ミ", "モ", "ム"),
    "n": ("ナ", "ネ", "ニ", "ノ", "ヌ"),
    "nh": ("ニャ", "ニェ", "ニ", "ニョ", "ニュ"),
    "lh": ("リャ", "リェ", "リ", "リョ", "リュ"),
    "l": ("ラ", "レ", "リ", "ロ", "ル"),
    "r": ("ラ", "レ", "リ", "ロ", "ル"),
    "h": ("ハ", "ヘ", "ヒ", "ホ", "フ"),  # 語頭の r・rr（ブラジルでは「h」の音）
    "w": ("ワ", "ウェ", "ウィ", "ウォ", "ウ"),
}
_VOWEL_COLUMN = {"a": 0, "e": 1, "i": 2, "o": 3, "u": 4}
# 母音が続かない子音。r・l が続くとき（br・pr・tr・cl …）は、前の子音を「ウ段・オ段」で書く
_BEFORE_LIQUID = {"p": "プ", "b": "ブ", "t": "ト", "d": "ド", "k": "ク", "g": "グ", "f": "フ", "v": "ヴ"}
# それ以外（子音が続く・語末）。p・b・t・d・k・g は、ブラジルの発音のとおり「イ」の段で書く（ritmo → ヒチモ）
_ALONE = {
    "p": "ピ", "b": "ビ", "t": "チ", "d": "ジ", "k": "キ", "g": "ギ", "f": "フ", "v": "ヴ", "s": "ス", "z": "ス",
    "x": "シ", "j": "ジ", "m": "ム", "n": "ヌ", "nh": "ニ", "lh": "リ", "l": "ウ", "r": "ル", "h": "フ", "w": "ウ",
}
_WORD = re.compile(r"[a-zàáâãçéêíóôõúü'’\-]+", re.I)


def to_katakana(text: str) -> str:
    """ポルトガル語の文をカタカナにする（語は空白で区切り、句読点はそのまま残す）。"""
    out = []
    position = 0
    for match in _WORD.finditer(text):
        out.append(text[position : match.start()])
        out.append(word_to_kana(match.group()))
        position = match.end()
    out.append(text[position:])
    return re.sub(r"\s+", " ", "".join(out)).strip()


def word_to_kana(word: str) -> str:
    """1語をカタカナにする。ハイフンでつながった語（me-dá）は、つなげて1語として書く。"""
    parts = [part for part in re.split(r"-", unicodedata.normalize("NFC", word.lower())) if part]
    return "".join(_part_to_kana(part) for part in parts) or word


def _part_to_kana(word: str) -> str:
    word = word.replace("’", "'").replace("'", "")
    if word in _WORDS:
        return _WORDS[word]
    return _compose(_scan(word))


# 発音の単位: ("C", 子音の種類)、("V", 母音の文字, 後ろに足す「ン」「イン」「ウン」, 伸ばすか)、("T", そのままの文字)
Item = tuple


def _scan(word: str) -> list[Item]:
    items: list[Item] = []
    n = len(word)
    i = 0

    def is_vowel(j: int) -> bool:
        return 0 <= j < n and word[j] in _VOWELS

    def last_vowel(j: int) -> bool:
        """word[j] より後ろに、母音の文字が無いか。"""
        return not any(ch in _VOWELS for ch in word[j + 1 :])

    def push_vowel(letter: str, suffix: str = "", acute: bool = False, at: int = 0) -> None:
        # 語末の強勢のない e・o は「イ」「ウ」（複数形の -es・-os も同じ）。アクセント記号のある母音は、語末なら伸ばす
        if letter in "eo" and not acute and word[at] in "eo":
            tail = word[at + 1 :]
            if tail in ("", "s"):
                letter = "i" if letter == "e" else "u"
        items.append(("V", letter, suffix, acute and last_vowel(at)))

    while i < n:
        c = word[i]
        rest = word[i:]
        nxt = word[i + 1] if i + 1 < n else ""
        prev = word[i - 1] if i > 0 else ""
        if rest.startswith(("ão", "õe")) or rest.startswith("ãe"):
            letter, suffix = ("a", "ウン") if rest.startswith("ão") else (("o", "イン") if rest.startswith("õe") else ("a", "イン"))
            items.append(("V", letter, suffix, False))
            i += 2
        elif c in "ãõ":
            items.append(("V", "a" if c == "ã" else "o", "ン", False))
            i += 1
        elif c in _VOWELS:
            base = unicodedata.normalize("NFD", c)[0]
            acute = c in _ACUTE_OR_CIRCUMFLEX
            # 語末の m: 鼻母音（bem → ベイン、um → ウン、som → ソン）
            if nxt == "m" and i + 2 == n:
                items.append(("V", base, "イン" if base == "e" else "ン", False))
                i += 2
            elif nxt in ("m", "n") and i + 2 < n and not is_vowel(i + 2) and word[i + 2] != "h":
                push_vowel(base, "ン", acute, i)  # 子音の前の m・n は、前の母音を鼻音にする（quanto → クアントゥ、sempre → セン…）
                i += 2
            else:
                push_vowel(base, "", acute, i)
                i += 1
        elif rest.startswith("ch"):
            items.append(("C", "x"))
            i += 2
        elif rest.startswith("lh"):
            items.append(("C", "lh"))
            i += 2
        elif rest.startswith("nh"):
            items.append(("C", "nh"))
            i += 2
        elif rest.startswith("qu"):
            items.append(("C", "k"))
            if i + 2 < n and word[i + 2] in "eéêií":
                i += 2  # que・qui の u は読まない
            else:
                items.append(("V", "u", "", False))  # quanto の u（クア）
                i += 2
        elif rest.startswith("gu") and i + 2 < n and word[i + 2] in "eéêií":
            items.append(("C", "g"))
            i += 2
        elif rest.startswith("rr"):
            items.append(("C", "h"))
            i += 2
        elif rest.startswith("ss"):
            items.append(("C", "s"))
            i += 2
        elif rest.startswith(("sc", "sç", "xc")) and i + 2 < n and word[i + 2] in "eéêií":
            items.append(("C", "s"))
            i += 3 if rest[0] == "x" else 2  # nascer → ナセール、excelente
            if rest[0] == "s" and rest[1] == "c":
                continue
        elif c == "ç":
            items.append(("C", "s"))
            i += 1
        elif c == "c":
            items.append(("C", "s" if nxt and nxt in "eéêií" else "k"))
            i += 1
        elif c == "g":
            items.append(("C", "j" if nxt and nxt in "eéêií" else "g"))
            i += 1
        elif c == "h":
            i += 1
        elif c == "j":
            items.append(("C", "j"))
            i += 1
        elif c == "r":
            initial = i == 0 or prev in "nls"
            items.append(("C", "h" if initial else "r"))
            i += 1
        elif c == "s":
            between_vowels = is_vowel(i - 1) and is_vowel(i + 1)
            items.append(("C", "z" if between_vowels else "s"))
            i += 1
        elif c == "x":
            if i == 1 and word[0] == "e" and is_vowel(i + 1):
                items.append(("C", "z"))  # exemplo → ゼンプル
            else:
                items.append(("C", "x"))
            i += 1
        elif c == "y":
            items.append(("V", "i", "", False))
            i += 1
        elif c == "z":
            items.append(("C", "s" if not nxt else "z"))
            i += 1
        elif c == "l":
            items.append(("C", "l"))
            i += 1
        elif c in "mnpbtdkfvw":
            items.append(("C", c))
            i += 1
        else:
            items.append(("T", c))
            i += 1
    return items


def _compose(items: list[Item]) -> str:
    out = []
    n = len(items)
    i = 0
    while i < n:
        item = items[i]
        nxt = items[i + 1] if i + 1 < n else None
        if item[0] == "T":
            out.append(item[1])
        elif item[0] == "V":
            out.append(_vowel(item, ""))
        else:
            kind = item[1]
            if nxt is not None and nxt[0] == "V":
                out.append(_vowel(nxt, kind))
                i += 1
            elif kind == "l" and nxt is not None and nxt[0] == "C" and nxt[1] != "l":
                out.append("ウ")  # 母音のない l（alto → アウトゥ、Brasil → ブラズィウ）
            elif nxt is not None and nxt[0] == "C" and nxt[1] in ("r", "l") and kind in _BEFORE_LIQUID:
                out.append(_BEFORE_LIQUID[kind])
            else:
                out.append(_ALONE.get(kind, ""))
        i += 1
    return "".join(out)


def _vowel(item: Item, consonant: str) -> str:
    _, letter, suffix, long = item
    kana = _ROWS.get(consonant, _ROWS[""])[_VOWEL_COLUMN[letter]]
    return kana + ("ー" if long else "") + suffix
