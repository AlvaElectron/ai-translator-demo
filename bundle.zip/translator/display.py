"""画面への出力と、タッチ・マウス・キーボードの入力。

- "auto"  : /dev/fb0 に書き込めれば fbdev、書き込めなければ kmsdrm（Pi 4 と Pi 5 で同じ設定が使える）。
- "fbdev" : /dev/fb0 に直接書き込む。GPU（EGL）を使わないので Raspberry Pi OS Lite でも動く。
            タッチ・マウス・キーボードは evdev（python3-evdev）で読む（Bluetooth の機器は、つながったときに見つける）。
            マウスのポインターは、画面に書き込むときに描き足す。
- それ以外: SDL で表示する（"kmsdrm"、PC では "" でウィンドウ表示）。
"""

from __future__ import annotations

import logging
import mmap
import os
import queue
import threading
import time
from pathlib import Path

import pygame

from .config import DisplayConfig
from .input_events import (
    _POINTER_SHAPE,
    ABS_MT_POSITION_X,
    ABS_MT_POSITION_Y,
    ABS_X,
    ABS_Y,
    KEYBOARD,
    MOUSE,
    TOUCH,
    InputBatch,
    _DeviceReader,
    classify_device,
    key_name,
)
from .keyboard import MODIFIERS, KeyPress, key_press

log = logging.getLogger(__name__)

# フレームバッファの色深度ごとの RGBA マスク（リトルエンディアン）
_FRAMEBUFFER_MASKS = {
    16: (0xF800, 0x07E0, 0x001F, 0),  # RGB565
    32: (0x00FF0000, 0x0000FF00, 0x000000FF, 0),  # XRGB8888
}


# 画面の部品の配置は、高さ 480 を前提に作ってある。これと違う解像度のモニターでは、高さ 480・幅は縦横比に合わせた
# 「論理の画面」に描いて、実際の画面の大きさに拡大して出す（800x480 の画面では、拡大しない）
LOGICAL_HEIGHT = 480


def logical_size(width: int, height: int) -> tuple[int, int]:
    """実際の画面の大きさ → 描く画面の大きさ（高さ 480 に縦横比を合わせる）。"""
    if height == LOGICAL_HEIGHT or height <= 0:
        return width, height
    return max(1, round(LOGICAL_HEIGHT * width / height)), LOGICAL_HEIGHT


class LogicalScreen:
    """描く画面（surface）と実際の画面の間の、拡大と、タッチの位置の換算。"""

    def __init__(self, width: int, height: int) -> None:
        self.size = (width, height)
        self.logical = logical_size(width, height)
        self.scaled = self.logical != self.size
        self.surface = pygame.Surface(self.logical, 0, 32)
        self._buffer = pygame.Surface(self.size, 0, 32) if self.scaled else None

    def render(self) -> pygame.Surface:
        """実際の画面の大きさの絵（拡大が要らなければ、描いた絵そのまま）。"""
        if self._buffer is None:
            return self.surface
        pygame.transform.smoothscale(self.surface, self.size, self._buffer)
        return self._buffer

    def to_logical(self, x: float, y: float) -> tuple[int, int]:
        """実際の画面の位置 → 描く画面の位置。"""
        if not self.scaled:
            return int(x), int(y)
        return int(x * self.logical[0] / self.size[0]), int(y * self.logical[1] / self.size[1])

    def to_physical(self, x: int, y: int) -> tuple[int, int]:
        if not self.scaled:
            return x, y
        return int(x * self.size[0] / self.logical[0]), int(y * self.size[1] / self.logical[1])


AUTO_DRIVER = "auto"
# auto で /dev/fb0 が使えないとき（Pi 5 など）に使う SDL のドライバー
AUTO_SDL_DRIVER = "kmsdrm"
# あとからつないだ機器（Bluetooth のマウス・キーボードなど）を探す間隔
RESCAN_SEC = 3.0


def open_display(cfg: DisplayConfig) -> SdlDisplay | FramebufferDisplay:
    driver = cfg.video_driver
    if driver == AUTO_DRIVER:
        driver = "fbdev" if framebuffer_usable() else AUTO_SDL_DRIVER
        log.info("画面の出し方を自動で選びました: %s", driver)
    if driver == "fbdev":
        try:
            return FramebufferDisplay()
        except Exception:
            # Pi 5 のように /dev/fb0 に書けない環境でも、GPU 経由でなら表示できることがある
            log.exception("フレームバッファを開けないため、SDL（%s）で表示します", AUTO_SDL_DRIVER)
            driver = AUTO_SDL_DRIVER
    return SdlDisplay(cfg, driver)


def framebuffer_usable(device: str = "/dev/fb0") -> bool:
    """/dev/fb0 に直接書き込めるか（対応する色深度で、書き込む権限がある）。"""
    try:
        bits = int((Path("/sys/class/graphics") / Path(device).name / "bits_per_pixel").read_text())
    except OSError:
        return False
    return bits in _FRAMEBUFFER_MASKS and os.access(device, os.W_OK)


# pygame のキーの名前のうち、evdev と違うもの（PC で画面を確認するとき用）
_PYGAME_KEY_NAMES = {
    "return": "enter", "escape": "esc", "-": "minus", "=": "equal", "[": "leftbrace", "]": "rightbrace",
    "\\": "backslash", ";": "semicolon", "'": "apostrophe", "`": "grave", ",": "comma", ".": "dot", "/": "slash",
    "left shift": "leftshift", "right shift": "rightshift", "left ctrl": "leftctrl", "right ctrl": "rightctrl",
}


class SdlDisplay:
    def __init__(self, cfg: DisplayConfig, driver: str | None = None) -> None:
        driver = cfg.video_driver if driver is None else driver
        if driver:
            os.environ["SDL_VIDEODRIVER"] = driver
        pygame.display.init()
        flags = pygame.FULLSCREEN if cfg.fullscreen else 0
        self._window = pygame.display.set_mode((cfg.width, cfg.height), flags)
        self._screen = LogicalScreen(*self._window.get_size())
        self.surface = self._screen.surface
        pygame.display.set_caption("Pi Translator")
        self._fullscreen = cfg.fullscreen
        if cfg.fullscreen:
            pygame.mouse.set_visible(False)

    def poll(self, timeout_sec: float) -> InputBatch:
        """届いた入力（タップ・キー）と、終了が要求されたかを返す。"""
        events = [pygame.event.wait(int(timeout_sec * 1000))] if timeout_sec > 0 else []
        events += pygame.event.get()
        width, height = self._screen.logical
        batch = InputBatch()
        for event in events:
            if event.type == pygame.QUIT:
                batch.quit = True
            elif event.type == pygame.FINGERDOWN:
                batch.taps.append((int(event.x * width), int(event.y * height)))
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and not getattr(event, "touch", False):
                batch.taps.append(self._screen.to_logical(*event.pos))
            elif event.type == pygame.MOUSEMOTION and self._fullscreen and not getattr(event, "touch", False):
                pygame.mouse.set_visible(True)  # マウスを動かしたら、ポインターを出す
            elif event.type == pygame.KEYDOWN:
                name = pygame.key.name(event.key)
                name = _PYGAME_KEY_NAMES.get(name, name)
                mods = pygame.key.get_mods()
                if name not in MODIFIERS:
                    shift, ctrl = bool(mods & pygame.KMOD_SHIFT), bool(mods & pygame.KMOD_CTRL)
                    key = key_press(name, shift, ctrl)
                    batch.keys.append(key if key.char or ctrl else KeyPress(name, event.unicode or "", shift, ctrl))
        return batch

    def present(self) -> None:
        if self._screen.scaled:
            self._window.blit(self._screen.render(), (0, 0))
        pygame.display.flip()

    def close(self) -> None:
        pygame.display.quit()


class FramebufferDisplay:
    def __init__(self, device: str = "/dev/fb0") -> None:
        info = Path("/sys/class/graphics") / Path(device).name
        width, height = (int(value) for value in (info / "virtual_size").read_text().split(","))
        bits = int((info / "bits_per_pixel").read_text())
        if bits not in _FRAMEBUFFER_MASKS:
            raise RuntimeError(f"フレームバッファの色深度 {bits}bpp には対応していません")
        stride_file = info / "stride"
        self._stride = int(stride_file.read_text()) if stride_file.exists() else width * bits // 8
        self._height = height
        self._screen = LogicalScreen(width, height)
        self.surface = self._screen.surface
        self._framebuffer_surface = pygame.Surface((width, height), 0, bits, _FRAMEBUFFER_MASKS[bits])
        self._file = open(device, "r+b")
        self._map = mmap.mmap(self._file.fileno(), self._stride * height)
        self._input = InputHub.open(width, height)
        log.info("フレームバッファ %s に表示します（%dx%d、%dbpp）", device, width, height, bits)

    def poll(self, timeout_sec: float) -> InputBatch:
        if self._input is None:
            time.sleep(timeout_sec)
            return InputBatch()
        batch = self._input.take(timeout_sec)
        batch.taps = [self._screen.to_logical(x, y) for x, y in batch.taps]  # 入力は実際の画面の位置
        return batch

    def present(self) -> None:
        # 描画用の 32bit サーフェスを、フレームバッファの画素形式に変換してから書き込む
        self._framebuffer_surface.blit(self._screen.render(), (0, 0))
        pointer = self._input.pointer if self._input is not None else None
        if pointer is not None:
            _draw_pointer(self._framebuffer_surface, pointer)
        pitch = self._framebuffer_surface.get_pitch()
        pixels = self._framebuffer_surface.get_buffer().raw
        if pitch == self._stride:
            self._map[: len(pixels)] = pixels
            return
        row = min(pitch, self._stride)
        for y in range(self._height):
            self._map[y * self._stride : y * self._stride + row] = pixels[y * pitch : y * pitch + row]

    def close(self) -> None:
        if self._input is not None:
            self._input.close()
        self._map[:] = bytes(len(self._map))  # 画面を黒に戻す
        self._map.close()
        self._file.close()


def _draw_pointer(surface: pygame.Surface, position: tuple[int, int]) -> None:
    """マウスのポインター（白い矢印に黒い縁）を描く。"""
    x, y = position
    points = [(x + dx, y + dy) for dx, dy in _POINTER_SHAPE]
    pygame.draw.polygon(surface, (255, 255, 255), points)
    pygame.draw.polygon(surface, (0, 0, 0), points, width=1)


class InputHub:
    """evdev で、タッチ画面・マウス・キーボードを読む。

    Bluetooth のマウス・キーボードは、アプリを起動したあとにつながることが多いので、RESCAN_SEC ごとに
    新しい機器を探す。マウスとキーボードは独り占め（grab）する。キーボードを独り占めしないと、
    打った文字が裏のコンソール（tty1）にも届き、画面に文字が重なって出てしまう。
    """

    @classmethod
    def open(cls, width: int, height: int) -> InputHub | None:
        try:
            import evdev
        except ImportError:
            log.warning("python3-evdev が入っていないため、タッチ・マウス・キーボードは使えません")
            return None
        return cls(evdev, width, height)

    def __init__(self, evdev, width: int, height: int) -> None:
        self._evdev = evdev
        self._width, self._height = width, height
        self._events: queue.Queue = queue.Queue()
        self._lock = threading.Lock()
        self._devices: dict[str, object] = {}
        self._pointer = (width // 2, height // 2)
        self._pointer_visible = False
        self._closed = False
        self._scan()
        if not any(TOUCH in roles for _, roles in self._devices.values()):
            log.warning("タッチ画面が見つかりません")
        threading.Thread(target=self._rescan_loop, name="input-scan", daemon=True).start()

    @property
    def pointer(self) -> tuple[int, int] | None:
        """マウスのポインターの位置（出していないときは None）。"""
        with self._lock:
            return self._pointer if self._pointer_visible else None

    def take(self, timeout_sec: float) -> InputBatch:
        batch = InputBatch()
        items = []
        try:
            items.append(self._events.get(timeout=timeout_sec) if timeout_sec > 0 else self._events.get_nowait())
            while True:
                items.append(self._events.get_nowait())
        except queue.Empty:
            pass
        for kind, value in items:
            if kind == "tap":
                batch.taps.append(value)
            elif kind == "key":
                batch.keys.append(value)
            elif kind == "pointer":
                batch.pointer_moved = True
        return batch

    def close(self) -> None:
        self._closed = True
        with self._lock:
            devices = [device for device, _ in self._devices.values()]
            self._devices.clear()
        for device in devices:
            try:
                device.close()
            except OSError:
                pass

    def _rescan_loop(self) -> None:
        while not self._closed:
            time.sleep(RESCAN_SEC)
            try:
                self._scan()
            except Exception:
                log.exception("入力機器を探せません")

    def _scan(self) -> None:
        for path in self._evdev.list_devices():
            with self._lock:
                if path in self._devices:
                    continue
            try:
                device = self._evdev.InputDevice(path)
                roles = classify_device(device.capabilities())
            except OSError:
                continue
            if not roles:
                device.close()  # 使わない機器（HDMI・電源ボタン・スピーカーフォンのボタンなど）
                continue
            if roles & {MOUSE, KEYBOARD}:
                try:
                    device.grab()
                except OSError:
                    log.warning("%s を独り占めできません（打った文字がコンソールにも届くことがあります）", device.name)
            with self._lock:
                self._devices[path] = (device, roles)
            log.info("入力機器: %s（%s、%s）", device.name, "・".join(sorted(roles)), path)
            threading.Thread(target=self._read_loop, args=(path, device, roles), name="input", daemon=True).start()

    def _read_loop(self, path: str, device, roles: set[str]) -> None:
        reader = _DeviceReader(self, device, roles)
        try:
            for event in device.read_loop():
                reader.handle(event.type, event.code, event.value)
        except (OSError, ValueError):
            pass  # 機器が外れた（Bluetooth の切断など）か、close() で閉じた
        with self._lock:
            self._devices.pop(path, None)  # 次に探したとき、つなぎ直した機器を開き直す
        if MOUSE in roles:
            self._set_pointer_visible(False)
        if not self._closed:
            log.info("入力機器が外れました: %s", path)

    def _touch_range(self, device):
        codes = self._evdev.ecodes
        axes = dict(device.capabilities().get(codes.EV_ABS, []))
        for x_code, y_code in ((ABS_X, ABS_Y), (ABS_MT_POSITION_X, ABS_MT_POSITION_Y)):
            if x_code in axes and y_code in axes:
                x_axis, y_axis = axes[x_code], axes[y_code]
                return (x_axis.min, x_axis.max, self._width), (y_axis.min, y_axis.max, self._height)
        return (0, 1, self._width), (0, 1, self._height)

    def _tap(self, position: tuple[int, int]) -> None:
        self._events.put(("tap", position))

    def _move_pointer(self, dx: int, dy: int) -> None:
        with self._lock:
            x, y = self._pointer
            self._pointer = (max(0, min(self._width - 1, x + dx)), max(0, min(self._height - 1, y + dy)))
            self._pointer_visible = True
        self._events.put(("pointer", None))

    def _click(self) -> None:
        with self._lock:
            position = self._pointer
            self._pointer_visible = True
        self._events.put(("tap", position))

    def _set_pointer_visible(self, visible: bool) -> None:
        with self._lock:
            changed = self._pointer_visible != visible
            self._pointer_visible = visible
        if changed:
            self._events.put(("pointer", None))

    def _key(self, key: KeyPress) -> None:
        self._events.put(("key", key))

    def _key_name(self, code: int) -> str:
        return key_name(self._evdev.ecodes.KEY.get(code) or self._evdev.ecodes.BTN.get(code, ""))


