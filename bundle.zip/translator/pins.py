"""暗証番号（4 桁）の確認と変更（pygame に依存しない）。

番号は 2 つ:

- **一般の番号**: 「店舗用」「音の設定」「電源・再起動」を開くときに聞く。空（config.toml の general_pin が空で、まだ画面で決めていない）なら聞かない。
- **管理者の番号**: 管理者の画面に入るときに聞く。空にはできない。最初の番号は config.toml の admin_pin（管理者用取扱説明書に書いてある番号）。

最初の番号は config.toml の [security] に書く。管理者の画面で変えた番号は user_settings.json に残し、
こちらを優先する。残すのは番号そのものではなく、ランダムな「塩」を混ぜて計算した値（そのままでは読めない）。
画面で変えた番号を忘れたときは、user_settings.json から pin_general / pin_admin の行を消してアプリを再起動すると、
config.toml の最初の番号に戻る。
"""

from __future__ import annotations

import hashlib
import hmac
import secrets
from typing import Protocol

PIN_LENGTH = 4
GENERAL_KEY, ADMIN_KEY = "pin_general", "pin_admin"
# 値は "pbkdf2$塩$計算した値"（16 進数）。回数を変えたときに古い値を読めるよう、書式に回数は入れず、固定にしている
_ITERATIONS = 50_000

SAME_AS_ADMIN = "管理者の番号と同じにはできません / Must differ from the administrator number"
SAME_AS_GENERAL = "一般の番号と同じにはできません / Must differ from the general number"
NOT_FOUR_DIGITS = "数字 4 つにしてください / Use exactly 4 digits"


class Settings(Protocol):
    def get_str(self, key: str, default: str = "") -> str: ...

    def set(self, key: str, value: object) -> None: ...


def is_valid_pin(text: str) -> bool:
    return len(text) == PIN_LENGTH and text.isascii() and text.isdigit()


def _pbkdf2_sha256(password: bytes, salt: bytes, iterations: int) -> bytes:
    """PBKDF2-HMAC-SHA256（出力 32 バイト）。hashlib.pbkdf2_hmac が無い環境（ブラウザの Python）で、同じ値を出すための代わり。"""
    key = password.ljust(64, b"\0") if len(password) <= 64 else hashlib.sha256(password).digest().ljust(64, b"\0")
    inner, outer = hashlib.sha256(bytes(b ^ 0x36 for b in key)), hashlib.sha256(bytes(b ^ 0x5C for b in key))

    def prf(data: bytes) -> bytes:
        first = inner.copy()
        first.update(data)
        second = outer.copy()
        second.update(first.digest())
        return second.digest()

    block = prf(salt + b"\x00\x00\x00\x01")
    result = int.from_bytes(block, "big")
    for _ in range(iterations - 1):
        block = prf(block)
        result ^= int.from_bytes(block, "big")
    return result.to_bytes(32, "big")


def _derive(pin: str, salt: str, iterations: int = _ITERATIONS) -> str:
    try:
        return hashlib.pbkdf2_hmac("sha256", pin.encode(), bytes.fromhex(salt), iterations).hex()
    except AttributeError:  # ブラウザの Python には、hashlib.pbkdf2_hmac が無い
        return _pbkdf2_sha256(pin.encode(), bytes.fromhex(salt), iterations).hex()


def hash_pin(pin: str, salt: str | None = None) -> str:
    salt = salt or secrets.token_hex(8)
    return f"pbkdf2${salt}${_derive(pin, salt)}"


def check_hash(stored: str, pin: str) -> bool:
    try:
        scheme, salt, digest = stored.split("$")
        if scheme != "pbkdf2":
            return False
        expected = hash_pin(pin, salt)
    except ValueError:
        return False
    return hmac.compare_digest(expected, stored)


class PinStore:
    """一般の番号と管理者の番号。画面で変えた番号（settings に保存）が、config.toml の最初の番号より優先する。"""

    def __init__(self, settings: Settings, general_initial: str, admin_initial: str) -> None:
        self._settings = settings
        self._general_initial = general_initial
        self._admin_initial = admin_initial

    # --- 確認 ---

    def general_required(self) -> bool:
        """一般の番号を聞くか。"""
        return bool(self._settings.get_str(GENERAL_KEY) or self._general_initial)

    def admin_required(self) -> bool:
        """管理者の番号を聞くか（いつも聞く）。"""
        return True

    def verify_general(self, entry: str) -> bool:
        return self._verify(GENERAL_KEY, self._general_initial, entry)

    def verify_admin(self, entry: str) -> bool:
        return self._verify(ADMIN_KEY, self._admin_initial, entry)

    def general_is_initial(self) -> bool:
        """一般の番号を、まだ画面で変えていない（config.toml の最初の番号のまま）か。"""
        return not self._settings.get_str(GENERAL_KEY)

    def admin_is_initial(self) -> bool:
        """管理者の番号を、まだ画面で変えていない（管理者用取扱説明書に書いてある番号のまま）か。"""
        return not self._settings.get_str(ADMIN_KEY)

    def _verify(self, key: str, initial: str, entry: str) -> bool:
        if not is_valid_pin(entry):
            return False
        stored = self._settings.get_str(key)
        if stored:
            return check_hash(stored, entry)
        return bool(initial) and hmac.compare_digest(initial.encode(), entry.encode())

    # --- 変更（できなかったときは、その理由の文を返す。できたら None）---

    def set_general(self, pin: str) -> str | None:
        if not is_valid_pin(pin):
            return NOT_FOUR_DIGITS
        if self.verify_admin(pin):
            return SAME_AS_ADMIN
        self._settings.set(GENERAL_KEY, hash_pin(pin))
        return None

    def set_admin(self, pin: str) -> str | None:
        if not is_valid_pin(pin):
            return NOT_FOUR_DIGITS
        if self.general_required() and self.verify_general(pin):
            return SAME_AS_GENERAL
        self._settings.set(ADMIN_KEY, hash_pin(pin))
        return None


class NoPins:
    """暗証番号を使わないとき（設定をつないでいない画面のテストなど）。何も聞かず、管理者の画面にも入れる。"""

    def general_required(self) -> bool:
        return False

    def admin_required(self) -> bool:
        return False

    def verify_general(self, entry: str) -> bool:
        return True

    def verify_admin(self, entry: str) -> bool:
        return True

    def general_is_initial(self) -> bool:
        return True

    def admin_is_initial(self) -> bool:
        return True

    def set_general(self, pin: str) -> str | None:
        return None

    def set_admin(self, pin: str) -> str | None:
        return None
