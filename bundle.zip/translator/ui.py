"""翻訳結果を表示するタッチ画面と、メニュー・音の設定・Bluetooth・電源オフの画面（800x480 を想定）。"""

from __future__ import annotations

import logging
import math
import random
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from pathlib import Path

import pygame
import pygame.freetype

from .auto_off import AutoOff, IdleOff
from .clock_setting import ClockFields, format_clock
from .bluetooth import BluetoothDevice
from .chinese import SIMPLIFIED, TRADITIONAL
from .config import DisplayConfig
from .display import InputBatch, open_display
from .gain import (
    GAIN_STEPS,
    GOOD_LEVEL,
    MAX_SPEECH_STEPS,
    SILENCE_STEPS,
    SPEECH_SPEED_STEPS,
    VOLUME_STEPS,
    level_zone,
    step_value,
)
from . import flags, guide, guide_admin, guide_upload, icons
from . import chinese_study, english_study
from . import hangul_study as study
from . import screen_keyboard as skb
from .pins import PIN_LENGTH, NoPins, PinStore
from .industries import CATEGORIES, CATEGORY_BY_ID, ROW_LANGS, IndustrySelection, term_count
from .keyboard import INPUT_HINTS, UNSUPPORTED_MESSAGE, KeyPress, TextEntry, can_type
from .korean_kana import to_katakana
from .langs import EN, FR, FUK, HOK, JA, KO, OSA, PT, RU, TH, VOICES, YUE, ZH, Mode
from .layout import blink_level, fit_text, mix_color
from .phrases import Phrase, search_phrases
from .power_saver import PowerSaver
from .system_monitor import CHART_RANGES, GAP, UPTIME_DAYS, Reading, UptimeCounter, axis_bounds, daily_uptime, time_ticks
from .usage_log import CORRECTIONS, MAX_TEMP, NO_LANG, PHRASE_USES, PHRASES, TRANSLATIONS, UsageLog
from .ui_state import LISTENING, Snapshot, UiState
from .wifi import WifiNetwork

log = logging.getLogger(__name__)

BACKGROUND = (16, 20, 24)
MENU_BACKGROUND = (22, 27, 33)
TEXT_COLOR = (240, 242, 245)
SUBTEXT_COLOR = (170, 180, 190)
DIVIDER_COLOR = (48, 56, 64)
BAR_COLOR = (28, 33, 39)
BUTTON_COLOR = (44, 50, 58)
DISABLED_BUTTON_COLOR = (32, 36, 42)
BUTTON_ACTIVE_COLOR = (47, 125, 209)
# 今は効かない設定（例: スピーカーが見つからないときの音声出力）で、選ばれている方のボタン
UNAVAILABLE_ACTIVE_COLOR = (38, 66, 96)
POWER_BUTTON_COLOR = (110, 44, 44)
DANGER_COLOR = (196, 58, 58)
LANG_COLORS = {
    JA: (196, 64, 76),
    KO: (54, 110, 196),
    EN: (46, 140, 100),
    ZH: (190, 130, 30),
    YUE: (170, 90, 150),
    TH: (40, 140, 150),
    FR: (90, 100, 190),
    RU: (150, 95, 60),
    PT: (110, 150, 60),
    HOK: (60, 120, 180),
    OSA: (200, 110, 50),
    FUK: (120, 90, 170),
}
LANG_LABELS = {JA: "JA", KO: "KO", EN: "EN", ZH: "ZH", YUE: "YUE", TH: "TH", FR: "FR", RU: "RU", PT: "PT", HOK: "北", OSA: "阪", FUK: "福"}
# 言語名とボタンの文言は、その言語を話す人が読めるように、それぞれの言語で書く
NATIVE_NAMES = {JA: "日本語", KO: "한국어", EN: "English", ZH: "中文", YUE: "廣東話", TH: "ภาษาไทย", FR: "Français", RU: "Русский", PT: "Português", HOK: "北海道弁", OSA: "大阪弁", FUK: "福岡弁"}
SPEAK_LABELS = {
    JA: "日本語で話す",
    KO: "한국어로 말하기",
    EN: "Speak English",
    ZH: "说中文",
    YUE: "講廣東話",
    TH: "พูดภาษาไทย",
    FR: "Parler français",
    RU: "Говорить по-русски",
    PT: "Falar português",
    HOK: "北海道弁で話す",
    OSA: "大阪弁で話す",
    FUK: "福岡弁で話す",
}
# 台湾の繁体字を選んでいるときの「中国語で話す」
SPEAK_LABEL_ZH_HANT = "說中文"
# 「翻訳の組み合わせ」の画面: 相手の言語と、中国語の書き方（簡体字 / 台湾の繁体字。中国語以外では使わない）。
# どれも日本語との組み合わせなので、ボタンには相手の言語だけを書く
PAIR_CHOICES = (
    (KO, SIMPLIFIED),
    (EN, SIMPLIFIED),
    (ZH, SIMPLIFIED),
    (ZH, TRADITIONAL),
    (YUE, SIMPLIFIED),
    (TH, SIMPLIFIED),
    (FR, SIMPLIFIED),
    (RU, SIMPLIFIED),
    (PT, SIMPLIFIED),
    (HOK, SIMPLIFIED),
    (OSA, SIMPLIFIED),
    (FUK, SIMPLIFIED),
)
PAIR_LABELS = {
    (KO, SIMPLIFIED): "한국어",
    (EN, SIMPLIFIED): "English",
    (ZH, SIMPLIFIED): "中文（简体）",
    (ZH, TRADITIONAL): "中文（台灣）",
    (YUE, SIMPLIFIED): "廣東話（香港）",
    (TH, SIMPLIFIED): "ภาษาไทย",
    (FR, SIMPLIFIED): "Français",
    (RU, SIMPLIFIED): "Русский",
    (PT, SIMPLIFIED): "Português",
    (HOK, SIMPLIFIED): "北海道弁",
    (OSA, SIMPLIFIED): "大阪弁",
    (FUK, SIMPLIFIED): "福岡弁",
}
# メニューの「翻訳の組み合わせ」ボタンの2行目に出す英語の言語名
PAIR_ENGLISH_NAMES = {
    (KO, SIMPLIFIED): "Korean",
    (EN, SIMPLIFIED): "English",
    (ZH, SIMPLIFIED): "Chinese (Simplified)",
    (ZH, TRADITIONAL): "Chinese (Taiwan)",
    (YUE, SIMPLIFIED): "Cantonese (Hong Kong)",
    (TH, SIMPLIFIED): "Thai",
    (FR, SIMPLIFIED): "French",
    (RU, SIMPLIFIED): "Russian",
    (PT, SIMPLIFIED): "Portuguese (Brazil)",
    (HOK, SIMPLIFIED): "Hokkaido dialect",
    (OSA, SIMPLIFIED): "Osaka dialect",
    (FUK, SIMPLIFIED): "Fukuoka dialect",
}
# 「翻訳の組み合わせ」の画面で、各言語のボタンの2行目に出す日本語の言語名
PAIR_JAPANESE_NAMES = {
    (KO, SIMPLIFIED): "韓国語",
    (EN, SIMPLIFIED): "英語",
    (ZH, SIMPLIFIED): "中国語（簡体字）",
    (ZH, TRADITIONAL): "中国語（台湾）",
    (YUE, SIMPLIFIED): "広東語（香港）",
    (TH, SIMPLIFIED): "タイ語",
    (FR, SIMPLIFIED): "フランス語",
    (RU, SIMPLIFIED): "ロシア語",
    (PT, SIMPLIFIED): "ポルトガル語（ブラジル）",
    (HOK, SIMPLIFIED): "北海道弁（なまら）",
    (OSA, SIMPLIFIED): "大阪弁（おおきに）",
    (FUK, SIMPLIFIED): "福岡弁（ばり）",
}
# 1行に収まらないので、英語は2行目に小さく書く
LANGUAGE_PAGE_TITLE = "翻訳の組み合わせ（日本語 ⇔ 相手の言語）"
LANGUAGE_PAGE_SUBTITLE = "Language pair (Japanese ⇔ other language)"
# 「翻訳の組み合わせ」の画面の下に出すお知らせ。読み上げない言語を話す人にも読めるよう、その言語でも書く
NOT_SPOKEN_NOTICES = (
    ("広東語・タイ語は読み上げず、画面に表示します", JA),
    ("廣東話同泰語唔會讀出嚟，只會喺畫面顯示。", YUE),
    ("ภาษากวางตุ้งและภาษาไทยจะไม่อ่านออกเสียง แสดงบนหน้าจอเท่านั้น", TH),
)
TITLE_SIZES = (28, 26, 24, 22, 20)
# メニューの「言語変更」ボタンの幅（「翻訳の組み合わせ」ボタンは、残りの幅を使う）
LANGUAGE_CHANGE_WIDTH = 220
# 「再生」ボタンは、話した人が読めるように、訳す前の言語で書く（一度読み上げたあとは「もう一度再生」）
# 「訳し直し」ボタン（訳文の言語の印のすぐ下。印と同じ幅の縦長のボタン）の高さ
RETRY_BUTTON_HEIGHT = 84
PLAY_LABELS = {JA: "再生", KO: "재생", EN: "Play", ZH: "播放", YUE: "播放", TH: "เล่น", FR: "Lire", RU: "Слушать", PT: "Ouvir", HOK: "再生", OSA: "再生", FUK: "再生"}
PLAY_AGAIN_LABELS = {
    JA: "もう一度再生",
    KO: "다시 재생",
    EN: "Play again",
    ZH: "再播放",
    YUE: "再播放",
    TH: "เล่นอีกครั้ง",
    FR: "Relire",
    RU: "Ещё раз",
    PT: "Ouvir de novo",
    HOK: "もっかい再生",
    OSA: "もういっぺん再生",
    FUK: "もういっちょ再生",
}
# 「再生」ボタンを押して合成が終わるまで、「再生中 / Playing」の下に出す文
PLAY_WAIT_SUBTITLE = "しばらくお待ちください"

MARGIN = 20
CHIP_WIDTH, CHIP_HEIGHT = 56, 36
TEXT_LEFT = MARGIN + CHIP_WIDTH + 16
# 通訳の画面: 上から 原文（+発音記号）、訳文（+発音記号）、確認用に元の言語へ訳し戻した文
CONTENT_TOP = 12
SOURCE_HEIGHT = 76
SOURCE_SIZES = (28, 24)
TARGET_SIZES = (44, 38, 32)
PRON_HEIGHT = 50
PRON_SIZES = (20, 17)
PRON_COLOR = (150, 200, 235)
BACK_HEIGHT = 58
BACK_SIZES = (22, 19)
BACK_CHIP_COLOR = (70, 78, 88)
SECTION_GAP = 8
LINE_SPACING = 1.35
TAP_DEBOUNCE_SEC = 0.3
KEYBOARD_DEBOUNCE_SEC = 0.12

# 下のバー: 「会話スタート」ボタン（状態表示を兼ねる）、「再生」ボタン、話す人の切り替えボタン、メニューボタン
BAR_HEIGHT = 80
BAR_BUTTON_HEIGHT = 60
PLAY_BUTTON_WIDTH = 130
DIRECTION_BUTTON_WIDTH = 200
MENU_BUTTON_WIDTH = 110
BUTTON_GAP = 10
STATUS_SIZES = (22, 18, 16)
START_COLOR = (46, 140, 100)
LISTENING_COLOR = (196, 72, 56)
# 「再生」ボタン: 他のボタン（青・緑・赤）と重ならない落ち着いた紫。
# BLINK_PERIOD_SEC ごとに明るくなり、そこから少しずつ暗くなる
PLAY_BRIGHT_COLOR = (132, 112, 172)
PLAY_DARK_COLOR = (56, 48, 72)
# 通訳画面は描き直しが重いので、メニュー画面より間隔を空けて明るさを変える
PLAY_BLINK_REDRAW_SEC = 0.2
START_TITLE_SIZES = (24, 20, 18, 16)
STARTUP_ERROR_SIZES = (32, 28, 24, 20)
# 起動中の画面: 左に会社のロゴ（白いカード）、右に製品名、その下の「起動中」、横棒グラフ（進み具合）、パーセント、読み込んでいるもの。
# 縦の位置は、画面の上から下のバーの手前までの真ん中（STARTUP_CENTER_Y）からの差で決める
LOGO_FILE = Path(__file__).resolve().parent / "assets" / "alva_logo.png"
LOGO_CARD_COLOR, LOGO_CARD_PAD, LOGO_CARD_LEFT = (255, 255, 255), 12, 28
STARTUP_TITLE_SIZES = (72, 64, 56, 48)
STARTUP_BRAND_SIZES = (34, 30, 28, 26, 24)  # その下の「『コトリア』(Kotoria)」（右に、向かい合う小鳥を添えるので、文字と合わせて収まる大きさにする）
STARTUP_BIRDS_RATIO, STARTUP_BIRDS_GAP = 1.7, 8  # 小鳥の絵の高さ（文字の大きさの倍率）と、文字との間
STARTUP_TITLE_DY, STARTUP_BRAND_DY, STARTUP_SUB_DY = -118, -66, -26
STARTUP_BAR_DY, STARTUP_PERCENT_DY, STARTUP_STATUS_DY = 14, 58, 98
STARTUP_SUB_SIZE = 24
STARTUP_BAR_MAX_WIDTH, STARTUP_BAR_HEIGHT = 560, 32
STARTUP_PERCENT_SIZE = 24
STARTUP_STATUS_SIZES = (26, 22, 18)
START_SUBTITLE_SIZES = (14, 13, 12, 11, 10)

# メニュー画面
MENU_TITLE_Y = 12
# 製品名。起動の画面は「AI-Translator」の下に PRODUCT_BRAND を出す。メニューは、「話す人 / Speaker」の行の右端に、
# 「AI-Translator コトリア」と、向かい合う小鳥の印を出す（2026-10-23。それまでは、「翻訳の組み合わせ」の行の右端に「コトリア」だけ）
PRODUCT_NAME = "AI-Translator"
PRODUCT_BRAND = "『コトリア』(Kotoria)"
MENU_PRODUCT_NAME = "コトリア"
MENU_PRODUCT_ROMAJI = "(Kotoria)"
PRODUCT_NAME_SIZE = 28  # 「コトリア」
MENU_BRAND_EN_SIZE, MENU_BIRDS_SIZE, MENU_BRAND_DY = 20, 60, 12
# 分かりやすい印（Wi-Fi・Bluetooth・音・定型文）。ボタンでは文字の左に、画面の見出しでは見出しの左に出す
BUTTON_ICON_SIZE, BUTTON_ICON_LEFT, BUTTON_ICON_TEXT_SHIFT = 32, 8, 16
TITLE_ICON_SIZE, TITLE_ICON_Y, TITLE_ICON_SHIFT = 36, -5, 46
LABEL_ICON_SIZE, LABEL_ICON_SHIFT = 26, 32
# 国旗（flags.py）。言語の選択ボタンでは左端に、文の左の言語の印（チップ）では文字の代わりに出す
FLAG_WIDTH_BUTTON, FLAG_WIDTH_PAIR, FLAG_LEFT = 42, 36, 14
FLAG_WIDTH_CHIP = 40
PAIR_LABEL_Y = 58
PAIR_TOP = 86
# 「翻訳の組み合わせ」の画面: 言語のボタンを3列に並べる（9 言語。2 列だと下の戻るボタンにかかる）
LANGUAGE_COLUMNS = 3
LANGUAGE_TOP = 66
LANGUAGE_BUTTON_HEIGHT = 68
LANGUAGE_GAP = 12
SPEAKER_LABEL_Y = 170
SPEAKER_TOP = 198
SPEECH_LABEL_Y = 282
SPEECH_TOP = 310
MENU_BUTTON_HEIGHT = 70
MENU_GAP = 20
# 見出しが長いときは、ボタンの幅に収まるまで文字を小さくする
LABEL_SIZES = (22, 20, 18, 16)
CLOSE_WIDTH, CLOSE_HEIGHT = 160, 64

# 音の設定の画面: 上から 音量、マイク感度（入力レベルのバーと増幅）、発話の区切り方
VOLUME_LABEL_Y = 54
VOLUME_TOP = 80
MIC_LABEL_Y = 146
LEVEL_BAR_TOP, LEVEL_BAR_WIDTH, LEVEL_BAR_HEIGHT = 174, 540, 40
GAIN_TOP = 222
STEP_BUTTON_WIDTH, STEP_BUTTON_HEIGHT = 140, 58
STEP_VALUE_WIDTH = 200
# 「ノイズ除去」の「オン」「オフ」は、音量の行の右の空いている所に置く
DENOISE_LEFT = MARGIN + 2 * STEP_BUTTON_WIDTH + STEP_VALUE_WIDTH + MENU_GAP
DENOISE_LABEL = "ノイズ除去（雑音を減らす）"
# 「読み上げの速さ」は、マイク感度の行の右の空いている所に置く。見出しを置く行がないので、値の上に小さく出す
SPEED_LEFT = DENOISE_LEFT
SPEED_BUTTON_WIDTH = 70
SPEED_LABEL = "読み上げの速さ"
# 音の設定の左下の「声」ボタン: 押すたびに 標準 → 女性 → 男性 → 標準 …（選んだ声で短い文を読み上げる）
VOICE_ORDER = VOICES
VOICE_NAMES = {"standard": ("標準", "Standard"), "female": ("女性", "Female"), "male": ("男性", "Male")}
VOICE_BUTTON_LEFT, VOICE_BUTTON_WIDTH = 236, 200
STEPPER_CAPTION_SIZE = 15
# 発話の区切り方: 「話し終わりの間」と「1回に話せる長さ」を、小さめの「−」「＋」で1行に並べる
SEGMENT_LABEL_Y = 290
SEGMENT_TOP = 318
SMALL_STEP_BUTTON_WIDTH, SMALL_STEP_VALUE_WIDTH = 112, 146
SEGMENT_LABEL_SIZES = (19, 18, 17, 16)
LEVEL_REDRAW_SEC = 0.1
# メニュー画面の「通訳表示」ボタンの点滅: BLINK_PERIOD_SEC ごとに明るくなり、そこから少しずつ暗くなる。
# 「再生」ボタンも同じ間隔で明滅する。どちらも BLINK_DURATION_SEC で明滅を止め、明るいままにする
BLINK_PERIOD_SEC = 5.0
BLINK_DURATION_SEC = 30.0
BLINK_REDRAW_SEC = 0.1
BLINK_BRIGHT_COLOR = (255, 150, 40)
BLINK_DARK_COLOR = (74, 44, 16)
BLINK_BORDER_DARK_COLOR = (90, 80, 70)
# バーが急に縮んで読みにくくならないよう、表示するレベルは少しずつ下げる
LEVEL_DECAY = 0.75
LEVEL_COLORS = {"low": (120, 130, 140), "good": (60, 170, 100), "high": (210, 70, 70)}
GOOD_ZONE_COLOR = (38, 70, 50)

# Bluetooth の画面
ROUTE_Y = 58
BT_BUTTON_TOP, BT_BUTTON_HEIGHT = 90, 56
SCAN_BUTTON_WIDTH, USB_BUTTON_WIDTH = 180, 200
BT_STATUS_CENTER_Y = 170
DEVICE_HINT_Y = 188
DEVICE_TOP, DEVICE_ROW_HEIGHT, DEVICE_ROW_GAP = 214, 40, 6
MAX_DEVICE_ROWS = 4

# 電源・再起動の確認画面（「キャンセル」「再起動」「電源を切る」の 3 つを 1 行に並べる）
CONFIRM_TITLE_Y = 110
CONFIRM_TEXT_Y = 166
CONFIRM_TEXT_GAP = 32
CONFIRM_TOP, CONFIRM_BUTTON_HEIGHT = 290, 90
CONFIRM_BUTTONS = 3

MAIN_PAGE, MENU_PAGE, SOUND_PAGE, BLUETOOTH_PAGE, POWER_PAGE, SHUTDOWN_PAGE, REBOOT_PAGE = (
    "main",
    "menu",
    "sound",
    "bluetooth",
    "power",
    "shutdown",
    "reboot",
)
# 「翻訳の組み合わせ」を選ぶ画面（メニューの「翻訳の組み合わせ」ボタンから開く）
LANGUAGE_PAGE = "language"
# Bluetooth のマウス・キーボードをつなぐ画面（Bluetooth の画面から開く）
INPUT_PAGE = "input"
# Wi-Fi の設定の画面（メニュー上の「Wi-Fi設定」ボタンから開く）と、パスワードを入れる画面（画面のキーボード）
WIFI_PAGE, WIFI_PASSWORD_PAGE = "wifi", "wifi_password"
# 定型文の一覧の画面（メニュー上の「定型文」ボタンから開く）
PHRASES_PAGE = "phrases"
# 定型文の修正の画面（定型文の画面の「修正」を押して、文をタップして開く）: 元の文と、各言語の訳文を、画面のキーボードで直す
PHRASE_EDIT_PAGE = "phrase_edit"
# 画面のキーボードの画面（通訳の画面の下の「文字入力」ボタンから開く）
KEYBOARD_PAGE = "keyboard"
# CPU 温度と 5V 入力電圧のグラフの画面（電源・再起動の画面の「管理者」ボタンから開く）
ADMIN_PAGE = "admin"
# 翻訳回数履歴の画面（電源・再起動の画面の「管理者」の下の「翻訳回数履歴」ボタンから、一般の番号を入れて開く）:
# 日ごとの、翻訳・定型文を使った数・訂正の数の棒グラフ（言語別）
USAGE_PAGE = "usage"
# 「使い方」（動画・スライド）の画面（メニュー上の「使い方」ボタンから開く）:
# お客様用 / 店舗用を選ぶ → 一覧（店舗用は 操作説明・従業員用・管理者用 を選んでから一覧）→ スライド・動画
GUIDE_PAGE, GUIDE_LIST_PAGE, GUIDE_VIEW_PAGE = "guide", "guide_list", "guide_view"
# 店舗用の「動画の追加・管理」（店舗用の一覧の左下のボタンから。店舗用は番号を入れてから開くので、ここでは聞かない）:
# 入れ方を選ぶ → USB メモリの動画の一覧 → 入れる場所 / スマホから（QR コード）/ 入れた動画の一覧（名前の変更・削除）
GUIDE_ADMIN_PAGE, GUIDE_USB_PAGE, GUIDE_DEST_PAGE, GUIDE_UPLOAD_PAGE, GUIDE_MANAGE_PAGE = (
    "guide_admin",
    "guide_usb",
    "guide_dest",
    "guide_upload",
    "guide_manage",
)
GUIDE_ADMIN_PAGES = (GUIDE_ADMIN_PAGE, GUIDE_USB_PAGE, GUIDE_DEST_PAGE, GUIDE_UPLOAD_PAGE, GUIDE_MANAGE_PAGE)
# 4 桁の暗証番号を入れる画面。「店舗用」「音の設定」「電源・再起動」（一般の番号）と、管理者の画面（管理者の番号）を開くとき、
# 管理者の画面で番号を変えるとき（新しい番号を 2 回）に出る。何の番号かは PIN_TASKS で決まる
PIN_PAGE = "pin"
# 訂正の画面（通訳の画面の「訂正」ボタンから、一般の番号を入れて開く）: 誤訳を、決めた訳に直す一覧（corrections.py）
FIX_PAGE = "fix"
# 業種（用語集）を選ぶ画面（メニューの「業種」ボタンから開く）: 区分（飲食店・宿泊施設 …）を選ぶ → その区分の業種を選ぶ
INDUSTRY_PAGE, INDUSTRY_SUB_PAGE = "industry", "industry_sub"
# ハングル学習（「ガイド」の画面の「ハングル学習」ボタンから開く）: 4 つの項目 → 文字と発音 / 接客フレーズ（発音チェックつき）/ 読む練習（クイズ）
STUDY_PAGE, STUDY_LETTERS_PAGE, STUDY_PHRASE_PAGE, STUDY_QUIZ_PAGE = "study", "study_letters", "study_phrases", "study_quiz"
# 時計設定（メニューの右上の日付・時刻を押して開く）
CLOCK_PAGE = "clock"
CLOCK_COLUMN_WIDTH, CLOCK_COLUMN_GAP = 128, 16
CLOCK_LABEL_Y, CLOCK_UP_TOP, CLOCK_VALUE_Y, CLOCK_DOWN_TOP, CLOCK_BUTTON_HEIGHT = 92, 118, 208, 238, 58
CLOCK_NTP_LABEL_Y, CLOCK_NTP_TOP, CLOCK_NTP_WIDTH, CLOCK_NTP_HEIGHT = 322, 346, 130, 52
CLOCK_FIELD_LABELS = (("year", "年", "Year"), ("month", "月", "Month"), ("day", "日", "Day"), ("hour", "時", "Hour"), ("minute", "分", "Min"))
CLOCK_MENU_WIDTH = 236  # メニューの右上の、日付・時刻を出す（押すと時計設定が開く）場所の幅
MENU_CLOCK_COLOR = (36, 98, 64)  # その背景の色（濃い緑。2026-10-23 に、ボタンと同じ灰色から変えた）
STUDY_PAGES = (STUDY_PAGE, STUDY_LETTERS_PAGE, STUDY_PHRASE_PAGE, STUDY_QUIZ_PAGE)
# マイクの調整・切り替えの画面と、Wi-Fi の画面、「使い方」の画面（開いている間は翻訳しない）
TUNING_PAGES = (
    SOUND_PAGE,
    BLUETOOTH_PAGE,
    INPUT_PAGE,
    WIFI_PAGE,
    WIFI_PASSWORD_PAGE,
    GUIDE_PAGE,
    PIN_PAGE,
    GUIDE_LIST_PAGE,
    GUIDE_VIEW_PAGE,
    *GUIDE_ADMIN_PAGES,
)
# キーボードの Esc で戻る先
ESCAPE_PAGES = {
    MENU_PAGE: MAIN_PAGE,
    LANGUAGE_PAGE: MENU_PAGE,
    SOUND_PAGE: MENU_PAGE,
    BLUETOOTH_PAGE: SOUND_PAGE,
    INPUT_PAGE: BLUETOOTH_PAGE,
    POWER_PAGE: MENU_PAGE,
    ADMIN_PAGE: POWER_PAGE,
    USAGE_PAGE: POWER_PAGE,
    PHRASES_PAGE: MENU_PAGE,
    PHRASE_EDIT_PAGE: PHRASES_PAGE,
    KEYBOARD_PAGE: MAIN_PAGE,
    WIFI_PAGE: MENU_PAGE,
    WIFI_PASSWORD_PAGE: WIFI_PAGE,
    GUIDE_PAGE: MENU_PAGE,
    PIN_PAGE: MENU_PAGE,
    FIX_PAGE: MAIN_PAGE,
    GUIDE_LIST_PAGE: GUIDE_PAGE,
    GUIDE_VIEW_PAGE: GUIDE_LIST_PAGE,
    GUIDE_ADMIN_PAGE: GUIDE_LIST_PAGE,
    GUIDE_USB_PAGE: GUIDE_ADMIN_PAGE,
    GUIDE_DEST_PAGE: GUIDE_USB_PAGE,
    GUIDE_UPLOAD_PAGE: GUIDE_ADMIN_PAGE,
    GUIDE_MANAGE_PAGE: GUIDE_ADMIN_PAGE,
    INDUSTRY_PAGE: MENU_PAGE,
    INDUSTRY_SUB_PAGE: INDUSTRY_PAGE,
    STUDY_PAGE: GUIDE_PAGE,
    STUDY_LETTERS_PAGE: STUDY_PAGE,
    STUDY_PHRASE_PAGE: STUDY_PAGE,
    STUDY_QUIZ_PAGE: STUDY_PAGE,
}

# 番号の画面: 数字のキー（3 列 x 4 行。下の段は「消去」「0」「1 文字消す」）、キーの大きさ、間違えたときの扱い
PIN_KEYS = ("1", "2", "3", "4", "5", "6", "7", "8", "9", "clear", "0", "back")
PIN_KEY_WIDTH, PIN_KEY_HEIGHT, PIN_KEY_GAP, PIN_KEYS_TOP = 104, 70, 8, 96
# この回数、続けて間違えると、PIN_LOCK_SEC 秒のあいだ受け付けない（当てずっぽうで開かないように。一般と管理者で別に数える）
PIN_MAX_TRIES, PIN_LOCK_SEC = 5, 30.0
PIN_WRONG = "番号が違います / Wrong number"
PIN_MISMATCH = "2 回の番号が違います。最初からやり直してください / The two numbers differ. Start again"
PIN_CHANGED = "変更しました / Changed"
GENERAL, ADMIN = "general", "admin"  # どちらの番号か


@dataclass(frozen=True)
class PinTask:
    """番号の画面で何をするか: 画面の見出し、どちらの番号か、「戻る」で戻る先。setting なら、新しい番号を 2 回入れて決める。"""

    title: str
    title_en: str
    icon: str
    group: str
    back: str
    setting: bool = False


PIN_TASKS = {
    "store": PinTask("店舗用", "For the store", icons.SHOP, GENERAL, GUIDE_PAGE),
    "sound": PinTask("音の設定", "Sound", icons.SPEAKER, GENERAL, MENU_PAGE),
    "power": PinTask("電源・再起動", "Power", icons.POWER, GENERAL, MENU_PAGE),
    "admin": PinTask("管理者", "Administrator", icons.LOCK, ADMIN, POWER_PAGE),
    "usage": PinTask("翻訳回数履歴", "Usage history", icons.LOCK, GENERAL, POWER_PAGE),
    "clock": PinTask("時計設定", "Clock", icons.LOCK, GENERAL, MENU_PAGE),
    "wifi": PinTask("Wi-Fi設定", "Wi-Fi settings", icons.WIFI, GENERAL, MENU_PAGE),
    "fix": PinTask("訂正", "Corrections", icons.LOCK, GENERAL, MAIN_PAGE),
    "set_general": PinTask("一般の暗証番号を変える", "Change the general number", icons.LOCK, GENERAL, ADMIN_PAGE, True),
    "set_admin": PinTask("管理者の暗証番号を変える", "Change the administrator number", icons.LOCK, ADMIN, ADMIN_PAGE, True),
}
# 番号の画面の案内（日本語, 英語）: 番号を聞くとき / 新しい番号を決めるとき（1 回目・2 回目）
PIN_PROMPTS = {
    (GENERAL, False): ("4桁の番号を入れてください", "Enter the 4-digit number"),
    (ADMIN, False): ("管理者の番号を入れてください", "Enter the administrator number"),
    (GENERAL, 1): ("新しい4桁の番号を入れてください", "Enter a new 4-digit number"),
    (ADMIN, 1): ("新しい4桁の番号を入れてください", "Enter a new 4-digit number"),
    (GENERAL, 2): ("もう一度、同じ番号を入れてください", "Enter the same number once more"),
    (ADMIN, 2): ("もう一度、同じ番号を入れてください", "Enter the same number once more"),
}

# メニュー上の「使い方」ボタン（「定型文」の左）と、「使い方」の画面
GUIDE_BUTTON_WIDTH = 150
GUIDE_BUTTON_COLOR = (84, 82, 160)
# お客様用 / 店舗用の大きなボタン（上端と高さ）。色は、お客様用 = 緑、店舗用 = 茶
GUIDE_AUDIENCE_TOP, GUIDE_AUDIENCE_HEIGHT = 92, 250
GUIDE_AUDIENCE_COLORS = {guide.CUSTOMER: (44, 104, 84), guide.STORE: (150, 110, 60)}
GUIDE_CATEGORY_COLOR = (62, 70, 104)
GUIDE_AUDIENCE_ICONS = {guide.CUSTOMER: icons.PERSON, guide.STORE: icons.SHOP}
GUIDE_ROW_SIZES = (26, 22, 19)
# 一覧にない・まだ置いていないときの案内（{place} には、guides の中のフォルダの名前を入れる）
GUIDE_EMPTY = "まだ動画・スライドがありません\nguides フォルダの {place} に入れてください"
GUIDE_VIDEO_UNAVAILABLE = "動画を再生できませんでした / Could not play the video"
# スライドの画面: 下の操作の段より上が画像の場所。画像の左の 1/4 をタップすると前へ、それ以外は次へ
GUIDE_SLIDE_BACK_RATIO = 0.25
# 動画の画面の「再生」ボタンの大きさ
GUIDE_PLAY_WIDTH, GUIDE_PLAY_HEIGHT = 300, 84
# 「動画の追加・管理」: 店舗用の一覧の左下のボタンの幅（上限）、入れ方の 3 つのボタンの色、入れる場所のボタンの高さ
GUIDE_ADMIN_BUTTON_MAX = 300
GUIDE_ADMIN_TILE_COLORS = ((62, 70, 104), (44, 104, 84), (150, 110, 60))
GUIDE_DEST_TOP, GUIDE_DEST_HEIGHT, GUIDE_DEST_GAP = 96, 96, 16
GUIDE_OK_COLOR = (127, 214, 168)
GUIDE_MANAGE_HINT = "「名前を変える」か「削除」を押してから、動画をタップしてください / Choose Rename or Delete, then tap a video"
GUIDE_DELETE_CONFIRM = "もう一度タップすると消えます / Tap again to delete"
GUIDE_WAIT_COPY = "入れ終わるまでお待ちください / Please wait until it finishes"
GUIDE_UPLOAD_STEPS = (
    "1. スマホのカメラで QR コードを読み取ります",
    "2. 開いたページで、動画・入れる場所・題名を選んで「送る」",
    "スマホは、この通訳機と同じ Wi-Fi につないでください",
)
GUIDE_UPLOAD_STEPS_EN = "Scan the QR code, pick a video, where to add it and a title, then Send (same Wi-Fi)."
GUIDE_NO_QR = "QR コードを出せません。下のアドレスを、スマホのブラウザに入れてください / Type this address in the phone's browser"

# メニュー上のボタン（右から「Wi-Fi設定」「定型文」「使い方」「業種」。「メニュー」の右の空いている所。2 行目に英語）
TOP_BUTTON_TOP, TOP_BUTTON_HEIGHT = 6, 46

# メニュー上の「業種」ボタン（「使い方」の左）と、業種を選ぶ画面。区分（飲食店 …）のボタンを 2 列に並べ、
# 区分を押すと、その区分の業種のボタン（押すたびに選ぶ・外す）を並べた画面を開く。
# 8 つ目の場所は、区分の画面では「選択をすべて解除」、業種の画面では「全部選ぶ・全部外す」
INDUSTRY_BUTTON_WIDTH = 120
INDUSTRY_BUTTON_COLOR = (28, 104, 120)
INDUSTRY_PAGE_TITLE = "業種の選択（用語集）"
INDUSTRY_PAGE_SUBTITLE = "Business type (glossary of terms)"
INDUSTRY_HINT = "何も選ばないときは、すべての用語を使います"
INDUSTRY_HINT_EN = "With nothing selected, all terms are used"
INDUSTRY_SUB_HINT = "当てはまる業種を、いくつでも選べます"
INDUSTRY_SUB_HINT_EN = "You can select more than one"
INDUSTRY_COLUMNS = 2
INDUSTRY_TOP = 66
INDUSTRY_BUTTON_HEIGHT = 68
INDUSTRY_GAP = 12
INDUSTRY_CHECK_SIZE = 30
INDUSTRY_COUNT_WIDTH = 96  # 業種のボタンの右端に、定型文の数と単語の数を出す幅
INDUSTRY_SLOTS = 8

# ハングル学習の画面
STUDY_COLOR = (150, 70, 120)
STUDY_COURSES = {KO: study, EN: english_study, ZH: chinese_study}  # 学習する言語 → 中身のモジュール
STUDY_COURSE_LABELS = {
    KO: ("ハングル学習", "Hangul study"),
    EN: ("英語学習", "English study"),
    ZH: ("中国語学習", "Chinese study"),
}
# 最初の画面の 4 つの項目（番号, 日本語, 英語, 説明）
STUDY_TILES = (
    ("letters", "文字と発音", "Letters & sounds", "母音・子音の読みと、例の単語"),
    ("phrases", "接客フレーズ", "Service phrases", "お店で使う言葉を、聞いて覚える"),
    ("words", "読む練習", "Reading practice", "ハングルを読んで、意味を選ぶ"),
    ("check", "発音チェック", "Pronunciation check", "話して、通じるか確かめる"),
)
# 英語学習の項目の説明（項目の並びと意味は、ハングル学習と同じ）
STUDY_TILES_EN = (
    ("letters", "文字と発音", "Letters & sounds", "文字・つづりの音と、例の単語"),
    ("phrases", "接客フレーズ", "Service phrases", "お店で使う言葉を、聞いて覚える"),
    ("words", "読む練習", "Reading practice", "英単語を読んで、意味を選ぶ"),
    ("check", "発音チェック", "Pronunciation check", "話して、通じるか確かめる"),
)
# 中国語学習の項目の説明
STUDY_TILES_ZH = (
    ("letters", "声調と発音", "Tones & sounds", "声調・声母・韻母と、例の単語"),
    ("phrases", "接客フレーズ", "Service phrases", "お店で使う言葉を、聞いて覚える"),
    ("words", "読む練習", "Reading practice", "中国語の単語を読んで、意味を選ぶ"),
    ("check", "発音チェック", "Pronunciation check", "話して、通じるか確かめる"),
)
STUDY_TILES_BY_LANG = {KO: STUDY_TILES, EN: STUDY_TILES_EN, ZH: STUDY_TILES_ZH}
STUDY_LETTER_COLUMNS = 7
STUDY_TAB_TOP, STUDY_TAB_HEIGHT = 56, 44
STUDY_GRID_TOP, STUDY_CELL_HEIGHT, STUDY_CELL_GAP = 108, 50, 6
STUDY_PANEL_TOP, STUDY_PANEL_HEIGHT = 284, 104
STUDY_QUESTIONS_PER_ROUND = 10
STUDY_NOT_HEARD = "聞き取れませんでした。もう一度 / Not heard. Try again"
STUDY_BUSY = "いま聞き取れません。少し待ってください / Please wait"

# メニュー上の「定型文」ボタン（「Wi-Fi設定」の左）と、定型文の画面
# （一覧は 1 画面に LIST_ROWS 行。下に「登録」「削除」「前へ」「次へ」「戻る」）
LIST_ROW_TOP, LIST_ROW_HEIGHT, LIST_ROW_GAP, LIST_ROWS = 62, 56, 8, 5
PHRASE_BUTTON_WIDTH = 150
PHRASE_BUTTON_COLOR = (150, 110, 60)
PHRASE_ADD_WIDTH, PHRASE_DELETE_WIDTH, PHRASE_EDIT_WIDTH = 95, 70, 70  # 3 つで「前へ」(x=280〜) に重ならない幅（800px の画面）
# 定型文の修正の画面: 案内と、知らせ
PHRASE_EDIT_TITLE = "定型文の修正 / Edit phrase"
PHRASE_EDIT_HINT = "直したい行をタップして、キーボードで打ち直します"
PHRASE_EDIT_SOURCE_NOTE = "元の文を直すと、訳文は消えて、次に使うときに訳し直します"
PHRASE_EDIT_CANNOT_TYPE = "この言語は画面では打てません（定型文を消して、声で登録し直してください）"
PHRASE_EDIT_DUPLICATE = "同じ文がもう登録されています"
PHRASE_EDIT_SAVED = "直しました / Saved"
PHRASE_EDIT_EMPTY_TRANSLATION = "（まだ訳していません）"
PHRASE_TEXT_SIZES = (24, 21, 18)
# 各行の右端に出す、使った回数と登録日（3回  2026/10/01）の文字の大きさ
PHRASE_DATE_SIZE = 16
PHRASE_EMPTY = "まだ登録されていません\n通訳の画面で話した（打った）あと、この画面の「登録」を押すと、その文を登録できます"
PHRASE_NO_MATCH = "選んでいる業種に合う定型文は、ありません\n「業種」の選び方を変えるか、通訳の画面で話したあと「登録」を押してください"
PHRASE_BUSY = "処理中です。終わってから選んでください"
# 定型文の画面の右上の「音声検索」ボタン
PHRASE_SEARCH_WIDTH = 170
PHRASE_NOT_HEARD = "聞き取れませんでした / Not heard"
PHRASE_NOT_FOUND = "見つかりませんでした / Not found\n文の初めの言葉を、登録したときと同じように話してください"

# メニュー上の「Wi-Fi設定」ボタン（右端）
WIFI_BUTTON_WIDTH = 150
WIFI_DISCONNECT_WIDTH = 190
# メニューの「Wi-Fi設定」と「音の設定」ボタンの背景（ネイビーブルー。2026-10-23 に、緑・灰色から変えた）
NAVY_BUTTON_COLOR = (26, 46, 108)
WIFI_BUTTON_COLOR = NAVY_BUTTON_COLOR
# Wi-Fi の画面: 状態の行、「探す」ボタン、Wi-Fi の一覧（1 画面に WIFI_ROWS 行。多いときは「前へ」「次へ」）
WIFI_CURRENT_Y = 56
WIFI_ROW_TOP, WIFI_ROW_HEIGHT, WIFI_ROW_GAP, WIFI_ROWS = 158, 50, 8, 4
WIFI_NOT_CONNECTED = "未接続 / Not connected"
# パスワードを入れる画面: 入力欄と、画面のキーボード（5 段）
WIFI_ENTRY_TOP, WIFI_ENTRY_HEIGHT = 50, 58
WIFI_KEY_TOP, WIFI_KEY_HEIGHT, WIFI_KEY_GAP = 118, 62, 8
WIFI_KEY_ROWS = ("1234567890", "qwertyuiop", "asdfghjkl", "zxcvbnm")
# キーの文字と入力欄は、記号や l / 1 / I、0 / O の見分けがつくフォントで描く（日本語のフォントの半角記号は、
# 「_」が「–」、「`」が「、」のように見える）。無ければ日本語のフォントを使う
KEY_FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
PASSWORD_FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"
# 記号（Wi-Fi のパスワードに使えるのは半角の文字だけ。4 段目は、よく使う記号をもう一度並べる）
WIFI_SYMBOL_ROWS = ("!@#$%^&*()", "-_=+[]{}\\|", ";:'\",.<>/?", "`~@#_.-")

# 電源・再起動の画面の右上の「管理者」ボタンと、管理者の画面（CPU 温度と 5V 入力電圧のグラフ）
ADMIN_BUTTON_WIDTH, ADMIN_BUTTON_HEIGHT = 150, 52
# 「管理者」ボタンを押してから ADMIN_UNLOCK_SEC 秒以内に、画面の左上の角（ADMIN_CORNER の四角）に触ると、管理者の画面に入る
ADMIN_UNLOCK_SEC = 5.0
ADMIN_CORNER = 110
# 電源・再起動の画面の下の「省電力モード」の「オン」「オフ」と、その右の説明
ECO_LABEL_Y, ECO_TOP, ECO_BUTTON_WIDTH, ECO_BUTTON_HEIGHT = 388, 414, 150, 52
# 電源・再起動の画面の左上の「自動オフ」: 見出し、時刻（「−」「＋」で 15 分きざみ）。右上の「管理者」の左に収める
AUTO_OFF_TOP, AUTO_OFF_HEIGHT = MARGIN, 52
AUTO_OFF_LABEL_WIDTH, AUTO_OFF_STEP_WIDTH, AUTO_OFF_VALUE_WIDTH = 120, 80, 130
AUTO_OFF_SWITCH_WIDTH, AUTO_OFF_SWITCH_GAP = 150, 14  # 「＋」の右の、オン・オフの切り替え
# 省電力モードで画面が消えている間に、3 分ごとに数秒だけ出すお知らせ（日本語と英語）
NOTICE_TITLE = ("只今、低消費電力モード中です。", "Low-power mode is active.")
NOTICE_BODY = (
    "ご使用されない場合は、\n「メニュー」→「電源・再起動」→「電源を切る」\nを押してください。",
    "If you are not using this device,\ntap Menu → Power / Restart → Power off.",
)
NOTICE_HINT = "画面に触ると点きます / Touch the screen to wake up"
# 上に期間のボタン、その下に温度のグラフと電圧のグラフ（横軸の時刻は共通）、下に最低・最高と「戻る」
# 期間のボタンの右端に「稼働時間」（1 日ごとの稼働時間の棒グラフ）
ADMIN_RANGE_WIDTH, ADMIN_RANGE_HEIGHT = 74, 46
ADMIN_UPTIME_VIEW = len(CHART_RANGES)
# 訂正の画面（FIX_PAGE）: 誤訳を、決めた訳に直す一覧（corrections.py）。「覚える」「入力」「削除」
FIX_TITLE = "訂正 / Corrections"
# 通訳の画面の「訂正」ボタン（「訳し直し」の下）の高さと、「訳し直し」との間
FIX_BUTTON_HEIGHT, FIX_BUTTON_GAP = 44, 6
FIX_EMPTY = "訂正はまだありません\n訳し直して、よい訳が出たら「覚える」を押します。\nちがう訳にしたいときは「入力」で、正しい訳を打ちます"
FIX_NO_EXCHANGE = "先に、通訳をしてください（直したい文を訳したあとに押します）"
# 「音声入力」: 訂正後の訳を話す → 聞き取った訳を確かめて「登録」
FIX_VOICE_BUSY = "今は聞き取れません（翻訳の途中か、言語が変わりました）"
FIX_VOICE_NOT_HEARD = "聞き取れませんでした / Not heard"
FIX_VOICE_LISTENING = "聞き取り中… 正しい訳を話してください / Listening…"
# 訂正の画面の下のボタンの幅: 「前へ」「次へ」と、「入力」「音声入力」（「覚える」「削除」の 1.5 倍ほど）
FIX_PAGING_WIDTH, FIX_WIDE_WIDTH = 110, 82
# 管理者の画面の最後のタブ「暗証番号」: 一般の番号と管理者の番号を変える（グラフではなく、番号の説明と「変更」ボタン）
ADMIN_PIN_VIEW = len(CHART_RANGES) + 1
ADMIN_PIN_LABEL = "暗証番号"
# 管理者の画面の 7 つ目のタブ「利用状況」: 日ごとの、翻訳の数・訂正の数・定型文を足した数（言語別の積み上げ棒グラフ。usage_log.py）
ADMIN_USAGE_VIEW = len(CHART_RANGES) + 2
ADMIN_USAGE_LABEL = "利用状況"
USAGE_KIND_LABELS = {
    TRANSLATIONS: ("翻訳", "Translations"),
    CORRECTIONS: ("訂正", "Corrections"),
    PHRASES: ("定型文", "Phrases"),
    PHRASE_USES: ("定型文を使用", "Phrase uses"),
    MAX_TEMP: ("最高温度", "Max temp"),
}
USAGE_TITLES = {
    TRANSLATIONS: "翻訳した数",
    CORRECTIONS: "訂正を登録した数",
    PHRASES: "定型文を足した数",
    PHRASE_USES: "定型文を使った数",
    MAX_TEMP: "最高温度",
}
# 種類のボタン: 管理者の画面の「利用状況」と、「翻訳回数履歴」の画面（左から順に並べる）
ADMIN_USAGE_KINDS = (TRANSLATIONS, CORRECTIONS, PHRASES, MAX_TEMP)
HISTORY_KINDS = (TRANSLATIONS, PHRASE_USES, CORRECTIONS)
# 電源・再起動の画面の「管理者」の下の「翻訳回数履歴」ボタンと、その画面の見出し
HISTORY_BUTTON_GAP = 10
HISTORY_KIND_WIDTH = 160  # 「翻訳回数履歴」の種類のボタンの幅（「定型文を使用」が収まる幅）
HISTORY_TITLE = "翻訳回数履歴 / Usage history"
HISTORY_TITLE_Y = 14
# 「最高温度」のグラフ: 縦軸は 0〜100℃。80℃は、CPU が熱で速度を落とし始める目安。棒の色は、温度で変える
USAGE_TEMP_TOP, USAGE_TEMP_STEP, USAGE_TEMP_LIMIT = 100, 20, 80
USAGE_TEMP_COLORS = ((70.0, (80, 190, 120)), (80.0, (245, 176, 65)), (1000.0, (230, 95, 95)))  # 70℃まで 緑、80℃まで 黄、それ以上 赤
USAGE_DAYS = (7, 14, 30)
USAGE_DEFAULT_DAYS = 14
USAGE_ROW_TOP, USAGE_ROW_HEIGHT, USAGE_KIND_WIDTH, USAGE_DAYS_WIDTH = 66, 40, 112, 66
USAGE_LEGEND_Y, USAGE_LEGEND_ROW, USAGE_CHART_TOP, USAGE_CHART_HEIGHT = 108, 20, 152, 198  # 凡例は、収まらなければ 2 行
# 言語ごとの色と、凡例の短い名前（相手の言語。日本語どうしの訳は無い）
USAGE_LANG_COLORS = {
    "ko": (91, 155, 230), "en": (245, 176, 65), "zh": (230, 95, 95), "yue": (188, 127, 222), "th": (72, 199, 168),
    "fr": (130, 200, 90), "ru": (225, 130, 170), "pt": (240, 225, 110), "hok": (160, 170, 185), "osa": (255, 140, 60),
    "fuk": (120, 120, 230), NO_LANG: (80, 190, 120),
}
USAGE_LANG_NAMES = {
    "ko": "韓国語", "en": "英語", "zh": "中国語", "yue": "広東語", "th": "タイ語", "fr": "フランス語", "ru": "ロシア語",
    "pt": "ポルトガル語", "hok": "北海道弁", "osa": "大阪弁", "fuk": "福岡弁",
}
USAGE_EMPTY = "この期間の記録はまだありません"
USAGE_NO_LOG = "利用状況を記録していません"
ADMIN_PIN_ROWS_TOP, ADMIN_PIN_ROW_HEIGHT, ADMIN_PIN_ROW_GAP = 84, 112, 14
ADMIN_PIN_CHANGE_WIDTH, ADMIN_PIN_CHANGE_HEIGHT = 170, 64
ADMIN_UPTIME_LABEL = "稼働時間"
ADMIN_UPTIME_COLOR = (80, 190, 120)
# 合計稼働時間の「リセット」は、ADMIN_CONFIRM_SEC 秒以内にもう一度押したときだけ行う（押し間違いで消さないように）
ADMIN_CONFIRM_SEC = 5.0
ADMIN_AXIS_WIDTH = 58
ADMIN_CHART_TOPS, ADMIN_CHART_HEIGHT = (74, 232), 132
ADMIN_TEMP_COLOR = (255, 150, 40)
ADMIN_VOLT_COLOR = (90, 170, 255)
# 下のグラフ: CPU クロック（左の縦軸）と CPU 電圧（右の縦軸）を 1 つのグラフに重ねる。右の縦軸の目盛りの幅も取る
ADMIN_CLOCK_COLOR, ADMIN_CPU_VOLT_COLOR = (90, 170, 255), (120, 220, 120)
ADMIN_RIGHT_AXIS_WIDTH = 66
ADMIN_CLOCK_STEP, ADMIN_CPU_VOLT_STEP = 300.0, 0.05
# Pi 5・CM5 は、電源管理チップが 5V 入力電圧を測れるので、CPU 電圧の代わりに、入力電圧を重ねる（Pi 4 は、CPU 電圧のまま）
ADMIN_INPUT_VOLT_STEP = 0.05
ADMIN_LABEL_SIZE = 15
# 縦軸の目盛りの幅（温度 5℃、電圧 0.1V）
ADMIN_TEMP_STEP, ADMIN_VOLT_STEP = 5.0, 0.1
# 最初に選んでいる期間（24時間）と、開いている間に記録を読み直す間隔
ADMIN_DEFAULT_RANGE = 1
ADMIN_RELOAD_SEC = 60.0
ADMIN_EMPTY = "まだ記録がありません\n起動したときと、そのあと 10 分ごとに、10 秒間の平均を記録します"

# Bluetooth の画面の「マウス・キーボード ▶」ボタン（右上）
HID_BUTTON_WIDTH = 220
# 通訳の画面の、キーボードで打った文の欄（下のバーのすぐ上に重ねて出す）
ENTRY_HEIGHT = 66
ENTRY_COLOR = (34, 42, 52)
ENTRY_BORDER_COLOR = (90, 140, 200)
ENTRY_SIZES = (26, 22, 18)
ENTRY_HINT = "Enter: 送信 / Send　Esc: 取り消し / Clear"
# 打った文を送れなかったとき（前の発話を処理している途中）に出す文
ENTRY_BUSY_MESSAGE = "処理中です。終わってから Enter を押してください"

# 画面のキーボードの画面。キーの並びは screen_keyboard.py にある。
# 上から 見出し（話す人の切り替えボタン付き）、入力欄と「消去」、キー 5 段（Wi-Fi のパスワードの画面と同じ大きさ）
KEYBOARD_BUTTON_WIDTH = 80
KB_SWAP_WIDTH, KB_SWAP_HEIGHT = 230, 40
KB_ENTRY_TOP, KB_ENTRY_HEIGHT, KB_CLEAR_WIDTH = 50, 58, 84
KB_KEY_TOP, KB_KEY_HEIGHT, KB_KEY_GAP = 118, 62, 8
KB_ENTRY_SIZES = (30, 26, 22, 18)
KB_KEY_SIZE, KB_HANGUL_KEY_SIZE = 26, 32
KB_BUSY_MESSAGE = "処理中です。終わってから送信してください / Busy"
# マウスのポインターを動かしたときに描き直す間隔（毎秒 30 回まで）
POINTER_REDRAW_SEC = 1 / 30

# 台湾の繁体字の書体（fonts の辞書のキー。言語としては中国語 ZH のまま扱う）
ZH_HANT = "zh-hant"
# Noto Sans CJK の TTC に入っている書体名の末尾と、言語の対応（HK は香港の字形。広東語に使う）
_FACE_SUFFIXES = {"JP": JA, "KR": KO, "SC": ZH, "TC": ZH_HANT, "HK": YUE}


def load_fonts(path: str, thai_path: str = "") -> dict[str, pygame.freetype.Font]:
    """TTC から日本語・韓国語・簡体字中国語・繁体字中国語（台湾・香港）の書体を取り出す。

    英語・フランス語・ロシア語・ポルトガル語は日本語の書体で表示する（キリル文字も入っている）。タイ文字は Noto Sans CJK にないので、thai_path のフォントを使う。
    """
    fonts: dict[str, pygame.freetype.Font] = {}
    first: pygame.freetype.Font | None = None
    for index in range(16):
        try:
            font = pygame.freetype.Font(path, 0, font_index=index, ucs4=True)
        except (OSError, pygame.error):
            break
        if first is None:
            first = font
        name = font.name or ""
        lang = _FACE_SUFFIXES.get(name.rsplit(" ", 1)[-1])
        if lang and "Mono" not in name:
            fonts.setdefault(lang, font)
    if first is None:
        log.warning("フォント %s を読み込めないため、既定のフォントを使います（漢字などは表示されません）", path)
        first = pygame.freetype.Font(None, 0)
    default = fonts.get(JA, first)
    for lang in (JA, KO, EN, ZH, FR, RU, PT, HOK, OSA, FUK):
        fonts.setdefault(lang, default)
    fonts.setdefault(ZH_HANT, fonts[ZH])  # 繁体字の書体が無ければ、簡体字の書体で表示する
    fonts.setdefault(YUE, fonts[ZH_HANT])
    if thai_path:
        try:
            fonts[TH] = pygame.freetype.Font(thai_path, 0)
        except (OSError, pygame.error):
            log.warning("タイ文字のフォント %s を読み込めないため、タイ文字は表示できません（scripts/download_models.sh を実行してください）", thai_path)
    fonts.setdefault(TH, default)
    for font in fonts.values():
        font.origin = True  # render_to の y 座標をベースラインとして扱う
    return fonts


def load_brand_font(path: str, fallback: pygame.freetype.Font) -> tuple[pygame.freetype.Font, int]:
    """製品名（AI-Translator・コトリア）用の、太くて読みやすい書体と、描くときの style。

    通常の書体の「Regular」を「Bold」に替えたファイル（Noto Sans CJK なら NotoSansCJK-Bold.ttc）があれば、その日本語の面を使う。
    無いときは、通常の書体を、太く見せる加工（STYLE_STRONG）をかけて使う。
    """
    candidate = path.replace("Regular", "Bold")
    if candidate != path and Path(candidate).exists():
        try:
            font = pygame.freetype.Font(candidate, 0, font_index=0, ucs4=True)
        except (OSError, pygame.error):
            log.warning("太字のフォント %s を読み込めないため、通常のフォントを太くして使います", candidate)
        else:
            font.origin = True
            return font, pygame.freetype.STYLE_NORMAL
    return fallback, pygame.freetype.STYLE_STRONG


def load_phonetic_font(path: str, fallback: pygame.freetype.Font) -> pygame.freetype.Font:
    """発音記号用のフォント。

    発音記号はカタカナなので、既定では空欄にして通常の CJK フォントを使う。IPA やピンインの
    声調記号に戻すときだけ、それらの字形を持つフォント（DejaVu など）を指定する。
    """
    if not path:
        return fallback
    try:
        font = pygame.freetype.Font(path, 0)
    except (OSError, pygame.error):
        log.warning("発音記号用のフォント %s がないため、通常のフォントで表示します（一部の記号が出ないことがあります）", path)
        return fallback
    font.origin = True
    return font


class TranslatorScreen:
    def __init__(self, cfg: DisplayConfig, state: UiState) -> None:
        self._display = open_display(cfg)
        self._surface = self._display.surface
        self._width, self._height = self._surface.get_size()
        pygame.freetype.init()
        self._state = state
        self._fonts = load_fonts(cfg.font, cfg.thai_font)
        self._phonetic_font = load_phonetic_font(cfg.phonetic_font, self._fonts[EN])
        self._brand_font, self._brand_style = load_brand_font(cfg.font, self._fonts[JA])  # 製品名用の、太い書体
        # Wi-Fi のパスワードの画面のキーと入力欄のフォント
        self._key_font = load_phonetic_font(KEY_FONT, self._fonts[EN])
        self._password_font = load_phonetic_font(PASSWORD_FONT, self._key_font)
        self._layout_buttons()
        self._on_mode_selected: Callable[[Mode], None] = state.set_mode
        self._on_start_listening: Callable[[], object] = lambda: state.set_listening_armed(True)
        self._on_stop_listening: Callable[[], None] = lambda: state.set_listening_armed(False)
        self._on_play: Callable[[], None] = lambda: None
        # 「訳し直し」ボタンの処理（受け付けたら True）と、ボタンの位置（表示していないときは None）
        self._on_retranslate: Callable[[], bool] = lambda: False
        self._retry_button: pygame.Rect | None = None
        self._logo: pygame.Surface | None = None  # 会社のロゴ（最初に使うときに読む。無ければ None のまま）
        self._logo_loaded = False
        self._fix_button: pygame.Rect | None = None  # 通訳の画面の「訂正」（「訳し直し」の下。描いたときだけ場所がある）
        self._on_cancel: Callable[[], None] = lambda: None
        self._on_speech_selected: Callable[[bool], None] = state.set_speech_enabled
        self._on_back_translation_selected: Callable[[bool], None] = state.set_back_translation_enabled
        self._on_denoise_selected: Callable[[bool], None] = state.set_denoise_enabled
        self._on_speech_speed_selected: Callable[[float], None] = state.set_speech_speed
        self._on_voice_selected: Callable[[str], None] = state.set_voice
        self._on_zh_script_selected: Callable[[str], None] = state.set_zh_script
        self._on_gain_selected: Callable[[float], None] = state.set_input_gain
        self._on_volume_selected: Callable[[float], None] = state.set_output_volume
        self._on_silence_selected: Callable[[float], None] = state.set_silence_sec
        self._on_max_speech_selected: Callable[[float], None] = state.set_max_speech_sec
        self._on_power_off: Callable[[], bool] = lambda: False
        self._on_reboot: Callable[[], bool] = lambda: False
        self._on_bt_scan: Callable[[], None] = lambda: None
        self._on_bt_select: Callable[[BluetoothDevice], None] = lambda device: None
        self._on_bt_use_usb: Callable[[], None] = lambda: None
        self._on_bt_open: Callable[[], None] = lambda: None
        self._on_bt_close: Callable[[], None] = lambda: None
        self._on_hid_scan: Callable[[], None] = lambda: None
        self._on_hid_select: Callable[[BluetoothDevice], None] = lambda device: None
        self._on_hid_open: Callable[[], None] = lambda: None
        self._on_hid_close: Callable[[], None] = lambda: None
        # 定型文: 一覧 / 直近の文を登録する（結果の文を返す）/ 削除する / 選んだ文を出す（受け付けたら True）
        self._on_phrase_list: Callable[[], tuple[Phrase, ...]] = lambda: ()
        self._on_phrase_add: Callable[[], str] = lambda: ""
        self._on_phrase_remove: Callable[[int], None] = lambda index: None
        self._on_phrase_use: Callable[[int], bool] = lambda index: False
        self._phrase_first = 0  # 一覧の 1 行目に出す定型文の番号
        self._phrase_delete = False  # 「削除」を押して、消す文を選んでいる途中か
        self._phrase_edit_mode = False  # 「修正」を押して、直す文を選んでいる途中か
        self._phrase_edit_key: tuple[str, str] | None = None  # 修正の画面で開いている定型文（話した言語, 文）
        self._phrase_edit_first = 0  # 修正の画面の 1 行目に出す行の番号
        self._phrase_edit_message = ""
        self._kb_phrase: tuple[str, str] | None = None  # キーボードで定型文を直している間の（直す行, 打つ言語）。行は "src" か、訳す先の言語
        self._on_phrase_rename: Callable[[str, str, str], str] = lambda lang, text, new_text: ""
        self._on_phrase_translation: Callable[[str, str, str, str], None] = lambda lang, text, target, translation: None
        self._phrase_message = ""
        # 音声検索: 始める（聞き取った文を渡す関数を渡す。始められたら True）/ やめる
        self._on_phrase_search: Callable[[Callable[[str], None]], bool] = lambda heard: False
        self._on_phrase_search_cancel: Callable[[], None] = lambda: None
        self._phrase_searching = False  # 聞き取っている途中か
        self._phrase_query = ""  # 聞き取った言葉
        # 見つかった定型文の番号（近い順）。検索していなければ None で、すべて出す
        self._phrase_filter: list[int] | None = None
        # 使い方: 動画・スライドの一覧を読む（画面を開くたびに読み直す）/ 動画を再生する（始められたら True）/ 再生を止める
        self._on_guide_load: Callable[[], dict[str, guide.Section]] = lambda: {}
        self._on_guide_play: Callable[[Path], bool] = lambda path: False
        self._on_guide_stop: Callable[[], None] = lambda: None
        self._guides: dict[str, guide.Section] = {}
        self._guide_audience = ""  # 選んだ お客様用 / 店舗用（まだ選んでいなければ空）
        self._guide_category: guide.Category | None = None  # 選んだ分類（分類を選んでいなければ None）
        self._guide_first = 0  # 一覧の 1 行目に出す行の番号
        self._guide_item: guide.Item | None = None  # 開いている動画・スライド
        self._guide_slide = 0  # スライドの何枚目か（0 から）
        self._guide_image: tuple[Path, tuple[int, int], pygame.Surface | None] | None = None  # 大きさを合わせた画像
        self._guide_was_playing = False
        self._guide_was_started = False  # 今開いている動画を、一度でも再生したか（「再生」→「もう一度再生」）
        # 店舗用の「動画の追加・管理」（set_guide_admin でつなぐ。つながなければボタンを出さない）
        self._guide_root: Path | None = None
        self._guide_checker: Callable[[Path], bool] = guide_admin.check_video
        self._guide_progress = guide_admin.Progress()
        self._usb = guide_admin.UsbBrowser()
        self._guide_upload: guide_upload.UploadServer | None = None
        self._guide_qr: tuple[str, pygame.Surface | None] | None = None  # （URL, QR コードの絵）
        self._guide_admin_first = 0  # USB メモリ・入れた動画の一覧の 1 行目
        self._guide_usb_pick: guide_admin.UsbVideo | None = None  # 入れる場所を選んでいる動画
        self._guide_manage: list[guide_admin.ManagedVideo] = []
        self._guide_manage_mode = ""  # "rename" / "delete" / ""
        self._guide_manage_armed: Path | None = None  # 削除で 1 回タップした動画
        self._guide_note = ""  # 画面の上に出す知らせ（名前の変更・削除の結果など）
        self._drawn_guide_admin: tuple[int, int] = (-1, -1)  # 描いたときの（進み具合, USB の一覧）の版
        self._kb_guide: Path | None = None  # 画面のキーボードで名前を変えている動画
        # 暗証番号（一般・管理者）の確認と変更。つないでいなければ、何も聞かない
        self._pins: PinStore | NoPins = NoPins()
        # 番号の画面: 何の番号か、新しい番号を決めるときは何回目か（1 か 2）と 1 回目の番号、今入れている番号、知らせの文、
        # 続けて間違えた回数と受け付けない時刻まで（一般と管理者で別）
        self._pin_kind = ""
        self._pin_step = 1
        self._pin_first = ""
        self._pin_entry = ""
        self._pin_message = ""
        self._pin_failures = {GENERAL: 0, ADMIN: 0}
        self._pin_locked_until = {GENERAL: -math.inf, ADMIN: -math.inf}
        # 管理者の画面の「暗証番号」の見出しの下に出す知らせ（番号を変えた結果）
        self._admin_message = ""
        # 訂正の一覧（管理者の画面の「訂正」タブ）: 処理と、画面の状態。_kb_fix は、キーボードで正しい訳を打っている間の
        # （話した言語, 話した文, 訳す先の言語）
        self._fix_list: Callable[[], tuple] = lambda: ()
        self._fix_keep: Callable[[], str] = lambda: FIX_NO_EXCHANGE
        self._fix_last: Callable[[], tuple[str, str, str, str] | None] = lambda: None
        self._fix_save: Callable[[str, str, str, str], str] = lambda source, text, target, translation: ""
        self._fix_remove: Callable[[int], None] = lambda index: None
        self._fix_first = 0
        self._fix_delete = False
        self._fix_message = ""
        self._kb_fix: tuple[str, str, str] | None = None
        # 訂正の「音声入力」: 訂正後の訳を話して入れる。voice(訳す先の言語, heard) で聞き取りを始め（始められたら True）、
        # 聞き取った訳を _fix_heard に持って、「登録」で確かめてから登録する。_fix_voice は直した文（話した言語, 文, 訳す先）
        self._fix_voice_start: Callable[[str, Callable[[str], None]], bool] = lambda target, heard: False
        self._fix_voice_cancel: Callable[[], None] = lambda: None
        self._fix_listening = False
        self._fix_voice: tuple[str, str, str] | None = None
        self._fix_heard = ""
        # Wi-Fi: 画面を開いたとき（探す）/ 「探す」/ つなぐ（Wi-Fi と、新しく入れたパスワード）
        self._on_wifi_open: Callable[[], None] = lambda: None
        self._on_wifi_scan: Callable[[], None] = lambda: None
        self._on_wifi_connect: Callable[[WifiNetwork, str | None], None] = lambda network, password: None
        self._on_wifi_disconnect: Callable[[], None] = lambda: None
        self._wifi_disconnect_armed_at = -math.inf  # 「切断」を 1 回押した時刻（もう一度押すと、切る）
        self._wifi_first = 0  # 一覧の 1 行目に出す Wi-Fi の番号
        # パスワードを入れる画面: つなぐ Wi-Fi、入れた文字、文字を見せるか、大文字・記号のキーボードか
        self._wifi_target: WifiNetwork | None = None
        self._wifi_password = ""
        self._wifi_show = False
        self._wifi_shift = False
        self._wifi_symbols = False
        # 省電力モード（画面を暗くする・消す、CPU を遅くする）と、オン・オフが選ばれたときの処理
        self._power_saver: PowerSaver | None = None
        self._on_power_saving: Callable[[bool], None] = lambda enabled: None
        self._auto_off: AutoOff | None = None
        self._idle_off: IdleOff | None = None
        self._idle_warning_drawn: int | None = None  # 画面に出している「あと何秒で電源が切れる」の秒数
        self._on_auto_off_changed: Callable[[], None] = lambda: None
        # 時計設定: 画面で変えている日付・時刻と、決める・自動合わせを切り替える処理（失敗したときは、画面に出す文を返す）
        self._clock_fields = ClockFields.from_datetime(datetime.now())
        self._clock_message = ""
        self._clock_ntp: bool | None = None
        self._on_clock_set: Callable[[datetime], str | None] = lambda moment: "この機器では時計を変えられません"
        self._on_clock_ntp: Callable[[bool], str | None] = lambda enabled: "この機器では時計を変えられません"
        self._get_clock_ntp: Callable[[], bool | None] = lambda: None
        self._drawn_clock_stamp = ""  # 直前に描いた日付・時刻（分が変わったら、メニューと時計設定を描き直す）
        # 業種の選択（用語集）。選び方が変わったら _on_industries_changed() を呼ぶ（保存用）。開いている区分は _industry_category
        self._industries: IndustrySelection | None = None
        self._on_industries_changed: Callable[[], None] = lambda: None
        self._industry_category: str | None = None
        # ハングル学習: 読み上げ・発音チェックの処理と、画面の状態
        self._on_study_speak: Callable[[str], bool] = lambda text: False
        self._on_study_check: Callable[[Callable[[str], None]], bool] = lambda heard: False
        self._on_study_cancel: Callable[[], None] = lambda: None
        self._on_study_close: Callable[[], None] = lambda: None
        self._study_lang = KO  # 学習している言語（KO = ハングル学習、EN = 英語学習）
        self._on_study_language: Callable[[str], None] = lambda lang: None
        self._study_random = random.Random()
        self._study_group = 0  # 文字の画面で選んでいる区分（母音・子音 …）
        self._study_letter = 0  # 選んでいる字（区分の中の番号）
        self._study_cards: list[tuple[str, str]] = []  # 接客フレーズ（日本語, 韓国語）
        self._study_card = 0
        self._study_kind = "words"  # クイズの種類: words（単語の意味）/ letters（字の読み）
        self._study_question: study.Question | None = None
        self._study_picked: int | None = None
        self._study_right = 0
        self._study_asked = 0
        self._study_target = ""  # 発音チェックの手本
        self._study_heard: str | None = None  # 認識した文（None = まだ話していない、"" = 聞き取れなかった）
        self._study_checking = False
        self._study_check_mode = False  # 最初の画面の「発音チェック」から入った（フレーズの画面の見出しを変える）
        self._study_notice = ""
        self._study_pool: list[tuple[str, str]] | None = None  # 読む練習の単語（最初に使うときに作る）
        # 管理者の画面: 記録を読む処理（さかのぼる時間を渡す）、選んでいる期間、読んだ記録と読んだ時刻
        self._on_system_readings: Callable[[int], list[Reading]] = lambda hours: []
        self._admin_range = ADMIN_DEFAULT_RANGE
        self._admin_readings: list[Reading] = []
        self._admin_loaded_at = -math.inf  # まだ読んでいない（time.monotonic() が小さい環境でも、最初に必ず読む）
        # 「管理者」ボタンを押した時刻（そのあと 5 秒以内の左上の角で入る）、リセットからの合計稼働時間、「リセット」を 1 回押した時刻
        self._admin_unlock_at = -math.inf
        self._uptime: UptimeCounter | None = None
        self._usage: UsageLog | None = None  # 利用状況の記録（管理者の画面の「利用状況」）
        self._usage_kind = TRANSLATIONS
        self._usage_days = USAGE_DEFAULT_DAYS
        self._history_kind = TRANSLATIONS  # 「翻訳回数履歴」の画面で選んでいる種類（期間は、管理者の画面と同じ _usage_days）
        self._reset_armed_at = -math.inf
        # 低消費電力モードのお知らせを描いたか（描いたあと、ふつうの画面を描き直すため）
        self._notice_drawn = False
        # キーボードで打った文を送る処理（受け付けたら True）と、打っている途中の文
        self._on_text: Callable[[str], bool] = lambda text: False
        self._entry = TextEntry()
        # 画面のキーボード: Shift（次の 1 文字だけ）と、数字・記号の段を出しているか、送れなかったときの知らせ
        self._kb_shift = False
        self._kb_symbols = False
        self._kb_message = ""
        # マウスのポインターが動いたので、描き直す必要があるか（描き直しは POINTER_REDRAW_SEC ごとまで）
        self._pointer_dirty = False
        self._last_pointer_draw = 0.0
        # 起動中は通訳の画面に読み込みの状況を出し、起動が終わったら open_menu() でメニュー画面にする
        self._page = MAIN_PAGE
        # 「通訳表示」「再生」ボタンの明るさ（1 = 明るい、0 = 暗い）と、明滅を始めた時刻
        self._blink_level = 1.0
        self._play_blink_level = 1.0
        self._menu_blink_started = time.monotonic()
        self._play_blink_started: float | None = None
        # 直前に描いた明るさ（変わったときだけ描き直す）
        self._drawn_menu_level = -1.0
        self._drawn_play_level = -1.0
        self._needs_redraw = True
        self._drawn_version = -1
        self._last_draw = 0.0
        self._shown_peak = 0.0
        self._last_tap = 0.0
        self._running = True

    def open_menu(self) -> None:
        """メニュー画面を表示する（起動が終わったときの最初の画面）。"""
        self._set_page(MENU_PAGE)
        self._needs_redraw = True

    def set_mode_handler(self, handler: Callable[[Mode], None]) -> None:
        self._on_mode_selected = handler

    def set_listen_handlers(self, start: Callable[[], object], stop: Callable[[], None]) -> None:
        """「会話スタート」ボタンの処理（start: 聞き取りを始める / stop: 聞き取り中にもう一度押したとき）。"""
        self._on_start_listening = start
        self._on_stop_listening = stop

    def set_play_handler(self, handler: Callable[[], None]) -> None:
        """「再生」ボタンの処理（表示中の訳文を読み上げる）。"""
        self._on_play = handler

    def set_retranslate_handler(self, handler: Callable[[], bool]) -> None:
        """「訳し直し」ボタンの処理（最後に訳した発話を、別の設定で訳し直す。受け付けたら True）。"""
        self._on_retranslate = handler

    def set_cancel_handler(self, handler: Callable[[], None]) -> None:
        """翻訳・読み上げの途中に「会話スタート」の位置のボタンを押したときの処理（やめて待機中に戻す）。"""
        self._on_cancel = handler

    def set_speech_handler(self, handler: Callable[[bool], None]) -> None:
        self._on_speech_selected = handler

    def set_back_translation_handler(self, handler: Callable[[bool], None]) -> None:
        """メニューの「翻訳の確認」（オン・オフ）が選ばれたときの処理。"""
        self._on_back_translation_selected = handler

    def set_denoise_handler(self, handler: Callable[[bool], None]) -> None:
        """音の設定の「ノイズ除去」（オン・オフ）が選ばれたときの処理。"""
        self._on_denoise_selected = handler

    def set_zh_script_handler(self, handler: Callable[[str], None]) -> None:
        """メニューで「中文（简体）」「中文（台灣）」が選ばれたときの処理（chinese.SIMPLIFIED / TRADITIONAL）。"""
        self._on_zh_script_selected = handler

    def set_speech_speed_handler(self, handler: Callable[[float], None]) -> None:
        """音の設定の「読み上げの速さ」が変えられたときの処理。"""
        self._on_speech_speed_selected = handler

    def set_voice_handler(self, handler: Callable[[str], None]) -> None:
        """音の設定の「声」（標準・女性・男性）が変えられたときの処理。"""
        self._on_voice_selected = handler

    def set_gain_handler(self, handler: Callable[[float], None]) -> None:
        self._on_gain_selected = handler

    def set_volume_handler(self, handler: Callable[[float], None]) -> None:
        self._on_volume_selected = handler

    def set_silence_handler(self, handler: Callable[[float], None]) -> None:
        """音の設定の「話し終わりの間」（秒数）が変えられたときの処理。"""
        self._on_silence_selected = handler

    def set_max_speech_handler(self, handler: Callable[[float], None]) -> None:
        """音の設定の「1回に話せる長さ」（秒数）が変えられたときの処理。"""
        self._on_max_speech_selected = handler

    def set_power_handlers(self, power_off: Callable[[], bool], reboot: Callable[[], bool]) -> None:
        """電源を切る処理と再起動する処理。どちらもできなかったときは False を返す。"""
        self._on_power_off = power_off
        self._on_reboot = reboot

    def set_bluetooth_handlers(
        self,
        scan: Callable[[], None],
        select: Callable[[BluetoothDevice], None],
        use_usb: Callable[[], None],
        open: Callable[[], None],
        close: Callable[[], None],
    ) -> None:
        self._on_bt_scan = scan
        self._on_bt_select = select
        self._on_bt_use_usb = use_usb
        self._on_bt_open = open
        self._on_bt_close = close

    def set_input_device_handlers(
        self,
        scan: Callable[[], None],
        select: Callable[[BluetoothDevice], None],
        open: Callable[[], None],
        close: Callable[[], None],
    ) -> None:
        """「マウス・キーボード」の画面の処理（scan: 探す / select: 一覧の機器をタップ / open・close: 画面の開閉）。"""
        self._on_hid_scan = scan
        self._on_hid_select = select
        self._on_hid_open = open
        self._on_hid_close = close

    def set_text_handler(self, handler: Callable[[str], bool]) -> None:
        """キーボードで打った文を送る処理（翻訳に回す。受け付けたら True）。"""
        self._on_text = handler

    def set_wifi_handlers(
        self,
        open: Callable[[], None],
        scan: Callable[[], None],
        connect: Callable[[WifiNetwork, str | None], None],
        disconnect: Callable[[], None] | None = None,
    ) -> None:
        """「Wi-Fi設定」の処理（open: 画面を開いた / scan: 探す / connect(Wi-Fi, パスワードか None): つなぐ / disconnect: すべて切る）。"""
        self._on_wifi_open = open
        self._on_wifi_scan = scan
        self._on_wifi_connect = connect
        if disconnect is not None:
            self._on_wifi_disconnect = disconnect

    def set_phrase_handlers(
        self,
        phrases: Callable[[], tuple[Phrase, ...]],
        add: Callable[[], str],
        remove: Callable[[int], None],
        use: Callable[[int], bool],
        search: Callable[[Callable[[str], None]], bool] = lambda heard: False,
        cancel_search: Callable[[], None] = lambda: None,
    ) -> None:
        """「定型文」の処理。

        phrases(): 登録してある定型文。add(): 直近に訳した文を登録し、結果を知らせる文を返す。
        remove(番号): 消す。use(番号): その定型文を通訳の画面に出して読み上げる（受け付けたら True）。
        search(heard): 音声検索を始める。次の発話を聞き取って heard(認識した文) を別のスレッドから呼ぶ
        （聞き取れなければ空の文。始められなければ False を返す）。cancel_search(): 音声検索をやめる。
        """
        self._on_phrase_list = phrases
        self._on_phrase_add = add
        self._on_phrase_remove = remove
        self._on_phrase_use = use
        self._on_phrase_search = search
        self._on_phrase_search_cancel = cancel_search

    def set_guide_handlers(
        self,
        load: Callable[[], dict[str, guide.Section]],
        play: Callable[[Path], bool],
        stop: Callable[[], None],
    ) -> None:
        """「使い方」の処理。load(): 動画・スライドの一覧（guide.read_guides）。play(動画のファイル): 再生を始める。stop(): 再生を止める。"""
        self._on_guide_load = load
        self._on_guide_play = play
        self._on_guide_stop = stop

    def set_guide_admin(
        self,
        root: Path | None,
        checker: Callable[[Path], bool] | None = None,
        upload_port: int = guide_upload.DEFAULT_PORT,
        usb: guide_admin.UsbBrowser | None = None,
        upload: guide_upload.UploadServer | None = None,
    ) -> None:
        """店舗用の「動画の追加・管理」を使えるようにする（root = guides のフォルダ。None なら出さない）。"""
        self._guide_root = Path(root) if root is not None else None
        self._guide_checker = checker or guide_admin.check_video
        if usb is not None:
            self._usb = usb
        if self._guide_root is not None:
            self._guide_upload = upload or guide_upload.UploadServer(
                self._guide_root, self._guide_progress, upload_port, self._guide_checker
            )

    def set_pin_store(self, pins: PinStore | NoPins) -> None:
        """暗証番号（pins.PinStore）をつなぐ。一般の番号は「店舗用」「音の設定」「電源・再起動」、管理者の番号は管理者の画面を開くとき聞く。"""
        self._pins = pins

    def set_system_handler(self, readings: Callable[[int], list[Reading]]) -> None:
        """管理者の画面で使う、CPU 温度と 5V 入力電圧の記録を読む処理（readings(時間): 今からその時間だけ前までの記録）。"""
        self._on_system_readings = readings

    def set_uptime_counter(self, counter: UptimeCounter) -> None:
        """管理者の画面の「稼働時間」に出す、リセットしてからの合計稼働時間。"""
        self._uptime = counter

    def set_usage_log(self, usage: UsageLog) -> None:
        """管理者の画面の「利用状況」に出す、日ごとの翻訳・訂正・定型文の数。"""
        self._usage = usage

    def set_power_saver(self, saver: PowerSaver, on_change: Callable[[bool], None]) -> None:
        """省電力モード。画面を消す・点けるのは saver が行い、オン・オフが選ばれたら on_change(オンか) を呼ぶ。"""
        self._power_saver = saver
        self._on_power_saving = on_change

    def set_clock_handlers(
        self,
        set_time: Callable[[datetime], str | None],
        set_ntp: Callable[[bool], str | None],
        get_ntp: Callable[[], bool | None],
    ) -> None:
        """時計設定の処理。set_time・set_ntp は、成功なら None、失敗なら画面に出す文を返す。"""
        self._on_clock_set, self._on_clock_ntp, self._get_clock_ntp = set_time, set_ntp, get_ntp

    def set_auto_off(self, auto_off: AutoOff, on_change: Callable[[], None]) -> None:
        """自動オフ（決めた時刻に電源を切る）。オン・オフや時刻が変わったら on_change() を呼ぶ（保存用）。"""
        self._auto_off = auto_off
        self._on_auto_off_changed = on_change

    def set_industries(self, selection: IndustrySelection, on_change: Callable[[], None]) -> None:
        """業種の選択（用語集）。「業種」の画面で選び方が変わったら、selection を直してから on_change() を呼ぶ（保存用）。"""
        self._industries = selection
        self._on_industries_changed = on_change

    def set_fix_handlers(
        self,
        items: Callable[[], tuple],
        keep: Callable[[], str],
        last: Callable[[], tuple[str, str, str, str] | None],
        save: Callable[[str, str, str, str], str],
        remove: Callable[[int], None],
        voice: Callable[[str, Callable[[str], None]], bool] | None = None,
        cancel_voice: Callable[[], None] | None = None,
    ) -> None:
        """「訂正」の処理。items: 訂正の一覧 / keep: 今の訳を覚える（結果の文を返す）/ last: 直近に訳した（言語, 文, 訳す先, 訳文）/
        save(話した言語, 文, 訳す先, 正しい訳): 打った訳を登録する（結果の文を返す）/ remove(番号): 消す。
        voice(訳す先の言語, heard): 「音声入力」。訳す先の言語で話した次の発話を 1 つ聞き取り、heard(認識した文) を別のスレッドから呼ぶ
        （聞き取れなければ空の文。始められなければ False を返す）。cancel_voice(): 聞き取りをやめる。"""
        self._fix_list, self._fix_keep, self._fix_last = items, keep, last
        self._fix_save, self._fix_remove = save, remove
        if voice is not None:
            self._fix_voice_start = voice
        if cancel_voice is not None:
            self._fix_voice_cancel = cancel_voice

    def set_study_handlers(
        self,
        speak: Callable[[str], bool],
        check: Callable[[Callable[[str], None]], bool],
        cancel: Callable[[], None],
        close: Callable[[], None],
        language: Callable[[str], None] | None = None,
    ) -> None:
        """「ハングル学習」「英語学習」の処理。language(言語): 学習する言語（KO か EN）を決めたとき。

        speak(韓国語の文): 読み上げる（始められたら True）。
        check(heard): 韓国語で話した次の発話を 1 つ聞き取り、heard(認識した文) を別のスレッドから呼ぶ
        （聞き取れなければ空の文。始められなければ False を返す）。cancel(): 聞き取りをやめる。
        close(): 学習の画面を出たとき（聞き取りのために変えた通訳の設定を元に戻す）。
        """
        self._on_study_speak = speak
        self._on_study_check = check
        self._on_study_cancel = cancel
        self._on_study_close = close
        if language is not None:
            self._on_study_language = language

    def set_idle_off(self, idle_off: IdleOff) -> None:
        """無操作オフ（操作がないまま決めた時間がたつと電源を切る）。使わないときは呼ばない。"""
        self._idle_off = idle_off

    def pump(self) -> bool:
        """たまった入力を処理し、状態が変わっていれば描き直す。終了が要求されたら False。"""
        self._handle_input(0)
        self._redraw_if_changed()
        return self._running

    def run(self) -> None:
        while self._running:
            # 入力は最大 0.1 秒待つ。描き直しは状態が変わったときだけにして、CPU を翻訳と音声合成に回す
            self._handle_input(0.1)
            self._redraw_if_changed()

    def close(self) -> None:
        self._display.close()
        pygame.quit()

    def _handle_input(self, timeout_sec: float) -> None:
        batch: InputBatch = self._display.poll(timeout_sec)
        if batch.quit:
            self._running = False
        if self._idle_off is not None and (batch.taps or batch.keys or batch.pointer_moved):
            self._idle_off.touch(time.monotonic())
            if self._idle_warning_drawn is not None:
                self._needs_redraw = True  # 「電源が切れます」の知らせを消す
        saver = self._power_saver
        if saver is not None and (batch.taps or batch.keys or batch.pointer_moved) and saver.wake():
            # 省電力モードで画面が消えていた: この操作は、画面を点けるためだけに使う（見えないボタンを押さないように）
            self._needs_redraw = True
            self._last_tap = time.monotonic()
            return
        for x, y in batch.taps:
            self._tap(x, y)
        for key in batch.keys:
            if self._key(key):
                self._needs_redraw = True
        if batch.pointer_moved:
            self._pointer_dirty = True

    def _key(self, key: KeyPress) -> bool:
        """キーボードのキー。画面が変わったら True。

        通訳の画面: スペース = 「会話スタート」（聞き取り中・処理中は中止）、Enter = 「再生」、Tab = 話す人の切り替え、
        Esc = メニュー。文字のキーを打つと入力欄が出て、Enter で送る（Esc で取り消し）。
        ほかの画面: Esc = 戻る。メニューでは Enter = 通訳の画面。
        """
        if self._page == MAIN_PAGE:
            return self._key_main(key)
        if self._page == KEYBOARD_PAGE:
            return self._key_keyboard(key)
        if self._page == GUIDE_VIEW_PAGE and self._key_guide_view(key):
            return True
        if self._page == PIN_PAGE:
            # 番号はキーボードの数字でも入れられる（Backspace で 1 文字消す）
            if key.char and key.char.isascii() and key.char.isdigit():
                self._pin_press(key.char)
                return True
            if key.name == "backspace":
                self._pin_press("back")
                return True
        if self._page == WIFI_PASSWORD_PAGE and key.name != "esc":
            # Wi-Fi のパスワード: キーボードでも打てる（Enter でつなぐ、Backspace で 1 文字消す）
            if key.name == "enter":
                self._wifi_key_action("connect")
            elif key.name == "backspace":
                self._wifi_key_action("backspace")
            elif key.char and key.char.isascii() and key.char.isprintable():
                self._wifi_key_action(key.char if key.char != " " else "space")
            else:
                return False
            return True
        if key.name == "esc" and self._page in ESCAPE_PAGES:
            self._go_back(ESCAPE_PAGES[self._page])
            return True
        if key.name == "enter" and self._page == MENU_PAGE:
            self._set_page(MAIN_PAGE)
            return True
        return False

    def _go_back(self, page: str) -> None:
        """Esc で前の画面に戻る（画面を閉じたときの処理も、ボタンで戻るときと同じように行う）。"""
        if self._page == PIN_PAGE:
            self._pin_cancel()
            return
        if self._page in (GUIDE_PAGE, GUIDE_LIST_PAGE, GUIDE_VIEW_PAGE):
            self._guide_back()
            return
        if self._page in GUIDE_ADMIN_PAGES:
            self._guide_admin_back()
            return
        if self._page == PHRASES_PAGE:
            self._stop_phrase_search()
        elif self._page == BLUETOOTH_PAGE:
            self._on_bt_close()
        elif self._page == INPUT_PAGE:
            self._on_hid_close()
            self._on_bt_open()
        self._set_page(page)

    def _key_keyboard(self, key: KeyPress) -> bool:
        """画面のキーボードの画面で、キーボードから打ったキー（Enter = 送信、Esc = 戻る、Tab = 話す人の切り替え）。"""
        lang = self._kb_lang(self._state.snapshot())
        if key.name == "esc":
            self._close_keyboard()
        elif key.name == "tab":
            if self._kb_fix is None and self._kb_phrase is None and self._kb_guide is None:
                self._swap_keyboard_speaker()
        elif not can_type(lang):
            return False
        elif key.name == "enter":
            self._send_keyboard_entry(lang)
        elif key.name == "backspace":
            self._kb_message = ""
            self._entry.backspace()
        elif key.char:
            self._kb_message = ""
            self._entry.feed(key, lang)
        else:
            return False
        return True

    def _key_main(self, key: KeyPress) -> bool:
        snap = self._state.snapshot()
        lang = snap.mode.speaker
        if self._entry.active and self._entry.lang != lang:
            self._entry.clear()  # 話す人を切り替えたので、打っていた文は消す
        if self._entry.active:
            if key.name == "enter":
                text = self._entry.take()
                if not self._on_text(text):
                    self._entry.restore(lang, text)
                    self._state.set_message(ENTRY_BUSY_MESSAGE)
            elif key.name == "esc":
                self._entry.clear()
            elif key.name == "backspace":
                self._entry.backspace()
            elif key.char:
                self._entry.feed(key, lang)
            else:
                return False
            return True
        if key.name == "space":
            return self._tap_main(*self._start_button.center)
        if key.name == "enter":
            return self._tap_main(*self._play_button.center)
        if key.name == "tab":
            return self._tap_main(*self._direction_button.center)
        if key.name == "esc":
            return self._tap_main(*self._menu_button.center)
        if key.char and snap.ready:
            if not can_type(lang):
                self._state.set_message(UNSUPPORTED_MESSAGE)
                return True
            self._state.set_message(None)
            self._entry.feed(key, lang)
            return True
        return False

    def _tap(self, x: int, y: int) -> None:
        now = time.monotonic()
        # 画面のキーボードは続けて打つので、二度押しを防ぐ間隔を短くする
        debounce = (
            KEYBOARD_DEBOUNCE_SEC if self._page in (WIFI_PASSWORD_PAGE, KEYBOARD_PAGE, PIN_PAGE) else TAP_DEBOUNCE_SEC
        )
        if now - self._last_tap < debounce:
            return
        handlers = {
            MAIN_PAGE: self._tap_main,
            MENU_PAGE: self._tap_menu,
            LANGUAGE_PAGE: self._tap_language,
            SOUND_PAGE: self._tap_sound,
            BLUETOOTH_PAGE: self._tap_bluetooth,
            INPUT_PAGE: self._tap_input,
            POWER_PAGE: self._tap_power,
            ADMIN_PAGE: self._tap_admin,
            USAGE_PAGE: self._tap_history,
            PHRASES_PAGE: self._tap_phrases,
            PHRASE_EDIT_PAGE: self._tap_phrase_edit,
            KEYBOARD_PAGE: self._tap_keyboard,
            WIFI_PAGE: self._tap_wifi,
            WIFI_PASSWORD_PAGE: self._tap_wifi_password,
            GUIDE_PAGE: self._tap_guide,
            PIN_PAGE: self._tap_pin,
            FIX_PAGE: self._tap_fix_page,
            GUIDE_LIST_PAGE: self._tap_guide_list,
            GUIDE_VIEW_PAGE: self._tap_guide_view,
            GUIDE_ADMIN_PAGE: self._tap_guide_admin,
            GUIDE_USB_PAGE: self._tap_guide_usb,
            GUIDE_DEST_PAGE: self._tap_guide_dest,
            GUIDE_UPLOAD_PAGE: self._tap_guide_upload,
            GUIDE_MANAGE_PAGE: self._tap_guide_manage,
            INDUSTRY_PAGE: self._tap_industry,
            INDUSTRY_SUB_PAGE: self._tap_industry_sub,
            STUDY_PAGE: self._tap_study,
            STUDY_LETTERS_PAGE: self._tap_study_letters,
            STUDY_PHRASE_PAGE: self._tap_study_phrases,
            STUDY_QUIZ_PAGE: self._tap_study_quiz,
            CLOCK_PAGE: self._tap_clock,
        }
        if self._page == GUIDE_VIEW_PAGE and self._state.snapshot().guide_playing:
            # 動画を再生している間は、どこをタップしても止まる（画面は動画のプログラムが使っている）
            self._on_guide_stop()
            self._last_tap = now
            return
        handler = handlers.get(self._page)  # 電源を切っている最中は、タップを受け付けない
        if handler is not None and handler(x, y):
            self._last_tap = now
            self._needs_redraw = True

    def _tap_main(self, x: int, y: int) -> bool:
        if self._start_button.collidepoint(x, y):
            snap = self._state.snapshot()
            if snap.listening_armed:
                self._on_stop_listening()
            elif snap.idle:
                self._on_start_listening()
            elif snap.ready:
                self._on_cancel()  # 翻訳・読み上げの途中: やめて待機中に戻す
            else:
                return False  # 起動中は押せない
        elif self._play_button.collidepoint(x, y):
            if not self._state.snapshot().can_play_target:
                return False  # 読み上げる訳文がない
            self._on_play()
        elif self._direction_button.collidepoint(x, y):
            self._on_mode_selected(self._state.mode.swapped())
        elif self._keyboard_button.collidepoint(x, y):
            return self._open_keyboard()
        elif self._menu_button.collidepoint(x, y):
            self._set_page(MENU_PAGE)
        elif self._retry_button is not None and self._retry_button.collidepoint(x, y):
            if not self._on_retranslate():
                return False  # まだ何も訳していないか、処理の途中
        elif self._fix_button is not None and self._fix_button.collidepoint(x, y):
            self._fix_first, self._fix_delete, self._fix_message = 0, False, ""
            self._ask_pin("fix")  # 訂正は、一般の番号を聞いてから開く
        else:
            return False
        return True

    def _tap_menu(self, x: int, y: int) -> bool:
        mode = self._state.mode
        if self._close_button.collidepoint(x, y):
            self._set_page(MAIN_PAGE)
        elif self._sound_button.collidepoint(x, y):
            self._set_page(SOUND_PAGE)  # 音の設定は、番号を聞かずに開く
        elif self._power_button.collidepoint(x, y):
            self._set_page(POWER_PAGE)  # 電源・再起動は、番号を聞かずに開く
        elif self._phrase_button.collidepoint(x, y):
            self._phrase_first, self._phrase_delete, self._phrase_message = 0, False, ""
            self._phrase_edit_mode = False
            self._phrase_filter, self._phrase_query = None, ""
            self._set_page(PHRASES_PAGE)
        elif self._wifi_button.collidepoint(x, y):
            self._ask_pin("wifi")  # Wi-Fi設定は、一般の番号を聞いてから開く
        elif self._guide_button.collidepoint(x, y):
            self._open_guide()
        elif self._industry_button.collidepoint(x, y):
            self._industry_category = None
            self._set_page(INDUSTRY_PAGE)
        elif self._clock_menu_rect.collidepoint(x, y):
            self._ask_pin("clock")  # 時計設定は、一般の番号を聞いてから開く
        elif self._language_change_button.collidepoint(x, y) or self._pair_button.collidepoint(x, y):
            # 「言語変更」ボタンで言語を選ぶ画面を開く（今の組み合わせのボタンを押しても同じ画面を開く）
            self._set_page(LANGUAGE_PAGE)
        elif (selected := self._mode_selection(x, y, mode)) is not None:
            self._on_mode_selected(selected)
        elif (enabled := self._on_off_selection(self._speech_buttons, x, y)) is not None:
            self._on_speech_selected(enabled)
        elif (enabled := self._on_off_selection(self._back_translation_buttons, x, y)) is not None:
            self._on_back_translation_selected(enabled)
        else:
            return False
        return True

    def _tap_sound(self, x: int, y: int) -> bool:
        volume, gain = self._state.output_volume, self._state.input_gain
        silence, max_speech = self._state.silence_sec, self._state.max_speech_sec
        if self._close_button.collidepoint(x, y):
            self._set_page(MENU_PAGE)
        elif self._bluetooth_button.collidepoint(x, y):
            self._on_bt_open()
            self._set_page(BLUETOOTH_PAGE)
        elif self._silence_down_button.collidepoint(x, y):
            self._on_silence_selected(step_value(SILENCE_STEPS, silence, -1))
        elif self._silence_up_button.collidepoint(x, y):
            self._on_silence_selected(step_value(SILENCE_STEPS, silence, +1))
        elif self._max_speech_down_button.collidepoint(x, y):
            self._on_max_speech_selected(step_value(MAX_SPEECH_STEPS, max_speech, -1))
        elif self._max_speech_up_button.collidepoint(x, y):
            self._on_max_speech_selected(step_value(MAX_SPEECH_STEPS, max_speech, +1))
        elif self._volume_down_button.collidepoint(x, y):
            self._on_volume_selected(step_value(VOLUME_STEPS, volume, -1))
        elif self._volume_up_button.collidepoint(x, y):
            self._on_volume_selected(step_value(VOLUME_STEPS, volume, +1))
        elif self._gain_down_button.collidepoint(x, y):
            self._on_gain_selected(step_value(GAIN_STEPS, gain, -1))
        elif self._gain_up_button.collidepoint(x, y):
            self._on_gain_selected(step_value(GAIN_STEPS, gain, +1))
        elif (enabled := self._on_off_selection(self._denoise_buttons, x, y)) is not None:
            self._on_denoise_selected(enabled)
        elif self._speed_down_button.collidepoint(x, y):
            self._on_speech_speed_selected(step_value(SPEECH_SPEED_STEPS, self._state.speech_speed, -1))
        elif self._speed_up_button.collidepoint(x, y):
            self._on_speech_speed_selected(step_value(SPEECH_SPEED_STEPS, self._state.speech_speed, +1))
        elif self._voice_button.collidepoint(x, y):
            current = self._state.voice
            index = VOICE_ORDER.index(current) if current in VOICE_ORDER else 0
            self._on_voice_selected(VOICE_ORDER[(index + 1) % len(VOICE_ORDER)])
        else:
            return False
        return True

    def _tap_bluetooth(self, x: int, y: int) -> bool:
        if self._close_button.collidepoint(x, y):
            self._on_bt_close()
            self._set_page(SOUND_PAGE)
        elif self._scan_button.collidepoint(x, y):
            self._on_bt_scan()
        elif self._usb_button.collidepoint(x, y):
            self._on_bt_use_usb()
        elif self._hid_button.collidepoint(x, y):
            self._on_bt_close()
            self._on_hid_open()
            self._set_page(INPUT_PAGE)
        else:
            for rect, device in zip(self._device_rows, self._state.snapshot().bt_devices):
                if rect.collidepoint(x, y):
                    self._on_bt_select(device)
                    return True
            return False
        return True

    def _tap_input(self, x: int, y: int) -> bool:
        """「マウス・キーボード」の画面。"""
        if self._close_button.collidepoint(x, y):
            self._go_back(BLUETOOTH_PAGE)
        elif self._scan_button.collidepoint(x, y):
            self._on_hid_scan()
        else:
            for rect, device in zip(self._device_rows, self._state.snapshot().hid_devices):
                if rect.collidepoint(x, y):
                    self._on_hid_select(device)
                    return True
            return False
        return True

    def _tap_wifi(self, x: int, y: int) -> bool:
        """Wi-Fi の画面。一覧の Wi-Fi をタップすると、つなぐ（パスワードが要って保存されていなければ、パスワードの画面へ）。"""
        snap = self._state.snapshot()
        networks = snap.wifi_networks
        if self._close_button.collidepoint(x, y):
            self._set_page(MENU_PAGE)
        elif self._scan_button.collidepoint(x, y):
            if snap.wifi_busy:
                return False
            self._wifi_first = 0
            self._on_wifi_scan()
        elif self._wifi_disconnect_button.collidepoint(x, y):
            return self._tap_wifi_disconnect(snap)
        elif self._wifi_first > 0 and self._power_button.collidepoint(x, y):
            self._wifi_first = max(0, self._wifi_first - WIFI_ROWS)  # 「前へ」
        elif self._wifi_first + WIFI_ROWS < len(networks) and self._sound_button.collidepoint(x, y):
            self._wifi_first += WIFI_ROWS  # 「次へ」
        else:
            shown = networks[self._wifi_first : self._wifi_first + WIFI_ROWS]
            for rect, network in zip(self._wifi_rows, shown):
                if not rect.collidepoint(x, y):
                    continue
                if snap.wifi_busy or network.in_use:
                    return False  # 操作の途中か、もうつないでいる
                if network.secure and not network.known:
                    self._open_wifi_password(network)
                else:
                    self._on_wifi_connect(network, None)
                return True
            return False
        return True

    def _tap_wifi_disconnect(self, snap: Snapshot) -> bool:
        """「切断」: 1 回目は確かめの表示（つながっている Wi-Fi が無いときや、処理の途中は何もしない）。5 秒以内にもう一度で、すべて切る。"""
        if snap.wifi_busy or not snap.wifi_current:
            return False
        now = time.monotonic()
        if now - self._wifi_disconnect_armed_at <= ADMIN_CONFIRM_SEC:
            self._wifi_disconnect_armed_at = -math.inf
            self._on_wifi_disconnect()
        else:
            self._wifi_disconnect_armed_at = now
        return True

    def _open_wifi_password(self, network: WifiNetwork) -> None:
        self._wifi_target = network
        self._wifi_password = ""
        self._wifi_show = self._wifi_shift = self._wifi_symbols = False
        self._set_page(WIFI_PASSWORD_PAGE)

    def _wifi_keys(self) -> list[tuple[pygame.Rect, str, str]]:
        """画面のキーボードのキー（場所, 表示する文字, 押したときの動き）。動きは 1 文字なら、その文字を打つ。"""
        inner = self._width - 2 * MARGIN
        unit = (inner - 9 * WIFI_KEY_GAP) / 10  # 10 個並ぶキーの幅
        rows = WIFI_SYMBOL_ROWS if self._wifi_symbols else WIFI_KEY_ROWS
        keys: list[tuple[pygame.Rect, str, str]] = []

        def top(row: int) -> int:
            return WIFI_KEY_TOP + row * (WIFI_KEY_HEIGHT + WIFI_KEY_GAP)

        def add(left: float, row: int, width: float, label: str, action: str) -> float:
            keys.append((pygame.Rect(round(left), top(row), round(width), WIFI_KEY_HEIGHT), label, action))
            return left + width + WIFI_KEY_GAP

        for row, chars in enumerate(rows[:3]):
            # 10 個より少ない段は、真ん中にそろえる
            left = MARGIN + (10 - len(chars)) * (unit + WIFI_KEY_GAP) / 2
            for ch in chars:
                ch = ch.upper() if self._wifi_shift and not self._wifi_symbols else ch
                left = add(left, row, unit, ch, ch)
        # 4 段目: 大文字（記号のときは使わない）、7 文字、1 文字消す
        wide = (inner - 7 * (unit + WIFI_KEY_GAP) - WIFI_KEY_GAP) / 2
        left = add(MARGIN, 3, wide, "ABC" if not self._wifi_shift else "abc", "shift")
        for ch in rows[3]:
            ch = ch.upper() if self._wifi_shift and not self._wifi_symbols else ch
            left = add(left, 3, unit, ch, ch)
        add(left, 3, MARGIN + inner - left, "削除 Del", "backspace")
        # 5 段目: 記号の切り替え、空白、文字を見せる、やめる、つなぐ
        spans = (("#+=" if not self._wifi_symbols else "abc", "symbols", 1.5), ("空白 Space", "space", 3.0),
                 ("表示 Show" if not self._wifi_show else "隠す Hide", "show", 1.8),
                 ("キャンセル", "cancel", 1.7), ("接続 Connect", "connect", 2.0))
        total = sum(weight for _, _, weight in spans)
        free = inner - (len(spans) - 1) * WIFI_KEY_GAP
        left = MARGIN
        for label, action, weight in spans:
            left = add(left, 4, free * weight / total, label, action)
        return keys

    def _tap_wifi_password(self, x: int, y: int) -> bool:
        for rect, _, action in self._wifi_keys():
            if rect.collidepoint(x, y):
                self._wifi_key_action(action)
                return True
        return False

    def _wifi_key_action(self, action: str) -> None:
        """画面のキーボード（とキーボード）で押されたキーの動き。"""
        if action == "shift":
            self._wifi_shift = not self._wifi_shift
        elif action == "symbols":
            self._wifi_symbols = not self._wifi_symbols
        elif action == "backspace":
            self._wifi_password = self._wifi_password[:-1]
        elif action == "space":
            self._wifi_password += " "
        elif action == "show":
            self._wifi_show = not self._wifi_show
        elif action == "cancel":
            self._set_page(WIFI_PAGE)
        elif action == "connect":
            # WPA のパスワードは 8〜63 文字（短すぎるときは、つながないで入れ直してもらう）
            if self._wifi_target is not None and 8 <= len(self._wifi_password) <= 63:
                self._on_wifi_connect(self._wifi_target, self._wifi_password)
                self._wifi_password = ""
                self._set_page(WIFI_PAGE)
        elif len(action) == 1 and len(self._wifi_password) < 63:
            self._wifi_password += action

    def _open_keyboard(self) -> bool:
        """通訳の画面の「文字入力」: 画面のキーボードを開く（起動が終わるまでは開かない）。"""
        if not self._state.snapshot().ready:
            return False
        self._kb_shift = self._kb_symbols = False
        self._kb_message = ""
        self._set_page(KEYBOARD_PAGE)
        return True

    def _close_keyboard(self) -> None:
        """通訳の画面に戻る（打っていた文は、通訳の画面の入力欄に残る）。訂正の入力中は、訂正の画面に戻る。"""
        if self._kb_phrase is not None:
            self._kb_phrase = None
            self._entry.clear()
            self._set_page(PHRASE_EDIT_PAGE)  # 定型文の修正の画面に戻る（直さずに戻る）
            return
        if self._kb_fix is not None:
            self._kb_fix = None
            self._entry.clear()
            self._set_page(FIX_PAGE)
            return
        if self._kb_guide is not None:
            self._kb_guide = None
            self._entry.clear()
            self._set_page(GUIDE_MANAGE_PAGE)  # 名前を変えずに、入れた動画の一覧に戻る
            return
        self._set_page(MAIN_PAGE)

    def _swap_keyboard_speaker(self) -> None:
        """話す人（打つ言語）を入れ替える。別の言語になったら、打っていた文は使わない。"""
        self._kb_message = ""
        self._kb_shift = self._kb_symbols = False
        self._on_mode_selected(self._state.mode.swapped())

    def _kb_entry_text(self, lang: str) -> str:
        """入力欄に出す文（話す人が替わったあとの古い文は出さない）。"""
        return self._entry.display if self._entry.lang == lang else ""

    def _send_keyboard_entry(self, lang: str) -> None:
        """打った文を、話した言葉と同じように訳して、通訳の画面に戻る。送れなければ、文を残して知らせる。"""
        if not self._kb_entry_text(lang):
            return
        if self._kb_phrase is not None:
            field = self._kb_phrase[0]
            self._save_phrase_edit(field, lang, self._entry.take())
            return
        if self._kb_guide is not None:
            path, self._kb_guide = self._kb_guide, None
            self._rename_guide_video(path, self._entry.take())
            return
        if self._kb_fix is not None:
            # 訂正の入力: 打った訳を、その文の訳として登録する（翻訳はしない）
            source, source_text, target = self._kb_fix
            translation = self._entry.take()
            self._fix_message = self._fix_save(source, source_text, target, translation)
            self._kb_fix = None
            self._fix_first = 0
            self._set_page(FIX_PAGE)
            return
        text = self._entry.take()
        if self._on_text(text):
            self._set_page(MAIN_PAGE)
        else:
            self._entry.restore(lang, text)
            self._kb_message = KB_BUSY_MESSAGE

    def _kb_keys(self, lang: str) -> list[tuple[pygame.Rect, skb.Key]]:
        """画面のキーボードのキー（場所, キー）。文字の段は文字のキーの幅で真ん中にそろえ、下の段などは幅いっぱいに並べる。"""
        inner = self._width - 2 * MARGIN
        unit = (inner - (skb.columns(lang, self._kb_symbols) - 1) * KB_KEY_GAP) / skb.columns(lang, self._kb_symbols)
        keys: list[tuple[pygame.Rect, skb.Key]] = []
        for index, row in enumerate(skb.layout(lang, self._kb_shift, self._kb_symbols)):
            top = KB_KEY_TOP + index * (KB_KEY_HEIGHT + KB_KEY_GAP)
            gaps = (len(row.keys) - 1) * KB_KEY_GAP
            if row.fill:
                per_weight = (inner - gaps) / sum(key.weight for key in row.keys)
                left = float(MARGIN)
            else:
                per_weight = unit
                left = MARGIN + (inner - (sum(key.weight for key in row.keys) * unit + gaps)) / 2
            for key in row.keys:
                width = per_weight * key.weight
                keys.append((pygame.Rect(round(left), top, round(width), KB_KEY_HEIGHT), key))
                left += width + KB_KEY_GAP
        return keys

    def _tap_keyboard(self, x: int, y: int) -> bool:
        """画面のキーボードの画面。話す人の切り替え・「消去」・キー。"""
        lang = self._kb_lang(self._state.snapshot())
        if self._kb_swap_button.collidepoint(x, y):
            if self._kb_fix is None and self._kb_phrase is None and self._kb_guide is None:
                self._swap_keyboard_speaker()
            return True
        if not can_type(lang):
            # 中国語・広東語は打てない: 「戻る」だけ使える（話す人は切り替えられる）
            if self._close_button.collidepoint(x, y):
                self._close_keyboard()
                return True
            return False
        if self._kb_clear_button.collidepoint(x, y):
            self._kb_message = ""
            self._entry.clear()
            return True
        for rect, key in self._kb_keys(lang):
            if rect.collidepoint(x, y):
                self._press_keyboard_key(key, lang)
                return True
        return False

    def _press_keyboard_key(self, key: skb.Key, lang: str) -> None:
        self._kb_message = ""
        if key.action == skb.KEY:
            self._entry.feed(key.press, lang)
            self._kb_shift = False  # Shift は次の 1 文字だけ
        elif key.action == skb.SHIFT:
            self._kb_shift = not self._kb_shift
        elif key.action == skb.SYMBOLS:
            self._kb_symbols, self._kb_shift = not self._kb_symbols, False
        elif key.action == skb.BACKSPACE:
            if self._entry.lang == lang:
                self._entry.backspace()
        elif key.action == skb.SEND:
            self._send_keyboard_entry(lang)
        elif key.action == skb.CLOSE:
            self._close_keyboard()

    def _open_guide(self) -> None:
        """「使い方」を開く（動画・スライドの一覧は、開くたびに読み直す。あとから足したファイルもすぐ出る）。"""
        self._guides = self._on_guide_load()
        self._guide_audience, self._guide_category, self._guide_first, self._guide_item = "", None, 0, None
        self._set_page(GUIDE_PAGE)

    def _guide_entries(self) -> list[tuple[str, guide.Category | guide.Item]]:
        """今の一覧の行: ("category", 分類) か ("item", 動画・スライド)。分類を選んでいなければ、分類が先で、そのあとに直接置かれた項目。"""
        section = self._guides.get(self._guide_audience)
        if section is None:
            return []
        if self._guide_category is not None:
            return [("item", item) for item in self._guide_category.items]
        return [("category", category) for category in section.categories] + [("item", item) for item in section.items]

    def _guide_back(self) -> None:
        """「使い方」の中で一つ前に戻る（スライド・動画 → 一覧 → 分類の一覧 → お客様用 / 店舗用の選択 → メニュー）。"""
        if self._page == GUIDE_VIEW_PAGE:
            if self._state.snapshot().guide_playing:
                self._on_guide_stop()
            self._guide_item = None
            self._set_page(GUIDE_LIST_PAGE)
        elif self._page == GUIDE_LIST_PAGE:
            self._guide_first = 0
            if self._guide_category is not None:
                self._guide_category = None  # 分類の一覧に戻る
            else:
                self._guide_audience = ""
                self._set_page(GUIDE_PAGE)
        elif self._page == GUIDE_PAGE:
            self._set_page(MENU_PAGE)

    def _tap_guide(self, x: int, y: int) -> bool:
        """お客様用 / 店舗用を選ぶ画面。"""
        if self._close_button.collidepoint(x, y):
            self._guide_back()
            return True
        for audience, rect in self._guide_audience_buttons.items():
            if rect.collidepoint(x, y):
                if audience == guide.STORE:
                    self._ask_pin("store")  # 店舗用は、一般の番号を聞いてから開く
                else:
                    self._open_guide_audience(audience)
                return True
        for lang, rect in ((KO, self._study_button), (EN, self._study_en_button), (ZH, self._study_zh_button)):
            if rect.collidepoint(x, y):
                self._open_study(lang)
                return True
        return False

    def _open_guide_audience(self, audience: str) -> None:
        self._guide_audience, self._guide_category, self._guide_first = audience, None, 0
        self._set_page(GUIDE_LIST_PAGE)

    # --- 暗証番号 ---

    def _ask_pin(self, kind: str) -> None:
        """kind（PIN_TASKS）の番号の画面を出す。番号を聞かない設定のときは、聞かずにそのまま先へ進む。"""
        task = PIN_TASKS[kind]
        if not task.setting:
            required = self._pins.admin_required() if task.group == ADMIN else self._pins.general_required()
            if not required:
                self._pin_done(kind)
                return
        self._pin_kind, self._pin_step, self._pin_first = kind, 1, ""
        self._pin_entry, self._pin_message = "", ""
        self._set_page(PIN_PAGE)

    def _pin_done(self, kind: str) -> None:
        """番号が合ったので、先へ進む。"""
        if kind == "store":
            self._open_guide_audience(guide.STORE)
        elif kind == "sound":
            self._set_page(SOUND_PAGE)
        elif kind == "power":
            self._set_page(POWER_PAGE)
        elif kind == "admin":
            self._open_admin()
        elif kind == "usage":
            self._set_page(USAGE_PAGE)
        elif kind == "clock":
            self._open_clock()
        elif kind == "wifi":
            self._open_wifi()
        elif kind == "fix":
            self._fix_first, self._fix_delete = 0, False
            self._set_page(FIX_PAGE)

    def _open_admin(self) -> None:
        """管理者の画面を開く（開くたびに、記録を読み直す）。"""
        self._admin_range = ADMIN_DEFAULT_RANGE
        self._admin_loaded_at = -math.inf  # まだ読んでいない（time.monotonic() が小さい環境でも、最初に必ず読む）
        self._reset_armed_at = -math.inf
        self._admin_message = ""
        self._set_page(ADMIN_PAGE)

    def _pin_cancel(self) -> None:
        """番号の画面から戻る（入れかけの番号は残さない）。"""
        task = PIN_TASKS.get(self._pin_kind)
        self._pin_entry, self._pin_first, self._pin_message = "", "", ""
        self._set_page(task.back if task else MENU_PAGE)

    def _tap_pin(self, x: int, y: int) -> bool:
        """番号を入れる画面。"""
        if self._pin_back_button.collidepoint(x, y):
            self._pin_cancel()
            return True
        for name, rect in self._pin_keys.items():
            if rect.collidepoint(x, y):
                self._pin_press(name)
                return True
        return False

    def _pin_press(self, name: str) -> None:
        """番号のキー（"0"〜"9"、"clear" = 全部消す、"back" = 1 文字消す）。4 桁入ったら、合っているか確かめる（新しい番号を決めるときは、集める）。"""
        task = PIN_TASKS[self._pin_kind]
        now = time.monotonic()
        if not task.setting and now < self._pin_locked_until[task.group]:
            wait = math.ceil(self._pin_locked_until[task.group] - now)
            self._pin_entry, self._pin_message = "", f"しばらくお待ちください（あと {wait} 秒）/ Please wait ({wait}s)"
            return
        self._pin_message = ""
        if name == "clear":
            self._pin_entry = ""
        elif name == "back":
            self._pin_entry = self._pin_entry[:-1]
        elif len(self._pin_entry) < PIN_LENGTH:
            self._pin_entry += name
        if len(self._pin_entry) < PIN_LENGTH:
            return
        entered, self._pin_entry = self._pin_entry, ""
        if task.setting:
            self._pin_collect(task, entered)
            return
        group = task.group
        if self._pins.verify_admin(entered) if group == ADMIN else self._pins.verify_general(entered):
            self._pin_failures[group] = 0
            self._pin_done(self._pin_kind)
            return
        self._pin_failures[group] += 1
        if self._pin_failures[group] >= PIN_MAX_TRIES:
            self._pin_failures[group] = 0
            self._pin_locked_until[group] = now + PIN_LOCK_SEC
            self._pin_message = f"{PIN_MAX_TRIES} 回間違えました。{PIN_LOCK_SEC:g} 秒お待ちください / Locked for {PIN_LOCK_SEC:g}s"
        else:
            self._pin_message = PIN_WRONG

    def _pin_collect(self, task: PinTask, entered: str) -> None:
        """新しい番号を決める: 1 回目を覚え、2 回目が同じなら保存する。"""
        if self._pin_step == 1:
            self._pin_first, self._pin_step = entered, 2
            return
        first, self._pin_first, self._pin_step = self._pin_first, "", 1
        if entered != first:
            self._pin_message = PIN_MISMATCH
            return
        error = self._pins.set_admin(entered) if task.group == ADMIN else self._pins.set_general(entered)
        if error:
            self._pin_message = error
            return
        self._admin_message = PIN_CHANGED
        self._admin_range = ADMIN_PIN_VIEW
        self._set_page(ADMIN_PAGE)
    def _tap_guide_list(self, x: int, y: int) -> bool:
        """分類・動画・スライドの一覧。分類をタップするとその中の一覧、動画・スライドをタップすると開く。"""
        entries = self._guide_entries()
        if self._close_button.collidepoint(x, y):
            self._guide_back()
        elif self._guide_admin_shown() and self._guide_admin_button.collidepoint(x, y):
            self._open_guide_admin()
        elif self._guide_first > 0 and self._power_button.collidepoint(x, y):
            self._guide_first = max(0, self._guide_first - LIST_ROWS)  # 「前へ」
        elif self._guide_first + LIST_ROWS < len(entries) and self._sound_button.collidepoint(x, y):
            self._guide_first += LIST_ROWS  # 「次へ」
        else:
            shown = entries[self._guide_first : self._guide_first + LIST_ROWS]
            for rect, (kind, entry) in zip(self._list_rows, shown):
                if not rect.collidepoint(x, y):
                    continue
                if kind == "category":
                    self._guide_category, self._guide_first = entry, 0
                else:
                    self._open_guide_item(entry)
                return True
            return False
        return True

    def _open_guide_item(self, item: guide.Item) -> None:
        self._guide_item, self._guide_slide, self._guide_image = item, 0, None
        self._guide_was_started = False
        self._set_page(GUIDE_VIEW_PAGE)
        if item.kind == guide.VIDEO:
            self._play_guide_video(item)

    def _play_guide_video(self, item: guide.Item) -> None:
        """動画を再生する（失敗は、画面の状態の guide_error に出る）。"""
        self._guide_was_started = True
        self._on_guide_play(item.path)

    def _tap_guide_view(self, x: int, y: int) -> bool:
        item = self._guide_item
        if item is None or self._close_button.collidepoint(x, y):
            self._guide_back()
        elif item.kind == guide.VIDEO:
            if not self._guide_play_button.collidepoint(x, y):
                return False
            self._play_guide_video(item)  # 「もう一度再生」
        elif self._guide_slide > 0 and self._power_button.collidepoint(x, y):
            self._guide_slide -= 1
        elif self._guide_slide + 1 < item.page_count and self._sound_button.collidepoint(x, y):
            self._guide_slide += 1
        elif self._guide_image_area.collidepoint(x, y):
            back = x < self._guide_image_area.width * GUIDE_SLIDE_BACK_RATIO
            self._guide_slide = max(0, self._guide_slide - 1) if back else min(item.page_count - 1, self._guide_slide + 1)
        else:
            return False
        return True

    def _key_guide_view(self, key: KeyPress) -> bool:
        """スライド・動画の画面でのキーボード（→・Space・Enter = 次へ、← = 前へ。再生中はどのキーでも止まる）。"""
        if self._state.snapshot().guide_playing:
            self._on_guide_stop()
            return True
        item = self._guide_item
        if item is None:
            return False
        if item.kind == guide.VIDEO:
            if key.name in ("enter", "space"):
                self._play_guide_video(item)
                return True
            return False
        if key.name in ("right", "pagedown", "space", "enter"):
            self._guide_slide = min(item.page_count - 1, self._guide_slide + 1)
        elif key.name in ("left", "pageup", "backspace"):
            self._guide_slide = max(0, self._guide_slide - 1)
        else:
            return False
        return True

    # --- 店舗用の「動画の追加・管理」（USB メモリから・スマホから・入れた動画の名前の変更と削除） ---

    def _guide_admin_shown(self) -> bool:
        """店舗用の一覧（分類を選ぶ前）で、「動画の追加・管理」ボタンを出すか。"""
        return self._guide_root is not None and self._guide_audience == guide.STORE and self._guide_category is None

    def _guide_admin_versions(self) -> tuple[int, int]:
        return self._guide_progress.snapshot()[0], self._usb.snapshot()[0]

    def _guide_busy(self) -> bool:
        return self._guide_progress.snapshot()[1]

    def _open_guide_admin(self) -> None:
        self._guide_progress.clear()
        self._guide_note = ""
        self._set_page(GUIDE_ADMIN_PAGE)

    def _guide_admin_back(self) -> None:
        """「動画の追加・管理」の中で一つ前に戻る（入れている最中は戻らない）。"""
        page = self._page
        if page in (GUIDE_DEST_PAGE, GUIDE_UPLOAD_PAGE) and self._guide_busy():
            self._guide_note = GUIDE_WAIT_COPY
            self._needs_redraw = True
            return
        self._guide_note = ""
        if page == GUIDE_ADMIN_PAGE:
            self._guides = self._on_guide_load()  # 入れた・消した動画を、店舗用の一覧に出す
            self._guide_first = 0
            self._set_page(GUIDE_LIST_PAGE)
        elif page == GUIDE_USB_PAGE:
            self._usb.release()  # この画面でつないだ USB メモリを外す（抜いても大丈夫にする）
            self._set_page(GUIDE_ADMIN_PAGE)
        elif page == GUIDE_DEST_PAGE:
            self._guide_usb_pick = None
            self._guide_progress.clear()
            self._set_page(GUIDE_USB_PAGE)
        elif page == GUIDE_UPLOAD_PAGE:
            if self._guide_upload is not None:
                self._guide_upload.stop()
            self._guide_progress.clear()
            self._set_page(GUIDE_ADMIN_PAGE)
        elif page == GUIDE_MANAGE_PAGE:
            self._guide_manage_mode, self._guide_manage_armed = "", None
            self._set_page(GUIDE_ADMIN_PAGE)

    def _tap_guide_admin(self, x: int, y: int) -> bool:
        """入れ方を選ぶ画面: USB メモリから / スマホから / 入れた動画。"""
        if self._close_button.collidepoint(x, y):
            self._guide_admin_back()
            return True
        usb, phone, manage = self._guide_admin_tiles
        if usb.collidepoint(x, y):
            self._guide_admin_first, self._guide_note = 0, ""
            self._guide_progress.clear()
            self._usb.refresh()
            self._set_page(GUIDE_USB_PAGE)
        elif phone.collidepoint(x, y):
            self._open_guide_upload()
        elif manage.collidepoint(x, y):
            self._open_guide_manage()
        else:
            return False
        return True

    def _draw_guide_admin(self, snap: Snapshot) -> None:
        self._surface.fill(MENU_BACKGROUND)
        self._drawn_guide_admin = self._guide_admin_versions()
        self._draw_title_icon(icons.SHOP)
        self._draw_fitted_label("動画の追加・管理 / Add & manage videos", MARGIN + TITLE_ICON_SHIFT, MENU_TITLE_Y - 2, TITLE_SIZES, TEXT_COLOR)
        self._draw_label("パソコンなしで、ガイドの動画を入れられます / Add guide videos without a PC", MARGIN, 56, 18, SUBTEXT_COLOR)
        count = len(guide_admin.list_videos(self._guide_root)) if self._guide_root is not None else 0
        tiles = (
            (icons.FOLDER, "USB メモリから", "From a USB stick", "USB メモリを差してから / Insert it first"),
            (icons.WIFI, "スマホから", "From a phone", "同じ Wi-Fi で、QR コード / Same Wi-Fi, QR code"),
            (icons.PLAY, "入れた動画", "Manage videos", f"名前の変更・削除（{count} 件）/ Rename, delete"),
        )
        for rect, color, (icon, label, label_en, note) in zip(self._guide_admin_tiles, GUIDE_ADMIN_TILE_COLORS, tiles):
            pygame.draw.rect(self._surface, color, rect, border_radius=14)
            self._draw_icon(icon, (rect.centerx, rect.top + 66), 72)
            self._blit_centered_at(label, rect, 30, 0.57)
            self._blit_centered_at(label_en, rect, 19, 0.72)
            note_rect = pygame.Rect(rect.left + 10, rect.top + int(rect.height * 0.8), rect.width - 20, rect.height // 5)
            self._draw_text(note, self._fonts[JA], note_rect, (15, 13, 12), SUBTEXT_COLOR)
        self._draw_two_line_button(self._close_button, "戻る", "Back", BUTTON_COLOR)

    # USB メモリ

    def _tap_guide_usb(self, x: int, y: int) -> bool:
        """USB メモリの動画の一覧。動画をタップすると、入れる場所を選ぶ画面。"""
        _version, busy, videos, _message = self._usb.snapshot()
        if self._close_button.collidepoint(x, y):
            self._guide_admin_back()
        elif self._guide_admin_button.collidepoint(x, y):
            if not busy:
                self._guide_admin_first = 0
                self._usb.refresh()  # 「読み直す」
        elif self._guide_admin_first > 0 and self._power_button.collidepoint(x, y):
            self._guide_admin_first = max(0, self._guide_admin_first - LIST_ROWS)
        elif self._guide_admin_first + LIST_ROWS < len(videos) and self._sound_button.collidepoint(x, y):
            self._guide_admin_first += LIST_ROWS
        else:
            shown = videos[self._guide_admin_first : self._guide_admin_first + LIST_ROWS]
            for rect, video in zip(self._list_rows, shown):
                if rect.collidepoint(x, y):
                    self._guide_usb_pick = video
                    self._guide_progress.clear()
                    self._guide_note = ""
                    self._set_page(GUIDE_DEST_PAGE)
                    return True
            return False
        return True

    @staticmethod
    def _size_text(size: int) -> str:
        return f"{size / 1024**3:.1f} GB" if size >= 1024**3 else f"{max(1, round(size / 1024**2))} MB"

    def _draw_guide_rows(self, rows: list[tuple[str, str, tuple[int, int, int]]]) -> None:
        """一覧の行（題名, 右に出す小さな文字, 色）。長い題名は、はみ出す部分を描かない。"""
        font = self._fonts[JA]
        for rect, (name, note, color) in zip(self._list_rows, rows):
            pygame.draw.rect(self._surface, color, rect, border_radius=10)
            self._draw_icon(icons.PLAY, (rect.left + 14 + 15, rect.centery), 30)
            right = rect.right - 16
            note_surface, _ = font.render(note, SUBTEXT_COLOR, size=17)
            self._surface.blit(note_surface, note_surface.get_rect(midright=(right, rect.centery)))
            left = rect.left + 14 + 30 + 14
            width = right - note_surface.get_width() - 14 - left
            size = next((s for s in GUIDE_ROW_SIZES if font.get_rect(name, size=s).width <= width), GUIDE_ROW_SIZES[-1])
            text, _ = font.render(name, TEXT_COLOR, size=size)
            self._surface.set_clip(pygame.Rect(left, rect.top, width, rect.height))
            self._surface.blit(text, text.get_rect(midleft=(left, rect.centery)))
            self._surface.set_clip(None)

    def _draw_paging(self, first: int, total: int) -> None:
        if first > 0:
            self._draw_two_line_button(self._power_button, "◀ 前へ", "Previous", BUTTON_COLOR, title_size=22)
        if first + LIST_ROWS < total:
            self._draw_two_line_button(self._sound_button, "次へ ▶", "Next", BUTTON_COLOR, title_size=22)

    def _draw_guide_usb(self, snap: Snapshot) -> None:
        self._surface.fill(MENU_BACKGROUND)
        self._drawn_guide_admin = self._guide_admin_versions()
        _version, busy, videos, message = self._usb.snapshot()
        self._draw_title_icon(icons.FOLDER)
        title = f"USB メモリの動画（{len(videos)} 件）タップで入れる / Tap to add" if videos else "USB メモリから入れる / From a USB stick"
        self._draw_fitted_label(title, MARGIN + TITLE_ICON_SHIFT, MENU_TITLE_Y - 2, TITLE_SIZES, TEXT_COLOR)
        if message and (busy or not videos):
            rect = pygame.Rect(MARGIN, LIST_ROW_TOP + 30, self._width - 2 * MARGIN, 200)
            self._draw_text(message, self._fonts[JA], rect, (24, 20, 17), SUBTEXT_COLOR if busy else BLINK_BRIGHT_COLOR)
        shown = videos[self._guide_admin_first : self._guide_admin_first + LIST_ROWS]
        self._draw_guide_rows([(video.relative, f"{video.volume}  {self._size_text(video.size)}", BUTTON_COLOR) for video in shown])
        self._draw_paging(self._guide_admin_first, len(videos))
        self._draw_two_line_button(
            self._guide_admin_button, "読み直す", "Reload", BUTTON_COLOR if not busy else DISABLED_BUTTON_COLOR, title_size=22
        )
        self._draw_two_line_button(self._close_button, "戻る", "Back", BUTTON_COLOR)

    # 入れる場所

    def _tap_guide_dest(self, x: int, y: int) -> bool:
        """入れる場所を選ぶ画面。場所を押すと、コピーを始める（終わるまで、ほかは押せない）。"""
        if self._close_button.collidepoint(x, y):
            self._guide_admin_back()
            return True
        video = self._guide_usb_pick
        for rect, destination in zip(self._guide_dest_buttons, guide_admin.DESTINATIONS):
            if rect.collidepoint(x, y):
                if video is not None and self._guide_root is not None:
                    self._start_guide_import(video, destination)
                return True
        return False

    def _start_guide_import(self, video: guide_admin.UsbVideo, destination: guide_admin.Destination) -> None:
        if not self._guide_progress.start("コピーしています… / Copying…"):
            return  # 入れている最中
        self._guide_note = ""
        root, checker = self._guide_root, self._guide_checker
        title = guide_admin.title_from_filename(video.path.name)

        def run() -> None:
            guide_admin.import_file(video.path, root, destination, title, self._guide_progress, checker)

        threading.Thread(target=run, name="guide-import", daemon=True).start()

    def _draw_guide_progress(self, top: int) -> None:
        """入れている途中の進み具合（棒）と、結果の知らせ。"""
        _version, busy, fraction, message, error = self._guide_progress.snapshot()
        font = self._fonts[JA]
        width = self._width - 2 * MARGIN
        if busy:
            bar = pygame.Rect(MARGIN, top, width, 22)
            pygame.draw.rect(self._surface, BUTTON_COLOR, bar, border_radius=8)
            done = bar.copy()
            done.width = max(0, round(bar.width * (fraction or 0.0)))
            if done.width:
                pygame.draw.rect(self._surface, START_COLOR, done, border_radius=8)
            percent = f"  {round((fraction or 0.0) * 100)}%" if fraction is not None else ""
            self._draw_text(message + percent, font, pygame.Rect(MARGIN, top + 30, width, 40), (20, 17), TEXT_COLOR)
        elif message:
            self._draw_text(message, font, pygame.Rect(MARGIN, top, width, 60), (22, 19, 16), BLINK_BRIGHT_COLOR if error else GUIDE_OK_COLOR)
        if self._guide_note:
            self._draw_text(self._guide_note, font, pygame.Rect(MARGIN, top + 62, width, 30), (18, 16), BLINK_BRIGHT_COLOR)

    def _draw_guide_dest(self, snap: Snapshot) -> None:
        self._surface.fill(MENU_BACKGROUND)
        self._drawn_guide_admin = self._guide_admin_versions()
        self._draw_title_icon(icons.FOLDER)
        self._draw_fitted_label("入れる場所を選ぶ / Choose where to add", MARGIN + TITLE_ICON_SHIFT, MENU_TITLE_Y - 2, TITLE_SIZES, TEXT_COLOR)
        video = self._guide_usb_pick
        if video is not None:
            self._draw_fitted_label(
                f"動画: {video.relative}（{self._size_text(video.size)}）", MARGIN, 58, (18, 16, 14, 12), SUBTEXT_COLOR
            )
        busy = self._guide_busy()
        for rect, destination in zip(self._guide_dest_buttons, guide_admin.DESTINATIONS):
            color = GUIDE_AUDIENCE_COLORS[destination.audience] if not busy else DISABLED_BUTTON_COLOR
            pygame.draw.rect(self._surface, color, rect, border_radius=12)
            self._blit_centered_at(destination.label, rect, 28, 0.42)
            self._blit_centered_at(destination.label_en, rect, 17, 0.75)
        last = self._guide_dest_buttons[-1]
        self._draw_guide_progress(last.bottom + 16)
        self._draw_two_line_button(self._close_button, "戻る", "Back", BUTTON_COLOR if not busy else DISABLED_BUTTON_COLOR)

    # スマホから

    def _open_guide_upload(self) -> None:
        self._guide_progress.clear()
        self._guide_note = ""
        self._guide_qr = None
        if self._guide_upload is not None:
            self._guide_upload.start()
        self._set_page(GUIDE_UPLOAD_PAGE)

    def _tap_guide_upload(self, x: int, y: int) -> bool:
        if self._close_button.collidepoint(x, y):
            self._guide_admin_back()
            return True
        return False

    def _guide_qr_surface(self, url: str, size: int) -> pygame.Surface | None:
        """URL の QR コード（白い余白つき。segno が無ければ None）。同じ URL は描き直さない。"""
        if self._guide_qr is not None and self._guide_qr[0] == url:
            return self._guide_qr[1]
        matrix = guide_upload.qr_matrix(url)
        surface = None
        if matrix:
            modules = len(matrix) + 8  # まわりに 4 マスずつの白い余白
            cell = max(1, size // modules)
            surface = pygame.Surface((cell * modules, cell * modules))
            surface.fill((255, 255, 255))
            for row, cells in enumerate(matrix):
                for col, dark in enumerate(cells):
                    if dark:
                        surface.fill((0, 0, 0), pygame.Rect((col + 4) * cell, (row + 4) * cell, cell, cell))
        self._guide_qr = (url, surface)
        return surface

    def _draw_guide_upload(self, snap: Snapshot) -> None:
        self._surface.fill(MENU_BACKGROUND)
        self._drawn_guide_admin = self._guide_admin_versions()
        self._draw_title_icon(icons.WIFI)
        self._draw_fitted_label("スマホから送る / Send from a phone", MARGIN + TITLE_ICON_SHIFT, MENU_TITLE_Y - 2, TITLE_SIZES, TEXT_COLOR)
        font = self._fonts[JA]
        server = self._guide_upload
        bottom = self._close_button.top - 10
        if server is None or not server.url:
            error = server.error if server is not None else guide_upload.MSG_NO_NETWORK
            rect = pygame.Rect(MARGIN, LIST_ROW_TOP + 30, self._width - 2 * MARGIN, 200)
            self._draw_text(error or guide_upload.MSG_NO_NETWORK, font, rect, (24, 20, 17), BLINK_BRIGHT_COLOR)
            self._draw_two_line_button(self._close_button, "戻る", "Back", BUTTON_COLOR)
            return
        size = min(bottom - 64, self._width // 2 - MARGIN)
        qr = self._guide_qr_surface(server.url, size)
        text_left = MARGIN
        if qr is not None:
            self._surface.blit(qr, (MARGIN, 60))
            text_left = MARGIN + qr.get_width() + 24
        text_width = self._width - MARGIN - text_left
        top = 64
        if qr is None:
            top = self._draw_text(GUIDE_NO_QR, font, pygame.Rect(text_left, top, text_width, 80), (20, 18, 16), BLINK_BRIGHT_COLOR) + 8
        for line in GUIDE_UPLOAD_STEPS:
            top = self._draw_text(line, font, pygame.Rect(text_left, top, text_width, 70), (21, 19, 17, 15), TEXT_COLOR) + 6
        top = self._draw_text(GUIDE_UPLOAD_STEPS_EN, font, pygame.Rect(text_left, top, text_width, 60), (15, 13, 12), SUBTEXT_COLOR) + 8
        top = self._draw_text(server.url, self._fonts[EN], pygame.Rect(text_left, top, text_width, 50), (17, 15, 13, 12), SUBTEXT_COLOR) + 10
        # 受け取りの様子（右側の下）
        _version, busy, fraction, message, error = self._guide_progress.snapshot()
        if busy:
            bar = pygame.Rect(text_left, top, text_width, 20)
            pygame.draw.rect(self._surface, BUTTON_COLOR, bar, border_radius=8)
            done = bar.copy()
            done.width = max(0, round(bar.width * (fraction or 0.0)))
            if done.width:
                pygame.draw.rect(self._surface, START_COLOR, done, border_radius=8)
            percent = f"  {round((fraction or 0.0) * 100)}%" if fraction is not None else ""
            self._draw_text(message + percent, font, pygame.Rect(text_left, top + 26, text_width, 40), (18, 16), TEXT_COLOR)
        elif message:
            self._draw_text(message, font, pygame.Rect(text_left, top, text_width, max(30, bottom - top)), (19, 17, 15), BLINK_BRIGHT_COLOR if error else GUIDE_OK_COLOR)
        if self._guide_note:
            self._draw_text(self._guide_note, font, pygame.Rect(MARGIN, self._close_button.top, self._close_button.left - MARGIN - 10, CLOSE_HEIGHT), (17, 15), BLINK_BRIGHT_COLOR)
        self._draw_two_line_button(self._close_button, "戻る", "Back", BUTTON_COLOR if not busy else DISABLED_BUTTON_COLOR)

    # 入れた動画（名前の変更・削除）

    def _open_guide_manage(self) -> None:
        self._guide_manage_mode, self._guide_manage_armed, self._guide_note = "", None, ""
        self._guide_admin_first = 0
        self._reload_guide_manage()
        self._set_page(GUIDE_MANAGE_PAGE)

    def _reload_guide_manage(self) -> None:
        self._guide_manage = guide_admin.list_videos(self._guide_root) if self._guide_root is not None else []
        if self._guide_admin_first >= len(self._guide_manage):
            self._guide_admin_first = max(0, (len(self._guide_manage) - 1) // LIST_ROWS * LIST_ROWS)

    def _tap_guide_manage(self, x: int, y: int) -> bool:
        """入れた動画の一覧。「名前を変える」「削除」を選んでから、動画をタップする（削除は 2 回タップ）。"""
        videos = self._guide_manage
        if self._close_button.collidepoint(x, y):
            self._guide_admin_back()
        elif self._guide_rename_button.collidepoint(x, y):
            self._guide_manage_mode = "" if self._guide_manage_mode == "rename" else "rename"
            self._guide_manage_armed, self._guide_note = None, ""
        elif self._guide_delete_button.collidepoint(x, y):
            self._guide_manage_mode = "" if self._guide_manage_mode == "delete" else "delete"
            self._guide_manage_armed, self._guide_note = None, ""
        elif self._guide_admin_first > 0 and self._power_button.collidepoint(x, y):
            self._guide_admin_first = max(0, self._guide_admin_first - LIST_ROWS)
        elif self._guide_admin_first + LIST_ROWS < len(videos) and self._sound_button.collidepoint(x, y):
            self._guide_admin_first += LIST_ROWS
        else:
            shown = videos[self._guide_admin_first : self._guide_admin_first + LIST_ROWS]
            for rect, video in zip(self._list_rows, shown):
                if rect.collidepoint(x, y):
                    self._tap_managed_video(video)
                    return True
            return False
        return True

    def _tap_managed_video(self, video: guide_admin.ManagedVideo) -> None:
        if self._guide_manage_mode == "rename":
            self._kb_guide = video.path
            self._entry.clear()
            self._entry.restore(JA, video.title)
            self._kb_shift = self._kb_symbols = False
            self._kb_message = ""
            self._set_page(KEYBOARD_PAGE)
        elif self._guide_manage_mode == "delete":
            if self._guide_manage_armed != video.path:
                self._guide_manage_armed, self._guide_note = video.path, GUIDE_DELETE_CONFIRM
                return
            try:
                guide_admin.delete_video(self._guide_root, video.path)
                self._guide_note = f"消しました / Deleted: {video.title}"
            except guide_admin.GuideAdminError as error:
                self._guide_note = str(error)
            self._guide_manage_armed = None
            self._reload_guide_manage()
        else:
            self._guide_note = GUIDE_MANAGE_HINT

    def _rename_guide_video(self, path: Path, text: str) -> None:
        """画面のキーボードで打った名前に変えて、入れた動画の一覧に戻る。"""
        self._set_page(GUIDE_MANAGE_PAGE)
        if not text.strip():
            return
        try:
            target = guide_admin.rename_video(self._guide_root, path, text)
            self._guide_note = f"名前を変えました / Renamed: {guide.display_title(target.name)}"
        except guide_admin.GuideAdminError as error:
            self._guide_note = str(error)
        self._reload_guide_manage()

    def _draw_guide_manage(self, snap: Snapshot) -> None:
        self._surface.fill(MENU_BACKGROUND)
        self._drawn_guide_admin = self._guide_admin_versions()
        videos = self._guide_manage
        mode = self._guide_manage_mode
        self._draw_title_icon(icons.PLAY)
        if self._guide_note:
            color = BLINK_BRIGHT_COLOR if self._guide_note in (GUIDE_DELETE_CONFIRM, GUIDE_MANAGE_HINT) else GUIDE_OK_COLOR
            self._draw_fitted_label(self._guide_note, MARGIN + TITLE_ICON_SHIFT, 16, (20, 18, 16, 14, 12), color)
        else:
            title = f"入れた動画（{len(videos)} 件）/ Videos"
            if mode == "rename":
                title = "名前を変える動画をタップ / Tap a video to rename"
            elif mode == "delete":
                title = "消す動画をタップ（2 回）/ Tap twice to delete"
            self._draw_fitted_label(title, MARGIN + TITLE_ICON_SHIFT, MENU_TITLE_Y - 2, TITLE_SIZES, DANGER_COLOR if mode == "delete" else TEXT_COLOR)
        if not videos:
            rect = pygame.Rect(MARGIN, LIST_ROW_TOP + 30, self._width - 2 * MARGIN, 200)
            self._draw_text("まだ動画がありません / No videos yet", self._fonts[JA], rect, (24, 20), SUBTEXT_COLOR)
        rows = []
        for video in videos[self._guide_admin_first : self._guide_admin_first + LIST_ROWS]:
            if video.path == self._guide_manage_armed:
                color = DANGER_COLOR
            elif mode == "delete":
                color = POWER_BUTTON_COLOR
            elif mode == "rename":
                color = GUIDE_CATEGORY_COLOR
            else:
                color = BUTTON_COLOR
            rows.append((video.title, video.destination.label, color))
        self._draw_guide_rows(rows)
        self._draw_paging(self._guide_admin_first, len(videos))
        self._draw_two_line_button(
            self._guide_rename_button, "名前を変える", "Rename", GUIDE_CATEGORY_COLOR if mode == "rename" else BUTTON_COLOR, title_size=20, subtitle_size=13
        )
        self._draw_two_line_button(
            self._guide_delete_button, "削除", "Delete", DANGER_COLOR if mode == "delete" else BUTTON_COLOR, title_size=20, subtitle_size=13
        )
        self._draw_two_line_button(self._close_button, "戻る", "Back", BUTTON_COLOR)

    def _tap_admin(self, x: int, y: int) -> bool:
        """管理者の画面（温度と電圧のグラフ）。期間のボタンで、さかのぼる時間を変える。"""
        if self._close_button.collidepoint(x, y):
            self._set_page(POWER_PAGE)
            return True
        for i, rect in enumerate(self._admin_range_buttons):
            if rect.collidepoint(x, y):
                self._admin_range, self._admin_loaded_at = i, -math.inf  # 次の描き直しで読み直す
                self._reset_armed_at = -math.inf
                self._admin_message = ""
                return True
        if self._admin_range == ADMIN_USAGE_VIEW:
            for kind, rect in self._usage_kind_buttons.items():
                if rect.collidepoint(x, y):
                    self._usage_kind = kind
                    return True
            for days, rect in self._usage_days_buttons.items():
                if rect.collidepoint(x, y):
                    self._usage_days = days
                    return True
            return False
        if self._admin_range == ADMIN_PIN_VIEW:
            for group, rect in self._admin_pin_change_buttons.items():
                if rect.collidepoint(x, y):
                    self._admin_message = ""
                    self._ask_pin("set_admin" if group == ADMIN else "set_general")  # 新しい番号を 2 回入れる
                    return True
            return False
        if self._admin_range == ADMIN_UPTIME_VIEW and self._uptime is not None and self._reset_button.collidepoint(x, y):
            now = time.monotonic()
            if now - self._reset_armed_at <= ADMIN_CONFIRM_SEC:
                self._uptime.reset()
                self._reset_armed_at = -math.inf
            else:
                self._reset_armed_at = now  # もう一度押すとリセット
            return True
        return False

    def _tap_history(self, x: int, y: int) -> bool:
        """翻訳回数履歴の画面。種類（翻訳・定型文を使用・訂正）と期間（7・14・30 日）を切り替える。"""
        if self._close_button.collidepoint(x, y):
            self._set_page(POWER_PAGE)
            return True
        for kind, rect in self._history_kind_buttons.items():
            if rect.collidepoint(x, y):
                self._history_kind = kind
                return True
        for days, rect in self._usage_days_buttons.items():
            if rect.collidepoint(x, y):
                self._usage_days = days
                return True
        return False

    def _tap_fix_page(self, x: int, y: int) -> bool:
        """訂正の画面。「戻る」で通訳の画面へ。音声入力の途中は、聞き取り・確かめの操作だけ受け付ける。"""
        if self._fix_listening or self._fix_heard:
            return self._tap_fix_voice(x, y)
        if self._close_button.collidepoint(x, y):
            self._set_page(MAIN_PAGE)
            return True
        return self._tap_fixes(x, y)

    def _tap_fix_voice(self, x: int, y: int) -> bool:
        """音声入力の途中。聞き取り中は「やめる」だけ。聞き取れたあとは「登録」「やり直し」「やめる」。"""
        if self._close_button.collidepoint(x, y) or (self._fix_listening and self._fix_voice_button.collidepoint(x, y)):
            self._stop_fix_voice()
            return True
        if self._fix_heard and self._fix_voice is not None:
            if self._fix_keep_button.collidepoint(x, y):
                source, text, target = self._fix_voice
                heard = self._fix_heard
                self._stop_fix_voice()
                self._fix_message = self._fix_save(source, text, target, heard)
                self._fix_first = 0
                return True
            if self._fix_type_button.collidepoint(x, y):
                self._start_fix_voice()  # 「やり直し」
                return True
        return False

    def _start_fix_voice(self) -> None:
        """直近に訳した文の、訳す先の言語で話してもらい、次の発話を 1 つ聞き取る。"""
        last = self._fix_last()
        if last is None:
            self._fix_message = FIX_NO_EXCHANGE
            return
        source, text, target, _translation = last
        self._fix_voice, self._fix_heard, self._fix_message = (source, text, target), "", ""
        self._fix_listening = self._fix_voice_start(target, self._fix_voice_heard)
        if not self._fix_listening:
            self._fix_voice = None
            self._fix_message = FIX_VOICE_BUSY

    def _fix_voice_heard(self, text: str) -> None:
        """聞き取った訳が届いた（音声認識のスレッドから呼ばれる。聞き取れなければ空の文）。確かめてから登録する。"""
        if self._fix_voice is None:
            return  # やめたあとに届いた（体験版の見本など）
        self._fix_listening = False
        if text:
            self._fix_heard = text
        else:
            self._fix_voice, self._fix_message = None, FIX_VOICE_NOT_HEARD
        self._needs_redraw = True

    def _stop_fix_voice(self) -> None:
        """音声入力をやめる（聞き取りの途中なら、聞き取りもやめる）。"""
        if self._fix_listening:
            self._fix_listening = False
            self._fix_voice_cancel()
        self._fix_voice, self._fix_heard, self._fix_message = None, "", ""

    def _tap_fixes(self, x: int, y: int) -> bool:
        """訂正の画面:「覚える」（今の訳を登録）、「入力」（正しい訳を打つ）、「削除」、前へ・次へ、一覧の行。"""
        items = self._fix_list()
        if self._fix_keep_button.collidepoint(x, y):
            self._fix_delete = False
            self._fix_message = self._fix_keep()
            self._fix_first = max(0, (len(self._fix_list()) - 1) // LIST_ROWS * LIST_ROWS)  # 登録した行が見えるページ
        elif self._fix_type_button.collidepoint(x, y):
            self._fix_delete = False
            last = self._fix_last()
            if last is None:
                self._fix_message = FIX_NO_EXCHANGE
            else:
                self._open_fix_keyboard(last)
        elif self._fix_voice_button.collidepoint(x, y):
            self._fix_delete = False
            self._start_fix_voice()
        elif self._fix_delete_button.collidepoint(x, y):
            self._fix_delete, self._fix_message = not self._fix_delete, ""
        elif self._fix_first > 0 and self._fix_prev_button.collidepoint(x, y):
            self._fix_first = max(0, self._fix_first - LIST_ROWS)  # 「前へ」
        elif self._fix_first + LIST_ROWS < len(items) and self._fix_next_button.collidepoint(x, y):
            self._fix_first += LIST_ROWS  # 「次へ」
        else:
            shown = range(self._fix_first, min(len(items), self._fix_first + LIST_ROWS))
            for rect, index in zip(self._list_rows, shown):
                if rect.collidepoint(x, y) and self._fix_delete:
                    self._fix_remove(index)
                    self._fix_message = "削除しました / Deleted"
                    if self._fix_first >= len(items) - 1 and self._fix_first > 0:
                        self._fix_first -= LIST_ROWS
                    return True
            return False
        return True

    def _open_fix_keyboard(self, last: tuple[str, str, str, str]) -> None:
        """正しい訳を、画面のキーボードで打つ（訳す先の言語のキーボードが出る。送信 = 登録）。"""
        source, text, target, _translation = last
        self._kb_fix = (source, text, target)
        self._entry.clear()
        self._kb_shift = self._kb_symbols = False
        self._kb_message = ""
        self._set_page(KEYBOARD_PAGE)

    def _kb_lang(self, snap: Snapshot) -> str:
        """画面のキーボードで打つ言語（訂正の入力中は、訳す先の言語。そうでなければ、話す人の言語）。"""
        if self._kb_phrase is not None:
            return self._kb_phrase[1]  # 定型文を直している間は、直す行の言語
        if self._kb_guide is not None:
            return JA  # 動画の名前は日本語で打つ
        return self._kb_fix[2] if self._kb_fix is not None else snap.mode.speaker

    def _tap_power(self, x: int, y: int) -> bool:
        if self._power_saver is not None and (enabled := self._on_off_selection(self._eco_buttons, x, y)) is not None:
            self._on_power_saving(enabled)
        elif self._auto_off is not None and self._tap_auto_off(x, y):
            pass
        elif self._admin_button.collidepoint(x, y):
            # これだけでは入らない。5 秒以内に左上の角に触ると入る（見た目は変えない）
            self._admin_unlock_at = time.monotonic()
        elif self._history_button.collidepoint(x, y):
            self._ask_pin("usage")  # 一般の番号を聞いてから、翻訳回数履歴を開く
        elif x < ADMIN_CORNER and y < ADMIN_CORNER:
            if time.monotonic() - self._admin_unlock_at > ADMIN_UNLOCK_SEC:
                return False
            self._admin_unlock_at = -math.inf
            self._ask_pin("admin")  # 管理者の番号を聞いてから、管理者の画面を開く
        elif self._cancel_button.collidepoint(x, y):
            self._set_page(MENU_PAGE)
        elif self._reboot_button.collidepoint(x, y):
            self._run_power_action(REBOOT_PAGE, self._on_reboot)
        elif self._confirm_power_button.collidepoint(x, y):
            self._run_power_action(SHUTDOWN_PAGE, self._on_power_off)
        else:
            return False
        return True

    def _tap_auto_off(self, x: int, y: int) -> bool:
        """「自動オフ」の時刻の「−」「＋」。押されたら True。"""
        auto_off = self._auto_off
        if auto_off is None:
            return False
        if self._auto_switch.collidepoint(x, y):
            auto_off.set_enabled(not auto_off.enabled)
        elif self._auto_down.collidepoint(x, y):
            auto_off.step(-1)
        elif self._auto_up.collidepoint(x, y):
            auto_off.step(1)
        else:
            return False
        self._on_auto_off_changed()
        self._needs_redraw = True
        return True

    def _check_auto_off(self, busy: bool) -> None:
        """決めた時刻になったら、電源を切る（「電源を切る」ボタンと同じ）。"""
        auto_off = self._auto_off
        if auto_off is not None and auto_off.due(datetime.now(), busy):
            self._run_power_action(SHUTDOWN_PAGE, self._on_power_off)

    def _check_idle_off(self, busy: bool, now: float) -> None:
        """何も操作がないまま決めた時間がたったら、電源を切る。切る直前は、知らせを出すため描き直す。"""
        idle_off = self._idle_off
        if idle_off is None:
            return
        saver = self._power_saver
        if saver is None or not saver.enabled:
            # 省電力モードがオフのときは、操作がなくても電源を切らない（オンにしたとき、すぐ切れないよう、数え直しておく）
            idle_off.touch(now)
            if self._idle_warning_drawn is not None:
                self._needs_redraw = True  # 出ていた「電源が切れます」の知らせを消す
            return
        if idle_off.due(now, busy):
            self._run_power_action(SHUTDOWN_PAGE, self._on_power_off)
            return
        if idle_off.warning(now) != self._idle_warning_drawn:
            self._needs_redraw = True

    def _draw_idle_warning(self) -> None:
        """電源が切れる直前の知らせ（画面の下に帯を重ねる）。"""
        idle_off = self._idle_off
        warning = None if idle_off is None else idle_off.warning(time.monotonic())
        self._idle_warning_drawn = warning
        if warning is None:
            return
        band = pygame.Rect(0, self._height - 110, self._width, 110)
        pygame.draw.rect(self._surface, (120, 40, 30), band)
        self._draw_label(f"操作がないので、あと {warning} 秒で電源が切れます", MARGIN, band.y + 14, 30, TEXT_COLOR)
        self._draw_label(f"No activity: powering off in {warning} s. Touch the screen to cancel.", MARGIN, band.y + 62, 22, TEXT_COLOR)

    def _phrase_indices(self, phrases: tuple[Phrase, ...]) -> list[int]:
        """一覧に出す定型文の番号。選んでいる業種に合う文だけ（音声検索をしていれば、見つかったものだけを近い順に）。"""
        selected = self._industries.ids if self._industries is not None else ()
        if self._phrase_filter is None:
            candidates = range(len(phrases))
        else:
            candidates = [index for index in self._phrase_filter if index < len(phrases)]
        return [index for index in candidates if phrases[index].shown_for(selected)]

    def _phrase_heard(self, text: str) -> None:
        """音声検索で聞き取った文が届いた（音声認識のスレッドから呼ばれる。聞き取れなければ空の文）。"""
        self._phrase_searching = False
        if text:
            self._phrase_query = text
            self._phrase_filter = search_phrases(self._on_phrase_list(), text)
            self._phrase_first, self._phrase_message = 0, ""
        else:
            self._phrase_message = PHRASE_NOT_HEARD
        self._needs_redraw = True

    def _stop_phrase_search(self) -> None:
        """聞き取りの途中なら、音声検索をやめる。"""
        if self._phrase_searching:
            self._on_phrase_search_cancel()
            self._phrase_searching, self._phrase_message = False, ""

    def _tap_phrases(self, x: int, y: int) -> bool:
        """定型文の画面。文をタップすると、通訳の画面に出して読み上げる（「削除」を押したあとなら、その文を消す）。"""
        phrases = self._on_phrase_list()
        indices = self._phrase_indices(phrases)
        if self._close_button.collidepoint(x, y):
            self._stop_phrase_search()
            self._set_page(MENU_PAGE)
        elif self._phrase_search_button.collidepoint(x, y):
            if self._phrase_searching:
                self._stop_phrase_search()  # 聞き取りをやめる
            elif self._phrase_filter is not None:
                # 「すべて表示」: 検索をやめて、すべての定型文を出す
                self._phrase_filter, self._phrase_query, self._phrase_first, self._phrase_message = None, "", 0, ""
            else:
                self._phrase_delete = self._phrase_edit_mode = False
                self._phrase_searching = self._on_phrase_search(self._phrase_heard)
                self._phrase_message = "" if self._phrase_searching else PHRASE_BUSY
        elif self._phrase_add_button.collidepoint(x, y):
            self._stop_phrase_search()
            self._phrase_delete, self._phrase_edit_mode = False, False
            self._phrase_filter, self._phrase_query = None, ""
            self._phrase_message = self._on_phrase_add()
            # 登録した文（一覧の最後）が見えるページにする
            self._phrase_first = max(0, (len(self._phrase_indices(self._on_phrase_list())) - 1) // LIST_ROWS * LIST_ROWS)
        elif self._phrase_delete_button.collidepoint(x, y):
            self._stop_phrase_search()
            self._phrase_delete, self._phrase_edit_mode, self._phrase_message = not self._phrase_delete, False, ""
        elif self._phrase_edit_button.collidepoint(x, y):
            self._stop_phrase_search()
            self._phrase_edit_mode, self._phrase_delete, self._phrase_message = not self._phrase_edit_mode, False, ""
        elif self._phrase_first > 0 and self._power_button.collidepoint(x, y):
            self._phrase_first = max(0, self._phrase_first - LIST_ROWS)  # 「前へ」
        elif self._phrase_first + LIST_ROWS < len(indices) and self._sound_button.collidepoint(x, y):
            self._phrase_first += LIST_ROWS  # 「次へ」
        else:
            shown = indices[self._phrase_first : self._phrase_first + LIST_ROWS]
            for rect, index in zip(self._list_rows, shown):
                if not rect.collidepoint(x, y):
                    continue
                self._stop_phrase_search()
                if self._phrase_delete:
                    self._on_phrase_remove(index)
                    self._phrase_message = "削除しました / Deleted"
                    if self._phrase_filter is not None:
                        # 消した文を検索結果から外し、それより後ろの番号を 1 つずつ詰める
                        self._phrase_filter = [i - (i > index) for i in self._phrase_filter if i != index]
                    if self._phrase_first >= len(indices) - 1 and self._phrase_first > 0:
                        self._phrase_first -= LIST_ROWS  # このページの最後の 1 つを消した
                elif self._phrase_edit_mode:
                    self._open_phrase_edit(phrases[index])
                else:
                    self._set_page(MAIN_PAGE)
                    if not self._on_phrase_use(index):
                        self._state.set_message(PHRASE_BUSY)
                return True
            return False
        return True

    # --- 定型文の修正 ---

    def set_phrase_edit_handlers(
        self, rename: Callable[[str, str, str], str], set_translation: Callable[[str, str, str, str], None]
    ) -> None:
        """定型文の修正の処理。rename(言語, 文, 新しい文): 文を直す（結果を返す。訳文は消える）。
        set_translation(言語, 文, 訳す先の言語, 新しい訳文): その言語の訳文を直す。"""
        self._on_phrase_rename = rename
        self._on_phrase_translation = set_translation

    def _open_phrase_edit(self, phrase: Phrase) -> None:
        self._phrase_edit_key = (phrase.lang, phrase.text)
        self._phrase_edit_first, self._phrase_edit_message = 0, PHRASE_EDIT_HINT
        self._set_page(PHRASE_EDIT_PAGE)

    def _editing_phrase(self) -> Phrase | None:
        """修正の画面で開いている定型文（消えていれば None）。"""
        key = self._phrase_edit_key
        return next((p for p in self._on_phrase_list() if (p.lang, p.text) == key), None) if key else None

    @staticmethod
    def _phrase_edit_rows(phrase: Phrase) -> list[tuple[str, str, str]]:
        """修正の画面の行: （直す行, 言語, 今の文）。先頭は元の文（行は "src"）、あとは訳す先の言語ごとの訳文（まだ無ければ空）。"""
        rows = [("src", phrase.lang, phrase.text)]
        targets = [lang for lang in ROW_LANGS if lang != phrase.lang] if phrase.lang == JA else [JA]
        targets += [lang for lang in phrase.translations if lang not in targets and lang != phrase.lang]
        rows += [(lang, lang, phrase.translations.get(lang, "")) for lang in targets]
        return rows

    def _tap_phrase_edit(self, x: int, y: int) -> bool:
        """定型文の修正の画面。行をタップすると、その行を打ち直すキーボードが開く。"""
        phrase = self._editing_phrase()
        if self._close_button.collidepoint(x, y) or phrase is None:
            self._phrase_edit_key = None
            self._set_page(PHRASES_PAGE)
            return True
        rows = self._phrase_edit_rows(phrase)
        if self._phrase_edit_first > 0 and self._power_button.collidepoint(x, y):
            self._phrase_edit_first = max(0, self._phrase_edit_first - LIST_ROWS)  # 「前へ」
            return True
        if self._phrase_edit_first + LIST_ROWS < len(rows) and self._sound_button.collidepoint(x, y):
            self._phrase_edit_first += LIST_ROWS  # 「次へ」
            return True
        shown = rows[self._phrase_edit_first : self._phrase_edit_first + LIST_ROWS]
        for rect, (field, lang, current) in zip(self._list_rows, shown):
            if not rect.collidepoint(x, y):
                continue
            if not can_type(lang):
                self._phrase_edit_message = PHRASE_EDIT_CANNOT_TYPE
            else:
                self._open_phrase_keyboard(field, lang, current)
            return True
        return False

    def _open_phrase_keyboard(self, field: str, lang: str, current: str) -> None:
        """定型文の 1 行を、画面のキーボードで打ち直す（今の文が入力欄に入った状態で開く。送信 = 直す）。"""
        self._kb_phrase = (field, lang)
        self._entry.clear()
        self._entry.restore(lang, current)
        self._kb_shift = self._kb_symbols = False
        self._kb_message = ""
        self._set_page(KEYBOARD_PAGE)

    def _save_phrase_edit(self, field: str, lang: str, text: str) -> None:
        """キーボードで打ち直した文を、定型文に書いて、修正の画面に戻る。"""
        phrase = self._editing_phrase()
        self._kb_phrase = None
        self._set_page(PHRASE_EDIT_PAGE)
        if phrase is None or not text:
            return
        if field == "src":
            result = self._on_phrase_rename(phrase.lang, phrase.text, text)
            if result == "duplicate":
                self._phrase_edit_message = PHRASE_EDIT_DUPLICATE
                return
            if result == "renamed":
                self._phrase_edit_key = (phrase.lang, text)
        else:
            self._on_phrase_translation(phrase.lang, phrase.text, field, text)
        self._phrase_edit_message = PHRASE_EDIT_SAVED + ("　" + PHRASE_EDIT_SOURCE_NOTE if field == "src" else "")

    def _run_power_action(self, page: str, action: Callable[[], bool]) -> None:
        """電源が切れる（再起動が始まる）前に「電源を切っています」などを表示してから実行する。

        失敗したときは画面が残ってしまうので、メニューに戻す（理由は下部の状態表示に出る）。
        """
        self._set_page(page)
        self._needs_redraw = True
        self._redraw_if_changed()
        if not action():
            self._set_page(MENU_PAGE)

    def _set_page(self, page: str) -> None:
        if page == MENU_PAGE and self._page != MENU_PAGE:
            # メニューを開くたびに、「通訳表示」ボタンの明滅を最初からやり直す
            self._menu_blink_started = time.monotonic()
        if self._page in STUDY_PAGES and (self._study_checking or page not in STUDY_PAGES):
            self._study_stop(leaving=page not in STUDY_PAGES)
        self._page = page
        self._state.set_mic_tuning(page in TUNING_PAGES)

    def _open_wifi(self) -> None:
        """Wi-Fi の画面を開く（開くたびに、一覧を最初から出し、探し直す）。"""
        self._wifi_first = 0
        self._set_page(WIFI_PAGE)
        self._on_wifi_open()

    def _open_clock(self) -> None:
        """時計設定の画面を開く（今の日付・時刻から始める）。"""
        self._clock_fields = ClockFields.from_datetime(datetime.now())
        self._clock_message = ""
        self._clock_ntp = self._get_clock_ntp()
        self._set_page(CLOCK_PAGE)

    def _tap_clock(self, x: int, y: int) -> bool:
        """時計設定の画面: 年・月・日・時・分の「−」「＋」、「設定する」、自動合わせのオン・オフ、「戻る」。"""
        if self._close_button.collidepoint(x, y):
            self._set_page(MENU_PAGE)
            return True
        for (field, _ja, _en), (down, up) in zip(CLOCK_FIELD_LABELS, self._clock_step_buttons):
            if up.collidepoint(x, y):
                self._clock_fields.step(field, +1)
                self._clock_message = ""
                return True
            if down.collidepoint(x, y):
                self._clock_fields.step(field, -1)
                self._clock_message = ""
                return True
        if self._clock_set_button.collidepoint(x, y):
            error = self._on_clock_set(self._clock_fields.to_datetime())
            if error:
                self._clock_message = error
            else:
                self._clock_message = "時計を合わせました / Clock set"
                self._clock_ntp = self._get_clock_ntp()  # 手で合わせると、自動合わせはオフになる
            return True
        selected = self._on_off_selection(self._clock_ntp_buttons, x, y)
        if selected is not None:
            error = self._on_clock_ntp(selected)
            if error:
                self._clock_message = error
            else:
                self._clock_ntp = selected
                self._clock_message = ""
            return True
        return False

    def _tap_language(self, x: int, y: int) -> bool:
        """「翻訳の組み合わせ」の画面。言語を選ぶと、メニューに戻る。"""
        if self._close_button.collidepoint(x, y):
            self._set_page(MENU_PAGE)
            return True
        for (partner, script), rect in self._language_buttons.items():
            if rect.collidepoint(x, y):
                if partner == ZH:
                    # 中国語の書き方を先に変えておく（組み合わせを変えると、すぐ聞き取りが始まるため）
                    self._on_zh_script_selected(script)
                self._on_mode_selected(self._state.mode.with_partner(partner))
                self._set_page(MENU_PAGE)
                return True
        return False

    # --- ハングル学習 ---

    @property
    def _course(self):
        """今の学習の中身（hangul_study か english_study）。"""
        return STUDY_COURSES[self._study_lang]

    def _open_study(self, lang: str) -> None:
        """「ハングル学習」「英語学習」を開く。言語が変わったら、前の問題・単語・結果は持ち越さない。"""
        if lang != self._study_lang:
            self._study_pool = None
            self._study_question = None
            self._study_cards = []
        self._study_lang = lang
        self._on_study_language(lang)
        self._set_page(STUDY_PAGE)

    def _study_stop(self, leaving: bool) -> None:
        """学習の画面から移るとき: 聞き取りの途中ならやめる。学習の画面を出るときは、結果と変えた設定も戻す。"""
        if self._study_checking:
            self._study_checking = False
            self._on_study_cancel()
        self._study_heard, self._study_notice = None, ""
        if leaving:
            self._on_study_close()

    def _study_clear_result(self) -> None:
        if self._study_checking:
            self._study_checking = False
            self._on_study_cancel()
        self._study_heard, self._study_notice = None, ""

    def _study_heard_callback(self, text: str) -> None:
        """発音チェックの聞き取りが終わった（別のスレッドから呼ばれる）。"""
        self._study_heard = text
        self._study_checking = False
        self._needs_redraw = True

    def _study_toggle_check(self, target: str) -> None:
        """「話してみる」: 手本（target）を話した声を聞き取る。聞き取っている間にもう一度押すと、やめる。"""
        if self._study_checking:
            self._study_clear_result()
            return
        self._study_heard, self._study_notice = None, ""
        self._study_target = target
        self._study_checking = self._on_study_check(self._study_heard_callback)
        if not self._study_checking:
            self._study_notice = STUDY_BUSY

    def _study_say(self, text: str) -> None:
        if text and not self._on_study_speak(text):
            self._study_notice = "いま読み上げられません（音声出力が使えないか、処理中です）/ Cannot speak now"

    def _tap_study(self, x: int, y: int) -> bool:
        """ハングル学習の最初の画面。"""
        if self._close_button.collidepoint(x, y):
            self._set_page(GUIDE_PAGE)
            return True
        for (key, *_), rect in zip(STUDY_TILES, self._study_tiles):
            if not rect.collidepoint(x, y):
                continue
            self._study_clear_result()
            if key == "letters":
                self._study_group = self._study_letter = 0
                self._set_page(STUDY_LETTERS_PAGE)
            elif key in ("phrases", "check"):
                selection = self._industries.ids if self._industries is not None else ()
                self._study_cards = self._course.phrase_deck(selection)
                self._study_card, self._study_check_mode = 0, key == "check"
                self._set_page(STUDY_PHRASE_PAGE)
            else:
                self._study_start_quiz("words")
            return True
        return False

    def _study_current_letters(self) -> tuple[study.Letter, ...]:
        return self._course.LETTER_GROUPS[self._study_group][2]

    def _tap_study_letters(self, x: int, y: int) -> bool:
        if self._close_button.collidepoint(x, y):
            self._set_page(STUDY_PAGE)
            return True
        for i, rect in enumerate(self._study_tabs[: len(self._course.LETTER_GROUPS)]):
            if rect.collidepoint(x, y):
                self._study_clear_result()
                self._study_group, self._study_letter = i, 0
                return True
        letters = self._study_current_letters()
        for i, rect in enumerate(self._study_cells[: len(letters)]):
            if rect.collidepoint(x, y):
                self._study_clear_result()
                self._study_letter = i
                self._study_say(letters[i].say)
                return True
        letter = letters[min(self._study_letter, len(letters) - 1)]
        listen, speak, quiz = self._study_letters_row
        if listen.collidepoint(x, y):
            self._study_notice = ""
            self._study_say(letter.example)
        elif speak.collidepoint(x, y):
            self._study_toggle_check(letter.example)
        elif quiz.collidepoint(x, y):
            self._study_start_quiz("letters")
        else:
            return False
        return True

    def _tap_study_phrases(self, x: int, y: int) -> bool:
        if self._close_button.collidepoint(x, y):
            self._set_page(STUDY_PAGE)
            return True
        if not self._study_cards:
            return False
        previous, following, listen, speak = self._study_phrases_row
        if previous.collidepoint(x, y) or following.collidepoint(x, y):
            self._study_clear_result()
            step = -1 if previous.collidepoint(x, y) else 1
            self._study_card = (self._study_card + step) % len(self._study_cards)
        elif listen.collidepoint(x, y):
            self._study_notice = ""
            self._study_say(self._study_cards[self._study_card][1])
        elif speak.collidepoint(x, y):
            self._study_toggle_check(self._study_cards[self._study_card][1])
        else:
            return False
        return True

    def _study_start_quiz(self, kind: str) -> None:
        self._study_kind = kind
        self._study_right = self._study_asked = 0
        self._study_next_question()
        self._set_page(STUDY_QUIZ_PAGE)

    def _study_next_question(self) -> None:
        rng = self._study_random
        if self._study_kind == "letters":
            self._study_question = self._course.letter_question(rng)
        else:
            if self._study_pool is None:
                self._study_pool = self._course.word_pool()
            self._study_question = self._course.word_question(rng, self._study_pool)
        self._study_picked = None
        self._study_notice = ""

    def _tap_study_quiz(self, x: int, y: int) -> bool:
        if self._close_button.collidepoint(x, y):
            self._set_page(STUDY_PAGE)
            return True
        question = self._study_question
        if question is None:
            return False
        if self._study_picked is None:
            for i, rect in enumerate(self._study_choices[: len(question.choices)]):
                if rect.collidepoint(x, y):
                    self._study_picked = i
                    self._study_asked += 1
                    self._study_right += int(i == question.answer)
                    self._study_say(question.speak)  # 答え合わせのあと、手本を聞かせる
                    return True
        listen, following = self._study_quiz_row
        if listen.collidepoint(x, y):
            self._study_say(question.speak)
        elif following.collidepoint(x, y):
            if self._study_picked is None:
                self._study_asked += 1  # 答えずに次へ進んだ（外れ扱い）
            self._study_next_question()
        else:
            return False
        return True

    def _draw_study(self, snap: Snapshot) -> None:
        self._surface.fill(MENU_BACKGROUND)
        self._draw_title_icon(icons.CHECKLIST)
        name_ja, name_en = STUDY_COURSE_LABELS[self._study_lang]
        self._draw_label(f"{name_ja} / {name_en}", MARGIN + TITLE_ICON_SHIFT, MENU_TITLE_Y, 30, TEXT_COLOR)
        tiles = STUDY_TILES_BY_LANG[self._study_lang]
        for (key, title, english, note), rect in zip(tiles, self._study_tiles):
            pygame.draw.rect(self._surface, STUDY_COLOR if key != "check" else (44, 104, 84), rect, border_radius=14)
            self._blit_centered_at(title, rect, 34, 0.30)
            self._blit_centered_at(english, rect, 20, 0.52)
            self._blit_centered_at(note, rect, 18, 0.76)
        self._draw_two_line_button(self._close_button, "戻る", "Back", BUTTON_COLOR)

    def _draw_study_notice(self, y: int) -> None:
        if self._study_notice:
            self._draw_fitted_label(self._study_notice, MARGIN, y, (20, 18, 16), (240, 190, 90))

    def _draw_study_result(self, rect: pygame.Rect, size: int = 30) -> None:
        """発音チェックの様子（聞き取り中 / 結果）を rect の中に出す。"""
        if self._study_checking:
            surface, _ = self._fonts[JA].render("聞き取り中… 話してください / Listening… please speak", LISTENING_COLOR, size=size - 6)
            self._surface.blit(surface, surface.get_rect(midleft=rect.midleft))
        elif self._study_heard is not None:
            if not self._study_heard:
                surface, _ = self._fonts[JA].render(STUDY_NOT_HEARD, (240, 190, 90), size=size - 8)
                self._surface.blit(surface, surface.get_rect(midleft=rect.midleft))
                return
            score = self._course.similarity(self._study_target, self._study_heard)
            mark, comment = self._course.verdict(score)
            color = (90, 200, 130) if score >= 0.7 else (240, 190, 90) if score >= 0.5 else (230, 110, 100)
            top = pygame.Rect(rect.left, rect.top, rect.width, rect.height // 2)
            line, _ = self._fonts[JA].render(f"{mark} {round(score * 100)}点  {comment}", color, size=size)
            self._surface.blit(line, line.get_rect(midleft=top.midleft))
            heard = pygame.Rect(rect.left, rect.top + rect.height // 2, rect.width, rect.height // 2)
            self._draw_text(f"聞き取った言葉: {self._study_heard}", self._fonts[self._study_lang], heard, (22, 18, 16), SUBTEXT_COLOR)

    def _draw_study_letters(self, snap: Snapshot) -> None:
        self._surface.fill(MENU_BACKGROUND)
        self._draw_label("文字と発音 / Letters & sounds", MARGIN, 8, 26, TEXT_COLOR)
        for i, ((_, title, letters), rect) in enumerate(zip(self._course.LETTER_GROUPS, self._study_tabs)):
            self._draw_button(rect, title, 22, BUTTON_ACTIVE_COLOR if i == self._study_group else BUTTON_COLOR)
        letters = self._study_current_letters()
        selected = min(self._study_letter, len(letters) - 1)
        for i, (letter, rect) in enumerate(zip(letters, self._study_cells)):
            pygame.draw.rect(self._surface, STUDY_COLOR if i == selected else BUTTON_COLOR, rect, border_radius=8)
            text, _ = self._fonts[self._study_lang].render(letter.char, TEXT_COLOR, size=30 if self._study_lang == KO else 26)
            self._surface.blit(text, text.get_rect(center=rect.center))
        letter = letters[selected]
        panel = self._study_panel
        pygame.draw.rect(self._surface, (30, 36, 44), panel, border_radius=10)
        big, _ = self._fonts[self._study_lang].render(letter.display, TEXT_COLOR, size=64 if self._study_lang == KO else 52)
        self._surface.blit(big, big.get_rect(center=(panel.left + 56, panel.centery - 8)))
        small, _ = self._fonts[JA].render(letter.kana, PRON_COLOR, size=22)
        self._surface.blit(small, small.get_rect(center=(panel.left + 56, panel.bottom - 14)))
        text_left = panel.left + 120
        self._draw_label(letter.char, text_left, panel.top + 6, 26, TEXT_COLOR)
        # 発音記号（IPA）は、記号が出せるフォントで、文字の右に小さめに書く
        char_width = self._fonts[JA].get_rect(letter.char, size=26).width
        roman, _ = self._phonetic_font.render(letter.roman, PRON_COLOR, size=22)
        self._surface.blit(roman, (text_left + char_width + 16, panel.top + 10))
        tip_rect = pygame.Rect(text_left, panel.top + 40, panel.width - 136, 30)
        self._draw_text(letter.tip, self._fonts[JA], tip_rect, (19, 17, 15), SUBTEXT_COLOR)
        bottom = pygame.Rect(text_left, panel.top + 70, panel.width - 136, 30)
        if self._study_checking or self._study_heard is not None:
            self._draw_study_result(bottom, 26)
        else:
            self._draw_text(
                (f"例: {letter.example}（{letter.example_kana}）＝ {letter.example_ja}" if letter.example_kana else f"例: {letter.example} ＝ {letter.example_ja}"),
                self._fonts[self._study_lang],
                bottom,
                (22, 19, 16),
                TEXT_COLOR,
            )
        self._draw_study_notice(panel.bottom + 2)
        listen, speak, quiz = self._study_letters_row
        self._draw_two_line_button(listen, "聞く", "Listen", BUTTON_COLOR, icon=icons.SPEAKER)
        self._draw_two_line_button(
            speak, "やめる" if self._study_checking else "話してみる", "Stop" if self._study_checking else "Say it", (44, 104, 84), title_size=22
        )
        self._draw_two_line_button(quiz, "クイズ", "Quiz", BUTTON_COLOR)
        self._draw_two_line_button(self._close_button, "戻る", "Back", BUTTON_COLOR)

    def _draw_study_phrases(self, snap: Snapshot) -> None:
        self._surface.fill(MENU_BACKGROUND)
        title = "発音チェック / Pronunciation check" if self._study_check_mode else "接客フレーズ / Service phrases"
        self._draw_label(title, MARGIN, 8, 26, TEXT_COLOR)
        if not self._study_cards:
            self._draw_two_line_button(self._close_button, "戻る", "Back", BUTTON_COLOR)
            return
        ja, ko = self._study_cards[self._study_card]
        count = f"{self._study_card + 1} / {len(self._study_cards)}"
        surface, _ = self._fonts[EN].render(count, SUBTEXT_COLOR, size=22)
        self._surface.blit(surface, surface.get_rect(topright=(self._width - MARGIN, 14)))
        self._draw_text(ja, self._fonts[JA], pygame.Rect(MARGIN, 52, self._width - 2 * MARGIN, 40), (28, 24, 20), SUBTEXT_COLOR)
        ko_rect = pygame.Rect(MARGIN, 96, self._width - 2 * MARGIN, 112)
        self._draw_text(ko, self._fonts[self._study_lang], ko_rect, (50, 42, 36, 30), TEXT_COLOR)
        kana_rect = pygame.Rect(MARGIN, 212, self._width - 2 * MARGIN, 44)
        self._draw_text(self._course.kana_of(ko), self._fonts[JA], kana_rect, (26, 22, 18), PRON_COLOR)
        self._draw_study_result(pygame.Rect(MARGIN, 276, self._width - 2 * MARGIN, 76), 32)
        self._draw_study_notice(360)
        previous, following, listen, speak = self._study_phrases_row
        self._draw_two_line_button(previous, "◀ 前へ", "Prev", BUTTON_COLOR, title_size=22)
        self._draw_two_line_button(following, "次へ ▶", "Next", BUTTON_COLOR, title_size=22)
        self._draw_two_line_button(listen, "聞く", "Listen", BUTTON_COLOR, icon=icons.SPEAKER)
        self._draw_two_line_button(
            speak, "やめる" if self._study_checking else "話してみる", "Stop" if self._study_checking else "Say it", (44, 104, 84), title_size=22
        )
        self._draw_two_line_button(self._close_button, "戻る", "Back", BUTTON_COLOR)

    def _draw_study_quiz(self, snap: Snapshot) -> None:
        self._surface.fill(MENU_BACKGROUND)
        title = "字の読み / Reading letters" if self._study_kind == "letters" else "読む練習 / Reading practice"
        self._draw_label(title, MARGIN, 8, 26, TEXT_COLOR)
        score, _ = self._fonts[JA].render(f"正解 {self._study_right} / {self._study_asked}", SUBTEXT_COLOR, size=22)
        self._surface.blit(score, score.get_rect(topright=(self._width - MARGIN, 14)))
        question = self._study_question
        if question is None:
            self._draw_two_line_button(self._close_button, "戻る", "Back", BUTTON_COLOR)
            return
        hint = "カタカナの読みを選んでください" if self._study_kind == "letters" else "意味を選んでください"
        self._draw_label(hint, MARGIN, 48, 20, SUBTEXT_COLOR)
        self._draw_text(
            question.prompt, self._fonts[self._study_lang], pygame.Rect(MARGIN, 72, self._width - 2 * MARGIN, 104), (84, 68, 54, 44, 36), TEXT_COLOR
        )
        for i, (text, rect) in enumerate(zip(question.choices, self._study_choices)):
            if self._study_picked is None:
                color = BUTTON_COLOR
            elif i == question.answer:
                color = START_COLOR
            elif i == self._study_picked:
                color = DANGER_COLOR
            else:
                color = DISABLED_BUTTON_COLOR
            pygame.draw.rect(self._surface, color, rect, border_radius=10)
            self._draw_text(text, self._fonts[JA], rect.inflate(-24, -16), (28, 24, 20, 16), TEXT_COLOR)
        if self._study_picked is not None:
            right = self._study_picked == question.answer
            mark = "◎ 正解です" if right else "× 残念。正解は緑のボタンです"
            self._draw_label(mark, MARGIN, 342, 24, (90, 200, 130) if right else (230, 110, 100))
            self._draw_text(question.detail, self._fonts[self._study_lang], pygame.Rect(MARGIN, 372, self._width - 2 * MARGIN, 24), (20, 17, 15), SUBTEXT_COLOR)
        self._draw_study_notice(342 if self._study_picked is None else 322)
        listen, following = self._study_quiz_row
        self._draw_two_line_button(listen, "聞く", "Listen", BUTTON_COLOR, icon=icons.SPEAKER)
        self._draw_two_line_button(following, "次の問題 ▶", "Next", STUDY_COLOR, title_size=22)
        self._draw_two_line_button(self._close_button, "戻る", "Back", BUTTON_COLOR)

    def _tap_industry(self, x: int, y: int) -> bool:
        """「業種」の画面（区分の一覧）。区分を押すと、その区分の業種を選ぶ画面を開く。"""
        if self._close_button.collidepoint(x, y):
            self._set_page(MENU_PAGE)
            return True
        for category_id, rect in self._industry_category_buttons.items():
            if rect.collidepoint(x, y):
                self._industry_category = category_id
                self._set_page(INDUSTRY_SUB_PAGE)
                return True
        selection = self._industries
        if selection is not None and selection.ids and self._industry_bulk_button.collidepoint(x, y):
            selection.clear()
            self._on_industries_changed()
            return True
        return False

    def _tap_industry_sub(self, x: int, y: int) -> bool:
        """区分の中の業種を選ぶ画面。業種のボタンは、押すたびに選ぶ・外す。"""
        if self._close_button.collidepoint(x, y):
            self._set_page(INDUSTRY_PAGE)
            return True
        category = CATEGORY_BY_ID.get(self._industry_category or "")
        selection = self._industries
        if category is None or selection is None:
            return False
        for item, rect in zip(category.items, self._industry_item_buttons):
            if rect.collidepoint(x, y):
                selection.toggle(item.id)
                self._on_industries_changed()
                return True
        if self._industry_bulk_button.collidepoint(x, y):
            # 全部は選んでいなければ全部選ぶ。全部選んでいれば全部外す
            selection.set_category(category.id, selection.count(category.id) < len(category.items))
            self._on_industries_changed()
            return True
        return False

    @staticmethod
    def _current_choice(snap: Snapshot) -> tuple[str, str]:
        """今の「翻訳の組み合わせ」（相手の言語, 中国語の書き方）。中国語以外では書き方は使わない。"""
        partner = snap.mode.partner
        return partner, (snap.zh_script if partner == ZH else SIMPLIFIED)

    def _mode_selection(self, x: int, y: int, mode: Mode) -> Mode | None:
        """「話す人」のどちらが押されたか。"""
        for lang, rect in zip((JA, mode.partner), self._speaker_buttons):
            if rect.collidepoint(x, y):
                return Mode(mode.partner, lang)
        return None

    @staticmethod
    def _on_off_selection(buttons: list[pygame.Rect], x: int, y: int) -> bool | None:
        """「オン」「オフ」の2つのボタンのどちらが押されたか（どちらでもなければ None）。"""
        for enabled, rect in zip((True, False), buttons):
            if rect.collidepoint(x, y):
                return enabled
        return None

    def _layout_buttons(self) -> None:
        button_top = self._height - BAR_HEIGHT + (BAR_HEIGHT - BAR_BUTTON_HEIGHT) // 2
        menu_left = self._width - MARGIN - MENU_BUTTON_WIDTH
        self._menu_button = pygame.Rect(menu_left, button_top, MENU_BUTTON_WIDTH, BAR_BUTTON_HEIGHT)
        self._direction_button = pygame.Rect(
            menu_left - BUTTON_GAP - DIRECTION_BUTTON_WIDTH, button_top, DIRECTION_BUTTON_WIDTH, BAR_BUTTON_HEIGHT
        )
        self._play_button = pygame.Rect(
            self._direction_button.left - BUTTON_GAP - PLAY_BUTTON_WIDTH, button_top, PLAY_BUTTON_WIDTH, BAR_BUTTON_HEIGHT
        )
        # 画面のキーボードを開く「文字入力」ボタンは、「再生」の左
        self._keyboard_button = pygame.Rect(
            self._play_button.left - BUTTON_GAP - KEYBOARD_BUTTON_WIDTH, button_top, KEYBOARD_BUTTON_WIDTH, BAR_BUTTON_HEIGHT
        )
        # 「会話スタート」ボタン（状態表示を兼ねる）は、左側の残りの幅を使う
        self._start_button = pygame.Rect(
            MARGIN, button_top, self._keyboard_button.left - BUTTON_GAP - MARGIN, BAR_BUTTON_HEIGHT
        )
        # 画面のキーボードの画面: 右上の話す人の切り替え、入力欄と「消去」
        self._kb_swap_button = pygame.Rect(
            self._width - MARGIN - KB_SWAP_WIDTH, 6, KB_SWAP_WIDTH, KB_SWAP_HEIGHT
        )
        self._kb_clear_button = pygame.Rect(
            self._width - MARGIN - KB_CLEAR_WIDTH, KB_ENTRY_TOP, KB_CLEAR_WIDTH, KB_ENTRY_HEIGHT
        )
        self._kb_entry = pygame.Rect(
            MARGIN, KB_ENTRY_TOP, self._kb_clear_button.left - BUTTON_GAP - MARGIN, KB_ENTRY_HEIGHT
        )

        # メニュー。「翻訳の組み合わせ」は1つの横長のボタンにして、押すと言語を選ぶ画面を開く
        inner_width = self._width - 2 * MARGIN
        # 今の組み合わせを示すボタン（左）と、言語を選ぶ画面を開く「言語変更」ボタン（右）
        self._language_change_button = pygame.Rect(
            self._width - MARGIN - LANGUAGE_CHANGE_WIDTH, PAIR_TOP, LANGUAGE_CHANGE_WIDTH, MENU_BUTTON_HEIGHT
        )
        self._pair_button = pygame.Rect(
            MARGIN, PAIR_TOP, self._language_change_button.left - MENU_GAP - MARGIN, MENU_BUTTON_HEIGHT
        )
        half_width = (inner_width - MENU_GAP) // 2
        # 「翻訳の組み合わせ」の画面: 言語のボタンを LANGUAGE_COLUMNS 列に並べる
        column_width = (inner_width - (LANGUAGE_COLUMNS - 1) * MENU_GAP) // LANGUAGE_COLUMNS
        self._language_buttons = {
            choice: pygame.Rect(
                MARGIN + (i % LANGUAGE_COLUMNS) * (column_width + MENU_GAP),
                LANGUAGE_TOP + (i // LANGUAGE_COLUMNS) * (LANGUAGE_BUTTON_HEIGHT + LANGUAGE_GAP),
                column_width,
                LANGUAGE_BUTTON_HEIGHT,
            )
            for i, choice in enumerate(PAIR_CHOICES)
        }
        self._speaker_buttons = [
            pygame.Rect(MARGIN + i * (half_width + MENU_GAP), SPEAKER_TOP, half_width, MENU_BUTTON_HEIGHT) for i in range(2)
        ]
        # 「音声出力」と「翻訳の確認」は、1行に並べる（それぞれ「オン」「オフ」の2つのボタン）
        quarter_width = (half_width - BUTTON_GAP) // 2
        self._speech_buttons, self._back_translation_buttons = (
            [
                pygame.Rect(left + i * (quarter_width + BUTTON_GAP), SPEECH_TOP, quarter_width, MENU_BUTTON_HEIGHT)
                for i in range(2)
            ]
            for left in (MARGIN, MARGIN + half_width + MENU_GAP)
        )
        bottom_top = self._height - MARGIN - CLOSE_HEIGHT
        self._close_button = pygame.Rect(self._width - MARGIN - CLOSE_WIDTH, bottom_top, CLOSE_WIDTH, CLOSE_HEIGHT)
        self._sound_button = pygame.Rect(
            self._close_button.left - BUTTON_GAP - CLOSE_WIDTH, bottom_top, CLOSE_WIDTH, CLOSE_HEIGHT
        )
        self._power_button = pygame.Rect(
            self._sound_button.left - BUTTON_GAP - CLOSE_WIDTH, bottom_top, CLOSE_WIDTH, CLOSE_HEIGHT
        )
        self._wifi_button = pygame.Rect(
            self._width - MARGIN - WIFI_BUTTON_WIDTH, TOP_BUTTON_TOP, WIFI_BUTTON_WIDTH, TOP_BUTTON_HEIGHT
        )
        self._phrase_button = pygame.Rect(
            self._wifi_button.left - BUTTON_GAP - PHRASE_BUTTON_WIDTH, TOP_BUTTON_TOP, PHRASE_BUTTON_WIDTH, TOP_BUTTON_HEIGHT
        )
        # 「使い方」: メニューのボタン（「定型文」の左）、お客様用 / 店舗用の大きなボタン、スライドの場所、動画の「再生」ボタン
        self._guide_button = pygame.Rect(
            self._phrase_button.left - BUTTON_GAP - GUIDE_BUTTON_WIDTH, TOP_BUTTON_TOP, GUIDE_BUTTON_WIDTH, TOP_BUTTON_HEIGHT
        )
        self._guide_audience_buttons = {
            audience: pygame.Rect(
                MARGIN + i * (half_width + MENU_GAP), GUIDE_AUDIENCE_TOP, half_width, GUIDE_AUDIENCE_HEIGHT
            )
            for i, audience in enumerate(guide.AUDIENCES)
        }
        # 「業種」ボタンは「使い方」の左。業種の画面は、8 つの場所を 2 列に並べる（区分のボタンも、業種のボタンも同じ場所）。
        # 最後の場所は、区分の画面では「選択をすべて解除」、業種の画面では「全部選ぶ・全部外す」
        self._industry_button = pygame.Rect(
            self._guide_button.left - BUTTON_GAP - INDUSTRY_BUTTON_WIDTH, TOP_BUTTON_TOP, INDUSTRY_BUTTON_WIDTH, TOP_BUTTON_HEIGHT
        )
        industry_width = (inner_width - (INDUSTRY_COLUMNS - 1) * MENU_GAP) // INDUSTRY_COLUMNS
        industry_slots = [
            pygame.Rect(
                MARGIN + (i % INDUSTRY_COLUMNS) * (industry_width + MENU_GAP),
                INDUSTRY_TOP + (i // INDUSTRY_COLUMNS) * (INDUSTRY_BUTTON_HEIGHT + INDUSTRY_GAP),
                industry_width,
                INDUSTRY_BUTTON_HEIGHT,
            )
            for i in range(INDUSTRY_SLOTS)
        ]
        self._industry_category_buttons = {category.id: industry_slots[i] for i, category in enumerate(CATEGORIES)}
        self._industry_item_buttons = industry_slots[: INDUSTRY_SLOTS - 1]
        self._industry_bulk_button = industry_slots[-1]
        # ハングル学習: 「ガイド」の画面の左下のボタン、最初の画面の 4 項目、文字の画面の区分・字のボタンと説明の枠、下の段のボタン
        # 「ガイド」の画面の左下: 3 つの学習のボタン（「戻る」の左に収める）
        study_width = (self._close_button.left - BUTTON_GAP - MARGIN - 2 * BUTTON_GAP) // 3
        self._study_button = pygame.Rect(MARGIN, bottom_top, study_width, CLOSE_HEIGHT)
        self._study_en_button = pygame.Rect(self._study_button.right + BUTTON_GAP, bottom_top, study_width, CLOSE_HEIGHT)
        self._study_zh_button = pygame.Rect(self._study_en_button.right + BUTTON_GAP, bottom_top, study_width, CLOSE_HEIGHT)
        tile_width = (inner_width - MENU_GAP) // 2
        self._study_tiles = [
            pygame.Rect(MARGIN + (i % 2) * (tile_width + MENU_GAP), 70 + (i // 2) * 162, tile_width, 150) for i in range(len(STUDY_TILES))
        ]
        tab_width = (inner_width - 3 * BUTTON_GAP) // 4
        self._study_tabs = [
            pygame.Rect(MARGIN + i * (tab_width + BUTTON_GAP), STUDY_TAB_TOP, tab_width, STUDY_TAB_HEIGHT) for i in range(4)
        ]
        cell_width = (inner_width - (STUDY_LETTER_COLUMNS - 1) * STUDY_CELL_GAP) // STUDY_LETTER_COLUMNS
        self._study_cells = [
            pygame.Rect(
                MARGIN + (i % STUDY_LETTER_COLUMNS) * (cell_width + STUDY_CELL_GAP),
                STUDY_GRID_TOP + (i // STUDY_LETTER_COLUMNS) * (STUDY_CELL_HEIGHT + STUDY_CELL_GAP),
                cell_width,
                STUDY_CELL_HEIGHT,
            )
            for i in range(3 * STUDY_LETTER_COLUMNS)
        ]
        self._study_panel = pygame.Rect(MARGIN, STUDY_PANEL_TOP, inner_width, STUDY_PANEL_HEIGHT)

        def study_row(widths: tuple[int, ...]) -> list[pygame.Rect]:
            rects, left = [], MARGIN
            for width in widths:
                rects.append(pygame.Rect(left, bottom_top, width, CLOSE_HEIGHT))
                left += width + BUTTON_GAP
            return rects

        # 文字の画面: 聞く / 話してみる / クイズ。フレーズの画面: 前へ / 次へ / 聞く / 話してみる。クイズの画面: 聞く / 次の問題
        self._study_letters_row = study_row((130, 190, 150))
        self._study_phrases_row = study_row((110, 110, 130, 190))
        self._study_quiz_row = study_row((130, 190))
        choice_width = (inner_width - MENU_GAP) // 2
        self._study_choices = [
            pygame.Rect(MARGIN + (i % 2) * (choice_width + MENU_GAP), 184 + (i // 2) * 76, choice_width, 66) for i in range(4)
        ]
        # 動画の追加・管理: 店舗用の一覧の左下のボタン（「前へ」の左）、入れ方の 3 つのボタン、入れる場所の 4 つのボタン、
        # 入れた動画の一覧の左下の「名前を変える」「削除」
        admin_width = min(GUIDE_ADMIN_BUTTON_MAX, self._power_button.left - BUTTON_GAP - MARGIN)
        self._guide_admin_button = pygame.Rect(MARGIN, bottom_top, admin_width, CLOSE_HEIGHT)
        tile_width3 = (inner_width - 2 * MENU_GAP) // 3
        self._guide_admin_tiles = [
            pygame.Rect(MARGIN + i * (tile_width3 + MENU_GAP), GUIDE_AUDIENCE_TOP, tile_width3, GUIDE_AUDIENCE_HEIGHT) for i in range(3)
        ]
        self._guide_dest_buttons = [
            pygame.Rect(
                MARGIN + (i % 2) * (half_width + MENU_GAP),
                GUIDE_DEST_TOP + (i // 2) * (GUIDE_DEST_HEIGHT + GUIDE_DEST_GAP),
                half_width,
                GUIDE_DEST_HEIGHT,
            )
            for i in range(len(guide_admin.DESTINATIONS))
        ]
        mode_width = min(200, (self._power_button.left - BUTTON_GAP - MARGIN - BUTTON_GAP) // 2)
        self._guide_rename_button = pygame.Rect(MARGIN, bottom_top, mode_width, CLOSE_HEIGHT)
        self._guide_delete_button = pygame.Rect(MARGIN + mode_width + BUTTON_GAP, bottom_top, mode_width, CLOSE_HEIGHT)
        self._guide_image_area = pygame.Rect(0, 0, self._width, bottom_top - 8)
        self._guide_play_button = pygame.Rect(0, 0, GUIDE_PLAY_WIDTH, GUIDE_PLAY_HEIGHT)
        self._guide_play_button.center = (self._width // 2, 250)
        # 番号の画面: 右に数字のキー、左下に「戻る」
        keys_left = self._width - MARGIN - 3 * PIN_KEY_WIDTH - 2 * PIN_KEY_GAP
        self._pin_keys = {
            name: pygame.Rect(
                keys_left + (i % 3) * (PIN_KEY_WIDTH + PIN_KEY_GAP),
                PIN_KEYS_TOP + (i // 3) * (PIN_KEY_HEIGHT + PIN_KEY_GAP),
                PIN_KEY_WIDTH,
                PIN_KEY_HEIGHT,
            )
            for i, name in enumerate(PIN_KEYS)
        }
        self._pin_back_button = pygame.Rect(MARGIN, bottom_top, CLOSE_WIDTH, CLOSE_HEIGHT)
        # 定型文の画面の左下の「登録」「削除」（その右に「前へ」「次へ」「戻る」）
        self._phrase_add_button = pygame.Rect(MARGIN, bottom_top, PHRASE_ADD_WIDTH, CLOSE_HEIGHT)
        self._phrase_delete_button = pygame.Rect(
            self._phrase_add_button.right + BUTTON_GAP, bottom_top, PHRASE_DELETE_WIDTH, CLOSE_HEIGHT
        )
        self._phrase_edit_button = pygame.Rect(
            self._phrase_delete_button.right + BUTTON_GAP, bottom_top, PHRASE_EDIT_WIDTH, CLOSE_HEIGHT
        )
        self._phrase_search_button = pygame.Rect(
            self._width - MARGIN - PHRASE_SEARCH_WIDTH, TOP_BUTTON_TOP, PHRASE_SEARCH_WIDTH, TOP_BUTTON_HEIGHT
        )
        # 訂正の画面の下のボタン: 左から「覚える」「入力」「音声入力」「削除」、その右に「前へ」「次へ」（ほかの画面より狭くする）と「戻る」。
        # 「入力」と「音声入力」は、ほかの 2 つより広く（文字が収まるように）
        self._fix_next_button = pygame.Rect(
            self._width - MARGIN - CLOSE_WIDTH - BUTTON_GAP - FIX_PAGING_WIDTH, bottom_top, FIX_PAGING_WIDTH, CLOSE_HEIGHT
        )
        self._fix_prev_button = pygame.Rect(
            self._fix_next_button.left - BUTTON_GAP - FIX_PAGING_WIDTH, bottom_top, FIX_PAGING_WIDTH, CLOSE_HEIGHT
        )
        fix_space = self._fix_prev_button.left - BUTTON_GAP - MARGIN - 3 * BUTTON_GAP
        fix_wide = FIX_WIDE_WIDTH
        fix_narrow = (fix_space - 2 * fix_wide) // 2
        self._fix_keep_button = pygame.Rect(MARGIN, bottom_top, fix_narrow, CLOSE_HEIGHT)
        self._fix_type_button = pygame.Rect(self._fix_keep_button.right + BUTTON_GAP, bottom_top, fix_wide, CLOSE_HEIGHT)
        self._fix_voice_button = pygame.Rect(self._fix_type_button.right + BUTTON_GAP, bottom_top, fix_wide, CLOSE_HEIGHT)
        self._fix_delete_button = pygame.Rect(self._fix_voice_button.right + BUTTON_GAP, bottom_top, fix_narrow, CLOSE_HEIGHT)
        # Wi-Fi の画面の一覧の行と、パスワードの入力欄
        self._wifi_rows = [
            pygame.Rect(MARGIN, WIFI_ROW_TOP + i * (WIFI_ROW_HEIGHT + WIFI_ROW_GAP), inner_width, WIFI_ROW_HEIGHT)
            for i in range(WIFI_ROWS)
        ]
        self._wifi_entry = pygame.Rect(MARGIN, WIFI_ENTRY_TOP, inner_width, WIFI_ENTRY_HEIGHT)
        # 定型文の一覧の行
        self._list_rows = [
            pygame.Rect(MARGIN, LIST_ROW_TOP + i * (LIST_ROW_HEIGHT + LIST_ROW_GAP), inner_width, LIST_ROW_HEIGHT)
            for i in range(LIST_ROWS)
        ]

        # 音の設定
        self._volume_down_button, self._volume_up_button = self._step_buttons(VOLUME_TOP)
        # 「ノイズ除去」の「オン」「オフ」（音量の行の右）
        denoise_width = (self._width - MARGIN - DENOISE_LEFT - BUTTON_GAP) // 2
        self._denoise_buttons = [
            pygame.Rect(DENOISE_LEFT + i * (denoise_width + BUTTON_GAP), VOLUME_TOP, denoise_width, STEP_BUTTON_HEIGHT)
            for i in range(2)
        ]
        self._level_bar = pygame.Rect(MARGIN, LEVEL_BAR_TOP, LEVEL_BAR_WIDTH, LEVEL_BAR_HEIGHT)
        self._gain_down_button, self._gain_up_button = self._step_buttons(GAIN_TOP)
        # 「読み上げの速さ」（マイク感度の「−」「＋」の右）
        speed_value_width = self._width - MARGIN - SPEED_LEFT - 2 * SPEED_BUTTON_WIDTH
        self._speed_down_button, self._speed_up_button = self._step_buttons(
            GAIN_TOP, SPEED_LEFT, SPEED_BUTTON_WIDTH, speed_value_width
        )
        # 「話し終わりの間」（左半分）と「1回に話せる長さ」（右半分）
        self._silence_down_button, self._silence_up_button = self._step_buttons(
            SEGMENT_TOP, MARGIN, SMALL_STEP_BUTTON_WIDTH, SMALL_STEP_VALUE_WIDTH
        )
        self._max_speech_down_button, self._max_speech_up_button = self._step_buttons(
            SEGMENT_TOP, MARGIN + half_width + MENU_GAP, SMALL_STEP_BUTTON_WIDTH, SMALL_STEP_VALUE_WIDTH
        )
        self._bluetooth_button = self._sound_button  # 「戻る」の左隣
        # 「声」（標準・女性・男性）: 下の段の、「調整中は翻訳しません」の右、Bluetooth の左
        self._voice_button = pygame.Rect(
            VOICE_BUTTON_LEFT, self._close_button.top, VOICE_BUTTON_WIDTH, self._close_button.height
        )

        # Bluetooth
        self._scan_button = pygame.Rect(MARGIN, BT_BUTTON_TOP, SCAN_BUTTON_WIDTH, BT_BUTTON_HEIGHT)
        # Wi-Fi の画面の「切断」（「探す」と同じ段の右端）
        self._wifi_disconnect_button = pygame.Rect(
            self._width - MARGIN - WIFI_DISCONNECT_WIDTH, BT_BUTTON_TOP, WIFI_DISCONNECT_WIDTH, BT_BUTTON_HEIGHT
        )
        self._usb_button = pygame.Rect(
            self._scan_button.right + BUTTON_GAP, BT_BUTTON_TOP, USB_BUTTON_WIDTH, BT_BUTTON_HEIGHT
        )
        self._hid_button = pygame.Rect(
            self._width - MARGIN - HID_BUTTON_WIDTH, BT_BUTTON_TOP, HID_BUTTON_WIDTH, BT_BUTTON_HEIGHT
        )
        self._device_rows = [
            pygame.Rect(MARGIN, DEVICE_TOP + i * (DEVICE_ROW_HEIGHT + DEVICE_ROW_GAP), inner_width, DEVICE_ROW_HEIGHT)
            for i in range(MAX_DEVICE_ROWS)
        ]

        # 電源・再起動の確認（「キャンセル」「再起動」「電源を切る」）
        confirm_width = (inner_width - MENU_GAP * (CONFIRM_BUTTONS - 1)) // CONFIRM_BUTTONS
        self._cancel_button, self._reboot_button, self._confirm_power_button = (
            pygame.Rect(MARGIN + i * (confirm_width + MENU_GAP), CONFIRM_TOP, confirm_width, CONFIRM_BUTTON_HEIGHT)
            for i in range(CONFIRM_BUTTONS)
        )
        self._admin_button = pygame.Rect(
            self._width - MARGIN - ADMIN_BUTTON_WIDTH, MARGIN, ADMIN_BUTTON_WIDTH, ADMIN_BUTTON_HEIGHT
        )
        self._eco_buttons = [
            pygame.Rect(MARGIN + i * (ECO_BUTTON_WIDTH + BUTTON_GAP), ECO_TOP, ECO_BUTTON_WIDTH, ECO_BUTTON_HEIGHT)
            for i in range(2)
        ]
        # 左上の「自動オフ」: 見出しの右に「−」時刻「＋」
        self._auto_down = pygame.Rect(MARGIN + AUTO_OFF_LABEL_WIDTH, AUTO_OFF_TOP, AUTO_OFF_STEP_WIDTH, AUTO_OFF_HEIGHT)
        self._auto_up = pygame.Rect(
            self._auto_down.right + AUTO_OFF_VALUE_WIDTH, AUTO_OFF_TOP, AUTO_OFF_STEP_WIDTH, AUTO_OFF_HEIGHT
        )
        self._auto_switch = pygame.Rect(
            self._auto_up.right + AUTO_OFF_SWITCH_GAP, AUTO_OFF_TOP, AUTO_OFF_SWITCH_WIDTH, AUTO_OFF_HEIGHT
        )
        # メニューの右上、「翻訳の組み合わせ」の行の右端に出す日付・時刻（押すと時計設定が開く）
        self._clock_menu_rect = pygame.Rect(self._width - MARGIN - CLOCK_MENU_WIDTH, PAIR_LABEL_Y, CLOCK_MENU_WIDTH, 28)
        # 時計設定の画面: 年・月・日・時・分のそれぞれの「−」「＋」（上が「＋」、下が「−」）
        clock_left = (self._width - (5 * CLOCK_COLUMN_WIDTH + 4 * CLOCK_COLUMN_GAP)) // 2
        self._clock_step_buttons = []
        for i in range(5):
            left = clock_left + i * (CLOCK_COLUMN_WIDTH + CLOCK_COLUMN_GAP)
            down = pygame.Rect(left, CLOCK_DOWN_TOP, CLOCK_COLUMN_WIDTH, CLOCK_BUTTON_HEIGHT)
            up = pygame.Rect(left, CLOCK_UP_TOP, CLOCK_COLUMN_WIDTH, CLOCK_BUTTON_HEIGHT)
            self._clock_step_buttons.append((down, up))
        self._clock_ntp_buttons = [
            pygame.Rect(MARGIN + i * (CLOCK_NTP_WIDTH + BUTTON_GAP), CLOCK_NTP_TOP, CLOCK_NTP_WIDTH, CLOCK_NTP_HEIGHT)
            for i in range(2)
        ]
        self._clock_set_button = self._close_button.move(-(self._close_button.width + BUTTON_GAP), 0)
        # 管理者の画面の、期間のボタン（左上に横に並べる）
        self._admin_range_buttons = [
            pygame.Rect(MARGIN + i * (ADMIN_RANGE_WIDTH + BUTTON_GAP), 12, ADMIN_RANGE_WIDTH, ADMIN_RANGE_HEIGHT)
            for i in range(len(CHART_RANGES) + 3)  # 期間 4 つ、稼働時間、暗証番号、利用状況
        ]
        # 「暗証番号」のタブの 2 つの段（一般の番号・管理者の番号）と、それぞれの右の「変更」ボタン
        self._admin_pin_rows = {
            group: pygame.Rect(
                MARGIN, ADMIN_PIN_ROWS_TOP + i * (ADMIN_PIN_ROW_HEIGHT + ADMIN_PIN_ROW_GAP), inner_width, ADMIN_PIN_ROW_HEIGHT
            )
            for i, group in enumerate((GENERAL, ADMIN))
        }
        self._admin_pin_change_buttons = {}
        for group, row in self._admin_pin_rows.items():
            button = pygame.Rect(0, 0, ADMIN_PIN_CHANGE_WIDTH, ADMIN_PIN_CHANGE_HEIGHT)
            button.midright = (row.right - 18, row.centery)
            self._admin_pin_change_buttons[group] = button
        # 「利用状況」のタブの、種類（翻訳・訂正・定型文）のボタンと、期間（7・14・30 日）のボタン
        self._usage_kind_buttons = {
            kind: pygame.Rect(MARGIN + i * (USAGE_KIND_WIDTH + BUTTON_GAP), USAGE_ROW_TOP, USAGE_KIND_WIDTH, USAGE_ROW_HEIGHT)
            for i, kind in enumerate(ADMIN_USAGE_KINDS)
        }
        # 「翻訳回数履歴」の画面の種類のボタン（期間のボタンは、管理者の画面と同じ場所）
        self._history_kind_buttons = {
            kind: pygame.Rect(MARGIN + i * (HISTORY_KIND_WIDTH + BUTTON_GAP), USAGE_ROW_TOP, HISTORY_KIND_WIDTH, USAGE_ROW_HEIGHT)
            for i, kind in enumerate(HISTORY_KINDS)
        }
        # 電源・再起動の画面の「管理者」ボタンの下の「翻訳回数履歴」
        self._history_button = self._admin_button.move(0, ADMIN_BUTTON_HEIGHT + HISTORY_BUTTON_GAP)
        days_left = self._width - MARGIN - len(USAGE_DAYS) * USAGE_DAYS_WIDTH - (len(USAGE_DAYS) - 1) * BUTTON_GAP
        self._usage_days_buttons = {
            days: pygame.Rect(days_left + i * (USAGE_DAYS_WIDTH + BUTTON_GAP), USAGE_ROW_TOP, USAGE_DAYS_WIDTH, USAGE_ROW_HEIGHT)
            for i, days in enumerate(USAGE_DAYS)
        }
        # 稼働時間の画面の「リセット」（「戻る」の左）
        self._reset_button = self._close_button.move(-(self._close_button.width + BUTTON_GAP), 0)

    @staticmethod
    def _step_buttons(
        top: int,
        left: int = MARGIN,
        button_width: int = STEP_BUTTON_WIDTH,
        value_width: int = STEP_VALUE_WIDTH,
    ) -> tuple[pygame.Rect, pygame.Rect]:
        """「−」と「＋」のボタン（間に値を表示する）。"""
        down = pygame.Rect(left, top, button_width, STEP_BUTTON_HEIGHT)
        up = pygame.Rect(left + button_width + value_width, top, button_width, STEP_BUTTON_HEIGHT)
        return down, up

    def _redraw_if_changed(self) -> None:
        # メニューを開いているときに「スタート」と言われたら、訳文が見えるよう通訳の画面にする
        if self._state.take_main_page_request() and self._page == MENU_PAGE:
            self._set_page(MAIN_PAGE)
            self._needs_redraw = True
        snapshot = self._state.snapshot()
        now = time.monotonic()
        busy = not snapshot.idle or snapshot.listening_armed or snapshot.hearing
        self._check_auto_off(busy=busy)
        self._check_idle_off(busy or snapshot.guide_playing, now)
        saver = self._power_saver
        if saver is not None:
            # 聞き取り・翻訳・読み上げの途中は画面を点けておく。待機中にしばらく操作がなければ、画面を消す
            saver.tick(busy=not snapshot.idle or snapshot.listening_armed or snapshot.hearing)
            if saver.screen_off:
                # 画面が消えている間は描かない（点いたときに描き直す）。3 分ごとのお知らせの間だけ描いて、画面を点ける
                if saver.notice_showing and not saver.notice_lit:
                    self._draw_notice()
                    self._display.present()
                    self._notice_drawn = True
                    saver.notice_shown()
                return
            if self._notice_drawn:
                self._notice_drawn = False
                self._needs_redraw = True  # 画面にお知らせが残っているので、ふつうの画面を描き直す
        # 「使い方」の動画を再生している間は、画面を動画のプログラムが使うので、何も描かない。終わったら描き直す
        playing = self._page == GUIDE_VIEW_PAGE and snapshot.guide_playing
        if playing:
            self._guide_was_playing = True
            return
        if self._guide_was_playing:
            self._guide_was_playing = False
            self._needs_redraw = True
        # 「再生」ボタンが押せるようになった時刻を覚える（そこから BLINK_DURATION_SEC だけ明滅させる）
        if not snapshot.can_play_target:
            self._play_blink_started = None
        elif self._play_blink_started is None:
            self._play_blink_started = now
        menu_level = blink_level(now - self._menu_blink_started, BLINK_PERIOD_SEC, BLINK_DURATION_SEC)
        play_level = (
            1.0
            if self._play_blink_started is None
            else blink_level(now - self._play_blink_started, BLINK_PERIOD_SEC, BLINK_DURATION_SEC)
        )
        # 音の設定の画面では、入力レベルのバーを動かすため一定間隔で描き直す
        # 管理者の画面は、開いている間に足された記録が出るよう、ときどき描き直す
        level_due = (self._page == SOUND_PAGE and now - self._last_draw >= LEVEL_REDRAW_SEC) or (
            # 「切断」を 1 回押したあとは、確かめの表示を消すため 1 秒ごとに描き直す
            self._page == WIFI_PAGE
            and now - self._wifi_disconnect_armed_at <= ADMIN_CONFIRM_SEC + 1
            and now - self._last_draw >= 1.0
        ) or (
            self._page == ADMIN_PAGE
            # 「リセット」を 1 回押した後は、確かめる表示を消すため 1 秒ごと
            and now - self._last_draw >= (1.0 if now - self._reset_armed_at <= ADMIN_CONFIRM_SEC + 1 else ADMIN_RELOAD_SEC)
        )
        # 動画の追加・管理: 入れている途中の進み具合と、USB メモリを探し終えたときに描き直す
        level_due = level_due or (self._page in GUIDE_ADMIN_PAGES and self._guide_admin_versions() != self._drawn_guide_admin)
        # メニュー画面の「通訳表示」と、通訳画面の「再生」は、明るさを少しずつ変えるため一定間隔で描き直す。
        # 明滅が止まったあとは明るさが変わらないので、描き直しもそこで止まる
        blink_due = (
            self._page == MENU_PAGE and menu_level != self._drawn_menu_level and now - self._last_draw >= BLINK_REDRAW_SEC
        ) or (
            self._page == MAIN_PAGE
            and snapshot.can_play_target
            and play_level != self._drawn_play_level
            and now - self._last_draw >= PLAY_BLINK_REDRAW_SEC
        )
        # 日付・時刻は、分が変わったら描き直す（メニューと時計設定の画面）
        clock_due = self._page in (MENU_PAGE, CLOCK_PAGE) and format_clock(datetime.now()) != self._drawn_clock_stamp
        if snapshot.version == self._drawn_version and not self._needs_redraw and not level_due and not blink_due and not clock_due:
            # マウスのポインターだけが動いたときは、描いてある画面にポインターを描き足して出し直す
            if self._pointer_dirty and now - self._last_pointer_draw >= POINTER_REDRAW_SEC:
                self._display.present()
                self._pointer_dirty = False
                self._last_pointer_draw = now
            return
        self._pointer_dirty = False
        self._blink_level, self._play_blink_level = menu_level, play_level
        draw = {
            MAIN_PAGE: self._draw_main,
            MENU_PAGE: self._draw_menu,
            LANGUAGE_PAGE: self._draw_language,
            SOUND_PAGE: self._draw_sound,
            BLUETOOTH_PAGE: self._draw_bluetooth,
            INPUT_PAGE: self._draw_input,
            POWER_PAGE: self._draw_power_confirm,
            ADMIN_PAGE: self._draw_admin,
            USAGE_PAGE: self._draw_history,
            SHUTDOWN_PAGE: self._draw_shutdown,
            REBOOT_PAGE: self._draw_reboot,
            PHRASES_PAGE: self._draw_phrases,
            PHRASE_EDIT_PAGE: self._draw_phrase_edit,
            KEYBOARD_PAGE: self._draw_keyboard,
            WIFI_PAGE: self._draw_wifi,
            WIFI_PASSWORD_PAGE: self._draw_wifi_password,
            GUIDE_PAGE: self._draw_guide,
            PIN_PAGE: self._draw_pin,
            FIX_PAGE: self._draw_fix_page,
            GUIDE_LIST_PAGE: self._draw_guide_list,
            GUIDE_VIEW_PAGE: self._draw_guide_view,
            GUIDE_ADMIN_PAGE: self._draw_guide_admin,
            GUIDE_USB_PAGE: self._draw_guide_usb,
            GUIDE_DEST_PAGE: self._draw_guide_dest,
            GUIDE_UPLOAD_PAGE: self._draw_guide_upload,
            GUIDE_MANAGE_PAGE: self._draw_guide_manage,
            INDUSTRY_PAGE: self._draw_industry,
            INDUSTRY_SUB_PAGE: self._draw_industry_sub,
            STUDY_PAGE: self._draw_study,
            STUDY_LETTERS_PAGE: self._draw_study_letters,
            STUDY_PHRASE_PAGE: self._draw_study_phrases,
            STUDY_QUIZ_PAGE: self._draw_study_quiz,
            CLOCK_PAGE: self._draw_clock,
        }[self._page]
        draw(snapshot)
        self._draw_idle_warning()
        self._display.present()
        self._drawn_version = snapshot.version
        self._drawn_menu_level, self._drawn_play_level = menu_level, play_level
        self._needs_redraw = False
        self._last_draw = now

    def _draw_notice(self) -> None:
        """省電力モードで画面が消えている間に、3 分ごとに数秒出すお知らせ（日本語と英語）。"""
        self._surface.fill(BACKGROUND)
        font = self._fonts[JA]
        width = self._width - 2 * MARGIN
        y = 36
        for title, body, color in ((*NOTICE_TITLE[:1], NOTICE_BODY[0], TEXT_COLOR), (*NOTICE_TITLE[1:], NOTICE_BODY[1], SUBTEXT_COLOR)):
            title_surface, _ = font.render(title, color, size=38)
            self._surface.blit(title_surface, (MARGIN, y))
            bottom = self._draw_text(body, font, pygame.Rect(MARGIN, y + 56, width, 120), (30, 26, 22), color)
            y = bottom + 34
            if color == TEXT_COLOR:
                self._draw_divider(y - 17)
        self._draw_label(NOTICE_HINT, MARGIN, self._height - 46, 20, SUBTEXT_COLOR)

    def _draw_main(self, snap: Snapshot) -> None:
        self._surface.fill(BACKGROUND)
        self._retry_button = None
        self._fix_button = None
        text_width = self._width - TEXT_LEFT - MARGIN
        content_bottom = self._height - BAR_HEIGHT - SECTION_GAP
        if not snap.ready:
            # 起動中は、何を読み込んでいるか（起動できなければその理由）を、画面いっぱいに大きく出す
            rect = pygame.Rect(MARGIN, 40, self._width - 2 * MARGIN, content_bottom - 40)
            if snap.startup_error:
                self._draw_text(snap.startup_error, self._fonts[JA], rect, STARTUP_ERROR_SIZES, TEXT_COLOR)
            else:
                self._draw_startup(snap)
            self._draw_bar(snap)
            return

        # 上段: 原文と、その発音記号（発音記号は文のすぐ下に出す）
        top = CONTENT_TOP
        text_bottom = top
        if snap.source_text:
            self._draw_chip(snap.source_lang, MARGIN, top + 2, snap.zh_traditional)
            rect = pygame.Rect(TEXT_LEFT, top, text_width, SOURCE_HEIGHT)
            text_bottom = self._draw_text(
                snap.source_text, self._fonts[self._font_key(snap.source_lang, snap)], rect, SOURCE_SIZES, SUBTEXT_COLOR
            )
        top += SOURCE_HEIGHT
        # 発音記号は翻訳のたびに出す（無いときは、その分の高さも使わない）
        if snap.source_pron:
            self._draw_pron(snap.source_pron, pygame.Rect(TEXT_LEFT, text_bottom, text_width, PRON_HEIGHT))
            top += PRON_HEIGHT
        self._draw_divider(top + SECTION_GAP // 2)

        # 下端: 確認用に、元の言語へ訳し戻した文（翻訳の確認がオフなら、この欄を作らず訳文に使う）
        # 翻訳の確認は日本語で話したときだけなので、韓国語などで話した発話にも、この欄は作らない
        back_top = content_bottom - BACK_HEIGHT if snap.shows_back_translation else content_bottom + SECTION_GAP
        if snap.shows_back_translation:
            self._draw_divider(back_top - SECTION_GAP)
        if snap.shows_back_translation and snap.back_text:
            chip = pygame.Rect(MARGIN, back_top, CHIP_WIDTH, CHIP_HEIGHT)
            pygame.draw.rect(self._surface, BACK_CHIP_COLOR, chip, border_radius=8)
            self._blit_centered("確認", chip, 17, JA)
            rect = pygame.Rect(TEXT_LEFT, back_top + 2, text_width, BACK_HEIGHT)
            self._draw_text(snap.back_text, self._fonts[snap.back_lang], rect, BACK_SIZES, SUBTEXT_COLOR)

        # 中段: 訳文と、その発音記号（発音記号の分の高さを空けておき、訳文のすぐ下に出す）
        if snap.target_lang:
            top += SECTION_GAP + 8
            bottom = back_top - 2 * SECTION_GAP - (PRON_HEIGHT if snap.target_pron else 0)
            self._draw_chip(snap.target_lang, MARGIN, top + 4, snap.zh_traditional)
            # 訳文の言語の印の下に「訳し直し」（訳文が出ていて、何も処理していないときだけ）
            retry = pygame.Rect(MARGIN, top + 4 + CHIP_HEIGHT + 10, CHIP_WIDTH, RETRY_BUTTON_HEIGHT)
            if snap.target_text and snap.idle and not snap.listening_armed and retry.bottom <= back_top - SECTION_GAP:
                self._retry_button = retry
                pygame.draw.rect(self._surface, BUTTON_COLOR, retry, border_radius=8)
                self._blit_centered_at("訳し", retry, 18, 0.24)
                self._blit_centered_at("直し", retry, 18, 0.52)
                self._blit_centered_at("Retry", retry, 13, 0.81)
                # 「訳し直し」の下に「訂正」（置ける高さがあるときだけ）。押すと一般の番号を聞く
                fix = pygame.Rect(retry.left, retry.bottom + FIX_BUTTON_GAP, CHIP_WIDTH, FIX_BUTTON_HEIGHT)
                if fix.bottom <= back_top - SECTION_GAP:
                    self._fix_button = fix
                    self._draw_two_line_button(fix, "訂正", "Fix", BUTTON_COLOR, title_size=17, subtitle_size=12)
            rect = pygame.Rect(TEXT_LEFT, top, text_width, bottom - top)
            text_bottom = self._draw_text(
                snap.target_text,
                self._fonts[self._font_key(snap.target_lang, snap)],
                rect,
                TARGET_SIZES,
                TEXT_COLOR,
            )
            if snap.target_pron:
                self._draw_pron(snap.target_pron, pygame.Rect(TEXT_LEFT, text_bottom, text_width, PRON_HEIGHT))

        self._draw_text_entry(snap)
        self._draw_bar(snap)

    def _brand_text(self, text: str, color: tuple[int, int, int], size: int) -> pygame.Surface:
        """製品名の文字（太くて読みやすい書体）の絵。"""
        surface, _ = self._brand_font.render(text, color, size=size, style=self._brand_style)
        return surface

    def _brand_width(self, text: str, size: int) -> int:
        return self._brand_font.get_rect(text, style=self._brand_style, size=size).width

    def _logo_surface(self) -> pygame.Surface | None:
        """会社のロゴの画像（読めなかったら None。ロゴが無くても、起動の画面は出す）。"""
        if not self._logo_loaded:
            self._logo_loaded = True
            try:
                image = pygame.image.load(str(LOGO_FILE))
                # 画面（pygame.display）を開いているときだけ、画面に合わせた形式に直す（Pi のフレームバッファ表示では開かないので、そのまま使う）
                self._logo = image.convert() if pygame.display.get_surface() is not None else image
            except (pygame.error, FileNotFoundError, OSError):
                log.warning("ロゴの画像を読めませんでした: %s", LOGO_FILE, exc_info=True)
        return self._logo

    def _draw_startup(self, snap: Snapshot) -> None:
        """起動中の画面: 左に会社のロゴ、右に「AI-Translator」を大きく出し、その下に、起動の進み具合の横棒グラフと、読み込んでいるものを出す。"""
        center_y = (self._height - BAR_HEIGHT - SECTION_GAP) // 2
        right = self._width - MARGIN
        left = MARGIN
        logo = self._logo_surface()
        if logo is not None:
            card = pygame.Rect(0, 0, logo.get_width() + 2 * LOGO_CARD_PAD, logo.get_height() + 2 * LOGO_CARD_PAD)
            card.midleft = (LOGO_CARD_LEFT, center_y)
            pygame.draw.rect(self._surface, LOGO_CARD_COLOR, card, border_radius=16)
            self._surface.blit(logo, (card.left + LOGO_CARD_PAD, card.top + LOGO_CARD_PAD))
            left = card.right + 24
        room = right - left
        center_x = (left + right) // 2
        font = self._fonts[JA]
        title_size = next((s for s in STARTUP_TITLE_SIZES if self._brand_width(PRODUCT_NAME, s) <= room), STARTUP_TITLE_SIZES[-1])
        title = self._brand_text(PRODUCT_NAME, TEXT_COLOR, title_size)
        self._surface.blit(title, title.get_rect(center=(center_x, center_y + STARTUP_TITLE_DY)))
        # 「『コトリア』(Kotoria)」と、その右の向かい合う小鳥を、まとめて真ん中にそろえる（収まる大きさを選ぶ）
        for brand_size in STARTUP_BRAND_SIZES:
            birds = icons.birds_surface(round(brand_size * STARTUP_BIRDS_RATIO))
            text_width = self._brand_width(PRODUCT_BRAND, brand_size)
            if text_width + STARTUP_BIRDS_GAP + birds.get_width() <= room:
                break
        brand = self._brand_text(PRODUCT_BRAND, TEXT_COLOR, brand_size)
        block_left = center_x - (text_width + STARTUP_BIRDS_GAP + birds.get_width()) // 2
        brand_y = center_y + STARTUP_BRAND_DY
        self._surface.blit(brand, brand.get_rect(midleft=(block_left, brand_y)))
        self._surface.blit(birds, birds.get_rect(midleft=(block_left + text_width + STARTUP_BIRDS_GAP, brand_y)))
        sub, _ = font.render("起動中… / Starting up", SUBTEXT_COLOR, size=STARTUP_SUB_SIZE)
        self._surface.blit(sub, sub.get_rect(center=(center_x, center_y + STARTUP_SUB_DY)))
        track = pygame.Rect(0, 0, min(STARTUP_BAR_MAX_WIDTH, room), STARTUP_BAR_HEIGHT)
        track.midleft = (center_x - track.width // 2, center_y + STARTUP_BAR_DY)
        pygame.draw.rect(self._surface, BUTTON_COLOR, track, border_radius=STARTUP_BAR_HEIGHT // 2)
        progress = min(1.0, max(0.0, snap.startup_progress))
        fill_width = round(track.width * progress)
        if fill_width >= STARTUP_BAR_HEIGHT:  # 丸い両端が描ける長さになってから塗る
            fill = pygame.Rect(track.left, track.top, fill_width, track.height)
            pygame.draw.rect(self._surface, START_COLOR, fill, border_radius=STARTUP_BAR_HEIGHT // 2)
        percent, _ = font.render(f"{round(progress * 100)}%", TEXT_COLOR, size=STARTUP_PERCENT_SIZE)
        self._surface.blit(percent, percent.get_rect(center=(center_x, center_y + STARTUP_PERCENT_DY)))
        # 今読み込んでいるもの（長いときは小さくして、はみ出さない）
        size = next((s for s in STARTUP_STATUS_SIZES if font.get_rect(snap.status, size=s).width <= room), STARTUP_STATUS_SIZES[-1])
        status, _ = font.render(snap.status, SUBTEXT_COLOR, size=size)
        self._surface.blit(status, status.get_rect(center=(center_x, center_y + STARTUP_STATUS_DY), width=min(status.get_width(), room)))

    def _draw_text_entry(self, snap: Snapshot) -> None:
        """キーボードで打っている途中の文（下のバーのすぐ上に重ねて出す）。"""
        if not self._entry.active:
            return
        rect = pygame.Rect(MARGIN, self._height - BAR_HEIGHT - ENTRY_HEIGHT - 6, self._width - 2 * MARGIN, ENTRY_HEIGHT)
        pygame.draw.rect(self._surface, ENTRY_COLOR, rect, border_radius=8)
        pygame.draw.rect(self._surface, ENTRY_BORDER_COLOR, rect, width=2, border_radius=8)
        lang = self._entry.lang
        hint = f"キーボード入力：{INPUT_HINTS.get(lang, '')}　{ENTRY_HINT}"
        self._draw_label(hint, rect.left + 12, rect.top + 4, 14, SUBTEXT_COLOR)
        # 長くなったら、打っている最後の部分が見えるように、前を省いて出す
        font = self._fonts[self._font_key(lang, snap)]
        text, size = self._fit_entry(font, self._entry.display, rect.width - 32, ENTRY_SIZES)
        baseline = rect.bottom - 14
        font.render_to(self._surface, (rect.left + 12, baseline), text, fgcolor=TEXT_COLOR, size=size)
        # 文字を打つ位置（縦の線）
        cursor_x = rect.left + 14 + (font.get_rect(text, size=size).width if text else 0)
        pygame.draw.line(self._surface, TEXT_COLOR, (cursor_x, baseline - size), (cursor_x, baseline + 4), 2)

    @staticmethod
    def _fit_entry(font: pygame.freetype.Font, full: str, width: int, sizes: tuple[int, ...]) -> tuple[str, int]:
        """入力欄に収まる文字の大きさを選ぶ。最小の大きさでも収まらなければ、前を省いて「…」を付ける。"""
        for size in sizes:
            if font.get_rect(full, size=size).width <= width:
                return full, size
        size, text = sizes[-1], full
        while text and font.get_rect("…" + text, size=size).width > width:
            text = text[1:]
        return "…" + text, size

    def _draw_bar(self, snap: Snapshot) -> None:
        """下のバー: 「会話スタート」ボタン、「文字入力」ボタン、「再生」ボタン、話す人の切り替えボタン、メニューボタン。"""
        bar_top = self._height - BAR_HEIGHT
        pygame.draw.rect(self._surface, BAR_COLOR, (0, bar_top, self._width, BAR_HEIGHT))
        self._draw_start_button(snap)
        # 押せるときは、明るさが少しずつ変わる紫にする（訳文が表示されていない間は暗いまま）
        playable = snap.can_play_target
        play_color = (
            mix_color(PLAY_DARK_COLOR, PLAY_BRIGHT_COLOR, self._play_blink_level) if playable else DISABLED_BUTTON_COLOR
        )
        # ボタンの文字は、訳す前の言語（話した人の言語）で出す。長い「もう一度再生」は少し小さくする
        play_lang = snap.source_lang or snap.mode.speaker
        labels, size = (PLAY_AGAIN_LABELS, 20) if snap.target_played else (PLAY_LABELS, 26)
        self._draw_button(
            self._play_button, labels.get(play_lang, labels[JA]), size, play_color, self._font_key(play_lang, snap)
        )
        self._draw_direction(self._direction_button, snap, 22)
        # 画面のキーボードを開く（起動が終わるまでは暗い）
        self._draw_two_line_button(
            self._keyboard_button, "文字入力", "Keyboard", BUTTON_COLOR if snap.ready else DISABLED_BUTTON_COLOR, title_size=17
        )
        self._draw_button(self._menu_button, "メニュー", 22, BUTTON_COLOR)

    def _draw_direction(self, rect: pygame.Rect, snap: Snapshot, size: int) -> None:
        """「日本語 → ภาษาไทย」のボタン（話す人 → 訳す先）。書体の違う言語名が並ぶので、言語ごとの書体で描く。"""
        speaker, listener = snap.mode.speaker, snap.mode.listener
        pygame.draw.rect(self._surface, BUTTON_ACTIVE_COLOR, rect, border_radius=10)
        runs = [
            (NATIVE_NAMES[speaker], self._font_key(speaker, snap)),
            (" → ", JA),
            (NATIVE_NAMES[listener], self._font_key(listener, snap)),
        ]
        self._blit_runs_centered(runs, rect, size)

    def _draw_menu_brand(self) -> None:
        """「話す人 / Speaker」の行の右端に、「AI-Translator コトリア (Kotoria)」と、向かい合う小鳥の印を出す（太い書体）。"""
        center_y = SPEAKER_LABEL_Y + MENU_BRAND_DY
        birds = icons.birds_surface(MENU_BIRDS_SIZE)
        birds_rect = birds.get_rect(midright=(self._width - MARGIN, center_y))
        self._surface.blit(birds, birds_rect)
        romaji = self._brand_text(MENU_PRODUCT_ROMAJI, TEXT_COLOR, MENU_BRAND_EN_SIZE)
        romaji_rect = romaji.get_rect(midright=(birds_rect.left - 4, center_y))
        self._surface.blit(romaji, romaji_rect)
        name = self._brand_text(MENU_PRODUCT_NAME, TEXT_COLOR, PRODUCT_NAME_SIZE)
        name_rect = name.get_rect(midright=(romaji_rect.left - 6, center_y))
        self._surface.blit(name, name_rect)
        english = self._brand_text(PRODUCT_NAME, TEXT_COLOR, MENU_BRAND_EN_SIZE)
        self._surface.blit(english, english.get_rect(midright=(name_rect.left - 10, center_y)))

    def _draw_menu(self, snap: Snapshot) -> None:
        mode = snap.mode
        self._surface.fill(MENU_BACKGROUND)
        self._draw_label("メニュー", MARGIN, MENU_TITLE_Y, 30, TEXT_COLOR)
        # 今の日付・時刻（押すと「時計設定」が開く）。製品名は、下の「話す人 / Speaker」の行に出す
        clock_rect = self._clock_menu_rect
        pygame.draw.rect(self._surface, MENU_CLOCK_COLOR, clock_rect, border_radius=8)
        stamp = format_clock(datetime.now())
        clock_text, _ = self._fonts[JA].render(stamp, TEXT_COLOR, size=17)
        self._surface.blit(clock_text, clock_text.get_rect(center=clock_rect.center))
        self._drawn_clock_stamp = stamp
        # 右上の「業種」「使い方」「定型文」「Wi-Fi設定」（相手の人も分かるよう、2 行目に英語）
        industry = self._industry_button
        pygame.draw.rect(self._surface, INDUSTRY_BUTTON_COLOR, industry, border_radius=10)
        self._blit_centered_at("業種", industry, 18, 0.34, BUTTON_ICON_TEXT_SHIFT)
        self._blit_centered_at("Industry", industry, 13, 0.77, BUTTON_ICON_TEXT_SHIFT)
        self._draw_button_icon(icons.CHECKLIST, industry)
        selected_count = len(self._industries.ids) if self._industries is not None else 0
        if selected_count:
            # 業種を選んでいるときは、ボタンの右上の角に選んでいる数を出す
            badge = pygame.Rect(0, 0, 26, 26)
            badge.center = (industry.right - 6, industry.top + 6)
            pygame.draw.ellipse(self._surface, BLINK_BRIGHT_COLOR, badge)
            self._blit_centered(str(selected_count), badge, 16, EN)
        wifi = self._wifi_button
        pygame.draw.rect(self._surface, WIFI_BUTTON_COLOR, wifi, border_radius=10)
        self._blit_centered_at("Wi-Fi設定", wifi, 18, 0.34, BUTTON_ICON_TEXT_SHIFT)
        self._blit_centered_at("Wi-Fi settings", wifi, 13, 0.77, BUTTON_ICON_TEXT_SHIFT)
        self._draw_button_icon(icons.WIFI, wifi)
        manual = self._guide_button
        pygame.draw.rect(self._surface, GUIDE_BUTTON_COLOR, manual, border_radius=10)
        self._blit_centered_at("ガイド", manual, 18, 0.34, BUTTON_ICON_TEXT_SHIFT)
        self._blit_centered_at("Guide", manual, 13, 0.77, BUTTON_ICON_TEXT_SHIFT)
        self._draw_button_icon(icons.GUIDE, manual)
        phrase = self._phrase_button
        pygame.draw.rect(self._surface, PHRASE_BUTTON_COLOR, phrase, border_radius=10)
        self._blit_centered_at("定型文", phrase, 18, 0.34, BUTTON_ICON_TEXT_SHIFT)
        self._blit_centered_at("Phrases", phrase, 13, 0.77, BUTTON_ICON_TEXT_SHIFT)
        self._draw_button_icon(icons.BUBBLE, phrase)

        # 相手の言語の人も読めるよう、見出しは英語を併記する
        self._draw_fitted_label("翻訳の組み合わせ / Language pair", MARGIN, PAIR_LABEL_Y)
        # 今の組み合わせ（1行目は各言語の文字で、2行目は英語で）
        choice = self._current_choice(snap)
        rect = self._pair_button
        pygame.draw.rect(self._surface, BUTTON_ACTIVE_COLOR, rect, border_radius=10)
        self._blit_runs_centered(
            [("日本語 ⇔ ", JA), (PAIR_LABELS[choice], self._choice_font(choice))],
            rect,
            26,
            center_y=rect.top + round(rect.height * 0.38),
        )
        self._blit_centered_at(f"Japanese ⇔ {PAIR_ENGLISH_NAMES[choice]}", rect, 16, 0.76)
        # 両側に、日本と相手の国の旗
        self._draw_flag(JA, False, FLAG_WIDTH_PAIR, midleft=(rect.left + FLAG_LEFT, rect.centery))
        self._draw_flag(choice[0], choice[1] == TRADITIONAL, FLAG_WIDTH_PAIR, midright=(rect.right - FLAG_LEFT, rect.centery))
        # 言語を選ぶ画面を開くボタン
        change = self._language_change_button
        pygame.draw.rect(self._surface, BUTTON_COLOR, change, border_radius=10)
        self._blit_centered_at("言語変更 ▶", change, 26, 0.38)
        self._blit_centered_at("Change language", change, 16, 0.76)

        self._draw_fitted_label("話す人 / Speaker", MARGIN, SPEAKER_LABEL_Y)
        self._draw_menu_brand()
        for lang, rect in zip((JA, mode.partner), self._speaker_buttons):
            color = BUTTON_ACTIVE_COLOR if lang == mode.speaker else BUTTON_COLOR
            label = SPEAK_LABEL_ZH_HANT if lang == ZH and snap.zh_traditional else SPEAK_LABELS[lang]
            self._draw_button(rect, label, 28, color, self._font_key(lang, snap))
            self._draw_flag(lang, snap.zh_traditional, FLAG_WIDTH_PAIR, midleft=(rect.left + FLAG_LEFT, rect.centery))

        # スピーカーが見つからない・開けない間は、ボタンを暗く表示する
        self._draw_on_off(
            "音声出力 / Voice output",
            self._speech_buttons,
            snap.speech_enabled,
            available=snap.speech_output_available,
            english=True,
            icon=icons.SPEAKER,
        )
        # 翻訳の確認は日本語で話すときだけ行う。相手の言語で話す人を選んでいる間は、ボタンを暗く表示する
        self._draw_on_off(
            "翻訳の確認（日本語で話すときのみ）",
            self._back_translation_buttons,
            snap.back_translation_enabled,
            available=snap.back_translation_available,
        )

        close = self._close_button
        self._draw_status(snap.status, MARGIN, close.centery, self._power_button.left - MARGIN - BUTTON_GAP)
        # 「電源を切る」だけでなく「再起動」も選べる。印の分だけ狭いので、6 文字を小さく書き、2 行目に英語を書く
        self._draw_two_line_button(
            self._power_button, "電源・再起動", "Power", POWER_BUTTON_COLOR, title_size=17, icon=icons.POWER, subtitle_size=14
        )
        self._draw_two_line_button(self._sound_button, "音の設定", "Sound", NAVY_BUTTON_COLOR, title_size=24, icon=icons.SPEAKER)
        # 次に押すボタンだと分かるように、「通訳表示」は BLINK_PERIOD_SEC ごとに明るいオレンジになり、
        # そこから少しずつ暗くなる（白い枠も一緒に暗くする）
        level = self._blink_level
        # ボタンの幅に1行では収まらないので、英語は2行目に小さく書く
        pygame.draw.rect(self._surface, mix_color(BLINK_DARK_COLOR, BLINK_BRIGHT_COLOR, level), close, border_radius=10)
        title, _ = self._fonts[JA].render("▶ 通訳表示", TEXT_COLOR, size=24)
        subtitle, _ = self._fonts[JA].render("Interpreter", TEXT_COLOR, size=16)
        self._surface.blit(title, title.get_rect(center=(close.centerx, close.top + close.height * 0.38)))
        self._surface.blit(subtitle, subtitle.get_rect(center=(close.centerx, close.top + close.height * 0.76)))
        border = mix_color(BLINK_BORDER_DARK_COLOR, TEXT_COLOR, level)
        pygame.draw.rect(self._surface, border, close, width=3, border_radius=10)

    def _draw_clock(self, snap: Snapshot) -> None:
        """「時計設定」の画面: 今の日付・時刻、年・月・日・時・分の「＋」「−」、「設定する」、ネットワークでの自動合わせ。"""
        self._surface.fill(MENU_BACKGROUND)
        self._draw_fitted_label("時計設定 / Clock", MARGIN, MENU_TITLE_Y - 4, TITLE_SIZES, TEXT_COLOR)
        stamp = format_clock(datetime.now())
        self._drawn_clock_stamp = stamp
        self._draw_label(f"今の時刻 / Now:  {stamp}", MARGIN, MENU_TITLE_Y + 34, 22, SUBTEXT_COLOR)
        fields = self._clock_fields
        values = (f"{fields.year}", f"{fields.month}", f"{fields.day}", f"{fields.hour:02d}", f"{fields.minute:02d}")
        for (_field, ja, en), (down, up), value in zip(CLOCK_FIELD_LABELS, self._clock_step_buttons, values):
            self._draw_button(up, "+", 40, BUTTON_COLOR)
            self._draw_button(down, "−", 40, BUTTON_COLOR)
            caption, _ = self._fonts[JA].render(f"{ja} / {en}", SUBTEXT_COLOR, size=18)
            self._surface.blit(caption, caption.get_rect(midtop=(up.centerx, CLOCK_LABEL_Y)))
            text, _ = self._fonts[EN].render(value, TEXT_COLOR, size=40)
            self._surface.blit(text, text.get_rect(center=(up.centerx, CLOCK_VALUE_Y)))
        # ネットワークでの自動合わせ（つながっている場所では、オンのままでよい。手で合わせると、オフになる）
        available = self._clock_ntp is not None
        self._draw_on_off(
            "ネットワークで自動に合わせる / Auto sync",
            self._clock_ntp_buttons,
            bool(self._clock_ntp),
            available=available,
            label_y=CLOCK_NTP_LABEL_Y,
            english=True,
        )
        self._draw_label(
            "つながっていない場所では、オフにして上で合わせます",
            self._clock_ntp_buttons[-1].right + BUTTON_GAP,
            CLOCK_NTP_TOP + 14,
            15,
            SUBTEXT_COLOR,
        )
        self._draw_two_line_button(self._clock_set_button, "設定する", "Set", BUTTON_ACTIVE_COLOR)
        self._draw_two_line_button(self._close_button, "戻る", "Back", BUTTON_COLOR)
        if self._clock_message:
            self._draw_label(self._clock_message, MARGIN, self._close_button.centery - 12, 22, TEXT_COLOR)

    def _draw_language(self, snap: Snapshot) -> None:
        """「翻訳の組み合わせ」の画面: 日本語と組み合わせる相手の言語を選ぶ（選んでいるものは青）。"""
        self._surface.fill(MENU_BACKGROUND)
        self._draw_fitted_label(LANGUAGE_PAGE_TITLE, MARGIN, MENU_TITLE_Y - 4, TITLE_SIZES, TEXT_COLOR)
        self._draw_label(LANGUAGE_PAGE_SUBTITLE, MARGIN, MENU_TITLE_Y + 30, 17, SUBTEXT_COLOR)
        current = self._current_choice(snap)
        for choice, rect in self._language_buttons.items():
            # 1行目はその言語の文字で、2行目は日本語で書く
            color = BUTTON_ACTIVE_COLOR if choice == current else BUTTON_COLOR
            pygame.draw.rect(self._surface, color, rect, border_radius=10)
            # 文字は、旗の右の場所の真ん中に書く（3 列に並べているので、旗と重ならないようにする）
            flag_room = FLAG_LEFT + FLAG_WIDTH_BUTTON + 4
            text_rect = pygame.Rect(rect.left + flag_room, rect.top, rect.width - flag_room - 6, rect.height)
            center_y = rect.top + round(rect.height * 0.38)
            self._blit_runs_centered([(PAIR_LABELS[choice], self._choice_font(choice))], text_rect, 24, center_y=center_y)
            self._blit_centered_at(PAIR_JAPANESE_NAMES[choice], text_rect, 15, 0.76)
            self._draw_flag(choice[0], choice[1] == TRADITIONAL, FLAG_WIDTH_BUTTON, midleft=(rect.left + FLAG_LEFT, rect.centery))
        close = self._close_button
        # 読み上げない言語のお知らせを、日本語・広東語・タイ語の3行で出す（それぞれの言語の書体で）
        for i, (text, lang) in enumerate(NOT_SPOKEN_NOTICES):
            surface, _ = self._fonts[lang].render(text, SUBTEXT_COLOR, size=17)
            self._surface.blit(surface, (MARGIN, close.top - 6 + i * 24))
        self._draw_two_line_button(close, "戻る", "Back", BUTTON_COLOR)

    def _draw_industry(self, snap: Snapshot) -> None:
        """「業種」の画面: 区分のボタン（選んでいる業種がある区分は青で、選んだ数 / 区分の業種の数を右に出す）。"""
        self._surface.fill(MENU_BACKGROUND)
        self._draw_fitted_label(INDUSTRY_PAGE_TITLE, MARGIN, MENU_TITLE_Y - 4, TITLE_SIZES, TEXT_COLOR)
        self._draw_label(INDUSTRY_PAGE_SUBTITLE, MARGIN, MENU_TITLE_Y + 30, 17, SUBTEXT_COLOR)
        selection = self._industries
        for category in CATEGORIES:
            rect = self._industry_category_buttons[category.id]
            count = selection.count(category.id) if selection is not None else 0
            pygame.draw.rect(self._surface, BUTTON_ACTIVE_COLOR if count else BUTTON_COLOR, rect, border_radius=10)
            self._blit_centered_at(category.ja, rect, 24, 0.38)
            self._blit_centered_at(category.en, rect, 15, 0.76)
            if count:
                badge, _ = self._fonts[EN].render(f"{count}/{len(category.items)}", TEXT_COLOR, size=20)
                self._surface.blit(badge, badge.get_rect(midright=(rect.right - 16, rect.centery)))
        # 8 つ目の場所: 選んでいる業種をすべて外す（何も選んでいなければ暗くして、押せないことを示す）
        bulk = self._industry_bulk_button
        active = selection is not None and bool(selection.ids)
        pygame.draw.rect(self._surface, BUTTON_COLOR if active else DISABLED_BUTTON_COLOR, bulk, border_radius=10)
        color = TEXT_COLOR if active else SUBTEXT_COLOR
        for text, size, ratio in (("選択をすべて解除", 22, 0.38), ("Clear all", 15, 0.76)):
            surface, _ = self._fonts[JA].render(text, color, size=size)
            self._surface.blit(surface, surface.get_rect(center=(bulk.centerx, bulk.top + round(bulk.height * ratio))))
        self._draw_industry_hint(INDUSTRY_HINT, INDUSTRY_HINT_EN)
        self._draw_two_line_button(self._close_button, "戻る", "Back", BUTTON_COLOR)

    def _draw_industry_sub(self, snap: Snapshot) -> None:
        """区分の中の業種の画面: 業種のボタンは、選んでいるものが青で、左にチェックの印が付く。"""
        self._surface.fill(MENU_BACKGROUND)
        category = CATEGORY_BY_ID.get(self._industry_category or "") or CATEGORIES[0]
        self._draw_fitted_label(f"{category.ja}の業種", MARGIN, MENU_TITLE_Y - 4, TITLE_SIZES, TEXT_COLOR)
        self._draw_label(category.en, MARGIN, MENU_TITLE_Y + 30, 17, SUBTEXT_COLOR)
        selection = self._industries
        phrase_counts: dict[str, int] = {}
        for phrase in self._on_phrase_list():
            for industry_id in phrase.industries:
                phrase_counts[industry_id] = phrase_counts.get(industry_id, 0) + 1
        for item, rect in zip(category.items, self._industry_item_buttons):
            selected = selection is not None and selection.is_selected(item.id)
            pygame.draw.rect(self._surface, BUTTON_ACTIVE_COLOR if selected else BUTTON_COLOR, rect, border_radius=10)
            box = pygame.Rect(0, 0, INDUSTRY_CHECK_SIZE, INDUSTRY_CHECK_SIZE)
            box.midleft = (rect.left + 16, rect.centery)
            pygame.draw.rect(self._surface, TEXT_COLOR, box, width=2, border_radius=6)
            if selected:
                self._draw_icon(icons.CHECK, box.center, INDUSTRY_CHECK_SIZE - 4)
            text_rect = pygame.Rect(box.right + 8, rect.top, rect.right - box.right - 16 - INDUSTRY_COUNT_WIDTH, rect.height)
            self._blit_centered_at(item.ja, text_rect, 26, 0.38)
            self._blit_centered_at(item.en, text_rect, 15, 0.76)
            # 右端に、この業種の定型文の数と、用語（単語）の数
            for text, ratio in ((f"定型文 {phrase_counts.get(item.id, 0)}", 0.32), (f"単語 {term_count(item.id)}", 0.68)):
                counted, _ = self._fonts[JA].render(text, SUBTEXT_COLOR if not selected else TEXT_COLOR, size=16)
                self._surface.blit(counted, counted.get_rect(midright=(rect.right - 14, rect.top + round(rect.height * ratio))))
        # 8 つ目の場所: この区分の業種を全部選ぶ（全部選んでいれば、全部外す）
        bulk = self._industry_bulk_button
        everything = selection is not None and selection.count(category.id) == len(category.items)
        pygame.draw.rect(self._surface, BUTTON_COLOR, bulk, border_radius=10)
        title, subtitle = ("この区分をすべて外す", "Clear this group") if everything else ("この区分をすべて選ぶ", "Select all")
        self._blit_centered_at(title, bulk, 22, 0.38)
        self._blit_centered_at(subtitle, bulk, 15, 0.76)
        self._draw_industry_hint(INDUSTRY_SUB_HINT, INDUSTRY_SUB_HINT_EN)
        self._draw_two_line_button(self._close_button, "戻る", "Back", BUTTON_COLOR)

    def _draw_industry_hint(self, japanese: str, english: str) -> None:
        """業種の画面の左下の案内（日本語と英語）。"""
        top = self._close_button.top
        for i, (text, size) in enumerate(((japanese, 18), (english, 15))):
            surface, _ = self._fonts[JA].render(text, SUBTEXT_COLOR, size=size)
            self._surface.blit(surface, (MARGIN, top + 4 + i * 28))

    @staticmethod
    def _choice_font(choice: tuple[str, str]) -> str:
        """「翻訳の組み合わせ」のボタンの書体（台湾の繁体字の中国語は、台湾の字形の書体）。"""
        partner, script = choice
        return ZH_HANT if partner == ZH and script == TRADITIONAL else partner

    def _draw_sound(self, snap: Snapshot) -> None:
        self._surface.fill(MENU_BACKGROUND)
        self._draw_title_icon(icons.SPEAKER)
        self._draw_label("音の設定", MARGIN + TITLE_ICON_SHIFT, MENU_TITLE_Y, 30, TEXT_COLOR)
        self._draw_label(f"使用中: {snap.audio_route}", 240, MENU_TITLE_Y + 8, 20, SUBTEXT_COLOR)

        # スピーカー音量
        self._draw_label("音量（変えると確認の音が鳴ります）", MARGIN, VOLUME_LABEL_Y, 20, SUBTEXT_COLOR)
        self._draw_stepper(self._volume_down_button, self._volume_up_button, f"{round(snap.output_volume * 100)}%")

        # ノイズ除去（雑音の多い場所で使う。モデルが無いときはボタンを暗く表示する）
        self._draw_on_off(
            DENOISE_LABEL,
            self._denoise_buttons,
            snap.denoise_enabled,
            available=snap.denoise_available,
            label_y=VOLUME_LABEL_Y,
        )

        # マイク感度（入力レベルのバーと、増幅の倍率）
        low, high = GOOD_LEVEL
        self._draw_label(f"マイク感度（話しているときに、バーが緑の範囲 {low}〜{high} に入るように）", MARGIN, MIC_LABEL_Y, 20, SUBTEXT_COLOR)
        bar = self._level_bar
        pygame.draw.rect(self._surface, BUTTON_COLOR, bar, border_radius=8)
        good_zone = pygame.Rect(bar.left + int(bar.width * low), bar.top, int(bar.width * (high - low)), bar.height)
        pygame.draw.rect(self._surface, GOOD_ZONE_COLOR, good_zone)
        self._shown_peak = max(snap.input_peak, self._shown_peak * LEVEL_DECAY)
        filled_width = int(bar.width * min(1.0, self._shown_peak))
        if filled_width > 0:
            filled = pygame.Rect(bar.left, bar.top, filled_width, bar.height)
            pygame.draw.rect(self._surface, LEVEL_COLORS[level_zone(self._shown_peak)], filled, border_radius=8)
        value, _ = self._fonts[EN].render(f"{self._shown_peak:.2f}", TEXT_COLOR, size=22)
        self._surface.blit(value, value.get_rect(midright=(bar.right - 12, bar.centery)))
        if snap.hearing:
            self._draw_label("● 声を検出", bar.right + 16, bar.centery - 12, 22, LEVEL_COLORS["good"])
        else:
            self._draw_label("○ 声なし", bar.right + 16, bar.centery - 12, 22, SUBTEXT_COLOR)
        self._draw_stepper(self._gain_down_button, self._gain_up_button, f"× {snap.input_gain:g}")
        # 読み上げの速さ（変えると、その速さで短い文を読み上げる）
        self._draw_stepper(
            self._speed_down_button,
            self._speed_up_button,
            f"{snap.speech_speed:.1f}倍",
            value_size=26,
            caption=SPEED_LABEL,
        )

        # 発話の区切り方: 声がこの秒数だけ途切れたら区切る / 話し続けても、この秒数で区切る
        # 「話し終わりの間」は 0.5 秒ごとなので小数点を付け、「1回に話せる長さ」は 1 秒ごとなので整数で出す
        for label, down, up, value in (
            ("話し終わりの間（声の途切れで区切る）", self._silence_down_button, self._silence_up_button, f"{snap.silence_sec:.1f} 秒"),
            ("1回に話せる長さ（超えたら区切る）", self._max_speech_down_button, self._max_speech_up_button, f"{snap.max_speech_sec:g} 秒"),
        ):
            width = up.right - down.left
            size = next(
                (s for s in SEGMENT_LABEL_SIZES if self._fonts[JA].get_rect(label, size=s).width <= width),
                SEGMENT_LABEL_SIZES[-1],
            )
            self._draw_label(label, down.left, SEGMENT_LABEL_Y, size, SUBTEXT_COLOR)
            self._draw_stepper(down, up, value, value_size=30)

        close = self._close_button
        self._draw_label("調整中は翻訳しません", MARGIN, close.centery - 11, 20, SUBTEXT_COLOR)
        self._draw_button(self._bluetooth_button, "Bluetooth", 22, BUTTON_COLOR, icon=icons.BLUETOOTH)
        voice_ja, voice_en = VOICE_NAMES.get(snap.voice, VOICE_NAMES["standard"])
        self._draw_two_line_button(self._voice_button, f"声: {voice_ja}", f"Voice: {voice_en}", BUTTON_COLOR, title_size=24)
        self._draw_button(close, "戻る", 26, BUTTON_COLOR)

    def _draw_bluetooth(self, snap: Snapshot) -> None:
        self._surface.fill(MENU_BACKGROUND)
        self._draw_title_icon(icons.BLUETOOTH)
        self._draw_label("Bluetooth イヤホンマイク", MARGIN + TITLE_ICON_SHIFT, MENU_TITLE_Y, 30, TEXT_COLOR)
        self._draw_label(f"使用中: {snap.audio_route}", MARGIN, ROUTE_Y, 22, SUBTEXT_COLOR)

        button_color = DISABLED_BUTTON_COLOR if snap.bt_busy else BUTTON_COLOR
        scan_color = BUTTON_ACTIVE_COLOR if snap.bt_scanning else button_color
        self._draw_button(self._scan_button, "探しています…" if snap.bt_scanning else "探す", 22, scan_color)
        self._draw_button(self._usb_button, "本体に戻す", 24, button_color)
        self._draw_two_line_button(self._hid_button, "マウス・キーボード ▶", "Mouse / Keyboard", BUTTON_COLOR, title_size=20)
        if snap.bt_status:
            self._draw_status(snap.bt_status, MARGIN, BT_STATUS_CENTER_Y, self._width - 2 * MARGIN)

        self._draw_label("見つかった機器（タップすると接続して、マイクとスピーカーに使います）", MARGIN, DEVICE_HINT_Y, 18, SUBTEXT_COLOR)
        if not snap.bt_devices:
            first = self._device_rows[0]
            self._draw_label("（まだ見つかっていません）", first.left + 14, first.top + 8, 20, SUBTEXT_COLOR)
        for rect, device in zip(self._device_rows, snap.bt_devices):
            tag = "接続済み" if device.connected else ("ペアリング済み" if device.paired else "")
            self._draw_device_row(rect, device.name, tag, button_color)

        self._draw_button(self._close_button, "戻る", 26, BUTTON_COLOR)

    def _draw_input(self, snap: Snapshot) -> None:
        """「マウス・キーボード」の画面: Bluetooth のマウス・キーボードを探して、タップでつなぐ。"""
        self._surface.fill(MENU_BACKGROUND)
        self._draw_title_icon(icons.BLUETOOTH)
        self._draw_label("Bluetooth マウス・キーボード", MARGIN + TITLE_ICON_SHIFT, MENU_TITLE_Y, 30, TEXT_COLOR)
        self._draw_label("一度つなぐと、次からは電源を入れるだけでつながります", MARGIN, ROUTE_Y, 18, SUBTEXT_COLOR)
        button_color = DISABLED_BUTTON_COLOR if snap.hid_busy else BUTTON_COLOR
        scan_color = BUTTON_ACTIVE_COLOR if snap.hid_scanning else button_color
        self._draw_button(self._scan_button, "探しています…" if snap.hid_scanning else "探す", 22, scan_color)
        if snap.hid_passkey:
            # キーボードで打ってもらう番号（大きく出す）
            number, _ = self._fonts[EN].render(snap.hid_passkey, BLINK_BRIGHT_COLOR, size=48)
            area = pygame.Rect(self._scan_button.right + MENU_GAP, BT_BUTTON_TOP, 0, BT_BUTTON_HEIGHT)
            area.width = self._width - MARGIN - area.left
            self._surface.blit(number, number.get_rect(center=area.center))
        if snap.hid_status:
            self._draw_status(snap.hid_status, MARGIN, BT_STATUS_CENTER_Y, self._width - 2 * MARGIN)
        self._draw_label("見つかった機器（タップすると接続します）", MARGIN, DEVICE_HINT_Y, 18, SUBTEXT_COLOR)
        if not snap.hid_devices:
            first = self._device_rows[0]
            self._draw_label("（まだ見つかっていません）", first.left + 14, first.top + 8, 20, SUBTEXT_COLOR)
        for rect, device in zip(self._device_rows, snap.hid_devices):
            tag = "接続済み" if device.connected else ("ペアリング済み" if device.paired else "")
            self._draw_device_row(rect, device.name, tag, button_color)
        self._draw_two_line_button(self._close_button, "戻る", "Back", BUTTON_COLOR)

    def _draw_device_row(
        self,
        rect: pygame.Rect,
        name: str,
        tag: str,
        color: tuple[int, int, int],
        tag_color: tuple[int, int, int] = SUBTEXT_COLOR,
    ) -> None:
        """機器の一覧の1行（左に機器名、右にタグ）。"""
        pygame.draw.rect(self._surface, color, rect, border_radius=8)
        tag_surface, _ = self._fonts[JA].render(tag or " ", tag_color, size=18)
        tag_rect = tag_surface.get_rect(midright=(rect.right - 14, rect.centery))
        name_surface, _ = self._fonts[JA].render(name, TEXT_COLOR, size=22)
        # 長い名前がタグに重ならないよう、はみ出す部分は描かない
        self._surface.set_clip(pygame.Rect(rect.left, rect.top, tag_rect.left - rect.left - 10, rect.height))
        self._surface.blit(name_surface, name_surface.get_rect(midleft=(rect.left + 14, rect.centery)))
        self._surface.set_clip(None)
        self._surface.blit(tag_surface, tag_rect)

    def _draw_power_confirm(self, snap: Snapshot) -> None:
        self._surface.fill(MENU_BACKGROUND)
        self._draw_label("どうしますか？", MARGIN, CONFIRM_TITLE_Y, 34, TEXT_COLOR)
        # 説明の 2 行は、画面の幅（左右の余白の内側）に入る大きさにする（800 幅で右端まで届いていた。2026-11-09）
        room = self._width - 2 * MARGIN
        for i, line in enumerate(
            ("再起動：そのまま入り直します（1〜2 分かかります）。", "電源を切る：本体の緑のランプが消えてから、電源ケーブルを抜いてください。")
        ):
            size = next((s for s in (22, 20, 18) if self._fonts[JA].get_rect(line, size=s).width <= room), 18)
            surface, _ = self._fonts[JA].render(line, SUBTEXT_COLOR, size=size)
            self._surface.blit(_shrink_to_width(surface, room), (MARGIN, CONFIRM_TEXT_Y + i * CONFIRM_TEXT_GAP))
        self._draw_button(self._cancel_button, "キャンセル", 30, BUTTON_COLOR)
        self._draw_button(self._reboot_button, "再起動", 30, POWER_BUTTON_COLOR, icon=icons.RESTART)
        self._draw_button(self._confirm_power_button, "電源を切る", 30, DANGER_COLOR, icon=icons.POWER)
        self._draw_two_line_button(self._admin_button, "管理者", "Admin", BUTTON_COLOR, title_size=22)
        self._draw_two_line_button(self._history_button, "翻訳回数履歴", "Usage history", BUTTON_COLOR, title_size=20, subtitle_size=12)
        self._draw_auto_off()
        saver = self._power_saver
        if saver is not None:
            self._draw_on_off("省電力モード / Power saving", self._eco_buttons, saver.enabled, label_y=ECO_LABEL_Y, english=True)
            # ボタンの右に、オンにすると何が変わるか
            lines = [f"画面を暗くし、{saver.idle_sec:.0f} 秒操作がないと消します（触ると点きます）"]
            ratio = saver.cpu_off_ratio
            if saver.cpu_limited and ratio is not None:
                # 1/4（既定の 0.25）のときは「1/4」、それ以外の割合に変えているときは、その割合で書く
                share = "1/4" if abs(ratio - 0.25) < 0.005 else f"{ratio:.0%}"
                lines.append(f"画面が消えている間は、CPUの消費電力が{share}になります")
            elif ratio is not None:
                lines.append("画面が消えている間 CPU を遅くするには scripts/allow_power_mode.sh を実行します")
            left = self._eco_buttons[-1].right + MENU_GAP
            room = self._width - MARGIN - left
            for i, line in enumerate(lines):
                size = next((s for s in (17, 15, 13) if self._fonts[JA].get_rect(line, size=s).width <= room), 13)
                # 一番小さい文字でも入りきらない文は、残りの幅まで縮める（画面の右からはみ出していた。2026-11-09）
                surface, _ = self._fonts[JA].render(line, SUBTEXT_COLOR, size=size)
                self._surface.blit(_shrink_to_width(surface, room), (left, ECO_TOP + 4 + i * 24))

    def _draw_auto_off(self) -> None:
        """左上の「自動オフ」: 毎日、決めた時刻に電源を切る。"""
        auto_off = self._auto_off
        if auto_off is None:
            return
        self._draw_label("自動オフ", MARGIN, AUTO_OFF_TOP + 2, 20, SUBTEXT_COLOR)
        self._draw_label("Auto off", MARGIN, AUTO_OFF_TOP + 30, 14, SUBTEXT_COLOR)
        self._draw_button(self._auto_down, "−", 36, BUTTON_COLOR)
        self._draw_button(self._auto_up, "+", 36, BUTTON_COLOR)
        # オン・オフの切り替え（オンのとき青）。オフのあいだは、時刻になっても電源を切らない
        if auto_off.enabled:
            self._draw_two_line_button(self._auto_switch, "オン", "On", BUTTON_ACTIVE_COLOR)
        else:
            self._draw_two_line_button(self._auto_switch, "オフ", "Off", BUTTON_COLOR)
        value_rect = pygame.Rect(self._auto_down.right, AUTO_OFF_TOP, AUTO_OFF_VALUE_WIDTH, AUTO_OFF_HEIGHT)
        text, _ = self._fonts[EN].render(auto_off.text, TEXT_COLOR if auto_off.enabled else SUBTEXT_COLOR, size=34)
        self._surface.blit(text, text.get_rect(center=value_rect.center))

    def _draw_admin(self, snap: Snapshot) -> None:
        """管理者の画面: CPU 温度（上）と 5V 入力電圧（下）の折れ線グラフ。横軸は時刻で、上の期間のボタンで変える。"""
        pin_view = self._admin_range == ADMIN_PIN_VIEW
        usage_view = self._admin_range == ADMIN_USAGE_VIEW
        uptime = self._admin_range == ADMIN_UPTIME_VIEW
        hours = max(UPTIME_DAYS) * 24 if uptime else CHART_RANGES[min(self._admin_range, len(CHART_RANGES) - 1)].hours
        now = time.monotonic()
        if not pin_view and not usage_view and now - self._admin_loaded_at >= ADMIN_RELOAD_SEC:
            self._admin_readings = self._on_system_readings(hours)
            self._admin_loaded_at = now
        readings = self._admin_readings
        self._surface.fill(BACKGROUND)
        names = [choice.name for choice in CHART_RANGES] + [ADMIN_UPTIME_LABEL, ADMIN_PIN_LABEL, ADMIN_USAGE_LABEL]
        for i, (rect, name) in enumerate(zip(self._admin_range_buttons, names)):
            self._draw_button(rect, name, 20 if len(name) <= 3 else 17, BUTTON_ACTIVE_COLOR if i == self._admin_range else BUTTON_COLOR)
        self._draw_two_line_button(self._close_button, "戻る", "Back", BUTTON_COLOR)
        if pin_view:
            self._draw_admin_pin()
            return
        if usage_view:
            self._draw_usage(self._usage_kind, self._usage_kind_buttons)
            return
        if uptime:
            self._draw_uptime(readings)
            return
        chart = CHART_RANGES[self._admin_range]
        end = datetime.now()
        start = end - timedelta(hours=chart.hours)
        # 右上に、いちばん新しい記録
        if readings:
            last = readings[-1]
            parts = [last.when.strftime("%H:%M")]
            if last.temp is not None:
                parts.append(f"{last.temp:.0f}℃")
            if last.clock is not None:
                parts.append(f"{last.clock:.0f}MHz")
            if last.volt is not None:
                parts.append(f"{last.volt:.2f}V")  # 5V 入力電圧（Pi 5・CM5）
            elif last.cpu_volt is not None:
                parts.append(f"{last.cpu_volt:.2f}V")  # CPU 電圧（入力電圧を測れない Pi 4 など）
            text = "  ".join(parts)
            room = self._width - MARGIN - self._admin_range_buttons[-1].right - BUTTON_GAP
            size = next((s for s in (20, 18, 16, 15) if self._fonts[JA].get_rect(text, size=s).width <= room), 13)
            label, _ = self._fonts[JA].render(text, TEXT_COLOR, size=size)
            self._surface.blit(label, label.get_rect(midright=(self._width - MARGIN, self._admin_range_buttons[0].centery)))
        if not readings:
            rect = pygame.Rect(MARGIN, ADMIN_CHART_TOPS[0] + 40, self._width - 2 * MARGIN, 200)
            self._draw_text(ADMIN_EMPTY, self._fonts[JA], rect, (24, 20), SUBTEXT_COLOR)
            return
        ticks = time_ticks(start, end, chart.tick_hours)
        chart_width = self._width - 2 * MARGIN - ADMIN_AXIS_WIDTH - ADMIN_RIGHT_AXIS_WIDTH
        has_clock = any(r.clock is not None or r.cpu_volt is not None for r in readings)
        # 入力電圧を出すかは、いちばん新しい記録で決める（Pi 5 からコピーした古い記録が残る Pi 4 でも、CPU 電圧を出す）
        has_input_volt = readings[-1].volt is not None
        top_area = pygame.Rect(MARGIN + ADMIN_AXIS_WIDTH, ADMIN_CHART_TOPS[0], chart_width, ADMIN_CHART_HEIGHT)
        self._draw_line_chart(
            top_area, "CPU 温度 ℃", [(r.when, r.temp) for r in readings if r.temp is not None],
            ADMIN_TEMP_STEP, "{:.0f}", ADMIN_TEMP_COLOR, start, end, ticks,
        )
        low_area = pygame.Rect(MARGIN + ADMIN_AXIS_WIDTH, ADMIN_CHART_TOPS[1], chart_width, ADMIN_CHART_HEIGHT)
        if has_clock:
            # CPU クロックと、電圧を、1 つのグラフに重ねる（左の縦軸がクロック、右の縦軸が電圧）。
            # 電圧は、5V 入力電圧が測れる機器（Pi 5・CM5）では入力電圧、測れない機器では CPU 電圧
            if has_input_volt:
                volt_series = ("入力電圧 V", [(r.when, r.volt) for r in readings if r.volt is not None], ADMIN_INPUT_VOLT_STEP, "{:.2f}", ADMIN_CPU_VOLT_COLOR)
            else:
                volt_series = ("CPU 電圧 V", [(r.when, r.cpu_volt) for r in readings if r.cpu_volt is not None], ADMIN_CPU_VOLT_STEP, "{:.2f}", ADMIN_CPU_VOLT_COLOR)
            self._draw_dual_chart(
                low_area,
                ("CPU クロック MHz", [(r.when, r.clock) for r in readings if r.clock is not None], ADMIN_CLOCK_STEP, "{:.0f}", ADMIN_CLOCK_COLOR),
                volt_series,
                start, end, ticks,
            )
        else:
            # クロックの記録が無い（古い記録）ときは、5V 入力電圧を出す
            self._draw_line_chart(
                low_area, "5V 入力 V", [(r.when, r.volt) for r in readings if r.volt is not None],
                ADMIN_VOLT_STEP, "{:.1f}", ADMIN_VOLT_COLOR, start, end, ticks,
            )
        # 横軸の時刻（下のグラフの下に、1 回だけ書く）
        bottom = ADMIN_CHART_TOPS[-1] + ADMIN_CHART_HEIGHT
        span = (end - start).total_seconds()
        left, width = MARGIN + ADMIN_AXIS_WIDTH, chart_width
        for tick in ticks:
            x = left + round(width * (tick - start).total_seconds() / span)
            label, _ = self._fonts[JA].render(tick.strftime(chart.tick_format), SUBTEXT_COLOR, size=ADMIN_LABEL_SIZE)
            self._surface.blit(label, label.get_rect(midtop=(x, bottom + 6)))
        # 左下に、この期間の最低・最高（電圧は、10 秒間の最低の中でいちばん低い値も出す）
        temps = [r.temp for r in readings if r.temp is not None]
        volts = [r.volt for r in readings if r.volt is not None] if has_input_volt else []
        dips = [r.volt_min for r in readings if r.volt_min is not None]
        clocks = [r.clock for r in readings if r.clock is not None]
        clock_mins = [r.clock_min for r in readings if r.clock_min is not None]
        cpu_volts = [r.cpu_volt for r in readings if r.cpu_volt is not None]
        lines = []
        if temps:
            lines.append(f"温度  最低 {min(temps):.1f}  最高 {max(temps):.1f} ℃")
        if clocks or cpu_volts:
            parts = []
            if clocks:
                low = min(clock_mins) if clock_mins else min(clocks)
                parts.append(f"クロック {low:.0f}〜{max(clocks):.0f} MHz")
            if volts:
                # 5V 入力電圧が測れる機器（Pi 5・CM5）: 入力電圧の最低・最高（瞬間の最低も）
                dip = f"（瞬間の最低 {min(dips):.2f}）" if dips else ""
                parts.append(f"入力電圧 {min(volts):.2f}〜{max(volts):.2f} V{dip}")
            elif cpu_volts:
                parts.append(f"電圧 {min(cpu_volts):.3f}〜{max(cpu_volts):.3f} V")
            lines.append("  ".join(parts))
        elif volts:
            dip = f"（瞬間の最低 {min(dips):.2f}）" if dips else ""
            lines.append(f"電圧  最低 {min(volts):.2f}  最高 {max(volts):.2f} V{dip}")
        room = self._close_button.left - MARGIN - 12  # 「戻る」に重ならない幅
        for i, line in enumerate(lines):
            size = next((s for s in (20, 18, 16, 15) if self._fonts[JA].get_rect(line, size=s).width <= room), 14)
            self._draw_label(line, MARGIN, self._close_button.top + 6 + i * 28, size, SUBTEXT_COLOR)

    def _draw_fix_page(self, snap: Snapshot) -> None:
        """訂正の画面: 訂正の一覧（原文 → 決めた訳）。左下に「覚える」「入力」「削除」、右下に「戻る」。"""
        self._surface.fill(BACKGROUND)
        self._draw_label(FIX_TITLE, MARGIN, 14, 26, TEXT_COLOR)
        self._draw_two_line_button(self._close_button, "戻る", "Back", BUTTON_COLOR)
        items = self._fix_list()
        font = self._fonts[JA]
        # タイトルの右に、結果の知らせ
        message = self._fix_message
        if self._fix_delete:
            message = "消す訂正をタップしてください"
        if message:
            left = MARGIN + 270
            self._draw_fitted_label(message.split("\n")[0], left, 18, (16, 14, 12), DANGER_COLOR if self._fix_delete else TEXT_COLOR)
        if self._fix_voice is not None and (self._fix_listening or self._fix_heard):
            self._draw_fix_voice(snap)
            return
        if not items:
            rect = pygame.Rect(MARGIN, LIST_ROW_TOP + 40, self._width - 2 * MARGIN, 220)
            self._draw_text(FIX_EMPTY, font, rect, (22, 20, 18), SUBTEXT_COLOR)
        shown = range(self._fix_first, min(len(items), self._fix_first + LIST_ROWS))
        for rect, index in zip(self._list_rows, shown):
            item = items[index]
            pygame.draw.rect(self._surface, POWER_BUTTON_COLOR if self._fix_delete else BUTTON_COLOR, rect, border_radius=10)
            left = rect.left + 12
            width = rect.right - 14 - left
            half = rect.height // 2
            for text, lang, top in ((item.text, item.source, rect.top), (f"→ {item.translation}", item.target, rect.top + half)):
                text_font = self._fonts[self._font_key(lang, snap)]
                size = next((s for s in (20, 18, 16, 14) if text_font.get_rect(text, size=s).width <= width), 14)
                surface, _ = text_font.render(text, TEXT_COLOR if top != rect.top else SUBTEXT_COLOR, size=size)
                self._surface.set_clip(pygame.Rect(left, top, width, half))
                self._surface.blit(surface, surface.get_rect(midleft=(left, top + half // 2)))
                self._surface.set_clip(None)
        self._draw_two_line_button(self._fix_keep_button, "覚える", "Keep", START_COLOR, title_size=20, subtitle_size=13)
        self._draw_two_line_button(self._fix_type_button, "入力", "Type", BUTTON_COLOR, title_size=20, subtitle_size=13)
        self._draw_two_line_button(self._fix_voice_button, "音声入力", "Voice", BUTTON_COLOR, title_size=17, subtitle_size=13)
        self._draw_two_line_button(
            self._fix_delete_button, "削除", "Delete", DANGER_COLOR if self._fix_delete else BUTTON_COLOR, title_size=20, subtitle_size=13
        )
        if self._fix_first > 0:
            self._draw_two_line_button(self._fix_prev_button, "◀ 前へ", "Previous", BUTTON_COLOR, title_size=20)
        if self._fix_first + LIST_ROWS < len(items):
            self._draw_two_line_button(self._fix_next_button, "次へ ▶", "Next", BUTTON_COLOR, title_size=20)

    def _draw_fix_voice(self, snap: Snapshot) -> None:
        """訂正の「音声入力」の途中。聞き取り中は案内と「やめる」、聞き取れたあとは原文と聞き取った訳を出して「登録」「やり直し」「やめる」。"""
        assert self._fix_voice is not None
        source, text, target = self._fix_voice
        width = self._width - 2 * MARGIN
        listening = self._fix_listening
        blocks = [
            (text, source, "原文 / Original", LIST_ROW_TOP + 22),
            (FIX_VOICE_LISTENING if listening else self._fix_heard, target, "聞き取った訳 / Heard" if not listening else "", LIST_ROW_TOP + 162),
        ]
        for body, lang, caption, top in blocks:
            if caption:
                self._draw_label(caption, MARGIN, top - 22, 16, SUBTEXT_COLOR)
            rect = pygame.Rect(MARGIN, top, width, 100)
            pygame.draw.rect(self._surface, BUTTON_COLOR, rect, border_radius=10)
            body_font = self._fonts[JA] if (listening and top != LIST_ROW_TOP + 22) else self._fonts[self._font_key(lang, snap)]
            self._draw_text(body, body_font, rect.inflate(-24, -10), (28, 24, 20, 16), TEXT_COLOR)
        if listening:
            self._draw_two_line_button(self._close_button, "やめる", "Cancel", DANGER_COLOR)
        else:
            self._draw_two_line_button(self._fix_keep_button, "登録", "Save", START_COLOR, title_size=20, subtitle_size=13)
            self._draw_two_line_button(self._fix_type_button, "やり直し", "Retry", BUTTON_COLOR, title_size=17, subtitle_size=13)
            self._draw_two_line_button(self._close_button, "やめる", "Cancel", BUTTON_COLOR)

    def _draw_history(self, snap: Snapshot) -> None:
        """翻訳回数履歴の画面: 日ごとの、翻訳した数・定型文を使った数・訂正を登録した数の積み上げ棒グラフ（言語別に色分け）。"""
        self._surface.fill(BACKGROUND)
        self._draw_label(HISTORY_TITLE, MARGIN, HISTORY_TITLE_Y, 30, TEXT_COLOR)
        self._draw_two_line_button(self._close_button, "戻る", "Back", BUTTON_COLOR)
        self._draw_usage(self._history_kind, self._history_kind_buttons)

    def _draw_usage(self, selected_kind: str, kind_buttons: dict[str, pygame.Rect]) -> None:
        """日ごとの、翻訳した数・訂正を登録した数・定型文を足した数（使った数）の積み上げ棒グラフ（言語別に色分け）。
        上に、種類と期間（7・14・30 日）のボタン、下に、期間の合計と今日の数。管理者の画面の「利用状況」と、翻訳回数履歴で使う。"""
        font = self._fonts[JA]
        for kind, rect in kind_buttons.items():
            title, subtitle = USAGE_KIND_LABELS[kind]
            color = BUTTON_ACTIVE_COLOR if kind == selected_kind else BUTTON_COLOR
            self._draw_two_line_button(rect, title, subtitle, color, title_size=20, subtitle_size=12)
        for days, rect in self._usage_days_buttons.items():
            self._draw_button(rect, f"{days}日", 20, BUTTON_ACTIVE_COLOR if days == self._usage_days else BUTTON_COLOR)
        if self._usage is None:
            rect = pygame.Rect(MARGIN, USAGE_CHART_TOP + 40, self._width - 2 * MARGIN, 120)
            self._draw_text(USAGE_NO_LOG, font, rect, (24, 20), SUBTEXT_COLOR)
            return
        if selected_kind == MAX_TEMP:
            self._draw_usage_temperature()
            return
        bars = self._usage.daily(selected_kind, self._usage_days)
        window_total = sum(bar.total for bar in bars)
        # 言語は、この期間の多い順に、下から積む
        langs: dict[str, int] = {}
        for bar in bars:
            for lang, count in bar.by_lang.items():
                langs[lang] = langs.get(lang, 0) + count
        order = sorted(langs, key=lambda lang: (-langs[lang], lang))
        # 凡例（定型文は言語を分けないので出さない）
        if selected_kind != PHRASES:
            x, row_y = MARGIN, USAGE_LEGEND_Y
            for lang in order:
                name = USAGE_LANG_NAMES.get(lang, lang)
                label, _ = font.render(name, TEXT_COLOR, size=ADMIN_LABEL_SIZE)
                if x + 20 + label.get_width() > self._width - MARGIN:  # 右端に収まらなければ、次の行へ
                    x, row_y = MARGIN, row_y + USAGE_LEGEND_ROW
                pygame.draw.rect(self._surface, USAGE_LANG_COLORS.get(lang, SUBTEXT_COLOR), pygame.Rect(x, row_y + 3, 14, 14))
                self._surface.blit(label, label.get_rect(midleft=(x + 20, row_y + 10)))
                x += 20 + label.get_width() + 14
        area = pygame.Rect(
            MARGIN + ADMIN_AXIS_WIDTH, USAGE_CHART_TOP, self._width - 2 * MARGIN - ADMIN_AXIS_WIDTH, USAGE_CHART_HEIGHT
        )
        pygame.draw.rect(self._surface, MENU_BACKGROUND, area)
        highest = max((bar.total for bar in bars), default=0)
        top_level, step = _nice_axis(highest)
        for level in range(0, top_level + 1, step):
            y = area.bottom - round(area.height * level / top_level)
            pygame.draw.line(self._surface, DIVIDER_COLOR, (area.left, y), (area.right, y), 1)
            label, _ = font.render(str(level), SUBTEXT_COLOR, size=ADMIN_LABEL_SIZE)
            self._surface.blit(label, label.get_rect(midright=(area.left - 8, y)))
        slot = area.width / len(bars)
        width = max(2, round(slot * 0.7))
        every = 1 if len(bars) <= 7 else 2 if len(bars) <= 14 else 5  # 横軸の日付（今日から数えて、何日ごとに書くか）
        for i, bar in enumerate(bars):
            x = area.left + round(slot * i + (slot - width) / 2)
            filled = 0
            for lang in order:
                count = bar.by_lang.get(lang, 0)
                if not count:
                    continue
                y_low = area.bottom - round(area.height * filled / top_level)
                filled += count
                y_high = area.bottom - round(area.height * filled / top_level)
                segment = pygame.Rect(x, y_high, width, max(1, y_low - y_high))
                pygame.draw.rect(self._surface, USAGE_LANG_COLORS.get(lang, SUBTEXT_COLOR), segment)
            if bar.total and len(bars) <= 14:
                label, _ = font.render(str(bar.total), TEXT_COLOR, size=ADMIN_LABEL_SIZE)
                self._surface.blit(label, label.get_rect(midbottom=(x + width // 2, area.bottom - round(area.height * bar.total / top_level) - 2)))
            if (len(bars) - 1 - i) % every == 0:
                label, _ = font.render(bar.day.strftime("%m/%d"), SUBTEXT_COLOR, size=ADMIN_LABEL_SIZE)
                self._surface.blit(label, label.get_rect(midtop=(x + width // 2, area.bottom + 4)))
        if not window_total:
            label, _ = font.render(USAGE_EMPTY, SUBTEXT_COLOR, size=20)
            self._surface.blit(label, label.get_rect(center=area.center))
        # 下に、この期間の合計と、今日の数
        self._draw_label(f"合計 {window_total} 件", MARGIN, self._close_button.top - 2, 28, TEXT_COLOR)
        summary = f"今日 {bars[-1].total} 件　／　最近 {len(bars)} 日の{USAGE_TITLES[selected_kind]}"
        self._draw_label(summary, MARGIN, self._close_button.top + 36, 17, SUBTEXT_COLOR)

    def _draw_usage_temperature(self) -> None:
        """「利用状況」の「最高温度」: 1 日ごとの、CPU 温度の最高の棒グラフ（70℃まで緑、80℃まで黄、それ以上は赤）。下に、期間の最高と、今日の最高。"""
        font = self._fonts[JA]
        days = self._usage.daily_max_temp(self._usage_days)
        area = pygame.Rect(
            MARGIN + ADMIN_AXIS_WIDTH, USAGE_CHART_TOP, self._width - 2 * MARGIN - ADMIN_AXIS_WIDTH, USAGE_CHART_HEIGHT
        )
        pygame.draw.rect(self._surface, MENU_BACKGROUND, area)
        for level in range(0, USAGE_TEMP_TOP + 1, USAGE_TEMP_STEP):
            y = area.bottom - round(area.height * level / USAGE_TEMP_TOP)
            pygame.draw.line(self._surface, DIVIDER_COLOR, (area.left, y), (area.right, y), 1)
            label, _ = font.render(f"{level}℃", SUBTEXT_COLOR, size=ADMIN_LABEL_SIZE)
            self._surface.blit(label, label.get_rect(midright=(area.left - 8, y)))
        slot = area.width / len(days)
        width = max(2, round(slot * 0.7))
        every = 1 if len(days) <= 7 else 2 if len(days) <= 14 else 5
        for i, day in enumerate(days):
            x = area.left + round(slot * i + (slot - width) / 2)
            if day.value is not None:
                color = next(color for limit, color in USAGE_TEMP_COLORS if day.value <= limit)
                height = round(area.height * min(day.value, USAGE_TEMP_TOP) / USAGE_TEMP_TOP)
                pygame.draw.rect(self._surface, color, pygame.Rect(x, area.bottom - height, width, height))
                if len(days) <= 14:
                    label, _ = font.render(f"{day.value:.1f}", TEXT_COLOR, size=ADMIN_LABEL_SIZE)
                    self._surface.blit(label, label.get_rect(midbottom=(x + width // 2, area.bottom - height - 2)))
            if (len(days) - 1 - i) % every == 0:
                label, _ = font.render(day.day.strftime("%m/%d"), SUBTEXT_COLOR, size=ADMIN_LABEL_SIZE)
                self._surface.blit(label, label.get_rect(midtop=(x + width // 2, area.bottom + 4)))
        # 80℃の線（熱で CPU の速度が落ち始める目安）
        y = area.bottom - round(area.height * USAGE_TEMP_LIMIT / USAGE_TEMP_TOP)
        pygame.draw.line(self._surface, USAGE_TEMP_COLORS[-1][1], (area.left, y), (area.right, y), 2)
        recorded = [day for day in days if day.value is not None]
        if not recorded:
            label, _ = font.render(USAGE_EMPTY, SUBTEXT_COLOR, size=20)
            self._surface.blit(label, label.get_rect(center=area.center))
            return
        peak = max(recorded, key=lambda day: day.value)
        self._draw_label(
            f"期間の最高 {peak.value:.1f}℃（{peak.day.strftime('%m/%d')} {peak.at}）", MARGIN, self._close_button.top - 2, 24, TEXT_COLOR
        )
        today = days[-1]
        today_text = f"今日の最高 {today.value:.1f}℃（{today.at}）" if today.value is not None else "今日は、まだ記録がありません"
        self._draw_label(f"{today_text}　／　80℃の線は、熱で速度が落ち始める目安", MARGIN, self._close_button.top + 36, 16, SUBTEXT_COLOR)

    def _draw_admin_pin(self) -> None:
        """管理者の画面の「暗証番号」のタブ: 一般の番号と管理者の番号の説明と、それぞれの「変更」ボタン。"""
        font = self._fonts[JA]
        rows = (
            (GENERAL, "一般の暗証番号", "General number",
             "店舗用・音の設定・電源・再起動を開くときの番号", self._pins.general_required(), self._pins.general_is_initial()),
            (ADMIN, "管理者の暗証番号", "Administrator number",
             "管理者の画面に入るときの番号", True, self._pins.admin_is_initial()),
        )
        for group, title, title_en, description, required, initial in rows:
            row = self._admin_pin_rows[group]
            pygame.draw.rect(self._surface, BUTTON_COLOR, row, border_radius=12)
            left = row.left + 18
            width = self._admin_pin_change_buttons[group].left - left - 14
            head, _ = font.render(f"{title} / {title_en}", TEXT_COLOR, size=24)
            self._surface.blit(head, (left, row.top + 10))
            desc_size = next((s for s in (18, 16, 14) if font.get_rect(description, size=s).width <= width), 14)
            desc, _ = font.render(description, SUBTEXT_COLOR, size=desc_size)
            self._surface.blit(desc, (left, row.top + 46))
            if not required:
                state, color = "番号なし（聞きません）/ No number", SUBTEXT_COLOR
            elif initial:
                state, color = "最初の番号のままです。変えてください / Still the first number", BLINK_BRIGHT_COLOR
            else:
                state, color = "変更ずみ / Changed", START_COLOR
            status, _ = font.render(state, color, size=17)
            self._surface.blit(status, (left, row.top + 78))
            self._draw_two_line_button(self._admin_pin_change_buttons[group], "変更", "Change", START_COLOR, title_size=24)
        if self._admin_message:
            message, _ = font.render(self._admin_message, TEXT_COLOR, size=22)
            self._surface.blit(message, (MARGIN, self._close_button.top + 18))

    def _draw_line_chart(
        self,
        area: pygame.Rect,
        title: str,
        points: list[tuple[datetime, float]],
        step: float,
        tick_format: str,
        color: tuple[int, int, int],
        start: datetime,
        end: datetime,
        ticks: list[datetime],
    ) -> None:
        """折れ線グラフを 1 つ描く（縦軸は値に合わせて決め、記録が長く空いた所は線をつながない）。"""
        font = self._fonts[JA]
        pygame.draw.rect(self._surface, MENU_BACKGROUND, area)
        span = (end - start).total_seconds()
        for tick in ticks:
            x = area.left + round(area.width * (tick - start).total_seconds() / span)
            pygame.draw.line(self._surface, DIVIDER_COLOR, (x, area.top), (x, area.bottom), 1)
        if not points:
            label, _ = font.render(f"{title}（記録がありません）", SUBTEXT_COLOR, size=18)
            self._surface.blit(label, label.get_rect(center=area.center))
            return
        low, high, levels = axis_bounds([value for _, value in points], step)
        for level in levels:
            y = area.bottom - round(area.height * (level - low) / (high - low))
            pygame.draw.line(self._surface, DIVIDER_COLOR, (area.left, y), (area.right, y), 1)
            label, _ = font.render(tick_format.format(level), SUBTEXT_COLOR, size=ADMIN_LABEL_SIZE)
            self._surface.blit(label, label.get_rect(midright=(area.left - 8, y)))
        # 線を、記録が続いているかたまりごとに描く
        run: list[tuple[int, int]] = []
        previous: datetime | None = None
        for when, value in points:
            x = area.left + round(area.width * (when - start).total_seconds() / span)
            y = area.bottom - round(area.height * (value - low) / (high - low))
            if previous is not None and when - previous > GAP:
                self._draw_run(run, color)
                run = []
            run.append((x, y))
            previous = when
        self._draw_run(run, color)
        label, _ = font.render(title, color, size=17)
        self._surface.blit(label, (area.left + 8, area.top + 4))

    def _draw_dual_chart(
        self,
        area: pygame.Rect,
        left_series: tuple[str, list[tuple[datetime, float]], float, str, tuple[int, int, int]],
        right_series: tuple[str, list[tuple[datetime, float]], float, str, tuple[int, int, int]],
        start: datetime,
        end: datetime,
        ticks: list[datetime],
    ) -> None:
        """2 つの値（例: CPU クロックと CPU 電圧）を、1 つのグラフに重ねて描く。

        左の縦軸が 1 つめ、右の縦軸が 2 つめ（それぞれの色で目盛りを書く）。横の線は、左の縦軸に合わせる。
        """
        font = self._fonts[JA]
        pygame.draw.rect(self._surface, MENU_BACKGROUND, area)
        span = (end - start).total_seconds()
        for tick in ticks:
            x = area.left + round(area.width * (tick - start).total_seconds() / span)
            pygame.draw.line(self._surface, DIVIDER_COLOR, (x, area.top), (x, area.bottom), 1)
        title_x = area.left + 8
        for index, (title, points, step, tick_format, color) in enumerate((left_series, right_series)):
            if not points:
                continue
            low, high, levels = axis_bounds([value for _, value in points], step)
            for level in levels:
                y = area.bottom - round(area.height * (level - low) / (high - low))
                if index == 0:
                    pygame.draw.line(self._surface, DIVIDER_COLOR, (area.left, y), (area.right, y), 1)
                    label, _ = font.render(tick_format.format(level), color, size=ADMIN_LABEL_SIZE)
                    self._surface.blit(label, label.get_rect(midright=(area.left - 8, y)))
                else:
                    label, _ = font.render(tick_format.format(level), color, size=ADMIN_LABEL_SIZE)
                    self._surface.blit(label, label.get_rect(midleft=(area.right + 8, y)))
            run: list[tuple[int, int]] = []
            previous: datetime | None = None
            for when, value in points:
                x = area.left + round(area.width * (when - start).total_seconds() / span)
                y = area.bottom - round(area.height * (value - low) / (high - low))
                if previous is not None and when - previous > GAP:
                    self._draw_run(run, color)
                    run = []
                run.append((x, y))
                previous = when
            self._draw_run(run, color)
            label, _ = font.render(title, color, size=17)
            self._surface.blit(label, (title_x, area.top + 4))
            title_x += label.get_width() + 18
        if not (left_series[1] or right_series[1]):
            label, _ = font.render("CPU クロック・CPU 電圧（記録がありません）", SUBTEXT_COLOR, size=18)
            self._surface.blit(label, label.get_rect(center=area.center))

    def _draw_uptime(self, readings: list[Reading]) -> None:
        """管理者の画面の「稼働時間」: 1 日ごとの稼働時間の棒グラフ（上に最近 7 日、下に最近 30 日）と、
        下に、リセットしてからの合計稼働時間と「リセット」。"""
        if readings:
            charts = [daily_uptime(readings, datetime.now(), days) for days in UPTIME_DAYS]
            for top, days, bars in zip(ADMIN_CHART_TOPS, UPTIME_DAYS, charts):
                area = pygame.Rect(MARGIN + ADMIN_AXIS_WIDTH, top, self._width - 2 * MARGIN - ADMIN_AXIS_WIDTH, ADMIN_CHART_HEIGHT)
                total = sum(hours for _, hours in bars)
                summary = f"平均 {_hours_text(total / len(bars))}" if days <= 7 else f"合計 {_hours_text(total)}"
                self._draw_bar_chart(area, f"最近 {days} 日の 1 日の稼働時間（{summary}）", bars, labels=days <= 7)
        else:
            rect = pygame.Rect(MARGIN, ADMIN_CHART_TOPS[0] + 40, self._width - 2 * MARGIN, 200)
            self._draw_text(ADMIN_EMPTY, self._fonts[JA], rect, (24, 20), SUBTEXT_COLOR)
        if self._uptime is None:
            return
        seconds = self._uptime.total_seconds()
        self._draw_label(f"合計 {_total_text(seconds)}", MARGIN, self._close_button.top - 2, 28, TEXT_COLOR)
        since = self._uptime.since.strftime("%Y/%m/%d %H:%M")
        self._draw_label(f"{since} にリセットしてから", MARGIN, self._close_button.top + 36, 16, SUBTEXT_COLOR)
        if time.monotonic() - self._reset_armed_at <= ADMIN_CONFIRM_SEC:
            self._draw_two_line_button(self._reset_button, "もう一度押す", "と 0 に戻します", DANGER_COLOR, title_size=20)
        else:
            self._draw_two_line_button(self._reset_button, "リセット", "Reset", BUTTON_COLOR)

    def _draw_bar_chart(self, area: pygame.Rect, title: str, bars: list[tuple[date, float]], labels: bool) -> None:
        """1 日ごとの棒グラフを 1 つ描く（縦軸は時間。labels なら、棒の上に時間を書く）。"""
        font = self._fonts[JA]
        pygame.draw.rect(self._surface, MENU_BACKGROUND, area)
        highest = max((hours for _, hours in bars), default=0.0)
        step = 2.0 if highest <= 12 else 4.0
        top_level = min(24.0, max(2 * step, math.ceil(highest / step - 1e-9) * step))
        level = 0.0
        while level <= top_level + 1e-9:
            y = area.bottom - round(area.height * level / top_level)
            pygame.draw.line(self._surface, DIVIDER_COLOR, (area.left, y), (area.right, y), 1)
            label, _ = font.render(f"{level:.0f}時間", SUBTEXT_COLOR, size=ADMIN_LABEL_SIZE)
            self._surface.blit(label, label.get_rect(midright=(area.left - 8, y)))
            level += step
        slot = area.width / len(bars)
        width = max(2, round(slot * 0.7))
        every = 1 if len(bars) <= 7 else 5  # 横軸の日付（30 日なら、今日から 5 日ごと）
        for i, (day, hours) in enumerate(bars):
            x = area.left + round(slot * i + (slot - width) / 2)
            height = round(area.height * min(hours, top_level) / top_level)
            if height:
                pygame.draw.rect(self._surface, ADMIN_UPTIME_COLOR, pygame.Rect(x, area.bottom - height, width, height))
            if labels:
                label, _ = font.render(_hours_text(hours), TEXT_COLOR, size=ADMIN_LABEL_SIZE)
                self._surface.blit(label, label.get_rect(midbottom=(x + width // 2, area.bottom - height - 2)))
            if (len(bars) - 1 - i) % every == 0:
                label, _ = font.render(day.strftime("%m/%d"), SUBTEXT_COLOR, size=ADMIN_LABEL_SIZE)
                self._surface.blit(label, label.get_rect(midtop=(x + width // 2, area.bottom + 4)))
        label, _ = font.render(title, ADMIN_UPTIME_COLOR, size=17)
        self._surface.blit(label, (area.left + 8, area.top + 4))

    def _draw_run(self, run: list[tuple[int, int]], color: tuple[int, int, int]) -> None:
        if len(run) >= 2:
            pygame.draw.lines(self._surface, color, False, run, 2)
        # 点が少ないときは、点も打つ（1 つだけの記録も見えるように）
        if len(run) <= 40:
            for point in run:
                pygame.draw.circle(self._surface, color, point, 3)

    def _draw_wifi(self, snap: Snapshot) -> None:
        """Wi-Fi の画面: つないでいる Wi-Fi、「探す」、見つかった Wi-Fi の一覧（電波の強い順）。"""
        self._surface.fill(MENU_BACKGROUND)
        self._draw_title_icon(icons.WIFI)
        self._draw_fitted_label("Wi-Fi 設定 / Wi-Fi settings", MARGIN + TITLE_ICON_SHIFT, MENU_TITLE_Y, TITLE_SIZES, TEXT_COLOR)
        if snap.wifi_current:
            current = f"接続中 / Connected: {snap.wifi_current}" + (f"（{snap.wifi_address}）" if snap.wifi_address else "")
        else:
            current = WIFI_NOT_CONNECTED
        self._draw_fitted_label(current, MARGIN, WIFI_CURRENT_Y, (20, 18, 16), SUBTEXT_COLOR)
        self._draw_two_line_button(
            self._scan_button, "探す", "Scan", DISABLED_BUTTON_COLOR if snap.wifi_busy else BUTTON_COLOR, title_size=24
        )
        # 「切断」: つながっているときだけ押せる。1 回押すと「もう一度押すと切断します」になる（5 秒間）
        armed = time.monotonic() - self._wifi_disconnect_armed_at <= ADMIN_CONFIRM_SEC
        connected = bool(snap.wifi_current) and not snap.wifi_busy
        if armed and connected:
            self._draw_two_line_button(
                self._wifi_disconnect_button, "もう一度押す", "Tap again", DANGER_COLOR, title_size=20, subtitle_size=14
            )
        else:
            self._draw_two_line_button(
                self._wifi_disconnect_button,
                "すべて切断",
                "Disconnect all",
                POWER_BUTTON_COLOR if connected else DISABLED_BUTTON_COLOR,
                title_size=22,
                subtitle_size=14,
            )
        if snap.wifi_status:
            left = self._scan_button.right + MENU_GAP
            self._draw_status(
                snap.wifi_status, left, self._scan_button.centery, self._wifi_disconnect_button.left - MENU_GAP - left
            )
        networks = snap.wifi_networks
        shown = networks[self._wifi_first : self._wifi_first + WIFI_ROWS]
        for rect, network in zip(self._wifi_rows, shown):
            self._draw_wifi_row(rect, network)
        if self._wifi_first > 0:
            self._draw_two_line_button(self._power_button, "◀ 前へ", "Previous", BUTTON_COLOR, title_size=22)
        if self._wifi_first + WIFI_ROWS < len(networks):
            self._draw_two_line_button(self._sound_button, "次へ ▶", "Next", BUTTON_COLOR, title_size=22)
        self._draw_two_line_button(self._close_button, "戻る", "Back", BUTTON_COLOR)

    def _draw_wifi_row(self, rect: pygame.Rect, network: WifiNetwork) -> None:
        """一覧の 1 行: 名前、つないでいる・保存済みの印、鍵（パスワードが要る）、電波の強さの棒。"""
        pygame.draw.rect(self._surface, BUTTON_ACTIVE_COLOR if network.in_use else BUTTON_COLOR, rect, border_radius=10)
        # 右から: 電波の棒（4 本）、鍵、印
        right = rect.right - 16
        bars = max(1, min(4, round(network.signal / 25)))
        for i in range(4):
            height = 8 + i * 6
            bar = pygame.Rect(right - (4 - i) * 9, rect.centery + 13 - height, 6, height)
            pygame.draw.rect(self._surface, TEXT_COLOR if i < bars else DIVIDER_COLOR, bar)
        right -= 4 * 9 + 12
        if network.secure:
            # 鍵: 四角と、上の半円の輪
            body = pygame.Rect(right - 14, rect.centery - 2, 14, 11)
            pygame.draw.rect(self._surface, TEXT_COLOR, body, border_radius=2)
            pygame.draw.arc(self._surface, TEXT_COLOR, pygame.Rect(right - 12, rect.centery - 10, 10, 14), 0, math.pi, 2)
        right -= 26
        tag = "接続中 Connected" if network.in_use else ("保存済み Saved" if network.known else "")
        if tag:
            label, _ = self._fonts[JA].render(tag, SUBTEXT_COLOR if not network.in_use else TEXT_COLOR, size=16)
            label_rect = label.get_rect(midright=(right, rect.centery))
            self._surface.blit(label, label_rect)
            right = label_rect.left - 12
        name, _ = self._fonts[JA].render(network.ssid, TEXT_COLOR, size=22)
        self._surface.set_clip(pygame.Rect(rect.left, rect.top, right - rect.left, rect.height))
        self._surface.blit(name, name.get_rect(midleft=(rect.left + 16, rect.centery)))
        self._surface.set_clip(None)

    def _draw_wifi_password(self, snap: Snapshot) -> None:
        """パスワードを入れる画面: Wi-Fi の名前、入力欄（ふだんは「*」で隠す）、画面のキーボード。"""
        self._surface.fill(MENU_BACKGROUND)
        ssid = self._wifi_target.ssid if self._wifi_target else ""
        self._draw_fitted_label(f"パスワード / Password: {ssid}", MARGIN, MENU_TITLE_Y, (24, 22, 20, 18), TEXT_COLOR)
        entry = self._wifi_entry
        pygame.draw.rect(self._surface, ENTRY_COLOR, entry, border_radius=8)
        pygame.draw.rect(self._surface, ENTRY_BORDER_COLOR, entry, width=2, border_radius=8)
        shown = self._wifi_password if self._wifi_show else "*" * len(self._wifi_password)
        font = self._password_font
        text, _ = font.render(shown or " ", TEXT_COLOR, size=28)
        self._surface.set_clip(entry.inflate(-24, 0))
        # 長くなったら、打っている最後の部分が見えるように右にそろえる
        x = min(entry.left + 14, entry.right - 20 - text.get_width())
        self._surface.blit(text, text.get_rect(midleft=(x, entry.centery)))
        self._surface.set_clip(None)
        cursor_x = x + (text.get_width() if self._wifi_password else 0) + 2
        pygame.draw.line(self._surface, TEXT_COLOR, (cursor_x, entry.top + 12), (cursor_x, entry.bottom - 12), 2)
        count, _ = self._fonts[EN].render(f"{len(self._wifi_password)}", SUBTEXT_COLOR, size=16)
        self._surface.blit(count, count.get_rect(midright=(entry.right - 10, entry.bottom - 12)))
        for rect, label, action in self._wifi_keys():
            if action == "connect":
                color = START_COLOR if 8 <= len(self._wifi_password) <= 63 else DISABLED_BUTTON_COLOR
            elif (action == "shift" and self._wifi_shift) or (action == "show" and self._wifi_show):
                color = BUTTON_ACTIVE_COLOR
            else:
                color = BUTTON_COLOR
            if len(label) == 1:
                # 1 文字のキーは、記号の見分けがつくフォントで大きく描く。上下は文字の基準線（ベースライン）でそろえる
                # （見える部分の真ん中にそろえると、「_」が「–」、「.」が「·」のように見えてしまう）
                pygame.draw.rect(self._surface, color, rect, border_radius=10)
                size = 26
                width = self._key_font.get_rect(label, size=size).width
                baseline = rect.centery + round(size * 0.36)
                self._key_font.render_to(
                    self._surface, (rect.centerx - width // 2, baseline), label, fgcolor=TEXT_COLOR, size=size
                )
            else:
                self._draw_button(rect, label, 18, color)

    def _draw_keyboard(self, snap: Snapshot) -> None:
        """画面のキーボードの画面: 見出しと話す人の切り替え、入力欄（と「消去」）、キー 5 段。"""
        lang = self._kb_lang(snap)
        self._surface.fill(MENU_BACKGROUND)
        phrase = self._editing_phrase() if self._kb_phrase is not None else None
        if self._kb_phrase is not None and phrase is not None:
            # 定型文の修正: どの文の、どの行を直すのかを見せる
            field = self._kb_phrase[0]
            self._draw_label("定型文の修正 / Edit phrase", MARGIN, 3, 22, TEXT_COLOR)
            target = "元の文" if field == "src" else f"{NATIVE_NAMES[field]}の訳文"
            self._draw_fitted_label(f"{target}を直します　元の文: {phrase.text}", MARGIN, 29, (15, 14, 13, 12), SUBTEXT_COLOR)
        elif self._kb_guide is not None:
            self._draw_label("動画の名前を変える / Rename the video", MARGIN, 3, 22, TEXT_COLOR)
            hint = f"今の名前: {guide.display_title(self._kb_guide.name)}　新しい名前を打って「送信」/ Type the new name and Send"
            self._draw_fitted_label(hint, MARGIN, 29, (15, 14, 13, 12), SUBTEXT_COLOR)
        elif self._kb_fix is not None:
            # 訂正の入力: どの文の訳を直すのかを見せる
            self._draw_label("訂正の入力 / Fix the translation", MARGIN, 3, 22, TEXT_COLOR)
            hint = f"原文: {self._kb_fix[1]}　→　{NATIVE_NAMES[self._kb_fix[2]]}で、正しい訳を打ってください"
            self._draw_fitted_label(hint, MARGIN, 29, (15, 14, 13, 12), SUBTEXT_COLOR)
        else:
            self._draw_label("文字入力 / Keyboard", MARGIN, 3, 22, TEXT_COLOR)
            # 送れなかったときの知らせは、入力方法の説明の代わりに出す
            hint, color = (self._kb_message, BLINK_BRIGHT_COLOR) if self._kb_message else (INPUT_HINTS.get(lang, ""), SUBTEXT_COLOR)
            self._draw_label(hint, MARGIN, 29, 14, color)
            self._draw_direction(self._kb_swap_button, snap, 20)
        if not can_type(lang):
            # 中国語・広東語は打てない。話す人を切り替えるか、戻る
            rect = pygame.Rect(MARGIN, KB_ENTRY_TOP + 30, self._width - 2 * MARGIN, 200)
            self._draw_text(UNSUPPORTED_MESSAGE, self._fonts[JA], rect, (28, 24, 20), TEXT_COLOR)
            self._draw_two_line_button(self._close_button, "戻る", "Back", BUTTON_COLOR)
            return
        entry = self._kb_entry
        pygame.draw.rect(self._surface, ENTRY_COLOR, entry, border_radius=8)
        pygame.draw.rect(self._surface, ENTRY_BORDER_COLOR, entry, width=2, border_radius=8)
        shown = self._kb_entry_text(lang)
        font = self._fonts[self._font_key(lang, snap)]
        text, size = self._fit_entry(font, shown, entry.width - 28, KB_ENTRY_SIZES)
        font.render_to(
            self._surface, (entry.left + 14, entry.centery + round(size * 0.36)), text, fgcolor=TEXT_COLOR, size=size
        )
        # 文字を打つ位置（縦の線）
        cursor_x = entry.left + 16 + (font.get_rect(text, size=size).width if text else 0)
        pygame.draw.line(self._surface, TEXT_COLOR, (cursor_x, entry.top + 12), (cursor_x, entry.bottom - 12), 2)
        self._draw_two_line_button(self._kb_clear_button, "消去", "Clear", BUTTON_COLOR, title_size=22)
        for rect, key in self._kb_keys(lang):
            self._draw_keyboard_key(rect, key, snap, bool(shown))

    def _draw_keyboard_key(self, rect: pygame.Rect, key: skb.Key, snap: Snapshot, has_text: bool) -> None:
        if key.action == skb.SEND:
            color = START_COLOR if has_text else DISABLED_BUTTON_COLOR
        elif (key.action == skb.SHIFT and self._kb_shift) or (key.action == skb.SYMBOLS and self._kb_symbols):
            color = BUTTON_ACTIVE_COLOR
        else:
            color = BUTTON_COLOR
        if key.action != skb.KEY or key.label == skb.SPACE_LABEL:
            self._draw_button(rect, key.label, 18, color)
            return
        # 文字のキー: 半角の文字は記号の見分けがつくフォントで、ほかの文字はその言語の書体で、大きく描く。
        # 上下は文字の基準線（ベースライン）でそろえる（見える部分の真ん中にそろえると、記号がずれて見える）
        pygame.draw.rect(self._surface, color, rect, border_radius=10)
        kb_lang = self._kb_lang(snap)
        font = self._key_font if key.label.isascii() else self._fonts[self._font_key(kb_lang, snap)]
        if key.label in skb.CENTERED_LABELS:
            image, _ = font.render(key.label, TEXT_COLOR, size=KB_KEY_SIZE)
            self._surface.blit(image, image.get_rect(center=rect.center))
            return
        # ハングルの字母は、同じ大きさでも小さく見えるので、少し大きく描く
        size = KB_HANGUL_KEY_SIZE if kb_lang == KO and not key.label.isascii() else KB_KEY_SIZE
        width = font.get_rect(key.label, size=size).width
        font.render_to(
            self._surface,
            (rect.centerx - width // 2, rect.centery + round(size * 0.36)),
            key.label,
            fgcolor=TEXT_COLOR,
            size=size,
        )

    def _draw_phrases(self, snap: Snapshot) -> None:
        """定型文の一覧（1 画面に LIST_ROWS 行。多いときは「前へ」「次へ」で送る）。右上に「音声検索」。"""
        self._surface.fill(MENU_BACKGROUND)
        phrases = self._on_phrase_list()
        indices = self._phrase_indices(phrases)
        search = self._phrase_search_button
        if self._phrase_filter is None:
            # 業種で絞っていて、出していない文があるときは「出している数 / 登録数」
            count = f"{len(indices)}" if len(indices) == len(phrases) else f"{len(indices)}/{len(phrases)}"
            title = f"定型文 / Phrases（{count}）"
        else:
            title = f"検索「{self._phrase_query}」{len(indices)} 件"
        font = self._fonts[JA]
        title_left = MARGIN + TITLE_ICON_SHIFT - 4
        title_width = search.left - 12 - title_left
        title_size = next((s for s in (28, 24, 20, 17) if font.get_rect(title, size=s).width <= title_width), 17)
        # この画面の見出しは、ほかの画面より 4px 上に描く
        self._draw_icon(icons.BUBBLE, (MARGIN + TITLE_ICON_SIZE // 2, MENU_TITLE_Y + TITLE_ICON_Y - 4 + TITLE_ICON_SIZE // 2), TITLE_ICON_SIZE)
        self._surface.set_clip(pygame.Rect(title_left, 0, title_width, LIST_ROW_TOP))
        self._draw_label(title, title_left, MENU_TITLE_Y - 4, title_size, TEXT_COLOR)
        self._surface.set_clip(None)
        # 見出しの右（「音声検索」ボタンの左）に、今できること・結果の知らせを小さく出す
        if self._phrase_searching:
            hint, color = f"{NATIVE_NAMES[snap.mode.speaker]}で、文の初めを話してください", LISTENING_COLOR
        elif self._phrase_delete:
            hint, color = "消す文をタップしてください", DANGER_COLOR
        elif self._phrase_edit_mode:
            hint, color = "直す文をタップしてください", BUTTON_ACTIVE_COLOR
        else:
            hint, color = self._phrase_message.split("\n")[0] or "タップで訳文を出して読み上げ", SUBTEXT_COLOR
        hint_left = title_left + font.get_rect(title, size=title_size).width + 16
        hint_size = next((s for s in (18, 16, 14) if font.get_rect(hint, size=s).width <= search.left - 12 - hint_left), 0)
        if hint_size:
            label, _ = font.render(hint, color, size=hint_size)
            self._surface.blit(label, label.get_rect(midright=(search.left - 12, MENU_TITLE_Y + 16)))
        if self._phrase_searching:
            self._draw_two_line_button(search, "聞いています…", "Tap to stop", LISTENING_COLOR, title_size=18)
        elif self._phrase_filter is not None:
            self._draw_two_line_button(search, "すべて表示", "Show all", BUTTON_ACTIVE_COLOR, title_size=18)
        else:
            self._draw_two_line_button(search, "音声検索", "Voice search", PHRASE_BUTTON_COLOR, title_size=18)
        if not indices:
            rect = pygame.Rect(MARGIN, LIST_ROW_TOP + 30, self._width - 2 * MARGIN, 200)
            empty = PHRASE_EMPTY if not phrases else PHRASE_NO_MATCH
            self._draw_text(empty if self._phrase_filter is None else PHRASE_NOT_FOUND, font, rect, (24, 20), SUBTEXT_COLOR)
        shown = indices[self._phrase_first : self._phrase_first + LIST_ROWS]
        for rect, index in zip(self._list_rows, shown):
            phrase = phrases[index]
            row_color = POWER_BUTTON_COLOR if self._phrase_delete else BUTTON_ACTIVE_COLOR if self._phrase_edit_mode else BUTTON_COLOR
            pygame.draw.rect(self._surface, row_color, rect, border_radius=10)
            self._draw_chip(phrase.lang, rect.left + 10, rect.top + (rect.height - CHIP_HEIGHT) // 2, snap.zh_traditional)
            text_font = self._fonts[self._font_key(phrase.lang, snap)]
            left = rect.left + 10 + CHIP_WIDTH + 14
            right = rect.right - 16
            # 右端に、使った回数と登録日を出す（文と重ならないよう、その分だけ文の幅を狭くする）
            note = "  ".join(part for part in (f"{phrase.uses}回" if phrase.uses else "", phrase.added_date) if part)
            if note:
                date, _ = self._fonts[JA].render(note, SUBTEXT_COLOR, size=PHRASE_DATE_SIZE)
                self._surface.blit(date, date.get_rect(midright=(right, rect.centery)))
                right -= date.get_width() + 14
            width = right - left
            size = next(
                (s for s in PHRASE_TEXT_SIZES if text_font.get_rect(phrase.text, size=s).width <= width), PHRASE_TEXT_SIZES[-1]
            )
            surface, _ = text_font.render(phrase.text, TEXT_COLOR, size=size)
            self._surface.set_clip(pygame.Rect(left, rect.top, width, rect.height))  # 長い文は、はみ出す部分を描かない
            self._surface.blit(surface, surface.get_rect(midleft=(left, rect.centery)))
            self._surface.set_clip(None)
        self._draw_two_line_button(self._phrase_add_button, "登録", "Save last", START_COLOR, title_size=22)
        delete_color = DANGER_COLOR if self._phrase_delete else BUTTON_COLOR
        self._draw_two_line_button(self._phrase_delete_button, "削除", "Delete", delete_color, title_size=22)
        edit_color = BUTTON_ACTIVE_COLOR if self._phrase_edit_mode else BUTTON_COLOR
        self._draw_two_line_button(self._phrase_edit_button, "修正", "Edit", edit_color, title_size=22)
        if self._phrase_first > 0:
            self._draw_two_line_button(self._power_button, "◀ 前へ", "Previous", BUTTON_COLOR, title_size=22)
        if self._phrase_first + LIST_ROWS < len(indices):
            self._draw_two_line_button(self._sound_button, "次へ ▶", "Next", BUTTON_COLOR, title_size=22)
        self._draw_two_line_button(self._close_button, "戻る", "Back", BUTTON_COLOR)

    def _draw_phrase_edit(self, snap: Snapshot) -> None:
        """定型文の修正の画面: 先頭に元の文、そのあとに各言語の訳文（1 画面に LIST_ROWS 行。「前へ」「次へ」で送る）。"""
        self._surface.fill(MENU_BACKGROUND)
        phrase = self._editing_phrase()
        font = self._fonts[JA]
        self._draw_icon(icons.BUBBLE, (MARGIN + TITLE_ICON_SIZE // 2, MENU_TITLE_Y + TITLE_ICON_Y - 4 + TITLE_ICON_SIZE // 2), TITLE_ICON_SIZE)
        title_left = MARGIN + TITLE_ICON_SHIFT - 4
        self._draw_label(PHRASE_EDIT_TITLE, title_left, MENU_TITLE_Y - 4, 28, TEXT_COLOR)
        self._draw_two_line_button(self._close_button, "戻る", "Back", BUTTON_COLOR)
        if phrase is None:
            return
        message = self._phrase_edit_message or PHRASE_EDIT_HINT
        self._draw_fitted_label(message, title_left, MENU_TITLE_Y + 30, (16, 15, 14, 13), SUBTEXT_COLOR)
        rows = self._phrase_edit_rows(phrase)
        shown = rows[self._phrase_edit_first : self._phrase_edit_first + LIST_ROWS]
        for rect, (field, lang, current) in zip(self._list_rows, shown):
            pygame.draw.rect(self._surface, BUTTON_ACTIVE_COLOR if field == "src" else BUTTON_COLOR, rect, border_radius=10)
            self._draw_chip(lang, rect.left + 10, rect.top + (rect.height - CHIP_HEIGHT) // 2, snap.zh_traditional)
            text_font = self._fonts[self._font_key(lang, snap)]
            left, right = rect.left + 10 + CHIP_WIDTH + 14, rect.right - 16
            if not can_type(lang):
                note, _ = font.render("打てません", SUBTEXT_COLOR, size=PHRASE_DATE_SIZE)
                self._surface.blit(note, note.get_rect(midright=(right, rect.centery)))
                right -= note.get_width() + 14
            text, color = (current, TEXT_COLOR) if current else (PHRASE_EDIT_EMPTY_TRANSLATION, SUBTEXT_COLOR)
            width = right - left
            size = next((s for s in PHRASE_TEXT_SIZES if text_font.get_rect(text, size=s).width <= width), PHRASE_TEXT_SIZES[-1])
            surface, _ = (text_font if current else font).render(text, color, size=size)
            self._surface.set_clip(pygame.Rect(left, rect.top, width, rect.height))
            self._surface.blit(surface, surface.get_rect(midleft=(left, rect.centery)))
            self._surface.set_clip(None)
        if self._phrase_edit_first > 0:
            self._draw_two_line_button(self._power_button, "◀ 前へ", "Previous", BUTTON_COLOR, title_size=22)
        if self._phrase_edit_first + LIST_ROWS < len(rows):
            self._draw_two_line_button(self._sound_button, "次へ ▶", "Next", BUTTON_COLOR, title_size=22)

    @staticmethod
    def _guide_count(section: guide.Section | None) -> int:
        """お客様用 / 店舗用にある動画・スライドの数（分類の中も含む）。"""
        if section is None:
            return 0
        return len(section.items) + sum(len(category.items) for category in section.categories)

    def _draw_guide(self, snap: Snapshot) -> None:
        """「使い方」の最初の画面: 大きく お客様用 / 店舗用 に分ける。"""
        self._surface.fill(MENU_BACKGROUND)
        self._draw_title_icon(icons.GUIDE)
        self._draw_label("ガイド / Guide", MARGIN + TITLE_ICON_SHIFT, MENU_TITLE_Y, 30, TEXT_COLOR)
        self._draw_label("動画とスライドで、使い方をご覧いただけます / Watch videos and slides", MARGIN, 56, 18, SUBTEXT_COLOR)
        for audience, rect in self._guide_audience_buttons.items():
            pygame.draw.rect(self._surface, GUIDE_AUDIENCE_COLORS[audience], rect, border_radius=14)
            label, label_en = guide.AUDIENCE_LABELS[audience]
            self._draw_icon(GUIDE_AUDIENCE_ICONS[audience], (rect.centerx, rect.top + 66), 80)
            self._blit_centered_at(label, rect, 40, 0.57)
            self._blit_centered_at(label_en, rect, 22, 0.73)
            locked = audience == guide.STORE and self._pins.general_required()
            if locked:
                # 番号が要る（押すと、4 桁の番号を聞く。中身の数は、番号を入れるまで見せない）
                note = "番号が必要です / PIN required"
                self._draw_icon(icons.LOCK, (rect.right - 38, rect.top + 38), 40)
            else:
                count = self._guide_count(self._guides.get(audience))
                note = f"動画・スライド {count} 件" if count else "まだありません / None yet"
            self._blit_centered_at(note, rect, 18, 0.89)
        for lang, rect in ((KO, self._study_button), (EN, self._study_en_button), (ZH, self._study_zh_button)):
            label, label_en = STUDY_COURSE_LABELS[lang]
            self._draw_two_line_button(rect, label, label_en, STUDY_COLOR, title_size=22, icon=icons.CHECKLIST, subtitle_size=13)
        self._draw_two_line_button(self._close_button, "戻る", "Back", BUTTON_COLOR)

    def _draw_pin(self, snap: Snapshot) -> None:
        """暗証番号を入れる画面: 入れた桁を丸で見せ（番号そのものは出さない）、右に数字のキー。"""
        self._surface.fill(MENU_BACKGROUND)
        task = PIN_TASKS.get(self._pin_kind, PIN_TASKS["store"])
        self._draw_icon(task.icon, (MARGIN + TITLE_ICON_SIZE // 2, MENU_TITLE_Y + 19), TITLE_ICON_SIZE)
        left_width = min(rect.left for rect in self._pin_keys.values()) - MARGIN - 20
        self._draw_fitted_label(
            f"{task.title} / {task.title_en}", MARGIN + TITLE_ICON_SHIFT, MENU_TITLE_Y - 2, TITLE_SIZES, TEXT_COLOR
        )
        font = self._fonts[JA]
        asking = self._pin_step if task.setting else False
        prompt_ja, prompt_en = PIN_PROMPTS[(task.group, asking)]
        for text, size, color, top in ((prompt_ja, 26, TEXT_COLOR, 108), (prompt_en, 19, SUBTEXT_COLOR, 148)):
            fitted = next((s for s in (size, size - 2, size - 4, size - 6) if font.get_rect(text, size=s).width <= left_width), size - 6)
            label, _ = font.render(text, color, size=fitted)
            self._surface.blit(label, (MARGIN, top))
        if task.setting:
            step_label, _ = font.render(f"{self._pin_step} / 2", SUBTEXT_COLOR, size=22)
            self._surface.blit(step_label, (MARGIN, 186))
        # 入れた桁の数だけ塗りつぶした丸
        count = PIN_LENGTH
        radius, step = 22, 66
        first_x = MARGIN + radius + 4
        for i in range(count):
            center = (first_x + i * step, 250)
            if i < len(self._pin_entry):
                pygame.draw.circle(self._surface, TEXT_COLOR, center, radius)
            else:
                pygame.draw.circle(self._surface, SUBTEXT_COLOR, center, radius, width=3)
        if self._pin_message:
            rect = pygame.Rect(MARGIN, 300, left_width, 80)
            self._draw_text(self._pin_message, font, rect, (22, 19, 16), BLINK_BRIGHT_COLOR)
        for name, rect in self._pin_keys.items():
            if name == "clear":
                self._draw_two_line_button(rect, "消去", "Clear", BUTTON_COLOR, title_size=22)
            elif name == "back":
                self._draw_two_line_button(rect, "◀ 削除", "Delete", BUTTON_COLOR, title_size=22)
            else:
                pygame.draw.rect(self._surface, BUTTON_COLOR, rect, border_radius=10)
                digit, _ = self._fonts[EN].render(name, TEXT_COLOR, size=38)
                self._surface.blit(digit, digit.get_rect(center=rect.center))
        self._draw_two_line_button(self._pin_back_button, "戻る", "Back", BUTTON_COLOR)

    def _draw_guide_list(self, snap: Snapshot) -> None:
        """お客様用 / 店舗用の中の一覧（店舗用は、まず 操作説明・従業員用・管理者用 の分類）。"""
        self._surface.fill(MENU_BACKGROUND)
        audience = self._guide_audience
        label, label_en = guide.AUDIENCE_LABELS[audience]
        category = self._guide_category
        title = f"{label} › {category.label}" if category else f"{label} / {label_en}"
        self._draw_icon(GUIDE_AUDIENCE_ICONS[audience], (MARGIN + TITLE_ICON_SIZE // 2, MENU_TITLE_Y + 19), TITLE_ICON_SIZE)
        self._draw_fitted_label(title, MARGIN + TITLE_ICON_SHIFT, MENU_TITLE_Y - 2, TITLE_SIZES, TEXT_COLOR)
        entries = self._guide_entries()
        font = self._fonts[JA]
        if not entries:
            place = f"{audience}/{category.key}" if category else audience
            rect = pygame.Rect(MARGIN, LIST_ROW_TOP + 30, self._width - 2 * MARGIN, 200)
            self._draw_text(GUIDE_EMPTY.format(place=place), font, rect, (24, 20), SUBTEXT_COLOR)
        shown = entries[self._guide_first : self._guide_first + LIST_ROWS]
        for rect, (kind, entry) in zip(self._list_rows, shown):
            if kind == "category":
                color, icon, note = GUIDE_CATEGORY_COLOR, icons.FOLDER, f"{len(entry.items)} 件 ›"
                name = entry.label if not entry.label_en else f"{entry.label} / {entry.label_en}"
            elif entry.kind == guide.VIDEO:
                color, icon, note, name = BUTTON_COLOR, icons.PLAY, "動画 Video", entry.title
            else:
                color, icon, note = BUTTON_COLOR, icons.SLIDES, f"スライド {entry.page_count} 枚"
                name = entry.title
            pygame.draw.rect(self._surface, color, rect, border_radius=10)
            self._draw_icon(icon, (rect.left + 14 + 15, rect.centery), 30)
            right = rect.right - 16
            note_surface, _ = font.render(note, SUBTEXT_COLOR, size=18)
            self._surface.blit(note_surface, note_surface.get_rect(midright=(right, rect.centery)))
            left = rect.left + 14 + 30 + 14
            width = right - note_surface.get_width() - 14 - left
            size = next((s for s in GUIDE_ROW_SIZES if font.get_rect(name, size=s).width <= width), GUIDE_ROW_SIZES[-1])
            text, _ = font.render(name, TEXT_COLOR, size=size)
            self._surface.set_clip(pygame.Rect(left, rect.top, width, rect.height))  # 長い題名は、はみ出す部分を描かない
            self._surface.blit(text, text.get_rect(midleft=(left, rect.centery)))
            self._surface.set_clip(None)
        if self._guide_first > 0:
            self._draw_two_line_button(self._power_button, "◀ 前へ", "Previous", BUTTON_COLOR, title_size=22)
        if self._guide_first + LIST_ROWS < len(entries):
            self._draw_two_line_button(self._sound_button, "次へ ▶", "Next", BUTTON_COLOR, title_size=22)
        if self._guide_admin_shown():
            self._draw_two_line_button(
                self._guide_admin_button, "動画の追加・管理", "Add & manage videos", GUIDE_BUTTON_COLOR, title_size=20, subtitle_size=13
            )
        self._draw_two_line_button(self._close_button, "戻る", "Back", BUTTON_COLOR)

    def _guide_slide_surface(self, path: Path, size: tuple[int, int]) -> pygame.Surface | None:
        """スライドの画像を、size に収まる大きさに縮める（縦横の比はそのまま）。読めなければ None。同じ画像・大きさは覚えておく。"""
        cached = self._guide_image
        if cached is not None and cached[0] == path and cached[1] == size:
            return cached[2]
        try:
            image = pygame.image.load(str(path))
            # 色の数が少ない（パレット）画像や透明な画像でも縮められるよう、32 ビットの面に写す
            flat = pygame.Surface(image.get_size(), 0, 32)
            flat.blit(image, (0, 0))
            scale = min(size[0] / flat.get_width(), size[1] / flat.get_height())
            new_size = (max(1, round(flat.get_width() * scale)), max(1, round(flat.get_height() * scale)))
            result: pygame.Surface | None = pygame.transform.smoothscale(flat, new_size)
        except (pygame.error, OSError):
            log.exception("スライドの画像を読み込めません: %s", path)
            result = None
        self._guide_image = (path, size, result)
        return result

    def _draw_guide_view(self, snap: Snapshot) -> None:
        """スライド（画像を 1 枚ずつ。前へ・次へ）か、動画の画面（再生中は動画のプログラムが画面を使うので、これは再生の前後）。"""
        item = self._guide_item
        self._surface.fill(BACKGROUND)
        if item is None:
            return
        font = self._fonts[JA]
        if item.kind == guide.VIDEO:
            icon_center = (self._width // 2, 110)
            self._draw_icon(icons.PLAY, icon_center, 72, SUBTEXT_COLOR)
            title, _ = font.render(item.title, TEXT_COLOR, size=32)
            self._surface.blit(title, title.get_rect(center=(self._width // 2, 180)))
            again = snap.guide_error == "" and self._guide_was_started
            pygame.draw.rect(self._surface, START_COLOR, self._guide_play_button, border_radius=12)
            self._blit_centered_at("もう一度再生" if again else "再生", self._guide_play_button, 30, 0.38)
            self._blit_centered_at("Play again" if again else "Play", self._guide_play_button, 18, 0.76)
            if snap.guide_error:
                rect = pygame.Rect(MARGIN, 310, self._width - 2 * MARGIN, 70)
                self._draw_text(snap.guide_error, font, rect, (20, 18), BLINK_BRIGHT_COLOR)
            else:
                hint, _ = font.render("再生中に画面をタップすると止まります / Tap the screen to stop", SUBTEXT_COLOR, size=18)
                self._surface.blit(hint, hint.get_rect(center=(self._width // 2, 330)))
        else:
            area = self._guide_image_area
            image = self._guide_slide_surface(item.pages[self._guide_slide], area.size)
            if image is None:
                self._draw_text("画像を読み込めません / Cannot load the image", font, area.inflate(-80, -160), (24, 20), BLINK_BRIGHT_COLOR)
            else:
                self._surface.blit(image, image.get_rect(center=area.center))
        # 下の段: 題名と何枚目か、「前へ」「次へ」、「戻る」
        bar = self._close_button
        left_width = self._power_button.left - MARGIN - BUTTON_GAP
        title_size = next((s for s in (20, 17, 15) if font.get_rect(item.title, size=s).width <= left_width), 15)
        title_surface, _ = font.render(item.title, SUBTEXT_COLOR, size=title_size)
        self._surface.set_clip(pygame.Rect(MARGIN, bar.top, left_width, bar.height))
        self._surface.blit(title_surface, title_surface.get_rect(midleft=(MARGIN, bar.top + 18)))
        self._surface.set_clip(None)
        if item.kind == guide.SLIDES:
            counter, _ = font.render(f"{self._guide_slide + 1} / {item.page_count}", TEXT_COLOR, size=26)
            self._surface.blit(counter, counter.get_rect(midleft=(MARGIN, bar.top + 46)))
            prev_color = BUTTON_COLOR if self._guide_slide > 0 else DISABLED_BUTTON_COLOR
            next_color = BUTTON_COLOR if self._guide_slide + 1 < item.page_count else DISABLED_BUTTON_COLOR
            self._draw_two_line_button(self._power_button, "◀ 前へ", "Previous", prev_color, title_size=22)
            self._draw_two_line_button(self._sound_button, "次へ ▶", "Next", next_color, title_size=22)
        self._draw_two_line_button(self._close_button, "戻る", "Back", BUTTON_COLOR)

    def _draw_shutdown(self, snap: Snapshot) -> None:
        self._draw_power_progress("電源を切っています…", "緑のランプが消えたら、電源ケーブルを抜いてください")

    def _draw_reboot(self, snap: Snapshot) -> None:
        self._draw_power_progress("再起動しています…", "1〜2 分でこの画面に戻ります。電源ケーブルは抜かないでください")

    def _draw_power_progress(self, title_text: str, hint_text: str) -> None:
        self._surface.fill(BACKGROUND)
        center_x, center_y = self._width // 2, self._height // 2
        title, _ = self._fonts[JA].render(title_text, TEXT_COLOR, size=36)
        self._surface.blit(title, title.get_rect(center=(center_x, center_y - 30)))
        hint, _ = self._fonts[JA].render(hint_text, SUBTEXT_COLOR, size=22)
        self._surface.blit(hint, hint.get_rect(center=(center_x, center_y + 30)))

    def _draw_start_button(self, snap: Snapshot) -> None:
        """「会話スタート」ボタン。状態表示を兼ね、待機中は押せる色、聞き取り中は目立つ色、処理中は暗い色にする。"""
        rect = self._start_button
        # 相手の人も分かるように、日本語と英語を併記する
        if not snap.ready:
            # 起動中（モデルの読み込み・翻訳サーバーの起動待ち）は押せない。今していること（「翻訳サーバーの起動を待っています」など）は
            # 起動画面の真ん中に大きく出るので、ボタンには短い文だけを出す（長い文はボタンからはみ出していた。2026-11-09）
            if snap.startup_error:
                color, title, subtitle = DISABLED_BUTTON_COLOR, snap.status, "理由は画面の文をご覧ください"
            else:
                color, title, subtitle = DISABLED_BUTTON_COLOR, "起動中… / Starting", "お待ちください / Please wait"
        elif snap.listening_armed:
            color, title, subtitle = LISTENING_COLOR, LISTENING, "話し終わると翻訳・タップで中止 / Tap to cancel"
        elif snap.idle:
            color, title, subtitle = START_COLOR, "会話スタート / Start", snap.status
        else:
            # 翻訳・読み上げの途中。タップでやめて待機中に戻せる
            # 「再生」ボタンで合成から始めたときは、音が出るまで待ってもらう文を出す
            hint = PLAY_WAIT_SUBTITLE if snap.waiting_for_audio else "タップで中止 / Tap to cancel"
            color, title, subtitle = BUTTON_COLOR, snap.status, hint
        pygame.draw.rect(self._surface, color, rect, border_radius=10)
        font = self._fonts[JA]
        inner = rect.width - 20
        title_size = next((s for s in START_TITLE_SIZES if font.get_rect(title, size=s).width <= inner), START_TITLE_SIZES[-1])
        subtitle_size = next(
            (s for s in START_SUBTITLE_SIZES if font.get_rect(subtitle, size=s).width <= inner), START_SUBTITLE_SIZES[-1]
        )
        title_surface, _ = font.render(title, TEXT_COLOR, size=title_size)
        subtitle_surface, _ = font.render(subtitle, TEXT_COLOR, size=subtitle_size)
        # 一番小さい文字でも入りきらない文（長いエラーの文など）は、ボタンの幅まで縮めて、はみ出さないようにする
        title_surface, subtitle_surface = (_shrink_to_width(s, inner) for s in (title_surface, subtitle_surface))
        self._surface.blit(title_surface, title_surface.get_rect(center=(rect.centerx, rect.top + rect.height * 0.38)))
        self._surface.blit(subtitle_surface, subtitle_surface.get_rect(center=(rect.centerx, rect.top + rect.height * 0.78)))

    def _draw_on_off(
        self,
        label: str,
        buttons: list[pygame.Rect],
        enabled: bool,
        available: bool = True,
        label_y: int = SPEECH_LABEL_Y,
        english: bool = False,
        icon: str | None = None,
    ) -> None:
        """「オン」「オフ」の2つのボタンと見出し。available でなければ（今は効かない設定なら）暗く表示する。
        english なら、ボタンの 2 行目に「On」「Off」と英語を併記する。icon があれば、見出しの左に印を描く。
        """
        width = buttons[-1].right - buttons[0].left
        shift = LABEL_ICON_SHIFT if icon else 0
        size = next(
            (size for size in LABEL_SIZES if self._fonts[JA].get_rect(label, size=size).width <= width - shift), LABEL_SIZES[-1]
        )
        if icon:
            self._draw_icon(icon, (buttons[0].left + LABEL_ICON_SIZE // 2, label_y + 13), LABEL_ICON_SIZE, SUBTEXT_COLOR)
        self._draw_label(label, buttons[0].left + shift, label_y, size, SUBTEXT_COLOR)
        active, inactive = (BUTTON_ACTIVE_COLOR, BUTTON_COLOR) if available else (UNAVAILABLE_ACTIVE_COLOR, DISABLED_BUTTON_COLOR)
        for value, rect in zip((True, False), buttons):
            color = active if value == enabled else inactive
            if english:
                self._draw_two_line_button(rect, "オン" if value else "オフ", "On" if value else "Off", color, title_size=26)
            else:
                self._draw_button(rect, "オン" if value else "オフ", 28, color)

    def _draw_stepper(
        self,
        down: pygame.Rect,
        up: pygame.Rect,
        value: str,
        value_size: int = 36,
        caption: str | None = None,
    ) -> None:
        """「−」「＋」と、その間の値。caption を渡すと、値の上に小さく見出しを出す（見出しの行がない場所用）。"""
        self._draw_button(down, "−", 40, BUTTON_COLOR)
        self._draw_button(up, "+", 40, BUTTON_COLOR)
        center_x, center_y = (down.right + up.left) // 2, down.centery
        if caption:
            label, _ = self._fonts[JA].render(caption, SUBTEXT_COLOR, size=STEPPER_CAPTION_SIZE)
            self._surface.blit(label, label.get_rect(midtop=(center_x, down.top + 2)))
            center_y = down.top + round(down.height * 0.64)
        text, _ = self._fonts[EN].render(value, TEXT_COLOR, size=value_size)
        self._surface.blit(text, text.get_rect(center=(center_x, center_y)))

    def _draw_divider(self, y: int) -> None:
        pygame.draw.line(self._surface, DIVIDER_COLOR, (MARGIN, y), (self._width - MARGIN, y), 2)

    def _draw_pron(self, pron: str, rect: pygame.Rect) -> None:
        """発音記号（IPA などの記号が出せるフォントで、訳文より小さく表示する）。"""
        self._draw_text(pron, self._phonetic_font, rect, PRON_SIZES, PRON_COLOR)

    def _draw_text(
        self,
        text: str,
        font: pygame.freetype.Font,
        rect: pygame.Rect,
        sizes: tuple[int, ...],
        color: tuple[int, int, int],
    ) -> int:
        """rect に収まるように折り返して描き、描いた最後の行の下端の y 座標を返す。"""
        lines, size = fit_text(
            text,
            rect.width,
            rect.height,
            sizes,
            measure=lambda s, sz: font.get_rect(s, size=sz).width if s else 0,
            line_height=lambda sz: int(sz * LINE_SPACING),
        )
        line_height = int(size * LINE_SPACING)
        baseline = rect.top + font.get_sized_ascender(size)
        for line in lines:
            font.render_to(self._surface, (rect.left, baseline), line, fgcolor=color, size=size)
            baseline += line_height
        return rect.top + len(lines) * line_height

    def _draw_status(self, status: str, left: int, center_y: int, max_width: int) -> None:
        """状態表示。長い文は、収まるまで文字を小さくする。"""
        font = self._fonts[JA]
        text = f"● {status}"
        for size in STATUS_SIZES:
            if font.get_rect(text, size=size).width <= max_width:
                break
        surface, _ = font.render(text, SUBTEXT_COLOR, size=size)
        self._surface.blit(surface, surface.get_rect(midleft=(left, center_y)))

    def _draw_label(self, text: str, x: int, y: int, size: int, color: tuple[int, int, int]) -> None:
        surface, _ = self._fonts[JA].render(text, color, size=size)
        self._surface.blit(surface, (x, y))

    def _draw_fitted_label(
        self,
        text: str,
        x: int,
        y: int,
        sizes: tuple[int, ...] = LABEL_SIZES,
        color: tuple[int, int, int] = SUBTEXT_COLOR,
    ) -> None:
        """見出し。英語を併記して長くなったときは、画面の幅に収まるまで文字を小さくする。"""
        max_width = self._width - x - MARGIN
        font = self._fonts[JA]
        size = next((s for s in sizes if font.get_rect(text, size=s).width <= max_width), sizes[-1])
        self._draw_label(text, x, y, size, color)

    def _draw_two_line_button(
        self,
        rect: pygame.Rect,
        title: str,
        subtitle: str,
        color: tuple[int, int, int],
        title_size: int = 24,
        icon: str | None = None,
        subtitle_size: int = 16,
    ) -> None:
        """1行目に日本語、2行目に小さく英語を書いたボタン（「戻る / Back」など）。icon があれば、左端に印を描く。"""
        pygame.draw.rect(self._surface, color, rect, border_radius=10)
        dx = BUTTON_ICON_TEXT_SHIFT if icon else 0
        self._blit_centered_at(title, rect, title_size, 0.38, dx)
        self._blit_centered_at(subtitle, rect, subtitle_size, 0.76, dx)
        if icon:
            self._draw_button_icon(icon, rect)

    @staticmethod
    def _font_key(lang: str, snap: Snapshot) -> str:
        """文字を描く書体（台湾の繁体字を選んでいるときの中国語は、台湾の字形の書体にする）。"""
        return ZH_HANT if lang == ZH and snap.zh_traditional else lang

    def _draw_chip(self, lang: str, x: int, y: int, traditional: bool = False) -> None:
        """文の左に出す言語の印（言語の色の地に、その国の旗）。旗が無い言語は、言語の略号を書く。"""
        rect = pygame.Rect(x, y, CHIP_WIDTH, CHIP_HEIGHT)
        pygame.draw.rect(self._surface, LANG_COLORS.get(lang, BUTTON_COLOR), rect, border_radius=8)
        if flags.flag_name(lang, traditional) in flags.FLAG_NAMES:
            self._draw_flag(lang, traditional, FLAG_WIDTH_CHIP, center=rect.center)
        else:
            self._blit_centered(LANG_LABELS.get(lang, lang.upper()), rect, 20, EN)

    def _draw_button(
        self, rect: pygame.Rect, text: str, size: int, color: tuple[int, int, int], lang: str = JA, icon: str | None = None
    ) -> None:
        pygame.draw.rect(self._surface, color, rect, border_radius=10)
        if icon is None:
            self._blit_centered(text, rect, size, lang)
            return
        surface, _ = self._fonts[lang].render(text, TEXT_COLOR, size=size)
        surface_rect = surface.get_rect(center=(rect.centerx + BUTTON_ICON_TEXT_SHIFT, rect.centery))
        self._surface.blit(surface, surface_rect)
        # 大きい文字のボタンでは、印も文字の高さに合わせて大きくする
        self._draw_button_icon(icon, rect, max(BUTTON_ICON_SIZE, round(size * 1.4)))

    def _blit_centered(self, text: str, rect: pygame.Rect, size: int, lang: str) -> None:
        surface, _ = self._fonts[lang].render(text, TEXT_COLOR, size=size)
        self._surface.blit(surface, surface.get_rect(center=rect.center))

    def _blit_runs_centered(
        self, runs: list[tuple[str, str]], rect: pygame.Rect, size: int, center_y: int | None = None
    ) -> None:
        """書体の違う文字列（例: 「日本語 → 」と「ภาษาไทย」）を横に並べて、rect の中央（高さは center_y）に描く。

        日本語とタイ文字の両方を持つフォントがないため、部分ごとにその言語の書体で描いてつなげる。
        """
        y = rect.centery if center_y is None else center_y
        surfaces = [self._fonts[font].render(text, TEXT_COLOR, size=size)[0] for text, font in runs]
        x = rect.centerx - sum(surface.get_width() for surface in surfaces) // 2
        for surface in surfaces:
            self._surface.blit(surface, surface.get_rect(midleft=(x, y)))
            x += surface.get_width()

    def _blit_centered_at(self, text: str, rect: pygame.Rect, size: int, height_ratio: float, dx: int = 0) -> None:
        """2行のボタンの1行分を描く（height_ratio はボタンの上端からの高さの割合。dx だけ右にずらす）。"""
        surface, _ = self._fonts[JA].render(text, TEXT_COLOR, size=size)
        self._surface.blit(surface, surface.get_rect(center=(rect.centerx + dx, rect.top + round(rect.height * height_ratio))))

    def _draw_icon(self, name: str, center: tuple[int, int], size: int, color: tuple[int, int, int] = TEXT_COLOR) -> None:
        """印（icons.py）を、center を中心にして描く。"""
        surface = icons.icon_surface(name, size, color)
        self._surface.blit(surface, surface.get_rect(center=center))

    def _draw_button_icon(self, name: str, rect: pygame.Rect, size: int = BUTTON_ICON_SIZE) -> None:
        """ボタンの左端に印を描く（文字は BUTTON_ICON_TEXT_SHIFT だけ右にずらして描く）。"""
        self._draw_icon(name, (rect.left + BUTTON_ICON_LEFT + size // 2, rect.centery), size)

    def _draw_flag(self, lang: str, traditional: bool, width: int, **anchor: tuple[int, int]) -> pygame.Rect:
        """言語の国旗を描く。anchor は Rect の位置の指定（midleft=(x, y) や center=(x, y)）。描いた範囲を返す。"""
        surface = flags.flag_surface(flags.flag_name(lang, traditional), width)
        rect = surface.get_rect(**anchor)
        self._surface.blit(surface, rect)
        return rect

    def _draw_title_icon(self, name: str) -> None:
        """画面の見出し（左上）の左に印を描く。見出しの文字は TITLE_ICON_SHIFT だけ右から描き始める。"""
        self._draw_icon(name, (MARGIN + TITLE_ICON_SIZE // 2, MENU_TITLE_Y + TITLE_ICON_Y + TITLE_ICON_SIZE // 2), TITLE_ICON_SIZE)


def _shrink_to_width(surface: pygame.Surface, width: int) -> pygame.Surface:
    """surface が width より広ければ、縦横の比を保ったまま width まで縮める（狭ければ、そのまま返す）。"""
    if surface.get_width() <= width or width <= 0:
        return surface
    height = max(1, round(surface.get_height() * width / surface.get_width()))
    return pygame.transform.smoothscale(surface, (width, height))


def _nice_axis(highest: int) -> tuple[int, int]:
    """縦軸（件数）の、いちばん上の値と、目盛りの間隔。目盛りは 5 本以内で、切りのよい数にする。"""
    for step in (1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000):
        if highest <= step * 5:
            return max(step * 2, -(-highest // step) * step), step
    return highest, max(1, highest // 5)


def _hours_text(hours: float) -> str:
    """稼働時間の書き方（1 時間未満は分、それ以上は 0.1 時間まで）。"""
    if round(hours * 60) < 60:
        return f"{round(hours * 60)}分"
    return f"{hours:.1f}時間"


def _total_text(seconds: float) -> str:
    """合計稼働時間の書き方（例: 123時間05分）。"""
    minutes = int(seconds // 60)
    return f"{minutes // 60}時間{minutes % 60:02d}分"
