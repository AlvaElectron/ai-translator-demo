"""操作説明の動画・スライドを置くフォルダを読む（メニューの「使い方」。pygame に依存しない）。

フォルダの置き方（config.toml の [guide] dir。既定は config.toml と同じ場所の guides）:

    guides/
      customer/                  お客様用
        01_ご利用案内.mp4          動画（mp4・mkv・webm・mov・avi）
        02_話しかけ方/             スライド（画像を番号順に入れたフォルダ）
          01.png  02.png  03.png
        03_案内.png                1 枚だけのスライド（png・jpg）
      store/                     店舗用
        howto/   操作説明（店舗用）
        staff/   従業員用
        admin/   管理者用
          01_Wi-Fiの設定.mp4
          02_電源の切り方/ 01.png 02.png

- 名前の順（数字は数として）に並ぶ。表示するときは、先頭の「01_」のような番号と拡張子を取り、「_」を空白にする。
- 店舗用の中のフォルダは分類（howto・staff・admin は決まった名前で表示し、それ以外は、フォルダの名前のまま）。
  お客様用も、中にフォルダ（動画か、さらにフォルダを含むもの）を置けば分類になる。画像だけのフォルダはスライドとして扱う。
- 店舗用は、中が空でも「操作説明・従業員用・管理者用」の 3 つを出す。
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

CUSTOMER, STORE = "customer", "store"
AUDIENCES = (CUSTOMER, STORE)
# 大きな分け方のボタンの文字（日本語, 英語）
AUDIENCE_LABELS = {CUSTOMER: ("お客様用", "For customers"), STORE: ("店舗用", "For the store")}
# 決まった名前の分類（フォルダ名 → 日本語, 英語）。この順に並べ、ほかの分類は名前順にその後ろに並べる
CATEGORY_LABELS = {
    "howto": ("操作説明", "How to use"),
    "staff": ("従業員用", "Staff"),
    "admin": ("管理者用", "Administrator"),
}
# 中が空でも出す分類
ALWAYS_SHOWN = {STORE: tuple(CATEGORY_LABELS)}

VIDEO_EXTS = frozenset({".mp4", ".mkv", ".webm", ".mov", ".avi"})
SLIDE_EXTS = frozenset({".png", ".jpg", ".jpeg"})

VIDEO, SLIDES = "video", "slides"

_NUMBER_PREFIX = re.compile(r"^\s*\d+\s*[_\-. ]+\s*")


@dataclass(frozen=True)
class Item:
    title: str
    kind: str  # VIDEO か SLIDES
    path: Path  # 動画のファイル / スライドのフォルダ（1 枚だけのときは画像のファイル）
    pages: tuple[Path, ...] = ()  # スライドの画像（順番どおり）

    @property
    def page_count(self) -> int:
        return len(self.pages)


@dataclass(frozen=True)
class Category:
    key: str
    label: str
    label_en: str
    items: tuple[Item, ...] = ()


@dataclass(frozen=True)
class Section:
    """お客様用か店舗用 1 つ分: 直接置かれた項目と、分類。"""

    audience: str
    items: tuple[Item, ...] = ()
    categories: tuple[Category, ...] = field(default_factory=tuple)

    @property
    def empty(self) -> bool:
        return not self.items and not any(category.items for category in self.categories)


def natural_key(name: str) -> list:
    """数字を数として比べる並べ替えの鍵（2 より 10 が後ろ）。"""
    return [int(part) if part.isdigit() else part.lower() for part in re.split(r"(\d+)", name)]


def display_title(name: str) -> str:
    """ファイル・フォルダの名前から、画面に出す題名を作る（先頭の番号と拡張子を取り、「_」を空白にする）。"""
    stem = Path(name).stem if Path(name).suffix.lower() in VIDEO_EXTS | SLIDE_EXTS else name
    stem = _NUMBER_PREFIX.sub("", stem) or stem
    return stem.replace("_", " ").strip() or name


def _sorted(paths) -> list[Path]:
    return sorted(paths, key=lambda path: natural_key(path.name))


def _images(folder: Path) -> tuple[Path, ...]:
    return tuple(_sorted(p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in SLIDE_EXTS and not p.name.startswith(".")))


def _read_items(folder: Path, skip: set[Path] = frozenset()) -> tuple[Item, ...]:
    """folder の直下の動画・画像・スライドのフォルダを、名前の順に項目にする（skip の分類のフォルダは除く）。"""
    items = []
    try:
        entries = _sorted(p for p in folder.iterdir() if not p.name.startswith("."))
    except OSError:
        return ()
    for entry in entries:
        suffix = entry.suffix.lower()
        if entry.is_file() and suffix in VIDEO_EXTS:
            items.append(Item(display_title(entry.name), VIDEO, entry))
        elif entry.is_file() and suffix in SLIDE_EXTS:
            items.append(Item(display_title(entry.name), SLIDES, entry, (entry,)))
        elif entry.is_dir() and entry not in skip:
            pages = _images(entry)
            if pages:
                items.append(Item(display_title(entry.name), SLIDES, entry, pages))
    return tuple(items)


def _is_deck(folder: Path) -> bool:
    """画像だけが入ったフォルダか（スライド）。動画やフォルダが入っていれば分類として扱う。"""
    if folder.name.lower() in CATEGORY_LABELS:
        return False
    try:
        entries = [p for p in folder.iterdir() if not p.name.startswith(".")]
    except OSError:
        return False
    if any(p.is_dir() or p.suffix.lower() in VIDEO_EXTS for p in entries):
        return False
    return any(p.suffix.lower() in SLIDE_EXTS for p in entries)


def read_section(root: Path, audience: str) -> Section:
    """root/<audience> を読む。フォルダが無ければ空の Section。"""
    folder = Path(root) / audience
    category_dirs: list[Path] = []
    if folder.is_dir():
        category_dirs = [p for p in _sorted(folder.iterdir()) if p.is_dir() and not p.name.startswith(".") and not _is_deck(p)]
    direct = _read_items(folder, skip=set(category_dirs)) if folder.is_dir() else ()
    by_key = {p.name.lower(): p for p in category_dirs}
    categories = []
    for key, (label, label_en) in CATEGORY_LABELS.items():
        if key in by_key or key in ALWAYS_SHOWN.get(audience, ()):
            path = by_key.get(key)
            categories.append(Category(key, label, label_en, _read_items(path) if path else ()))
    for path in category_dirs:
        if path.name.lower() not in CATEGORY_LABELS:
            categories.append(Category(path.name, display_title(path.name), "", _read_items(path)))
    return Section(audience, direct, tuple(categories))

def read_guides(root: Path) -> dict[str, Section]:
    """お客様用と店舗用の両方を読む。"""
    return {audience: read_section(root, audience) for audience in AUDIENCES}
