"""Wi-Fi の設定（メニューの「Wi-Fi設定」）。NetworkManager（nmcli）で、近くの Wi-Fi を探して、つなぐ。

- 探す: nmcli device wifi list（電波の強い順。つないでいるものを先頭に）。保存済みの接続は、名前（ふつうは SSID）で見分ける。
- つなぐ: 保存済み → nmcli connection up、パスワードの無い Wi-Fi → nmcli device wifi connect、
  パスワードのある Wi-Fi → 画面のキーボードで入れたパスワードで nmcli device wifi connect。
  つながらなかったときは、その接続を消す（間違ったパスワードを保存したままにしない。次にタップすると、パスワードを聞き直す）。
- アプリはサービスとして動くので、そのままでは Wi-Fi を変える許可が無い（NetworkManager は、画面の前でログインしている人にだけ
  許している）。scripts/allow_wifi.sh（最初の 1 回だけ sudo で実行）で、このユーザーに Wi-Fi の操作だけを許す。
"""

from __future__ import annotations

import logging
import subprocess
import threading
from collections.abc import Callable
from dataclasses import dataclass

from .ui_state import UiState

log = logging.getLogger(__name__)

NMCLI = "nmcli"
WIFI_CONNECTION_TYPE = "802-11-wireless"
# つなぐのを待つ時間（パスワードの確認や、アドレスをもらうまでに時間がかかる）
CONNECT_TIMEOUT_SEC = 45
COMMAND_TIMEOUT_SEC = 20

# 画面に出す状態（1 行目 日本語 / 英語）
SCANNING = "探しています… / Scanning…"
CONNECTING = "つないでいます… / Connecting…"
DISCONNECTING = "切断しています… / Disconnecting…"
DISCONNECTED = "すべて切断しました / Disconnected"
WIFI_TYPES = ("802-11-wireless", "wifi")  # nmcli connection show の TYPE
NOT_ALLOWED = "Wi-Fi を変える許可がありません（scripts/allow_wifi.sh を実行してください）"
NO_NMCLI = "NetworkManager（nmcli）がありません"
FAILED_SCAN = "探せませんでした / Scan failed"
WRONG_PASSWORD = "つながりませんでした。パスワードを確かめてください / Wrong password?"


@dataclass(frozen=True)
class WifiNetwork:
    ssid: str
    signal: int  # 電波の強さ（0〜100）
    secure: bool  # パスワードが要るか
    in_use: bool  # 今つないでいるか
    known: bool  # 保存済みの接続があるか


def split_terse(line: str) -> list[str]:
    """nmcli -t の 1 行を、項目に分ける（区切りは「:」、項目の中の「:」と「\\」は「\\」で逃がしてある）。"""
    fields, current, escaped = [], [], False
    for ch in line:
        if escaped:
            current.append(ch)
            escaped = False
        elif ch == "\\":
            escaped = True
        elif ch == ":":
            fields.append("".join(current))
            current = []
        else:
            current.append(ch)
    fields.append("".join(current))
    return fields


def parse_networks(list_output: str, known: set[str]) -> list[WifiNetwork]:
    """nmcli -t -f IN-USE,SSID,SIGNAL,SECURITY device wifi list の出力を読む。

    名前の無い（隠れた）Wi-Fi は出さない。同じ名前が何行もあるとき（中継器など）は、いちばん強いものだけ残す。
    つないでいるものを先頭に、あとは電波の強い順。
    """
    best: dict[str, WifiNetwork] = {}
    for line in list_output.splitlines():
        fields = split_terse(line)
        if len(fields) < 4 or not fields[1]:
            continue
        in_use, ssid, signal_text, security = fields[0], fields[1], fields[2], fields[3]
        try:
            signal = int(signal_text)
        except ValueError:
            signal = 0
        network = WifiNetwork(
            ssid=ssid,
            signal=signal,
            secure=security.strip() not in ("", "--"),
            in_use=in_use.strip() == "*",
            known=ssid in known,
        )
        old = best.get(ssid)
        if old is None or network.in_use or (not old.in_use and network.signal > old.signal):
            best[ssid] = network
    return sorted(best.values(), key=lambda n: (not n.in_use, -n.signal, n.ssid.lower()))


def parse_known(connections_output: str) -> set[str]:
    """nmcli -t -f NAME,TYPE connection show の出力から、保存済みの Wi-Fi の接続の名前。"""
    names = set()
    for line in connections_output.splitlines():
        fields = split_terse(line)
        if len(fields) >= 2 and fields[1] == WIFI_CONNECTION_TYPE and fields[0]:
            names.add(fields[0])
    return names


def failure_message(stderr: str) -> str:
    """nmcli の失敗の理由を、画面に出す文にする。"""
    text = stderr.lower()
    if "not authorized" in text or "insufficient privileges" in text:
        return NOT_ALLOWED
    if "secrets were required" in text or "invalid passphrase" in text or "802-1x" in text or "password" in text:
        return WRONG_PASSWORD
    if "no network with ssid" in text:
        return "その Wi-Fi が見つかりません / Network not found"
    if "timeout" in text or "timed out" in text:
        return "時間内につながりませんでした / Timed out"
    return "つながりませんでした / Could not connect"


class WifiController:
    """Wi-Fi の画面の処理（探す・つなぐは裏のスレッドで行い、結果を UiState に入れる）。"""

    def __init__(self, state: UiState, run: Callable[..., subprocess.CompletedProcess] = subprocess.run) -> None:
        self._state = state
        self._run = run
        self._lock = threading.Lock()
        self._busy = False

    # --- 画面から呼ばれる ---

    def open_page(self) -> None:
        self.scan()

    def scan(self) -> None:
        self._start(self._scan, SCANNING)

    def connect(self, network: WifiNetwork, password: str | None = None) -> None:
        """network につなぐ（パスワードの要る Wi-Fi で、保存されていなければ password を使う）。"""
        self._start(lambda: self._connect(network, password), CONNECTING)

    def disconnect_all(self) -> None:
        """今つながっている Wi-Fi を、すべて切る（切ったあとは、自動では、つなぎ直さない）。"""
        self._start(self._disconnect_all, DISCONNECTING)

    # --- 裏のスレッド ---

    def _start(self, work: Callable[[], None], status: str) -> None:
        with self._lock:
            if self._busy:
                return  # 前の操作の途中
            self._busy = True
        self._state.set_wifi(status=status, busy=True)

        def run() -> None:
            try:
                work()
            except FileNotFoundError:
                self._state.set_wifi(status=NO_NMCLI)
            except Exception:
                log.exception("Wi-Fi の操作に失敗しました")
                self._state.set_wifi(status=FAILED_SCAN)
            finally:
                with self._lock:
                    self._busy = False
                self._state.set_wifi(busy=False)

        threading.Thread(target=run, name="wifi", daemon=True).start()

    def _nmcli(self, *args: str, timeout: float = COMMAND_TIMEOUT_SEC) -> subprocess.CompletedProcess:
        try:
            return self._run([NMCLI, *args], capture_output=True, text=True, timeout=timeout)
        except subprocess.TimeoutExpired:
            # 時間内に終わらなかった（つなげない Wi-Fi への接続など）。失敗として返す（nmcli は、timeout で止められている）
            return subprocess.CompletedProcess([NMCLI, *args], 124, stdout="", stderr="Error: timed out")

    def _cancel_pending_connection(self) -> None:
        """つなごうとして終わっていない状態（接続の準備中）が残っていたら、取り消す。
        残っていると、NetworkManager は「探す」を受け付けず、一覧が更新されない（2026-10-13 に実機で確認）。"""
        result = self._nmcli("-t", "-f", "GENERAL.STATE", "device", "show", "wlan0")
        for line in result.stdout.splitlines():
            fields = split_terse(line)
            code = fields[-1].split(" ")[0] if fields else ""
            if code.isdigit() and 40 <= int(code) <= 90:  # 40〜90: 準備中・設定中・認証待ち・IP 取得中など
                log.info("つなぎかけの接続を取り消します（状態 %s）", code)
                self._nmcli("device", "disconnect", "wlan0")

    def _scan(self, status: str | None = None) -> None:
        self._cancel_pending_connection()
        # 探し直す（許可が無いと失敗するが、前に探した一覧は出せるので続ける）
        rescan = self._nmcli("device", "wifi", "rescan")
        listing = self._nmcli("-t", "-f", "IN-USE,SSID,SIGNAL,SECURITY", "device", "wifi", "list", "--rescan", "no")
        if listing.returncode != 0:
            self._state.set_wifi(status=failure_message(listing.stderr) if listing.stderr else FAILED_SCAN)
            return
        known = parse_known(self._nmcli("-t", "-f", "NAME,TYPE", "connection", "show").stdout)
        networks = parse_networks(listing.stdout, known)
        current = next((n.ssid for n in networks if n.in_use), "")
        address = self._address() if current else ""
        if status is None:
            status = NOT_ALLOWED if rescan.returncode != 0 and "not authorized" in rescan.stderr.lower() else ""
            if not status:
                status = f"{len(networks)} 件 / {len(networks)} found"
        self._state.set_wifi(status=status, networks=tuple(networks), current=current, address=address)

    def _address(self) -> str:
        """Wi-Fi でもらった IP アドレス（無ければ空）。"""
        result = self._nmcli("-t", "-f", "IP4.ADDRESS", "device", "show", "wlan0")
        for line in result.stdout.splitlines():
            value = split_terse(line)[-1]
            if value:
                return value.split("/")[0]
        return ""

    def _disconnect_all(self) -> None:
        active = self._nmcli("-t", "-f", "NAME,TYPE,DEVICE", "connection", "show", "--active")
        names = []
        for line in active.stdout.splitlines():
            fields = split_terse(line)
            if len(fields) >= 2 and fields[1] in WIFI_TYPES:
                names.append(fields[0])
        # 先に、機器ごと切る。接続だけを切ると、NetworkManager が、すぐ別の保存済みの Wi-Fi（2.4GHz → 5GHz など）に
        # 自動でつなぎ直してしまう（2026-10-13 に実機で確認）。機器ごと切ると、手でつなぐまで、自動ではつながらない
        result = self._nmcli("device", "disconnect", "wlan0")
        denied = result.returncode != 0 and "not authorized" in result.stderr.lower()
        # 機器が切れなかった（すでに切れている・別の経路でつながっている）ときの、残りの接続
        for name in names:
            result = self._nmcli("connection", "down", "id", name)
            denied = denied or (result.returncode != 0 and "not authorized" in result.stderr.lower())
        log.info("Wi-Fi をすべて切りました: %s", ", ".join(names) or "（つながっていませんでした）")
        self._scan(status=NOT_ALLOWED if denied else DISCONNECTED)
    def _connect(self, network: WifiNetwork, password: str | None) -> None:
        if network.known and password is None:
            result = self._nmcli("connection", "up", "id", network.ssid, timeout=CONNECT_TIMEOUT_SEC)
        elif password:
            result = self._nmcli(
                "device", "wifi", "connect", network.ssid, "password", password, timeout=CONNECT_TIMEOUT_SEC
            )
        else:
            result = self._nmcli("device", "wifi", "connect", network.ssid, timeout=CONNECT_TIMEOUT_SEC)
        if result.returncode == 0:
            log.info("Wi-Fi %s につなぎました", network.ssid)
            self._scan(status=f"つなぎました / Connected: {network.ssid}")
            return
        message = failure_message(result.stderr)
        log.warning("Wi-Fi %s につなげません: %s", network.ssid, result.stderr.strip()[-200:])
        # 間違ったパスワードの接続を残さない（次にタップしたら、パスワードを聞き直す）。
        # 新しく入れたパスワードでつながらなかったときと、保存済みの接続でパスワードの問題らしいときだけ消す
        # （電波が届かないだけなら、保存済みの接続は残す）
        if password is not None or message == WRONG_PASSWORD:
            self._nmcli("connection", "delete", "id", network.ssid)
        self._scan(status=message)
