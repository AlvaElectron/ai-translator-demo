"""発音記号（カタカナ）。

読むのは日本語話者なので、IPA やローマ字ではなくカタカナで出す。
- 英語: alkana の英和カナ辞書（約5万語）。辞書に無い語は英語のまま残す
- 中国語: pypinyin でピンインにしてから chinese_kana（このリポジトリの実装）でカタカナにする
- 韓国語: korean_kana（このリポジトリの実装。音韻変化も処理する）
- 広東語: ToJyutping で粤拼にしてから cantonese_kana（このリポジトリの実装）でカタカナにする
- タイ語: pythainlp で音節に分けてから thai_kana（このリポジトリの実装。綴りの規則で読む）でカタカナにする
- フランス語: french_kana（このリポジトリの実装。つづりの規則で読む）
- ロシア語: russian_kana（このリポジトリの実装。つづりの規則で読む）
- ポルトガル語: portuguese_kana（このリポジトリの実装。ブラジルの発音で、つづりの規則で読む）

英語の辞書（alkana）が入っていないときは、以前の表記（IPA）に戻す。
韓国語は外部ライブラリに頼らないので、常にカタカナで出せる。
"""

from __future__ import annotations

import logging
import re
import threading
from collections.abc import Callable, Iterable

from . import cantonese_kana, chinese_kana, french_kana, korean_kana, portuguese_kana, russian_kana, thai_kana
from .langs import EN, FR, KO, PT, RU, TH, YUE, ZH
from .number_words import (
    spell_cantonese_numbers,
    spell_chinese_numbers,
    spell_english_numbers,
    spell_french_numbers,
    spell_korean_numbers,
    spell_portuguese_numbers,
    spell_russian_numbers,
    spell_thai_numbers,
)

log = logging.getLogger(__name__)

Converter = Callable[[str], str]

# 中国語の句読点は、ピンインに合わせて半角にする
_CHINESE_PUNCTUATION = str.maketrans(
    {"，": ", ", "。": ". ", "？": "? ", "！": "! ", "、": ", ", "：": ": ", "；": "; ", "（": " (", "）": ") "}
)
_SPACE_BEFORE_PUNCTUATION = re.compile(r"\s+([,.?!:;)])")
_SPACE_BEFORE_KANA_PUNCTUATION = re.compile(r"\s+([，。？！、：；）,.?!:;)])")
_SPACES = re.compile(r"\s+")
# 英語を、語とそれ以外（空白・記号）に分ける
_ENGLISH_TOKENS = re.compile(r"[A-Za-z']+|[^A-Za-z']+")

# alkana の辞書は複合語に弱いので、前後に分けて引き直す。短すぎる断片で誤爆しないよう下限を決める
_MIN_COMPOUND_PART = 3
# 複数形の s。直前が無声音なら「ス」、そうでなければ「ズ」
_VOICELESS_KANA_ENDINGS = ("ク", "ト", "プ", "フ", "ス", "ッ", "シュ", "チ", "ツ")
# 辞書にも分割にも載らない語（見つけしだい足す）
_EXTRA_ENGLISH_KANA = {"wifi": "ワイファイ", "checkin": "チェックイン", "i": "アイ", "a": "ア"}
# 「Wi-Fi」は、ハイフンで分かれないよう1語にしてから引く
_WIFI = re.compile(r"\bwi-fi\b", re.I)
# 辞書（alkana）のカタカナを、日本でふつうに書く形に寄せる規則（トゥレイン → トレイン、オウプン → オープン など）
_ENGLISH_KANA_FIXES = tuple(
    (re.compile(pattern), replacement)
    for pattern, replacement in (
        (r"トゥ(?=[ラリルレロ])", "ト"),  # train・street・traffic
        (r"ドゥ(?=[ラリルレロ])", "ド"),  # dream・drink
        (r"([オコソトノホモヨロゴゾドボポョ])ウ", r"\1ー"),  # open・tomorrow・know
        (r"ットゥ$", "ット"),  # at
        (r"ッドゥ$", "ッド"),
        (r"^ホワ", "ワ"),  # what
        (r"^ホエ", "ウェ"),  # where
        (r"トゥェ", "トゥエ"),  # twenty
    )
)
# カタカナの語をつなぐハイフン（twenty-five → トゥエンティーファイブ）
_KANA_HYPHEN = re.compile(r"(?<=[ァ-ヶー])-(?=[ァ-ヶー])")
# 辞書を先に読み込むときに変換してみる文
_WARM_UP_SAMPLES = {EN: "hello", ZH: "你好", KO: "안녕하세요", YUE: "你好", TH: "สวัสดี", FR: "bonjour", RU: "привет", PT: "olá"}


def join_pinyin(tokens: list[str]) -> str:
    """pypinyin が返す音節（と、漢字以外の部分）を、読みやすい1行にする。"""
    text = " ".join(tokens).translate(_CHINESE_PUNCTUATION)
    return _SPACES.sub(" ", _SPACE_BEFORE_PUNCTUATION.sub(r"\1", text)).strip()


def join_chinese_kana(tokens: list[str]) -> str:
    """pinyin_kana が返す音節を、空白を挟んでつなぐ。

    1音節ずつ区切った方が読み上げやすく、幅も以前のピンイン表示とほぼ同じで収まる。
    """
    return _SPACES.sub(" ", _SPACE_BEFORE_KANA_PUNCTUATION.sub(r"\1", " ".join(tokens))).strip()


def clean_ipa(text: str) -> str:
    """eng-to-ipa は辞書にない語に「*」を付けるので、取り除く。"""
    return _SPACES.sub(" ", text.replace("*", "")).strip()


# 午前・午後の「a.m.」「p.m.」。「a」だけがカタカナになって「ア.m」と崩れないよう、そのまま残す
_AM_PM = re.compile(r"(?<![A-Za-z])[ap]\.m\b\.?", re.IGNORECASE)
_AM_PM_MARK = re.compile("\ue000(\\d+)\ue001")


def english_to_kana(text: str, lookup: Callable[[str], str | None]) -> str:
    """英語の文をカタカナにする。辞書にも規則にも載らない語は、そのまま英語で残す（a.m.・p.m. もそのまま）。"""
    kept: list[str] = []

    def keep(match: re.Match[str]) -> str:
        kept.append(match.group(0))
        return f"\ue000{len(kept) - 1}\ue001"  # 英字を含まない目印にして、語の変換に巻き込まれないようにする

    text = _AM_PM.sub(keep, text)
    kana = "".join(
        (tidy_english_kana(word_to_kana(token.lower(), lookup)) or token) if token[:1].isalpha() else token
        for token in _ENGLISH_TOKENS.findall(_WIFI.sub("wifi", text))
    )
    kana = _AM_PM_MARK.sub(lambda m: kept[int(m.group(1))], kana)
    return _KANA_HYPHEN.sub("", kana)


def tidy_english_kana(kana: str | None) -> str | None:
    """辞書のカタカナ（1語）を、日本でふつうに書く形に寄せる（辞書に無い語の None は、そのまま返す）。"""
    if kana:
        for pattern, replacement in _ENGLISH_KANA_FIXES:
            kana = pattern.sub(replacement, kana)
    return kana


def word_to_kana(word: str, lookup: Callable[[str], str | None]) -> str | None:
    """1語をカタカナにする。辞書を引き、だめなら複合語の分割と複数形を試す。"""
    kana = lookup(word) or _EXTRA_ENGLISH_KANA.get(word)
    if kana:
        return kana
    compound = _split_compound(word, lookup)
    if compound:
        return compound
    if word.endswith("s"):
        base = lookup(word[:-1]) or _EXTRA_ENGLISH_KANA.get(word[:-1])
        if base:
            return base + ("ス" if base.endswith(_VOICELESS_KANA_ENDINGS) else "ズ")
    return None


def _split_compound(word: str, lookup: Callable[[str], str | None]) -> str | None:
    """前後どちらも辞書にある分け方を探す（airport → air + port）。前半が長い分け方を優先する。"""
    for cut in range(len(word) - _MIN_COMPOUND_PART, _MIN_COMPOUND_PART - 1, -1):
        head, tail = lookup(word[:cut]), lookup(word[cut:])
        if head and tail:
            return head + tail
    return None


# 「萌え萌えキュン」は、どの言語でもローマ字（moe moe kyun）で書かれる。言語ごとの規則に任せると、
# フランス語は「モ モ キアン」、ポルトガル語は「モイ モイ キウヌ」、広東語は 1 文字ずつ、英語・中国語・タイ語・ロシア語は
# カタカナにならない。どの言語でも、この語を見つけたら、決めたカタカナに置き換える（moe-moe-kyun・Moe Moe Kyunn なども）
_MOE_MOE_KYUN = re.compile(r"moe[\s\-]*moe[\s\-]*kyu+n+", re.IGNORECASE)
MOE_MOE_KYUN_KANA = "モエモエキュン"


def convert_with_fixed_terms(converter: Converter, text: str) -> str:
    """text を converter でカタカナにする。ただし「moe moe kyun」は、決めた読み（モエモエキュン）に置き換える。

    その語の前後は、別々に変換する。前後の空白や記号の並びは、元の文のまま残す。
    """
    matches = list(_MOE_MOE_KYUN.finditer(text))
    if not matches:
        return converter(text)
    parts: list[str] = []
    position = 0
    for match in matches:
        parts.append(_convert_piece(converter, text[position : match.start()]))
        parts.append(MOE_MOE_KYUN_KANA)
        position = match.end()
    parts.append(_convert_piece(converter, text[position:]))
    return "".join(parts)


def _convert_piece(converter: Converter, piece: str) -> str:
    """文の一部を変換する（前後の空白は、そのまま残す。空白だけなら、変換しない）。"""
    core = piece.strip()
    if not core:
        return piece
    start = len(piece) - len(piece.lstrip())
    end = len(piece.rstrip())
    return piece[:start] + converter(core) + piece[end:]


class Phonetics:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._converters: dict[str, Converter | None] = {}

    def transcribe(self, text: str, lang: str) -> str:
        """text の発音記号。対応していない言語や、変換できないときは空文字を返す。"""
        converter = self._converter(lang)
        if converter is None or not text.strip():
            return ""
        try:
            return convert_with_fixed_terms(converter, text)
        except Exception:
            log.exception("発音記号に変換できません（%s）: %r", lang, text)
            return ""

    def prepare(self, langs: Iterable[str]) -> None:
        """langs の辞書を先に読み込んでおく（読み込みに時間がかかるので、最初の訳文の表示を待たせないため）。

        辞書には大きいもの（広東語 約90MB、タイ語 約80MB、中国語 約50MB）があるので、
        使う言語の分だけ読み込む（メモリ 4GB の Pi でも収まるように）。読み込んでいない言語も、
        必要になった時点で読み込む。いちど読み込んだライブラリは Python の仕組み上ほとんど解放できないので、
        ほかの言語に替えても、前の言語の辞書は消さない。
        """
        for lang in langs:
            sample = _WARM_UP_SAMPLES.get(lang)
            if sample:
                self.transcribe(sample, lang)

    def _converter(self, lang: str) -> Converter | None:
        with self._lock:
            if lang not in self._converters:
                self._converters[lang] = _load_converter(lang)
            return self._converters[lang]


def _load_converter(lang: str) -> Converter | None:
    if lang == KO:
        # 金額などの数字は、先に漢数字の読み（1,500 → 천오백）にする（そのままだと「1,500エニエヨ」になる）
        return lambda text: korean_kana.to_katakana(spell_korean_numbers(text))
    if lang == EN:
        return _english_converter()
    if lang == ZH:
        return _chinese_converter()
    if lang == YUE:
        return _cantonese_converter()
    if lang == TH:
        return _thai_converter()
    if lang == FR:
        return lambda text: french_kana.to_katakana(spell_french_numbers(text))
    if lang == RU:
        return lambda text: russian_kana.to_katakana(spell_russian_numbers(text))
    if lang == PT:
        return lambda text: portuguese_kana.to_katakana(spell_portuguese_numbers(text))
    return None


def _cantonese_converter() -> Converter | None:
    try:
        import ToJyutping
    except ImportError:
        log.warning("ToJyutping がないため、広東語の発音記号は表示しません（.venv/bin/pip install -r requirements.txt）")
        return None
    from .chinese import to_hongkong

    # 音声認識が簡体字で書いたときも粤拼を引けるよう、先に香港の繁体字にする
    # 金額などの数字は、先に数の読み（1,500 → 一千五百）にする
    return lambda text: join_chinese_kana(
        cantonese_kana.to_katakana(ToJyutping.get_jyutping_list(to_hongkong(spell_cantonese_numbers(text))))
    )


def _thai_converter() -> Converter | None:
    try:
        from pythainlp.tokenize import syllable_tokenize
    except ImportError:
        log.warning("pythainlp がないため、タイ語の発音記号は表示しません（.venv/bin/pip install -r requirements.txt）")
        return None
    # 音節の辞書（pythainlp に同梱）で分ける。ネットにはつながない
    return lambda text: join_chinese_kana(
        thai_kana.to_katakana(syllable_tokenize(spell_thai_numbers(text), engine="dict"))
    )


def _english_converter() -> Converter | None:
    try:
        import alkana
    except ImportError:
        log.warning("alkana がないため、英語は IPA で表示します（.venv/bin/pip install -r requirements.txt）")
        return _english_ipa_converter()
    return lambda text: english_to_kana(spell_english_numbers(text), alkana.get_kana)


def _english_ipa_converter() -> Converter | None:
    try:
        import eng_to_ipa
    except ImportError:
        log.warning("英語の発音記号のライブラリがありません（.venv/bin/pip install -r requirements.txt）")
        return None
    return lambda text: clean_ipa(eng_to_ipa.convert(text))


def _chinese_converter() -> Converter | None:
    try:
        from pypinyin import Style, lazy_pinyin
    except ImportError:
        log.warning("pypinyin がないため、中国語の発音記号は表示しません（.venv/bin/pip install -r requirements.txt）")
        return None

    def convert(text: str) -> str:
        text = spell_chinese_numbers(text)  # 金額などの数字は、先に数の読み（1,500 → 一千五百）にする
        # 声調を数字で付けたピンイン（軽声は 5）にする。漢字以外（句読点・英字）は、数字が付かずにそのまま返る
        tokens = lazy_pinyin(text, style=Style.TONE3, neutral_tone_with_five=True, v_to_u=False)
        return join_chinese_kana(
            [(chinese_kana.syllable_to_kana(token) or token) if token[-1:].isdigit() else token for token in tokens]
        )

    return convert
