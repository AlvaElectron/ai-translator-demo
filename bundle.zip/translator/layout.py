"""画面に収めるための折り返し処理と、ボタンの明るさの計算（pygame に依存しない）。"""

from __future__ import annotations

import re
from collections.abc import Callable, Iterator

# タイ文字のひとかたまり（前に置く母音 + 子音 + 上下・後ろに付く母音記号・声調記号）。
# タイ語は語の間に空白を入れないので、このかたまりの間で折り返す（記号だけが行頭に来ないように）
_THAI_CLUSTER = r"[เ-ไ]?[ก-ฯ฿ๆ๏-๛][ะ-ฺๅ็-๎]*"
# 英単語・フランス語・ロシア語・韓国語の語はまとめて扱い、タイ文字はかたまりごと、それ以外（日本語・中国語など）は1文字ずつ折り返す
_TOKEN = re.compile(rf"[0-9A-Za-zÀ-ɏЀ-ӿ가-힣'’\-]+[ \t]*|{_THAI_CLUSTER}[ \t]*|[ \t]+|.")
# 行頭に置かない文字（前の行に続けて表示する）
_NO_LINE_START = frozenset("、。，．,.!?！？:;：；」』）)]】〉》ーぁぃぅぇぉっゃゅょァィゥェォッャュョ")


def wrap_text(text: str, max_width: int, measure: Callable[[str], int]) -> list[str]:
    """measure で測った幅が max_width に収まるように、text を行に分ける。"""
    lines: list[str] = []
    for paragraph in text.split("\n"):
        line = ""
        for token in _tokens(paragraph, max_width, measure):
            if not line:
                line = token.lstrip()
            elif token[0] in _NO_LINE_START or measure((line + token).rstrip()) <= max_width:
                line += token
            else:
                lines.append(line.rstrip())
                line = token.lstrip()
        if line.strip():
            lines.append(line.rstrip())
    return lines


def fit_text(
    text: str,
    max_width: int,
    max_height: int,
    sizes: tuple[int, ...],
    measure: Callable[[str, int], int],
    line_height: Callable[[int], int],
) -> tuple[list[str], int]:
    """収まる最大の文字サイズで折り返す。最小サイズでも収まらなければ、末尾（最新）の行を残す。"""
    for size in sizes:
        lines = wrap_text(text, max_width, lambda s, size=size: measure(s, size))
        if len(lines) * line_height(size) <= max_height:
            return lines, size
    size = sizes[-1]
    max_lines = max(1, max_height // line_height(size))
    visible = lines[-max_lines:]
    visible[0] = "…" + visible[0]
    return visible, size


def fade_level(now: float, period_sec: float) -> float:
    """period_sec ごとに 1（明るい）に戻り、そこから 0（暗い）へ少しずつ下がる値。"""
    return 1.0 - (now % period_sec) / period_sec


def blink_level(elapsed_sec: float, period_sec: float, duration_sec: float) -> float:
    """明滅の明るさ。duration_sec を過ぎたら、明るいまま（1）で止める。

    ずっと明滅していると気が散るので、気づいてもらうのに十分な時間だけ明滅させる。
    """
    if elapsed_sec >= duration_sec:
        return 1.0
    return fade_level(elapsed_sec, period_sec)


def mix_color(dark: tuple[int, int, int], bright: tuple[int, int, int], level: float) -> tuple[int, int, int]:
    """level が 0 なら dark、1 なら bright、その間は両方を混ぜた色。"""
    level = min(1.0, max(0.0, level))
    return tuple(round(d + (b - d) * level) for d, b in zip(dark, bright))


def _tokens(paragraph: str, max_width: int, measure: Callable[[str], int]) -> Iterator[str]:
    for token in _TOKEN.findall(paragraph):
        if measure(token.rstrip()) <= max_width:
            yield token
        else:
            yield from token  # 1語が1行に収まらないときは文字単位で分ける
