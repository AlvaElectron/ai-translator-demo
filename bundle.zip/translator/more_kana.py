"""2026-11-14〜15 に足した言語を、日本語話者が読めるカタカナにする（外部ライブラリに依存しない）。

しくみ（どの言語も同じ 2 段）:
1. つづり → 音の並び。言語ごとの「つづり → 音」の表を、長い方から当てはめる（スペイン語の「ce」→ s+e、ドイツ語の「sch」→ sh など）。
   ヒンディー語・ネパール語・シンハラ語は、文字の組み立て（子音 + 母音記号）から音の並びを作る。
2. 音の並び → カタカナ。全言語で共通（k+a → カ、k+y+a → キャ、Q → ッ、a: → アー など）。

音の並びの書き方:
- 母音: a i u e o（長い母音は a: のように「:」を付ける）。「:」だけなら、前の音を伸ばす（ー）
- 子音: k g s z t d n h f b p m r v w y sh zh ch j ts dz ng x ny ty dy ly
  （x は ドイツ語の ch などの「ハ・ヒ・フ」、ny ty dy ly は「ニャ・チャ・ジャ・リャ」の行）
- Q は小さい「ッ」（次がマ行・ナ行なら「ン」）、N は「ン」、「!」で始まるものは、そのカタカナをそのまま出す

アクセントの位置はつづりから分からない言語が多いので、伸ばす音（ー）は、つづりで長さが分かる言語（チェコ語の á など）だけに付ける。
アラビア語・ペルシア語は、ふつう短い母音を書かない文字なので、つづりから読みが決まらない。ここでは扱わない。
"""

from __future__ import annotations

import re
import unicodedata
from collections.abc import Callable, Iterable

from .number_words_more import spell_numbers

Tokens = list[str]

# --- 2. 音の並び → カタカナ（全言語共通） ---

_VOWEL_INDEX = {"a": 0, "i": 1, "u": 2, "e": 3, "o": 4}
_VOWEL_KANA = ("ア", "イ", "ウ", "エ", "オ")
_ROWS = {
    "k": ("カ", "キ", "ク", "ケ", "コ"), "g": ("ガ", "ギ", "グ", "ゲ", "ゴ"),
    "s": ("サ", "シ", "ス", "セ", "ソ"), "z": ("ザ", "ジ", "ズ", "ゼ", "ゾ"),
    "t": ("タ", "ティ", "トゥ", "テ", "ト"), "d": ("ダ", "ディ", "ドゥ", "デ", "ド"),
    "n": ("ナ", "ニ", "ヌ", "ネ", "ノ"), "h": ("ハ", "ヒ", "フ", "ヘ", "ホ"), "x": ("ハ", "ヒ", "フ", "ヘ", "ホ"),
    "f": ("ファ", "フィ", "フ", "フェ", "フォ"), "b": ("バ", "ビ", "ブ", "ベ", "ボ"),
    "p": ("パ", "ピ", "プ", "ペ", "ポ"), "m": ("マ", "ミ", "ム", "メ", "モ"),
    "r": ("ラ", "リ", "ル", "レ", "ロ"), "v": ("ヴァ", "ヴィ", "ヴ", "ヴェ", "ヴォ"),
    "w": ("ワ", "ウィ", "ウ", "ウェ", "ウォ"), "y": ("ヤ", "イ", "ユ", "イェ", "ヨ"),
    "sh": ("シャ", "シ", "シュ", "シェ", "ショ"), "zh": ("ジャ", "ジ", "ジュ", "ジェ", "ジョ"),
    "ch": ("チャ", "チ", "チュ", "チェ", "チョ"), "j": ("ジャ", "ジ", "ジュ", "ジェ", "ジョ"),
    "ts": ("ツァ", "ツィ", "ツ", "ツェ", "ツォ"), "dz": ("ザ", "ジ", "ズ", "ゼ", "ゾ"),
    "ng": ("ガ", "ギ", "グ", "ゲ", "ゴ"),
    "ny": ("ニャ", "ニ", "ニュ", "ニェ", "ニョ"), "ty": ("チャ", "チ", "チュ", "チェ", "チョ"),
    "dy": ("ジャ", "ジ", "ジュ", "ジェ", "ジョ"), "ly": ("リャ", "リ", "リュ", "リェ", "リョ"),
}
# 子音 + y + 母音（k+y+a → キャ）。ここに無い子音（sh・ch・ny など、もともと「ャ」の行）は、y を読まない
_PALATAL = {
    "k": "キ", "g": "ギ", "s": "シ", "z": "ジ", "t": "チ", "d": "ジ", "n": "ニ", "h": "ヒ", "x": "ヒ", "f": "フ",
    "b": "ビ", "p": "ピ", "m": "ミ", "r": "リ", "v": "ヴ",
}
_SMALL = ("ャ", "", "ュ", "ェ", "ョ")
# 母音が続かない子音
_ALONE = {
    "k": "ク", "g": "グ", "s": "ス", "z": "ズ", "t": "ト", "d": "ド", "n": "ン", "h": "フ", "f": "フ", "b": "ブ",
    "p": "プ", "m": "ム", "r": "ル", "v": "ヴ", "w": "ウ", "y": "イ", "sh": "シュ", "zh": "ジュ", "ch": "チ", "j": "ジ",
    "ts": "ツ", "dz": "ズ", "ng": "ン", "ny": "ニ", "ty": "チ", "dy": "ジ", "ly": "リ",
}
_NASALS = {"m", "n", "ng", "ny", "N"}
_LABIALS = {"p", "b", "m"}


def _is_vowel(token: str) -> bool:
    return bool(token) and token[0] in _VOWEL_INDEX


def tokens_to_kana(tokens: Tokens) -> str:
    """音の並びを、カタカナにする。"""
    out: list[str] = []
    last_vowel = ""
    i, n = 0, len(tokens)
    while i < n:
        token = tokens[i]
        following = tokens[i + 1] if i + 1 < n else ""
        if token.startswith("!"):
            out.append(token[1:])
            i += 1
            continue
        if token == ":":
            if out and not out[-1].endswith("ー"):
                out.append("ー")
            i += 1
            continue
        if token == "Q":  # 重なった子音（ッ。マ行・ナ行の前では ン）
            if following in _NASALS:
                out.append("ン")
            elif following and not _is_vowel(following) and following not in ("y", "w", ":"):
                out.append("ッ")
            i += 1
            continue
        if token == "N":
            out.append("ン")
            i += 1
            continue
        if _is_vowel(token):
            out.append(_VOWEL_KANA[_VOWEL_INDEX[token[0]]] + ("ー" if token.endswith(":") else ""))
            last_vowel = token[0]
            i += 1
            continue
        if token not in _ROWS:
            i += 1
            continue
        # 子音 + y + 母音（キャ・ミュ など）
        if following == "y" and i + 2 < n and _is_vowel(tokens[i + 2]):
            vowel = tokens[i + 2]
            index = _VOWEL_INDEX[vowel[0]]
            if token in ("t", "d") and index == 2:
                out.append(("テュ" if token == "t" else "デュ") + ("ー" if vowel.endswith(":") else ""))  # Tür → テュール
            elif token in _PALATAL:
                out.append(_PALATAL[token] + _SMALL[index] + ("ー" if vowel.endswith(":") else ""))
            else:
                out.append(_ROWS[token][index] + ("ー" if vowel.endswith(":") else ""))
            last_vowel = vowel[0]
            i += 3
            continue
        if _is_vowel(following):
            index = _VOWEL_INDEX[following[0]]
            kana = _ROWS[token][index]
            if token == "ng" and i > 0 and _is_vowel(tokens[i - 1]):
                kana = "ン" + kana  # 語の中の ng + 母音（dengan → デンガン）
            out.append(kana + ("ー" if following.endswith(":") else ""))
            last_vowel = following[0]
            i += 2
            continue
        # 母音が続かない子音
        if token == "x":  # ドイツ語の ch など。前の母音で「ハ・フ・ヒ」が変わる（Bach → バッハ、Buch → ブーフ、ich → イヒ）
            out.append({"a": "ハ", "o": "ホ", "u": "フ"}.get(last_vowel, "ヒ" if last_vowel in ("i", "e") else "フ"))
        elif token == "h" and (not following or following.startswith("!") or following == "|"):
            pass  # 語末の h は、ほとんど聞こえない（kasih → カシ）
        elif token == "m" and following in _LABIALS:
            out.append("ン")
        else:
            out.append(_ALONE[token])
        i += 1
    return "".join(out)


# --- 1. つづり → 音の並び ---


class SpellingRules:
    """つづり → 音の表（長い方から当てはめる）。語の頭は「^」、語の終わりは「#」で書ける（「^sp」「b#」）。

    geminate の子音字が 2 つ続くと「ッ」にする（イタリア語の pizza → ピッツァ）。それ以外の子音字が 2 つ続くときは、1 つとして読む。
    """

    def __init__(self, table: dict[str, Iterable[str]], geminate: str = "") -> None:
        self._table = {key: list(value) for key, value in table.items()}
        self._longest = max(len(key) for key in self._table)
        self._geminate = set(geminate)

    def tokens(self, word: str) -> Tokens:
        text = "^" + word.lower() + "#"
        out: Tokens = []
        i = 0
        while i < len(text):
            # 2 文字以上の決まり
            for length in range(min(self._longest, len(text) - i), 1, -1):
                key = text[i : i + length]
                if key in self._table:
                    out.extend(self._table[key])
                    i += length
                    break
            else:
                ch = text[i]
                if i + 1 < len(text) and text[i + 1] == ch and ch.isalpha() and ch not in "aeiouy":
                    if ch in self._geminate:
                        out.append("Q")
                    i += 1  # 同じ子音字の 2 つ目を、ふつうに読む
                    continue
                out.extend(self._table.get(ch, []))
                i += 1
        return out


def _with_vowels(table: dict[str, Iterable[str]], prefix: str, vowels: str, consonant: Iterable[str], keep_i: bool = True) -> None:
    """prefix + 母音字 → consonant + その母音（スペイン語の「ce」→ s+e のような、後ろの母音で読みが変わる子音）。"""
    for vowel in vowels:
        table[prefix + vowel] = [*consonant, *table[vowel]]


_LATIN_BASE: dict[str, Iterable[str]] = {
    "a": ["a"], "e": ["e"], "i": ["i"], "o": ["o"], "u": ["u"], "y": ["i"],
    "á": ["a"], "à": ["a"], "â": ["a"], "ã": ["a"], "ä": ["e"], "é": ["e"], "è": ["e"], "ê": ["e"], "ë": ["e"],
    "í": ["i"], "ì": ["i"], "î": ["i"], "ï": ["i"], "ó": ["o"], "ò": ["o"], "ô": ["o"], "õ": ["o"], "ö": ["e"],
    "ú": ["u"], "ù": ["u"], "û": ["u"], "ü": ["y", "u"], "ý": ["i"],
    "b": ["b"], "c": ["k"], "d": ["d"], "f": ["f"], "g": ["g"], "h": ["h"], "j": ["y"], "k": ["k"], "l": ["r"],
    "m": ["m"], "n": ["n"], "p": ["p"], "q": ["k"], "r": ["r"], "s": ["s"], "t": ["t"], "v": ["v"], "w": ["w"],
    "x": ["k", "s"], "z": ["z"],
    "č": ["ch"], "ć": ["ch"], "š": ["sh"], "ś": ["sh"], "ž": ["zh"], "ź": ["zh"], "ż": ["zh"], "đ": ["j"],
    "ñ": ["ny"], "ń": ["ny"], "ň": ["ny"], "ł": ["w"], "ß": ["s"], "ç": ["ch"], "ş": ["sh"], "ğ": [":"], "ı": ["u"],
    "'": [], "^": [], "#": [],
}


def _latin(overrides: dict[str, Iterable[str]], contexts: Iterable[tuple[str, str, Iterable[str]]] = (),
           geminate: str = "") -> SpellingRules:
    table = {**_LATIN_BASE, **overrides}
    for prefix, vowels, consonant in contexts:
        _with_vowels(table, prefix, vowels, consonant)
    return SpellingRules(table, geminate)


_STOPS_AND_MORE = "bcdfgklmnprstvz"

_ES = _latin(
    {"ch": ["ch"], "ll": ["y"], "qu": ["k"], "h": [], "j": ["h"], "z": ["s"], "v": ["b"], "y": ["y"], "y#": ["i"],
     "rr": ["r"], "gü": ["g", "w"]},
    [("c", "eiéí", ["s"]), ("g", "eiéí", ["h"]), ("gu", "eiéí", ["g"]), ("qu", "eiéí", ["k"])],
)
_IT = _latin(
    {"ch": ["k"], "gh": ["g"], "gn": ["ny"], "gli": ["r", "i"], "h": [], "z": ["ts"], "j": ["y"], "qu": ["k", "w"]},
    [("c", "eiéèì", ["ch"]), ("g", "eiéèì", ["j"]), ("sc", "eiéèì", ["sh"]),
     ("ci", "aouàòóù", ["ch"]), ("gi", "aouàòóù", ["j"]), ("sci", "aouàòóù", ["sh"])],
    geminate=_STOPS_AND_MORE,
)
_DE = _latin(
    {"sch": ["sh"], "tsch": ["ch"], "ch": ["x"], "chs": ["k", "s"], "ck": ["Q", "k"], "tz": ["Q", "ts"], "ss": ["Q", "s"],
     "ph": ["f"], "th": ["t"], "ei": ["a", "i"], "ey": ["a", "i"], "ai": ["a", "i"], "ie": ["i:"], "ieh": ["i:"],
     "eu": ["o", "i"], "äu": ["o", "i"], "au": ["a", "u"], "aa": ["a:"], "ee": ["e:"], "oo": ["o:"],
     "ah": ["a:"], "eh": ["e:"], "ih": ["i:"], "oh": ["o:"], "uh": ["u:"], "äh": ["e:"], "öh": ["e:"], "üh": ["y", "u:"],
     "w": ["v"], "v": ["f"], "z": ["ts"], "j": ["y"], "qu": ["k", "v"], "y": ["i"], "ng": ["ng"],
     "^sp": ["sh", "p"], "^st": ["sh", "t"], "b#": ["p"], "d#": ["t"], "g#": ["k"], "ig#": ["i", "x"], "dt": ["t"],
     "er#": ["a:"]},
    [("s", "aeiouäöü", ["z"])],
    geminate="bdfgklmnprt",
)
_NL = _latin(
    {"ij": ["e", "i"], "ei": ["e", "i"], "ui": ["a", "u"], "oe": ["u"], "ou": ["a", "u"], "au": ["a", "u"],
     "eu": ["e:"], "ie": ["i"], "aa": ["a:"], "ee": ["e:"], "oo": ["o:"], "uu": ["u:"], "g": ["x"], "ch": ["x"],
     "sch": ["s", "x"], "th": ["t"], "v": ["f"], "j": ["y"], "tje": ["ch", "e"], "ng": ["ng"], "ck": ["k"], "y": ["i"]},
    [("c", "eiéè", ["s"])],
    geminate="kpt",
)
_PL_SOFT = (("si", ["sh"]), ("ci", ["ch"]), ("zi", ["zh"]), ("ni", ["ny"]), ("dzi", ["j"]))
_PL = _latin(
    {"sz": ["sh"], "cz": ["ch"], "rz": ["zh"], "dż": ["j"], "dź": ["j"], "dz": ["dz"], "ch": ["h"], "c": ["ts"],
     "w": ["v"], "ó": ["u"], "ą": ["o", "N"], "ę": ["e", "N"], "ę#": ["e"], "y": ["i"],
     "ia": ["y", "a"], "ie": ["y", "e"], "io": ["y", "o"], "iu": ["y", "u"], "ią": ["y", "o", "N"], "ię": ["y", "e", "N"],
     **{prefix: [*consonant, "i"] for prefix, consonant in _PL_SOFT}},
    [(prefix, "aeouóąę", consonant) for prefix, consonant in _PL_SOFT],
)
_CS_TABLE: dict[str, Iterable[str]] = {
    "ch": ["x"], "ř": ["r", "zh"], "c": ["ts"], "ď": ["dy"], "ť": ["ty"], "ě": ["y", "e"],
    "dě": ["dy", "e"], "tě": ["ty", "e"], "ně": ["ny", "e"], "di": ["dy", "i"], "ti": ["ty", "i"], "ni": ["ny", "i"],
    "dí": ["dy", "i:"], "tí": ["ty", "i:"], "ní": ["ny", "i:"],
    "á": ["a:"], "é": ["e:"], "í": ["i:"], "ý": ["i:"], "ó": ["o:"], "ú": ["u:"], "ů": ["u:"], "y": ["i"],
    "w": ["v"], "qu": ["k", "v"], "dž": ["j"], "dz": ["dz"],
}
_CS = _latin(_CS_TABLE)
_SK = _latin(
    {**_CS_TABLE, "ä": ["e"], "ô": ["u", "o"], "ľ": ["ly"], "ĺ": ["r", ":"], "ŕ": ["r", ":"],
     "ia": ["y", "a"], "ie": ["y", "e"], "iu": ["y", "u"], "de": ["dy", "e"], "te": ["ty", "e"], "ne": ["ny", "e"],
     "le": ["ly", "e"], "li": ["ly", "i"]},
)
_SOUTH_SLAVIC = {"dž": ["j"], "lj": ["ly"], "nj": ["ny"], "c": ["ts"], "h": ["x"]}
_HR = _latin(_SOUTH_SLAVIC)
_SL = _latin(_SOUTH_SLAVIC)
_HU = _latin(
    {"sz": ["s"], "s": ["sh"], "zs": ["zh"], "cs": ["ch"], "c": ["ts"], "dzs": ["j"], "dz": ["dz"], "gy": ["dy"],
     "ty": ["ty"], "ny": ["ny"], "ly": ["y"], "ssz": ["Q", "s"], "ggy": ["Q", "dy"], "tty": ["Q", "ty"],
     "nny": ["n", "ny"], "lly": ["y"], "ccs": ["Q", "ch"], "zzs": ["Q", "zh"],
     "á": ["a:"], "é": ["e:"], "í": ["i:"], "ó": ["o:"], "ő": ["e:"], "ú": ["u:"], "ű": ["y", "u:"]},
    geminate="bdfgklmnprstvz",
)
_ET = _latin(
    {"õ": ["o"], "š": ["sh"], "ž": ["zh"], "z": ["s"], "aa": ["a:"], "ee": ["e:"], "ii": ["i:"], "oo": ["o:"],
     "uu": ["u:"], "ää": ["e:"], "öö": ["e:"], "üü": ["y", "u:"], "õõ": ["o:"]},
    geminate="bdfgklmnprst",
)
_LV = _latin(
    {"ā": ["a:"], "ē": ["e:"], "ī": ["i:"], "ū": ["u:"], "ģ": ["dy"], "ķ": ["ty"], "ļ": ["ly"], "ņ": ["ny"],
     "c": ["ts"], "dz": ["dz"], "dž": ["j"], "ch": ["x"], "h": ["x"]},
)
_LT = _latin(
    {"c": ["ts"], "dž": ["j"], "dz": ["dz"], "ch": ["x"], "ą": ["a:"], "ę": ["e:"], "ė": ["e:"], "į": ["i:"],
     "y": ["i:"], "ų": ["u:"], "ū": ["u:"], "ia": ["y", "a"], "io": ["y", "o"], "iu": ["y", "u"], "iū": ["y", "u:"],
     "ią": ["y", "a:"], "ių": ["y", "u:"]},
)
_ID = _latin(
    {"c": ["ch"], "j": ["j"], "y": ["y"], "ng": ["ng"], "ny": ["ny"], "kh": ["h"], "sy": ["sh"], "k#": ["!ッ"]},
)
_TR = _latin(
    {"c": ["j"], "ç": ["ch"], "ş": ["sh"], "ğ": [":"], "ı": ["u"], "ö": ["o"], "kö": ["k", "y", "o"], "gö": ["g", "y", "o"],
     "ü": ["y", "u"], "j": ["zh"],
     "y": ["y"], "â": ["a:"], "î": ["i:"], "û": ["u:"]},
    geminate="bcçdfgkmnprsştvz",
)
_UZ = _latin(
    {"sh": ["sh"], "ch": ["ch"], "ng": ["ng"], "o'": ["o"], "g'": ["g"], "x": ["h"], "q": ["k"], "j": ["j"], "y": ["y"]},
)
# ベトナム語（1 音節ずつ、空白で区切って書く。北部の発音で、声調は読まない）
_VI = _latin(
    {"ngh": ["ng"], "ng": ["ng"], "nh": ["ny"], "ph": ["f"], "th": ["t"], "tr": ["ch"], "ch": ["ch"], "gh": ["g"],
     "^d": ["z"], "đ": ["d"], "x": ["s"], "kh": ["k"], "qu": ["k", "w"], "^r": ["z"], "^v": ["b"],
     "ă": ["a"], "â": ["a"], "ê": ["e"], "ô": ["o"], "ơ": ["o"], "ư": ["u"], "y": ["i"],
     "c#": ["!ッ"], "ch#": ["!ッ"], "t#": ["!ッ"], "p#": ["!ッ"], "ng#": ["N"], "nh#": ["N"], "n#": ["N"],
     "anh#": ["a", "i", "N"], "ênh#": ["e", "i", "N"], "ach#": ["a", "i", "!ッ"]},
)
_VI_TONES = {"̀", "́", "̃", "̉", "̣"}


def _vi_tokens(word: str) -> Tokens:
    # 声調の記号だけを取る（â・ơ・ư などの、母音を変える記号は残す）
    word = unicodedata.normalize(
        "NFC", "".join(ch for ch in unicodedata.normalize("NFD", word.lower()) if ch not in _VI_TONES)
    )
    if word.startswith("gi") and len(word) > 2 and word[2] in "aăâeêoôơuư":
        return ["z", *_VI.tokens(word[2:])]  # gi + 母音 は「ザ行」（giờ → ゾ）
    if word.startswith("gi"):
        return ["z", *_VI.tokens(word[1:])]  # gìn → ジン
    return _VI.tokens(word)


# --- キリル文字（ブルガリア語・ウクライナ語） ---
_CYRILLIC_BASE: dict[str, Iterable[str]] = {
    "а": ["a"], "б": ["b"], "в": ["v"], "г": ["g"], "д": ["d"], "е": ["e"], "ж": ["zh"], "з": ["z"], "и": ["i"],
    "й": ["y"], "к": ["k"], "л": ["r"], "м": ["m"], "н": ["n"], "о": ["o"], "п": ["p"], "р": ["r"], "с": ["s"],
    "т": ["t"], "у": ["u"], "ф": ["f"], "х": ["x"], "ц": ["ts"], "ч": ["ch"], "ш": ["sh"], "ю": ["y", "u"],
    "я": ["y", "a"], "дж": ["j"], "дз": ["dz"], "^": [], "#": [], "'": [], "’": [],
}
_BG = SpellingRules({
    **_CYRILLIC_BASE, "щ": ["sh", "t"], "ъ": ["a"], "ь": ["y"],
    "б#": ["p"], "в#": ["f"], "г#": ["k"], "д#": ["t"], "ж#": ["sh"], "з#": ["s"],
})
_UK = SpellingRules({
    **_CYRILLIC_BASE, "г": ["h"], "ґ": ["g"], "є": ["y", "e"], "і": ["i"], "ї": ["y", "i"], "щ": ["sh", "ch"],
    "ь": [], "ть": ["ty"], "дь": ["dy"], "нь": ["ny"], "ль": ["ly"], "сь": ["sh"], "зь": ["zh"], "ць": ["ts"],
    "в#": ["u"],
})


# --- デーヴァナーガリー（ヒンディー語・ネパール語） ---
_DEVA_CONSONANTS = {
    "क": "k", "ख": "k", "ग": "g", "घ": "g", "ङ": "ng", "च": "ch", "छ": "ch", "ज": "j", "झ": "j", "ञ": "n",
    "ट": "t", "ठ": "t", "ड": "d", "ढ": "d", "ण": "n", "त": "t", "थ": "t", "द": "d", "ध": "d", "न": "n",
    "प": "p", "फ": "f", "ब": "b", "भ": "b", "म": "m", "य": "y", "र": "r", "ल": "r", "व": "w", "श": "sh",
    "ष": "sh", "स": "s", "ह": "h", "ळ": "r",
    "ऴ": "r", "ऱ": "r", "ऩ": "n",  # タミル語・マラヤーラム語の字を、デーヴァナーガリーの同じ位置に置いたもの（ழ ற ன）
    "क़": "k", "ख़": "x", "ग़": "g", "ज़": "z", "ड़": "r", "ढ़": "r", "फ़": "f", "य़": "y",
}
_DEVA_NUKTA = {"k": "k", "x": "x", "g": "g", "j": "z", "d": "r", "f": "f", "y": "y"}
_DEVA_VOWELS = {  # 母音の文字（語頭など）
    "अ": "a", "आ": "a:", "इ": "i", "ई": "i:", "उ": "u", "ऊ": "u:", "ऋ": "ri", "ए": "e", "ऐ": "e", "ओ": "o",
    "औ": "o", "ऑ": "o", "ऍ": "e", "ऎ": "e", "ऒ": "o",
}
_DEVA_SIGNS = {  # 子音に付く母音の記号
    "ा": "a:", "ि": "i", "ी": "i:", "ु": "u", "ू": "u:", "ृ": "ri", "े": "e", "ै": "e", "ो": "o", "ौ": "o",
    "ॉ": "o", "ॅ": "e", "ॆ": "e", "ॊ": "o",
}
_VIRAMA_DEVA = "्"
_DEVA_DIGITS = str.maketrans(  # デーヴァナーガリーと、ほかのインドの文字・ミャンマー文字・クメール文字の数字（2026-11-23 に足した）
    "".join("".join(chr(start + d) for d in range(10)) for start in (0x0966, 0x09E6, 0x0A66, 0x0AE6, 0x0BE6, 0x0C66, 0x0D66, 0x1040, 0x17E0)),
    "0123456789" * 9,
)
_DANDA = str.maketrans({"।": "。", "॥": "。"})  # カタカナの行では、文の終わりを「。」で書く


def _deva_tokens(word: str, medial_schwa: bool, inherent: str = "a", final_schwa: bool = True,
                 final_virama_vowel: str = "", final_anusvara: str = "N", ai_vowel: str = "e") -> Tokens:
    """デーヴァナーガリーの 1 語を、音の並びにする。

    子音字には「a」が付いている（क = ka）。母音の記号（ि など）が付けば、その母音に変わり、् が付けば母音が消える。
    語末の a は読まない（ヒンディー語・ネパール語とも。ただし子音が重なったあと＝मित्र の र は読む）。
    medial_schwa のとき（ヒンディー語）、語中の「母音 子音 a 子音 母音」の a も読まない（समझना → サマジュナー）。
    ほかのインドの文字（more_kana_next.py が、デーヴァナーガリーの同じ位置の字に置き換えて渡す）のための指定:
    inherent = 子音字が持っている母音（ベンガル語は o）、final_schwa = 語末の a を読まない（タミル語などは False）、
    final_virama_vowel = 語末が ् で終わるときに読む母音（マラヤーラム語は u）、final_anusvara = 語末の ं の読み（マラヤーラム語は m）、
    ai_vowel = ै・ऐ の読み（タミル語・テルグ語・マラヤーラム語は ai）。
    """
    # 1 音節ずつ: (子音, 母音) 。母音が None は ् で消えた子音、"A" は子音字が持っている a
    syllables: list[list[str | None]] = []
    for ch in unicodedata.normalize("NFC", word):
        if ch in _DEVA_CONSONANTS:
            syllables.append([_DEVA_CONSONANTS[ch], "A"])
        elif ch == "़" and syllables and syllables[-1][0]:
            syllables[-1][0] = _DEVA_NUKTA.get(syllables[-1][0], syllables[-1][0])
        elif ch in _DEVA_VOWELS:
            syllables.append(["", ai_vowel if ch == "ऐ" else _DEVA_VOWELS[ch]])
        elif ch in _DEVA_SIGNS and syllables:
            syllables[-1][1] = ai_vowel if ch == "ै" else _DEVA_SIGNS[ch]
        elif ch == _VIRAMA_DEVA and syllables:
            syllables[-1][1] = None
        elif ch in "ंँ":
            syllables.append(["N", None])
        elif ch == "ः":
            syllables.append(["h", None])
    # 語末の a（子音が重なったあとは読む）
    real = [i for i, (consonant, vowel) in enumerate(syllables) if consonant not in ("N", "h") or vowel is not None]
    if len(real) > 1 and final_schwa:
        last = real[-1]
        before = syllables[last - 1]
        conjunct = before[0] not in ("", "N", "h") and before[1] is None  # 子音が重なったあと（मित्र）
        if syllables[last][1] == "A" and syllables[last][0] and not conjunct:
            syllables[last][1] = "D"
    if medial_schwa:
        # 右から見て「母音 + 子音 a + 子音 + 母音」の a を消す（消したすぐ左は消さない）
        i = len(syllables) - 2
        while i >= 1:
            here, left, right = syllables[i], syllables[i - 1], syllables[i + 1]
            if (here[1] == "A" and here[0] and left[1] is not None and right[0] and right[0] != "N"
                    and right[1] not in (None, "D")):
                here[1] = "D"  # 読まない a（् とちがい、次の子音と「ャ」の音にはならない: कृपया → クリプヤー）
                i -= 2
                continue
            i -= 1
    if final_virama_vowel and syllables and syllables[-1][0] not in ("", "N", "h") and syllables[-1][1] is None             and unicodedata.normalize("NFC", word).endswith(_VIRAMA_DEVA):
        syllables[-1][1] = final_virama_vowel  # マラヤーラム語の語末の ് は、短い「ウ」（പണ് → パヌ）
    tokens: Tokens = []
    for index, (consonant, vowel) in enumerate(syllables):
        if consonant == "N":
            tokens.append(final_anusvara if index == len(syllables) - 1 else "N")
            continue
        following = syllables[index + 1][0] if index + 1 < len(syllables) else ""
        if consonant == "n" and vowel in (None, "D") and following and following != "N":
            tokens.append("N")  # 子音の前の ん（धन्यवाद → ダンヤワード）
            continue
        if consonant and vowel is None and following == consonant:
            tokens.append("Q")  # 同じ子音が重なる（अच्छा → アッチャー）
            continue
        if consonant:
            tokens.append(consonant)
        if vowel == "A":
            tokens.append(inherent)
        elif vowel == "D":
            tokens.append("|")  # 音の切れ目（次の y と合わせて読まない）
        elif vowel:
            if vowel == "ri":
                tokens.extend(["r", "i"])
            elif vowel in ("ai", "au"):
                tokens.extend(list(vowel))
            else:
                tokens.append(vowel)
    return tokens


# --- シンハラ文字 ---
_SI_CONSONANTS: dict[str, Iterable[str]] = {
    "ක": ["k"], "ඛ": ["k"], "ග": ["g"], "ඝ": ["g"], "ඞ": ["ng"], "ඟ": ["N", "g"], "ච": ["ch"], "ඡ": ["ch"],
    "ජ": ["j"], "ඣ": ["j"], "ඤ": ["ny"], "ඥ": ["g", "ny"], "ඦ": ["N", "j"], "ට": ["t"], "ඨ": ["t"], "ඩ": ["d"],
    "ඪ": ["d"], "ණ": ["n"], "ඬ": ["N", "d"], "ත": ["t"], "ථ": ["t"], "ද": ["d"], "ධ": ["d"], "න": ["n"],
    "ඳ": ["N", "d"], "ප": ["p"], "ඵ": ["p"], "බ": ["b"], "භ": ["b"], "ම": ["m"], "ඹ": ["N", "b"], "ය": ["y"],
    "ර": ["r"], "ල": ["r"], "ව": ["w"], "ශ": ["sh"], "ෂ": ["sh"], "ස": ["s"], "හ": ["h"], "ළ": ["r"], "ෆ": ["f"],
}
_SI_VOWELS = {
    "අ": "a", "ආ": "a:", "ඇ": "e", "ඈ": "e:", "ඉ": "i", "ඊ": "i:", "උ": "u", "ඌ": "u:", "ඍ": "ri", "එ": "e",
    "ඒ": "e:", "ඓ": "ai", "ඔ": "o", "ඕ": "o:", "ඖ": "au",
}
_SI_SIGNS = {
    "ා": "a:", "ැ": "e", "ෑ": "e:", "ි": "i", "ී": "i:", "ු": "u", "ූ": "u:", "ෘ": "ru", "ෲ": "ru:", "ෙ": "e",
    "ේ": "e:", "ෛ": "ai", "ො": "o", "ෝ": "o:", "ෞ": "au",
}
_SI_VIRAMA = "්"


def _si_tokens(word: str) -> Tokens:
    """シンハラ文字の 1 語を、音の並びにする（子音字には a が付いている。් で母音が消える）。"""
    syllables: list[list] = []
    for ch in unicodedata.normalize("NFC", word):
        if ch in _SI_CONSONANTS:
            syllables.append([list(_SI_CONSONANTS[ch]), "a"])
        elif ch in _SI_VOWELS:
            syllables.append([[], _SI_VOWELS[ch]])
        elif ch in _SI_SIGNS and syllables:
            syllables[-1][1] = _SI_SIGNS[ch]
        elif ch == _SI_VIRAMA and syllables:
            syllables[-1][1] = ""
        elif ch == "ං":
            syllables.append([["N"], ""])
        elif ch == "ඃ":
            syllables.append([["h"], ""])
    tokens: Tokens = []
    for consonants, vowel in syllables:
        tokens.extend(consonants)
        if vowel in ("ru", "ru:"):
            tokens.extend(["r", vowel[1:]])
        elif vowel in ("ai", "au"):
            tokens.extend([vowel[0], vowel[1]])
        elif vowel:
            tokens.append(vowel)
    return tokens


# --- 言語ごとの変換 ---

_LATIN_WORD = re.compile(r"[^\W\d_]+(?:'[^\W\d_]+)*")
_CYRILLIC_WORD = re.compile(r"[а-яёґєії]+(?:['’][а-яёґєії]+)*", re.IGNORECASE)
_DEVANAGARI_WORD = re.compile(r"[ऀ-ॣ॰-ॿ]+")
_SINHALA_WORD = re.compile(r"[඀-෿‍]+")
_APOSTROPHES = str.maketrans({"‘": "'", "’": "'", "ʻ": "'", "ʼ": "'", "`": "'"})
_LATIN_SCRIPT_WORD = re.compile(r"[A-Za-zÀ-ɏ]")
_KANA_HYPHEN = re.compile(r"(?<=[ァ-ヶー])-(?=[ァ-ヶー])")


def _word_converter(pattern: re.Pattern[str], to_tokens: Callable[[str], Tokens]) -> Callable[[str], str]:
    def convert(text: str) -> str:
        converted = pattern.sub(lambda match: tokens_to_kana(to_tokens(match.group())) or match.group(), text)
        converted = _KANA_HYPHEN.sub(" ", converted)
        return re.sub(r"\s+", " ", converted).strip()

    return convert


def _latin_converter(rules: SpellingRules | Callable[[str], Tokens]) -> Callable[[str], str]:
    to_tokens = rules.tokens if isinstance(rules, SpellingRules) else rules

    def tokens(word: str) -> Tokens:
        return to_tokens(unicodedata.normalize("NFC", word))

    convert = _word_converter(_LATIN_WORD, tokens)
    # ウズベク語の o‘・g‘ の記号は、いろいろな字で書かれるので、先に「'」にそろえる（語の一部として読む）
    return lambda text: convert(text.translate(_APOSTROPHES))


_CONVERTERS: dict[str, Callable[[str], str]] = {
    "es": _latin_converter(_ES), "de": _latin_converter(_DE), "it": _latin_converter(_IT),
    "nl": _latin_converter(_NL), "pl": _latin_converter(_PL), "hr": _latin_converter(_HR),
    "sk": _latin_converter(_SK), "sl": _latin_converter(_SL), "hu": _latin_converter(_HU),
    "et": _latin_converter(_ET), "lv": _latin_converter(_LV), "lt": _latin_converter(_LT),
    "id": _latin_converter(_ID), "vi": _latin_converter(_vi_tokens), "tr": _latin_converter(_TR),
    "cs": _latin_converter(_CS), "uz": _latin_converter(_UZ),
    "bg": _word_converter(_CYRILLIC_WORD, _BG.tokens), "uk": _word_converter(_CYRILLIC_WORD, _UK.tokens),
    "hi": _word_converter(_DEVANAGARI_WORD, lambda word: _deva_tokens(word, medial_schwa=True)),
    "ne": _word_converter(_DEVANAGARI_WORD, lambda word: _deva_tokens(word, medial_schwa=False)),
    "si": _word_converter(_SINHALA_WORD, _si_tokens),
}
# 2026-11-23 に、2026-11-21 に足した 24 言語のうち 22 言語を足した（more_kana_next.py。ヘブライ語・ウルドゥー語は扱わない）
from . import more_kana_next as _next  # noqa: E402（上の部品を使うので、ここで読む）

_CONVERTERS.update(_next.CONVERTERS)
SUPPORTED_LANGS = frozenset(_CONVERTERS)


def to_katakana(text: str, lang: str) -> str:
    """lang の文をカタカナにする（数字は先に、その言語の言葉にする）。対応していない言語は空文字。"""
    converter = _CONVERTERS.get(lang)
    if converter is None:
        return ""
    return converter(spell_numbers(text.translate(_DEVA_DIGITS), lang)).translate(_DANDA)
