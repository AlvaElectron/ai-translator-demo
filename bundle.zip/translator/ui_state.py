"""画面に表示する状態。各スレッドが更新し、画面の描画ループが読み出す。"""

from __future__ import annotations

import threading
from dataclasses import dataclass
from typing import TYPE_CHECKING

from .chinese import SIMPLIFIED, TRADITIONAL, to_hongkong, to_simplified, to_traditional
from .langs import BACK_TRANSLATION_SPEAKERS, SPEAKABLE_LANGS, YUE, ZH, Mode

if TYPE_CHECKING:
    from .bluetooth import BluetoothDevice
    from .wifi import WifiNetwork


@dataclass(frozen=True)
class Snapshot:
    version: int
    mode: Mode
    speech_enabled: bool
    # 今の機器で音声出力ができるか（スピーカーを開けているときだけ True）
    speech_output_available: bool
    # 確認用に、訳文を元の言語に訳し戻して表示するか（メニューの「翻訳の確認」）
    back_translation_enabled: bool
    # 音の設定の「ノイズ除去」がオンか
    denoise_enabled: bool
    # 雑音除去のモデルがあるか（無ければボタンを暗くする）
    denoise_available: bool
    input_gain: float
    output_volume: float
    # 読み上げの速さ（音の設定の「読み上げの速さ」。config.toml の tts.speed を 1.0 とした倍率）
    speech_speed: float
    # 中国語の書き方（chinese.SIMPLIFIED = 簡体字、chinese.TRADITIONAL = 台湾の繁体字）
    zh_script: str
    # 読み上げられる言語（広東語・タイ語は読み上げないので含まない）
    speakable_langs: frozenset[str]
    # 話し終わりと判断する無音の秒数
    silence_sec: float
    # 1回に話せる長さの上限（秒）
    max_speech_sec: float
    input_peak: float
    hearing: bool
    # 「会話スタート」が押されて、発話を待っているか
    listening_armed: bool
    # 表示中の訳文を、一度でも読み上げたか（「再生」→「もう一度再生」の切り替えに使う）
    target_played: bool
    # 「再生」ボタンを押して、音が出るのを待っているか（合成が終わるまで）
    waiting_for_audio: bool
    # 起動（モデルの読み込み）が終わっているか
    ready: bool
    # 起動できなかった理由（起動できたときは空）
    startup_error: str
    # 何も処理していない（「会話スタート」を押せる）状態か
    idle: bool
    audio_route: str
    bt_status: str
    bt_devices: tuple[BluetoothDevice, ...]
    bt_busy: bool
    bt_scanning: bool
    # 「マウス・キーボード」の画面: 見つかった機器、操作の結果、接続中か、探しているか、キーボードで打ってもらう番号
    hid_devices: tuple[BluetoothDevice, ...]
    hid_status: str
    hid_busy: bool
    hid_scanning: bool
    hid_passkey: str
    # 「Wi-Fi設定」の画面: 操作の結果、見つかった Wi-Fi、つないでいる Wi-Fi の名前と IP アドレス、操作の途中か
    wifi_status: str
    wifi_networks: tuple[WifiNetwork, ...]
    wifi_current: str
    wifi_address: str
    wifi_busy: bool
    source_lang: str
    source_text: str
    source_pron: str
    target_lang: str
    target_text: str
    target_pron: str
    # 確認用に、訳文を元の言語に訳し戻した文
    back_lang: str
    back_text: str
    status: str
    # 「使い方」の動画を再生している最中か（終わった・止めたら False。終わった理由が失敗なら guide_error に入る）
    guide_playing: bool = False
    guide_error: str = ""

    @property
    def speaks(self) -> bool:
        """訳文を読み上げるか（音声出力がオンで、スピーカーを開けているとき）。"""
        return self.speech_enabled and self.speech_output_available

    @property
    def denoises(self) -> bool:
        """認識の前に雑音除去を行うか（オンで、モデルがあるとき）。"""
        return self.denoise_enabled and self.denoise_available

    @property
    def zh_traditional(self) -> bool:
        """中国語を台湾の繁体字で表示するか（メニューの「中文（台灣）」）。"""
        return self.zh_script == TRADITIONAL

    @property
    def back_translation_available(self) -> bool:
        """今の話す人の言語で、翻訳の確認を行うか（日本語で話すときだけ）。"""
        return self.mode.speaker in BACK_TRANSLATION_SPEAKERS

    @property
    def can_play_target(self) -> bool:
        """「再生」ボタンを押せるか（読み上げられる言語の訳文が表示されていて、スピーカーが使えて、何も処理していないとき）。

        メニューの「音声出力」がオフでも、ボタンを押せば読み上げる。広東語・タイ語の訳文は読み上げないので押せない。
        """
        return (
            bool(self.target_text)
            and self.target_lang in self.speakable_langs
            and self.speech_output_available
            and self.idle
        )

    @property
    def shows_back_translation(self) -> bool:
        """通訳の画面に、確認用の文の欄を作るか。

        表示中の発話を話した言語で決める（表示中の発話がなければ、今の話す人の言語で決める）。
        日本語で話した発話の確認を、話す人を切り替えたあとも、次の発話まで表示しておくため。
        """
        speaker = self.source_lang if self.target_lang else self.mode.speaker
        return self.back_translation_enabled and speaker in BACK_TRANSLATION_SPEAKERS


# 状態表示（日本語と英語を併記する）
LISTENING = "聞き取り中 / Listening"
RECOGNIZING = "認識中 / Recognizing"
TRANSLATING = "翻訳中 / Translating"
PLAYING = "再生中 / Playing"
STANDBY = "待機中 / Standby"
TUNING = "音の設定中"


class UiState:
    def __init__(
        self,
        mode: Mode,
        speech_enabled: bool = True,
        input_gain: float = 1.0,
        output_volume: float = 1.0,
        back_translation_enabled: bool = True,
        speech_output_available: bool = True,
        denoise_enabled: bool = False,
        denoise_available: bool = False,
        ready: bool = True,
        silence_sec: float = 1.0,
        max_speech_sec: float = 3.0,
        speech_speed: float = 1.0,
        zh_script: str = SIMPLIFIED,
        speakable_langs: frozenset[str] = SPEAKABLE_LANGS,
    ) -> None:
        self._lock = threading.Lock()
        self._version = 0
        self._ready = ready
        self._startup_error = ""
        self._mode = mode
        self._speech_enabled = speech_enabled
        self._speech_output_available = speech_output_available
        self._back_translation_enabled = back_translation_enabled
        self._denoise_enabled = denoise_enabled
        self._denoise_available = denoise_available
        self._input_gain = input_gain
        self._output_volume = output_volume
        self._speech_speed = speech_speed
        self._zh_script = zh_script
        self._speakable_langs = frozenset(speakable_langs)
        self._silence_sec = silence_sec
        self._max_speech_sec = max_speech_sec
        self._input_peak = 0.0
        self._mic_tuning = False
        self._audio_route = ""
        self._bt_status = ""
        self._bt_devices: tuple[BluetoothDevice, ...] = ()
        self._bt_busy = False
        self._bt_scanning = False
        self._hid_devices: tuple[BluetoothDevice, ...] = ()
        self._hid_status = ""
        self._hid_busy = False
        self._hid_scanning = False
        self._hid_passkey = ""
        self._wifi_status = ""
        self._wifi_networks: tuple[WifiNetwork, ...] = ()
        self._wifi_current = ""
        self._wifi_address = ""
        self._wifi_busy = False
        self._source_lang = ""
        self._source_text = ""
        self._source_pron = ""
        self._target_lang = ""
        self._target_text = ""
        self._target_pron = ""
        self._back_lang = ""
        self._back_text = ""
        self._message: str | None = None
        self._hearing = False
        self._listening_armed = False
        self._target_played = False
        self._waiting_for_audio = False
        # 音声で「スタート」と言われたので、通訳の画面を出してほしいか（画面が読み出したら消す）
        self._main_page_requested = False
        self._recognizing = False
        self._translating = False
        self._back_translating = False
        self._pending_speech = 0
        self._guide_playing = False
        self._guide_error = ""

    @property
    def mode(self) -> Mode:
        with self._lock:
            return self._mode

    @property
    def speech_enabled(self) -> bool:
        """メニューの「音声出力」がオンか。"""
        with self._lock:
            return self._speech_enabled

    @property
    def speaks(self) -> bool:
        """訳文を読み上げるか（音声出力がオンで、スピーカーを開けているとき）。"""
        with self._lock:
            return self._speech_enabled and self._speech_output_available

    @property
    def back_translation_enabled(self) -> bool:
        with self._lock:
            return self._back_translation_enabled

    @property
    def denoises(self) -> bool:
        """認識の前に雑音除去を行うか（「ノイズ除去」がオンで、モデルがあるとき）。"""
        with self._lock:
            return self._denoise_enabled and self._denoise_available

    @property
    def listening_armed(self) -> bool:
        """「会話スタート」が押されて、発話を待っているか。"""
        with self._lock:
            return self._listening_armed

    @property
    def hearing(self) -> bool:
        """マイクで声を検出している最中か。"""
        with self._lock:
            return self._hearing

    @property
    def pending_speech(self) -> int:
        """合成・再生を待っている文の数。"""
        with self._lock:
            return self._pending_speech

    @property
    def input_gain(self) -> float:
        with self._lock:
            return self._input_gain

    @property
    def output_volume(self) -> float:
        with self._lock:
            return self._output_volume

    @property
    def speech_speed(self) -> float:
        with self._lock:
            return self._speech_speed

    @property
    def silence_sec(self) -> float:
        with self._lock:
            return self._silence_sec

    @property
    def max_speech_sec(self) -> float:
        with self._lock:
            return self._max_speech_sec

    @property
    def mic_tuning(self) -> bool:
        """音の設定・Bluetooth の画面を開いているか（開いている間は翻訳しない）。"""
        with self._lock:
            return self._mic_tuning

    @property
    def bt_busy(self) -> bool:
        """Bluetooth 機器に接続している最中か。"""
        with self._lock:
            return self._bt_busy

    @property
    def bt_scanning(self) -> bool:
        with self._lock:
            return self._bt_scanning

    def set_mode(self, mode: Mode) -> None:
        self._update(mode=mode)

    def set_speech_enabled(self, enabled: bool) -> None:
        self._update(speech_enabled=enabled)

    def set_back_translation_enabled(self, enabled: bool) -> None:
        """翻訳の確認のオン・オフ。オフにしたら、表示中の確認用の文も消す。"""
        if enabled:
            self._update(back_translation_enabled=True)
        else:
            self._update(back_translation_enabled=False, back_lang="", back_text="")

    def set_denoise_enabled(self, enabled: bool) -> None:
        """雑音除去のオン・オフ（音の設定の「ノイズ除去」）。次の発話から効く。"""
        self._update(denoise_enabled=enabled)

    def set_input_gain(self, gain: float) -> None:
        self._update(input_gain=gain)

    def set_output_volume(self, volume: float) -> None:
        self._update(output_volume=volume)

    def set_speakable_langs(self, langs: frozenset[str]) -> None:
        """読み上げられる言語（音声合成を読み込んだあとに、その対応言語で決める）。"""
        self._update(speakable_langs=frozenset(langs))

    def set_speech_speed(self, speed: float) -> None:
        self._update(speech_speed=speed)

    def set_silence_sec(self, seconds: float) -> None:
        self._update(silence_sec=seconds)

    def set_max_speech_sec(self, seconds: float) -> None:
        self._update(max_speech_sec=seconds)

    def set_mic_tuning(self, tuning: bool) -> None:
        self._update(mic_tuning=tuning)

    def set_input_level(self, peak: float) -> None:
        """入力レベル。頻繁に呼ばれるので version は上げない（音の設定の画面が一定間隔で読みに来る）。"""
        with self._lock:
            self._input_peak = peak

    def set_audio_route(self, label: str, speech_output: bool) -> None:
        """使っているマイク・スピーカーの説明（例: 「マイク（機器名）」「Bluetooth（イヤホン名）」）。

        speech_output は、その機器で音声出力（読み上げ）ができるか（スピーカーを開けているときだけ True）。
        """
        self._update(audio_route=label, speech_output_available=speech_output)

    def set_bluetooth(
        self,
        *,
        status: str | None = None,
        devices: tuple[BluetoothDevice, ...] | None = None,
        busy: bool | None = None,
        scanning: bool | None = None,
    ) -> None:
        """Bluetooth の画面の表示。None の項目は変えない。"""
        fields = {
            name: value
            for name, value in (("bt_status", status), ("bt_devices", devices), ("bt_busy", busy), ("bt_scanning", scanning))
            if value is not None
        }
        if fields:
            self._update(**fields)

    def set_wifi(
        self,
        *,
        status: str | None = None,
        networks: tuple[WifiNetwork, ...] | None = None,
        current: str | None = None,
        address: str | None = None,
        busy: bool | None = None,
    ) -> None:
        """「Wi-Fi設定」の画面の表示。None の項目は変えない。"""
        fields = {
            name: value
            for name, value in (
                ("wifi_status", status),
                ("wifi_networks", networks),
                ("wifi_current", current),
                ("wifi_address", address),
                ("wifi_busy", busy),
            )
            if value is not None
        }
        if fields:
            self._update(**fields)

    def set_hid(
        self,
        *,
        devices: tuple[BluetoothDevice, ...] | None = None,
        status: str | None = None,
        busy: bool | None = None,
        scanning: bool | None = None,
        passkey: str | None = None,
    ) -> None:
        """「マウス・キーボード」の画面の表示。None の項目は変えない。"""
        fields = {
            name: value
            for name, value in (
                ("hid_devices", devices),
                ("hid_status", status),
                ("hid_busy", busy),
                ("hid_scanning", scanning),
                ("hid_passkey", passkey),
            )
            if value is not None
        }
        if fields:
            self._update(**fields)

    def begin_utterance(self, source_lang: str, source_text: str, target_lang: str, source_pron: str = "") -> None:
        """新しい発話の表示を始める（前の訳文・発音記号・確認用の訳は消す）。"""
        self._update(
            target_played=False,
            source_lang=source_lang,
            # 話した言葉は置き換えないよう、字だけを変える
            source_text=self._for_display(source_text, source_lang, taiwan_words=False),
            source_pron=source_pron,
            target_lang=target_lang,
            target_text="",
            target_pron="",
            back_lang="",
            back_text="",
        )

    def set_target_text(self, text: str) -> None:
        with self._lock:
            lang = self._target_lang
        self._update(target_text=self._for_display(text, lang))

    def set_zh_script(self, script: str) -> None:
        """中国語の書き方（簡体字 / 台湾の繁体字）を変える。表示中の中国語も書き直す。

        訳文は語彙ごと（台湾式 ⇔ 大陸式）、原文（話した言葉）は字だけを変える。
        """
        with self._lock:
            if script == self._zh_script:
                return
            source = (self._source_lang, self._source_text)
            target = (self._target_lang, self._target_text)
        convert = to_traditional if script == TRADITIONAL else to_simplified
        fields: dict[str, object] = {"zh_script": script}
        for name, (lang, text), words in (("source_text", source, False), ("target_text", target, True)):
            if lang == ZH and text:
                fields[name] = convert(text, words)
        self._update(**fields)

    def _for_display(self, text: str, lang: str, taiwan_words: bool = True) -> str:
        """画面に出す文。

        台湾の繁体字を選んでいるときは、中国語（翻訳・認識は簡体字）を繁体字に変える。
        広東語は、いつも香港の繁体字で出す（音声認識が簡体字で書くことがあるため）。
        """
        if not text:
            return text
        if lang == YUE:
            return to_hongkong(text)
        with self._lock:
            traditional = self._zh_script == TRADITIONAL
        return to_traditional(text, taiwan_words) if traditional and lang == ZH else text

    def set_target_pron(self, pron: str) -> None:
        self._update(target_pron=pron)

    def set_back_translation(self, lang: str, text: str) -> None:
        self._update(back_lang=lang, back_text=text)

    def set_back_translating(self, value: bool) -> None:
        self._update(back_translating=value)

    def cancel(self) -> None:
        """「キャンセル」: 表示中の文を消し、翻訳中・再生中の表示をやめて待機中に戻す。"""
        self._update(
            source_text="",
            source_pron="",
            target_lang="",
            target_text="",
            target_pron="",
            back_lang="",
            back_text="",
            message=None,
            recognizing=False,
            translating=False,
            back_translating=False,
            pending_speech=0,
            listening_armed=False,
            target_played=False,
            waiting_for_audio=False,
        )

    def set_message(self, message: str | None) -> None:
        """起動中やエラーなど、状態表示の代わりに出す文。None で通常の表示に戻す。"""
        self._update(message=message)

    def set_hearing(self, value: bool) -> None:
        self._update(hearing=value)

    def set_listening_armed(self, value: bool) -> None:
        self._update(listening_armed=value)

    def set_target_played(self, value: bool) -> None:
        """表示中の訳文を読み上げたか（「再生」ボタンの文字を切り替えるのに使う）。"""
        self._update(target_played=value)

    def set_waiting_for_audio(self, value: bool) -> None:
        """「再生」ボタンを押して、合成が終わるのを待っているか。"""
        self._update(waiting_for_audio=value)

    def request_main_page(self) -> None:
        """通訳の画面を出してほしいと画面に伝える（メニューを開いているときに音声で「スタート」と言われたとき）。"""
        with self._lock:
            self._main_page_requested = True

    def take_main_page_request(self) -> bool:
        """通訳の画面を出してほしいと頼まれていたか（読み出したら、頼みは消す）。"""
        with self._lock:
            requested, self._main_page_requested = self._main_page_requested, False
            return requested

    def set_guide_playing(self, playing: bool, error: str = "") -> None:
        """「使い方」の動画の再生を始めた・終えた（失敗して終えたときは、その理由）。"""
        self._update(guide_playing=playing, guide_error=error)

    def set_ready(self, value: bool) -> None:
        """起動（モデルの読み込み）が終わったか。終わるまでは「会話スタート」を押せない。"""
        self._update(ready=value)

    def show_startup_error(self, detail: str) -> None:
        """起動できなかった理由を、画面に大きく表示する。"""
        self._update(message="起動できません / Startup failed", startup_error=detail)

    def set_recognizing(self, value: bool) -> None:
        self._update(recognizing=value)

    def set_translating(self, value: bool) -> None:
        self._update(translating=value)

    def add_pending_speech(self, delta: int) -> None:
        with self._lock:
            self._pending_speech += delta
            self._version += 1

    def snapshot(self) -> Snapshot:
        with self._lock:
            return Snapshot(
                version=self._version,
                mode=self._mode,
                speech_enabled=self._speech_enabled,
                speech_output_available=self._speech_output_available,
                back_translation_enabled=self._back_translation_enabled,
                denoise_enabled=self._denoise_enabled,
                denoise_available=self._denoise_available,
                input_gain=self._input_gain,
                output_volume=self._output_volume,
                speech_speed=self._speech_speed,
                zh_script=self._zh_script,
                speakable_langs=self._speakable_langs,
                silence_sec=self._silence_sec,
                max_speech_sec=self._max_speech_sec,
                input_peak=self._input_peak,
                hearing=self._hearing,
                listening_armed=self._listening_armed,
                target_played=self._target_played,
                waiting_for_audio=self._waiting_for_audio,
                ready=self._ready,
                startup_error=self._startup_error,
                idle=self._ready and self._activity() == STANDBY,
                audio_route=self._audio_route,
                bt_status=self._bt_status,
                bt_devices=self._bt_devices,
                bt_busy=self._bt_busy,
                bt_scanning=self._bt_scanning,
                hid_devices=self._hid_devices,
                hid_status=self._hid_status,
                hid_busy=self._hid_busy,
                hid_scanning=self._hid_scanning,
                hid_passkey=self._hid_passkey,
                wifi_status=self._wifi_status,
                wifi_networks=self._wifi_networks,
                wifi_current=self._wifi_current,
                wifi_address=self._wifi_address,
                wifi_busy=self._wifi_busy,
                source_lang=self._source_lang,
                source_text=self._source_text,
                source_pron=self._source_pron,
                target_lang=self._target_lang,
                target_text=self._target_text,
                target_pron=self._target_pron,
                back_lang=self._back_lang,
                back_text=self._back_text,
                status=self._status(),
                guide_playing=self._guide_playing,
                guide_error=self._guide_error,
            )

    def _status(self) -> str:
        status = self._message or self._activity()
        speaks = self._speech_enabled and self._speech_output_available
        return status if speaks else f"{status}（音声オフ）"

    def _activity(self) -> str:
        if self._mic_tuning:
            return TUNING
        if self._pending_speech > 0:
            return PLAYING
        if self._translating:
            return TRANSLATING
        if self._back_translating:
            return TRANSLATING
        if self._recognizing:
            return RECOGNIZING
        if self._listening_armed or self._hearing:
            return LISTENING
        return STANDBY

    def _update(self, **fields: object) -> None:
        with self._lock:
            for name, value in fields.items():
                setattr(self, f"_{name}", value)
            self._version += 1
