"""ハングルをカタカナに変換する（発音記号の表示に使う）。

ハングルは字と実際の発音がずれるので、主な音韻変化（連音・鼻音化・流音化・激音化・口蓋音化）を
適用してから、1音節ずつカタカナに置き換える。ハングルの分解は計算だけでできるので、
外部ライブラリには頼らない。

発音記号は「日本語話者が読んで通じる」ことが目的なので、韓国語の区別のうち
日本語にないもの（어と오、으と우、平音と激音）は同じカタカナになる。
"""

from __future__ import annotations

_BASE = 0xAC00
_LAST = 0xD7A3
_JUNG_COUNT = 21
_JONG_COUNT = 28

# 初声 19 個 →（語頭の読み, 語中の読み, 濃音か）。平音は語中で濁る（부산 → プサン、한국 → ハングク）
_CHO = (
    ("k", "g", False),   # ㄱ
    ("k", "k", True),    # ㄲ
    ("n", "n", False),   # ㄴ
    ("t", "d", False),   # ㄷ
    ("t", "t", True),    # ㄸ
    ("r", "r", False),   # ㄹ
    ("m", "m", False),   # ㅁ
    ("p", "b", False),   # ㅂ
    ("p", "p", True),    # ㅃ
    ("s", "s", False),   # ㅅ
    ("s", "s", True),    # ㅆ
    ("", "", False),     # ㅇ（母音だけ）
    ("ch", "j", False),  # ㅈ
    ("ch", "ch", True),  # ㅉ
    ("ch", "ch", False),  # ㅊ
    ("k", "k", False),   # ㅋ
    ("t", "t", False),   # ㅌ
    ("p", "p", False),   # ㅍ
    ("h", "h", False),   # ㅎ
)

# 中声 21 個 → 母音の種類。어/오 は「オ」、으/우 は「ウ」、애/에 は「エ」にまとめる
_JUNG = (
    "a", "e", "ya", "ye", "o", "e", "yo", "ye", "o", "wa", "we",
    "we", "yo", "u", "wo", "we", "wi", "yu", "u", "i", "i",
)

# 終声 28 個 → 代表音（k/n/t/l/m/p/ng のどれか）
_JONG = (
    "", "k", "k", "k", "n", "n", "n", "t", "l", "k", "m", "l", "l", "l",
    "p", "l", "m", "p", "p", "t", "t", "ng", "t", "t", "k", "t", "p", "t",
)

# 連音（次が ㅇ）のときに動く子音。値は (残る終声, 次の初声になる子音)。ㅇ は動かない
_LIAISON = {
    1: (0, 0), 2: (0, 1), 3: (1, 9), 4: (0, 2), 5: (4, 12), 6: (4, 18), 7: (0, 3),
    8: (0, 5), 9: (8, 0), 10: (8, 6), 11: (8, 7), 12: (8, 9), 13: (8, 16), 14: (8, 17),
    15: (8, 18), 16: (0, 6), 17: (0, 7), 18: (17, 9), 19: (0, 9), 20: (0, 10),
    22: (0, 12), 23: (0, 14), 24: (0, 15), 25: (0, 16), 26: (0, 17), 27: (0, 18),
}

# 終声 + ㅎ、または ㅎ + 初声 で激音になる組み合わせ
_ASPIRATE = {0: 15, 3: 16, 12: 14, 7: 17}  # ㄱ→ㅋ、ㄷ→ㅌ、ㅈ→ㅊ、ㅂ→ㅍ
_ASPIRATE_FROM_JONG = {"k": 15, "t": 16, "p": 17}
# ㅎ を含む終声 → ㅎ が抜けたあとに残る終声（ㅎ → なし、ㄶ → ㄴ、ㅀ → ㄹ）
_H_FINALS = {27: 0, 6: 4, 15: 8}

_KANA = {
    "k": {"a": "カ", "i": "キ", "u": "ク", "e": "ケ", "o": "コ", "ya": "キャ", "yu": "キュ",
          "yo": "キョ", "ye": "キェ", "wa": "クァ", "wo": "クォ", "we": "クェ", "wi": "クィ"},
    "g": {"a": "ガ", "i": "ギ", "u": "グ", "e": "ゲ", "o": "ゴ", "ya": "ギャ", "yu": "ギュ",
          "yo": "ギョ", "ye": "ギェ", "wa": "グァ", "wo": "グォ", "we": "グェ", "wi": "グィ"},
    "n": {"a": "ナ", "i": "ニ", "u": "ヌ", "e": "ネ", "o": "ノ", "ya": "ニャ", "yu": "ニュ",
          "yo": "ニョ", "ye": "ニェ", "wa": "ヌァ", "wo": "ヌォ", "we": "ヌェ", "wi": "ヌィ"},
    "t": {"a": "タ", "i": "ティ", "u": "トゥ", "e": "テ", "o": "ト", "ya": "ティャ", "yu": "テュ",
          "yo": "テョ", "ye": "ティェ", "wa": "トァ", "wo": "トォ", "we": "トェ", "wi": "トィ"},
    "d": {"a": "ダ", "i": "ディ", "u": "ドゥ", "e": "デ", "o": "ド", "ya": "ディャ", "yu": "デュ",
          "yo": "デョ", "ye": "ディェ", "wa": "ドァ", "wo": "ドォ", "we": "ドェ", "wi": "ドィ"},
    "r": {"a": "ラ", "i": "リ", "u": "ル", "e": "レ", "o": "ロ", "ya": "リャ", "yu": "リュ",
          "yo": "リョ", "ye": "リェ", "wa": "ルァ", "wo": "ルォ", "we": "ルェ", "wi": "ルィ"},
    "m": {"a": "マ", "i": "ミ", "u": "ム", "e": "メ", "o": "モ", "ya": "ミャ", "yu": "ミュ",
          "yo": "ミョ", "ye": "ミェ", "wa": "ムァ", "wo": "ムォ", "we": "ムェ", "wi": "ムィ"},
    "p": {"a": "パ", "i": "ピ", "u": "プ", "e": "ペ", "o": "ポ", "ya": "ピャ", "yu": "ピュ",
          "yo": "ピョ", "ye": "ピェ", "wa": "プァ", "wo": "プォ", "we": "プェ", "wi": "プィ"},
    "b": {"a": "バ", "i": "ビ", "u": "ブ", "e": "ベ", "o": "ボ", "ya": "ビャ", "yu": "ビュ",
          "yo": "ビョ", "ye": "ビェ", "wa": "ブァ", "wo": "ブォ", "we": "ブェ", "wi": "ブィ"},
    "s": {"a": "サ", "i": "シ", "u": "ス", "e": "セ", "o": "ソ", "ya": "シャ", "yu": "シュ",
          "yo": "ショ", "ye": "シェ", "wa": "スァ", "wo": "スォ", "we": "スェ", "wi": "スィ"},
    "ch": {"a": "チャ", "i": "チ", "u": "チュ", "e": "チェ", "o": "チョ", "ya": "チャ", "yu": "チュ",
           "yo": "チョ", "ye": "チェ", "wa": "チャ", "wo": "チョ", "we": "チェ", "wi": "チュィ"},
    "j": {"a": "ジャ", "i": "ジ", "u": "ジュ", "e": "ジェ", "o": "ジョ", "ya": "ジャ", "yu": "ジュ",
          "yo": "ジョ", "ye": "ジェ", "wa": "ジャ", "wo": "ジョ", "we": "ジェ", "wi": "ジュィ"},
    "h": {"a": "ハ", "i": "ヒ", "u": "フ", "e": "ヘ", "o": "ホ", "ya": "ヒャ", "yu": "ヒュ",
          "yo": "ヒョ", "ye": "ヒェ", "wa": "ファ", "wo": "フォ", "we": "フェ", "wi": "フィ"},
    "": {"a": "ア", "i": "イ", "u": "ウ", "e": "エ", "o": "オ", "ya": "ヤ", "yu": "ユ",
         "yo": "ヨ", "ye": "イェ", "wa": "ワ", "wo": "ウォ", "we": "ウェ", "wi": "ウィ"},
}

# 終声のカタカナ。ㄱ と ㄷ 系は、次に子音が続くと促音、それ以外は「ク」「ッ」にする
_JONG_KANA = {"n": "ン", "ng": "ン", "l": "ル", "m": "ム", "p": "プ", "t": "ッ", "k": "ク"}


def is_hangul(ch: str) -> bool:
    return _BASE <= ord(ch) <= _LAST


def _decompose(ch: str) -> tuple[int, int, int]:
    code = ord(ch) - _BASE
    return code // (_JUNG_COUNT * _JONG_COUNT), (code // _JONG_COUNT) % _JUNG_COUNT, code % _JONG_COUNT


def to_katakana(text: str) -> str:
    """ハングルの文をカタカナにする。ハングル以外の文字はそのまま残す。"""
    return "".join(_convert_word(word) if any(map(is_hangul, word)) else word for word in _split_words(text))


def _split_words(text: str) -> list[str]:
    """空白で区切る（空白自体も残す）。語頭かどうかで平音が濁るかが変わるため。"""
    words: list[str] = []
    current = ""
    for ch in text:
        if ch.isspace():
            if current:
                words.append(current)
                current = ""
            words.append(ch)
        else:
            current += ch
    if current:
        words.append(current)
    return words


def _convert_word(word: str) -> str:
    syllables: list[list[int] | str] = [list(_decompose(ch)) if is_hangul(ch) else ch for ch in word]
    _apply_sound_changes(syllables)

    result = ""
    first_hangul = True
    tense = False  # 直前の終声が ㄱ/ㄷ/ㅂ のときは濃音化する（학교 → 학꾜 → ハッキョ）ので、濁らせない
    for index, syllable in enumerate(syllables):
        if isinstance(syllable, str):
            result += syllable
            continue
        cho, jung, jong = syllable
        initial, medial, geminate = _CHO[cho]
        key = initial if (first_hangul or tense) else medial
        if geminate and result and not tense:  # 終声が促音を出しているときは重ねない
            result += "ッ"
        first_hangul = False
        result += _KANA[key][_JUNG[jung]]
        tense = bool(jong) and _JONG[jong] in ("k", "t", "p")
        if jong:
            result += _jong_kana(_JONG[jong], syllables[index + 1 :])
    return result


def _jong_kana(sound: str, rest: list[list[int] | str]) -> str:
    """終声のカタカナ。ㄱ は次に子音が続くときだけ促音にする（학교 → ハッキョ、한국 → ハングク）。"""
    if sound == "k":
        following = rest[0] if rest else None
        if isinstance(following, list) and _CHO[following[0]][0] not in ("", "h"):
            return "ッ"
        return "ク"
    return _JONG_KANA[sound]


def _apply_sound_changes(syllables: list[list[int] | str]) -> None:
    """主な音韻変化を、前から順に適用する（リストを直接書き換える）。"""
    for i in range(len(syllables) - 1):
        current, following = syllables[i], syllables[i + 1]
        if not isinstance(current, list) or not isinstance(following, list):
            continue
        jong, next_cho = current[2], following[0]
        if not jong:
            continue

        # 激音化: 終声 ㅎ + ㄱ/ㄷ/ㅈ/ㅂ、または 終声 ㄱ/ㄷ/ㅂ + 初声 ㅎ（좋다 → 조타）
        if jong in _H_FINALS and next_cho in _ASPIRATE:
            current[2] = _H_FINALS[jong]  # 않게 → 안케、싫다 → 실타
            following[0] = _ASPIRATE[next_cho]
            continue
        if next_cho == 18 and _JONG[jong] in _ASPIRATE_FROM_JONG:
            current[2] = 0
            following[0] = _ASPIRATE_FROM_JONG[_JONG[jong]]
            continue

        # 連音: 次が ㅇ なら終声が次の初声に移る（한국어 → 한구거）。ㅎ は消える（좋아요 → 조아요）
        if next_cho == 11:
            if jong in (7, 25) and following[1] == 20:
                # 口蓋音化: ㄷ・ㅌ + 이 は「ジ」「チ」になる（굳이 → 구지、같이 → 가치）
                current[2], following[0] = 0, (12 if jong == 7 else 14)
                continue
            if jong in _H_FINALS:
                # ㅎ は消え、ㄶ・ㅀ の ㄴ・ㄹ は次の音節に移る（괜찮아요 → 괜차나요、싫어요 → 시러요）
                current[2] = 0
                if jong != 27:
                    following[0] = 2 if jong == 6 else 5
                continue
            if jong in _LIAISON:
                current[2], following[0] = _LIAISON[jong]
            continue

        # 鼻音化: ㄱ/ㄷ/ㅂ + ㄴ/ㅁ（합니다 → 함니다、한국말 → 한궁말）
        if next_cho in (2, 6) and _JONG[jong] in ("k", "t", "p"):
            current[2] = {"k": 21, "t": 4, "p": 16}.get(_JONG[jong], jong)
            continue

        # 流音化: ㄴ + ㄹ、ㄹ + ㄴ はどちらも ㄹㄹ（신라 → 실라、설날 → 설랄）
        if _JONG[jong] == "n" and next_cho == 5:
            current[2] = 8
        elif _JONG[jong] == "l" and next_cho == 2:
            following[0] = 5
