"""本体の日付・時刻を、画面で見る・合わせる。pygame に依存しない。

電池のない本体（Raspberry Pi）は、電源を切ると時計が止まる。ネットワークにつながっていれば自動で合うが、
つながっていない場所では、画面の「時計設定」で手で合わせる。時刻を変えるには timedatectl を使う
（通訳アプリのユーザーに許可を出す scripts/allow_clock.sh を、最初に一度だけ実行しておく）。
"""

from __future__ import annotations

import calendar
import logging
import subprocess
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime

log = logging.getLogger(__name__)

WEEKDAYS = "月火水木金土日"
YEAR_MIN, YEAR_MAX = 2024, 2099
FIELDS = ("year", "month", "day", "hour", "minute")


def format_clock(moment: datetime, seconds: bool = False) -> str:
    """「2026-10-13 (火) 06:30」の形。メニューの右上と、時計設定の画面に出す。"""
    weekday = WEEKDAYS[moment.weekday()]
    time_part = moment.strftime("%H:%M:%S" if seconds else "%H:%M")
    return f"{moment:%Y-%m-%d} ({weekday}) {time_part}"


@dataclass
class ClockFields:
    """画面で変えている日付と時刻（年・月・日・時・分）。「−」「＋」で 1 つずつ変える。"""

    year: int
    month: int
    day: int
    hour: int
    minute: int

    @classmethod
    def from_datetime(cls, moment: datetime) -> ClockFields:
        return cls(moment.year, moment.month, moment.day, moment.hour, moment.minute)

    def to_datetime(self) -> datetime:
        return datetime(self.year, self.month, self.day, self.hour, self.minute)

    def days_in_month(self) -> int:
        return calendar.monthrange(self.year, self.month)[1]

    def step(self, field: str, direction: int) -> None:
        """field を 1 つ進める（direction が正）・戻す（負）。月・日・時・分は、端でぐるっと回る。日は、月の日数に合わせる。"""
        delta = 1 if direction > 0 else -1
        if field == "year":
            self.year = min(YEAR_MAX, max(YEAR_MIN, self.year + delta))
        elif field == "month":
            self.month = (self.month - 1 + delta) % 12 + 1
        elif field == "day":
            self.day = (self.day - 1 + delta) % self.days_in_month() + 1
        elif field == "hour":
            self.hour = (self.hour + delta) % 24
        elif field == "minute":
            self.minute = (self.minute + delta) % 60
        else:
            raise ValueError(f"知らない項目です: {field}")
        self.day = min(self.day, self.days_in_month())  # 年・月を変えて、日が月の日数を超えたら、月の最後の日にする


Runner = Callable[[list[str]], subprocess.CompletedProcess]


def _run(command: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(command, capture_output=True, text=True, timeout=15, check=False)


class SystemClock:
    """timedatectl で、時刻の自動合わせ（NTP）と、時刻を決める。失敗したときは、画面に出す文を返す（成功は None）。"""

    def __init__(self, runner: Runner = _run) -> None:
        self._run = runner

    def ntp_enabled(self) -> bool | None:
        """ネットワークで自動に合わせる設定か（調べられなければ None）。"""
        try:
            result = self._run(["timedatectl", "show", "-p", "NTP", "--value"])
        except (OSError, subprocess.SubprocessError):
            return None
        if result.returncode != 0:
            return None
        value = result.stdout.strip().lower()
        return {"yes": True, "no": False}.get(value)

    def set_ntp(self, enabled: bool) -> str | None:
        return self._timedatectl(["set-ntp", "true" if enabled else "false"])

    def set_time(self, moment: datetime) -> str | None:
        """時刻を手で決める。自動合わせがオンのままでは変えられないので、先にオフにする。"""
        error = self._timedatectl(["set-ntp", "false"])
        if error:
            return error
        return self._timedatectl(["set-time", moment.strftime("%Y-%m-%d %H:%M:00")])

    def _timedatectl(self, args: list[str]) -> str | None:
        try:
            result = self._run(["timedatectl", *args])
        except FileNotFoundError:
            return "この機器では時計を変えられません"
        except (OSError, subprocess.SubprocessError) as error:
            log.warning("timedatectl %s に失敗しました: %s", " ".join(args), error)
            return "時計を変えられませんでした"
        if result.returncode == 0:
            return None
        detail = (result.stderr or result.stdout).strip()
        log.warning("timedatectl %s に失敗しました: %s", " ".join(args), detail)
        if "authentication" in detail.lower() or "access denied" in detail.lower() or "interactive" in detail.lower():
            return "時計を変える許可がありません（scripts/allow_clock.sh を実行してください）"
        return "時計を変えられませんでした"
