"""定型文の登録（メニューの「定型文」）。よく使う文を覚えておき、タップで訳文を出し直して読み上げる。

定型文は phrases.json（config.toml と同じフォルダ）に保存する。1 つの定型文は、話した言語・その文と、
訳文（訳す先の言語ごと。登録したとき・初めてその言語で使ったときの訳文）を持つ。
訳文を覚えておくので、2 回目からは翻訳サーバーを使わずにすぐ出せて、毎回同じ訳になる。
使った回数も数えて、よく使う文ほど一覧の上に出す（同じ回数なら、先に登録した文が上）。
定型文は、使う業種（「業種」の画面で選ぶもの）を持てる。業種を選んでいるときは、その業種の文と、業種を決めていない文
（どこでも使える文）だけを一覧に出す。何も選んでいないときは、すべて出す。
"""

from __future__ import annotations

import dataclasses
import difflib
import json
import logging
import os
import threading
import unicodedata
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from .industries import normalize as normalize_industries
from .langs import JA, PARTNER_LANGS

log = logging.getLogger(__name__)

FILE_NAME = "phrases.json"
# 登録できる数（一覧は「前へ」「次へ」で送り、音声検索と業種で絞れる範囲にとどめる。全言語チェックの店員の文 143 文と、
# 業種ごとの定型文（29 業種で約 340 文）が入る数）
MAX_PHRASES = 1000
_LANGS = frozenset({JA, *PARTNER_LANGS})
# 音声検索で「冒頭が似ている」とみなす度合い（0〜1。音声認識の 1〜2 文字の違いは拾い、別の文は拾わない）
SIMILAR_ENOUGH = 0.6
# phrases.json に保存する登録日時の書き方
_DATE_FORMAT = "%Y-%m-%d %H:%M"

# add() の結果
ADDED, EXISTS, FULL = "added", "exists", "full"
# rename() の結果
RENAMED, DUPLICATE, EMPTY_TEXT, MISSING = "renamed", "duplicate", "empty", "missing"


@dataclass(frozen=True)
class Phrase:
    lang: str  # 話した言語
    text: str  # 話した文
    # 訳す先の言語 → 訳文
    translations: dict[str, str] = field(default_factory=dict)
    # 登録した日時（"2026-10-01 09:30"。日付を保存する前に登録した文は空）
    added: str = ""
    # 使った回数（一覧でタップして、訳文を出した回数）。多い順に一覧に並べる
    uses: int = 0
    # 使う業種の番号（industries.py の id。空ならどこでも使える文）
    industries: tuple[str, ...] = ()

    @property
    def added_date(self) -> str:
        """画面に出す登録日（"2026/10/01"。分からなければ空）。"""
        return self.added[:10].replace("-", "/")

    def shown_for(self, selected: Sequence[str]) -> bool:
        """選んでいる業種（selected）で、一覧に出す文か。何も選んでいない・業種を決めていない文は、いつも出す。"""
        return not selected or not self.industries or any(i in selected for i in self.industries)


def industries_for_new(selected: Sequence[str]) -> tuple[str, ...]:
    """新しく登録する文に付ける業種。ちょうど 1 つ選んでいるときだけ、その業種（2 つ以上・なしは、どこでも使える文）。"""
    return tuple(selected) if len(selected) == 1 else ()


def _normalize(text: str) -> str:
    """比べやすい形にする: 全角・半角をそろえ、小文字にし、句読点・空白を除き、カタカナはひらがなにする。"""
    text = unicodedata.normalize("NFKC", text).lower()
    letters = (ch for ch in text if ch.isalnum() or unicodedata.category(ch).startswith("M"))
    return "".join(chr(ord(ch) - 0x60) if "ァ" <= ch <= "ヶ" else ch for ch in letters)


def search_phrases(phrases: Sequence[Phrase], query: str) -> list[int]:
    """話した言葉（query）で定型文を探し、見つかった定型文の番号を、近い順に返す（音声検索）。

    1. 文の冒頭が一致するもの（いちばん上に出す）
    2. 文の途中に含まれるもの
    3. 冒頭が似ているもの（音声認識の 1〜2 文字の違いは許す）
    漢字とかなの書き方が違うと一致しない（「お会計」と「おかいけい」）。定型文は音声認識の結果を登録するので、
    同じ言葉を話せば、ふつうは同じ書き方になる。
    """
    wanted = _normalize(query)
    if not wanted:
        return []
    scored = []
    for index, phrase in enumerate(phrases):
        text = _normalize(phrase.text)
        if not text:
            continue
        if text.startswith(wanted) or wanted.startswith(text):
            score = 3.0
        elif wanted in text:
            score = 2.0
        else:
            score = difflib.SequenceMatcher(None, wanted, text[: len(wanted)]).ratio()
            if score < SIMILAR_ENOUGH:
                continue
        scored.append((-score, index))
    return [index for _, index in sorted(scored)]


def phrases_path(config_path: Path) -> Path:
    """config.toml と同じフォルダの phrases.json。"""
    return Path(config_path).resolve().parent / FILE_NAME


class PhraseBook:
    """画面の操作と、翻訳のスレッド（訳文を覚える）から同時に使っても壊れないようにしてある。"""

    def __init__(self, path: Path, now: Callable[[], datetime] = datetime.now) -> None:
        """now は今の日時を返す（登録日に使う。テストで差し替える）。"""
        self._path = Path(path)
        self._now = now
        self._lock = threading.Lock()
        self._phrases = self._load()

    @property
    def phrases(self) -> tuple[Phrase, ...]:
        with self._lock:
            return tuple(self._phrases)

    def add(self, lang: str, text: str, target: str, translation: str, industries: Sequence[str] = ()) -> str:
        """定型文を登録する。同じ文がもうあれば、その訳文だけを覚え直す（EXISTS。登録日・業種は変えない）。いっぱいなら FULL。"""
        text = text.strip()
        with self._lock:
            for i, phrase in enumerate(self._phrases):
                if (phrase.lang, phrase.text) == (lang, text):
                    self._phrases[i] = dataclasses.replace(phrase, translations={**phrase.translations, target: translation})
                    self._save()
                    return EXISTS
            if len(self._phrases) >= MAX_PHRASES:
                return FULL
            self._phrases.append(
                Phrase(lang, text, {target: translation}, self._now().strftime(_DATE_FORMAT), 0, normalize_industries(industries))
            )
            self._save()
            return ADDED

    def rename(self, lang: str, text: str, new_text: str) -> str:
        """定型文の文（話した言葉）を直す。文を直すと、覚えていた訳文は消える（次に使うときに訳し直して覚える）。

        登録日・使った回数・業種は、そのまま。同じ言語に同じ文がもうあれば DUPLICATE、空なら EMPTY_TEXT、直す文がなければ MISSING。
        """
        new_text = new_text.strip()
        if not new_text:
            return EMPTY_TEXT
        with self._lock:
            for i, phrase in enumerate(self._phrases):
                if (phrase.lang, phrase.text) != (lang, text):
                    continue
                if new_text == text:
                    return RENAMED
                if any((p.lang, p.text) == (lang, new_text) for p in self._phrases):
                    return DUPLICATE
                self._phrases[i] = dataclasses.replace(phrase, text=new_text, translations={})
                self._save()
                return RENAMED
        return MISSING

    def remove(self, index: int) -> None:
        with self._lock:
            if 0 <= index < len(self._phrases):
                del self._phrases[index]
                self._save()

    def count_use(self, lang: str, text: str) -> None:
        """定型文を 1 回使ったと数え、使った回数の多い順に並べ直す。

        回数が同じものは、それまでの順（登録した順）のまま。よく使う文ほど一覧の上に来る。
        """
        with self._lock:
            for i, phrase in enumerate(self._phrases):
                if (phrase.lang, phrase.text) == (lang, text):
                    self._phrases[i] = dataclasses.replace(phrase, uses=phrase.uses + 1)
                    self._phrases.sort(key=lambda p: -p.uses)  # 安定ソートなので、同じ回数の順は変わらない
                    self._save()
                    return

    def remember(self, lang: str, text: str, target: str, translation: str) -> None:
        """登録済みの定型文に、その言語の訳文を覚えさせる（初めてその言語で使ったとき）。"""
        with self._lock:
            for i, phrase in enumerate(self._phrases):
                if (phrase.lang, phrase.text) == (lang, text):
                    if phrase.translations.get(target) != translation:
                        self._phrases[i] = dataclasses.replace(
                            phrase, translations={**phrase.translations, target: translation}
                        )
                        self._save()
                    return

    def _load(self) -> list[Phrase]:
        try:
            items = json.loads(self._path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return []
        except (OSError, ValueError):
            log.warning("定型文のファイルを読めないため、使いません: %s", self._path)
            return []
        phrases = []
        for item in items if isinstance(items, list) else []:
            if not isinstance(item, dict):
                continue
            lang, text, translations = item.get("lang"), item.get("text"), item.get("translations", {})
            added = item.get("added", "")
            if lang in _LANGS and isinstance(text, str) and text.strip() and isinstance(translations, dict):
                kept = {k: v for k, v in translations.items() if k in _LANGS and isinstance(v, str) and v}
                uses = item.get("uses", 0)
                uses = uses if isinstance(uses, int) and not isinstance(uses, bool) and uses > 0 else 0
                industries = item.get("industries", [])
                industries = normalize_industries(industries) if isinstance(industries, list) else ()
                phrases.append(Phrase(lang, text.strip(), kept, added if isinstance(added, str) else "", uses, industries))
        phrases = phrases[:MAX_PHRASES]
        phrases.sort(key=lambda p: -p.uses)  # 手で書き換えたファイルでも、使った回数の多い順にする
        return phrases

    def _save(self) -> None:
        """_lock を持って呼ぶ。書き込み途中で電源が切れても壊れないよう、別名で書いてから置き換える。"""
        items = [
            {"lang": p.lang, "text": p.text, "translations": p.translations, "added": p.added, "uses": p.uses}
            | ({"industries": list(p.industries)} if p.industries else {})
            for p in self._phrases
        ]
        temporary = self._path.with_name(self._path.name + ".tmp")
        try:
            temporary.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8")
            os.replace(temporary, self._path)
        except OSError:
            log.exception("定型文を保存できません: %s", self._path)
