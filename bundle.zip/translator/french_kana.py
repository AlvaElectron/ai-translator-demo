"""フランス語を、日本語話者が読めるカタカナにする（外部ライブラリに依存しない）。

つづりから発音を決める規則（語末の読まない子音・e、鼻母音 an/on/in、ou・oi・eau・ch・gn などのつづり）で
変換する。よく使う不規則な語（est・vous・merci など）は辞書で直接引く。
自動変換なので、実際の発音とは少し違う（リエゾンやアンシェヌマンは扱わない）。

例: Bonjour → ボンジュール、Excusez-moi → エクスキュゼモワ、Où est la gare ? → ウ エ ラ ガール ?
"""

from __future__ import annotations

import re

# よく使う語で、規則どおりに読まないもの（または規則より確実なもの）
_WORDS = {
    "a": "ア", "à": "ア", "au": "オ", "aux": "オ", "ce": "ス", "ces": "セ", "de": "ドゥ", "des": "デ",
    "deux": "ドゥ", "dix": "ディス", "elle": "エル", "elles": "エル", "en": "アン", "est": "エ", "et": "エ",
    "eu": "ユ", "eux": "ウ", "femme": "ファム", "fils": "フィス", "huit": "ユイット", "il": "イル", "ils": "イル",
    "je": "ジュ", "la": "ラ", "le": "ル", "les": "レ", "me": "ム", "merci": "メルシー", "mes": "メ",
    "mille": "ミル", "monsieur": "ムッシュー", "ne": "ヌ", "nous": "ヌ", "oui": "ウィ", "où": "ウ", "ou": "ウ",
    "plus": "プリュ", "que": "ク", "se": "ス", "ses": "セ", "six": "シス", "sont": "ソン", "te": "トゥ",
    "tes": "テ", "trois": "トロワ", "un": "アン", "une": "ユヌ", "ville": "ヴィル", "vous": "ヴ", "y": "イ",
    "cent": "サン", "vingt": "ヴァン", "sept": "セット", "neuf": "ヌフ", "œuf": "ウフ", "ok": "オーケー",
    "wifi": "ウィフィ", "taxi": "タクシー", "hôtel": "オテル", "hotel": "オテル",
    "cinq": "サンク", "pays": "ペイ", "beaucoup": "ボークー", "donc": "ドンク",
}

# 読まない語末の e の代わりに置く印。音は出さないが、前の子音を読ませる・鼻音にしないための手がかりになる
# （carte → カルト、aide → エド、rame → ラム。e を消してしまうと カール・エ・ラン になる）
_SILENT_E = "§"
_VOWEL_LETTERS = "aeiouyàâäéèêëîïôöùûüœæ" + _SILENT_E
# 語末で読まない子音（c・r・f・l は読む）
_SILENT_FINALS = frozenset("dtsxzpg")
# c・g を「ス」「ジュ」と読ませる、次の文字（読まない語末の e も含む: France・mange）
_SOFTENERS = "eéèêëiîïy" + _SILENT_E

# 発音の単位: 母音は a e i o u(ou) y(u) eu an in on、半母音は j（ヤ行）w（ワ）
# ieu（délicieux の「ユー」）と oo（eau の「オー」）は、伸ばして書く
_VOWELS = frozenset({"a", "e", "i", "o", "u", "y", "eu", "an", "in", "on", "ieu", "oo"})
_NASALS = ("an", "in", "on")
_LONG_VOWELS = ("ieu", "oo")
# 子音ごとの a・e・i・o・u(ou)・y(u)・eu の段
_ROWS: dict[str, tuple[str, str, str, str, str, str, str]] = {
    "": ("ア", "エ", "イ", "オ", "ウ", "ユ", "ウ"),
    "p": ("パ", "ペ", "ピ", "ポ", "プ", "ピュ", "プ"),
    "b": ("バ", "ベ", "ビ", "ボ", "ブ", "ビュ", "ブ"),
    "t": ("タ", "テ", "ティ", "ト", "トゥ", "テュ", "トゥ"),
    "d": ("ダ", "デ", "ディ", "ド", "ドゥ", "デュ", "ドゥ"),
    "k": ("カ", "ケ", "キ", "コ", "ク", "キュ", "ク"),
    "g": ("ガ", "ゲ", "ギ", "ゴ", "グ", "ギュ", "グ"),
    "f": ("ファ", "フェ", "フィ", "フォ", "フ", "フュ", "フ"),
    "v": ("ヴァ", "ヴェ", "ヴィ", "ヴォ", "ヴ", "ヴュ", "ヴ"),
    "s": ("サ", "セ", "シ", "ソ", "ス", "シュ", "ス"),
    "z": ("ザ", "ゼ", "ジ", "ゾ", "ズ", "ジュ", "ズ"),
    "sh": ("シャ", "シェ", "シ", "ショ", "シュ", "シュ", "シュ"),
    "zh": ("ジャ", "ジェ", "ジ", "ジョ", "ジュ", "ジュ", "ジュ"),
    "m": ("マ", "メ", "ミ", "モ", "ム", "ミュ", "ム"),
    "n": ("ナ", "ネ", "ニ", "ノ", "ヌ", "ニュ", "ヌ"),
    "ny": ("ニャ", "ニェ", "ニ", "ニョ", "ニュ", "ニュ", "ニュ"),
    "l": ("ラ", "レ", "リ", "ロ", "ル", "リュ", "ル"),
    "r": ("ラ", "レ", "リ", "ロ", "ル", "リュ", "ル"),
    "j": ("ヤ", "エ", "イ", "ヨ", "ユ", "ユ", "ユ"),
    "w": ("ワ", "ウェ", "ウィ", "ウォ", "ウ", "ウュ", "ウ"),
}
_VOWEL_COLUMN = {"a": 0, "e": 1, "i": 2, "o": 3, "u": 4, "y": 5, "eu": 6, "an": 0, "in": 0, "on": 3, "ieu": 5, "oo": 3}
# 母音が続かない子音
_ALONE = {"p": "プ", "b": "ブ", "t": "ト", "d": "ド", "k": "ク", "g": "グ", "f": "フ", "v": "ヴ", "s": "ス",
          "z": "ズ", "sh": "シュ", "zh": "ジュ", "m": "ム", "n": "ヌ", "ny": "ニュ", "l": "ル", "r": "ル",
          "j": "イユ", "w": "ウ"}

_WORD = re.compile(r"[a-zàâäéèêëîïôöùûüœæç'’\-]+", re.I)


def to_katakana(text: str) -> str:
    """フランス語の文をカタカナにする（語は空白で区切り、句読点はそのまま残す）。"""
    out = []
    position = 0
    for match in _WORD.finditer(text):
        out.append(text[position : match.start()])
        out.append(word_to_kana(match.group()))
        position = match.end()
    out.append(text[position:])
    return re.sub(r"\s+", " ", "".join(out)).strip()


def word_to_kana(word: str) -> str:
    """1語をカタカナにする。ハイフンでつながった語（Excusez-moi）は、つなげて1語として書く。"""
    parts = [part for part in re.split(r"-", word.lower()) if part]
    return "".join(_part_to_kana(part) for part in parts) or word


def _part_to_kana(word: str) -> str:
    word = word.replace("’", "'")
    if word in _WORDS:
        return _WORDS[word]
    # 省略（l'aéroport・s'il・qu'il）は、次の語につなげて読む
    word = word.replace("'", "")
    if word in _WORDS:
        return _WORDS[word]
    return _compose(_phonemes(_drop_silent_ending(word)))


def _drop_silent_ending(word: str) -> str:
    """語末の読まない文字を落とす。

    複数形の s・x を落としてから、-er・-ez・-et は「エ」、語末の e は印（読まない）に置き換え、
    それ以外で終わる語は、語末の d t s x z p g を読まない。
    """
    if len(word) > 3 and word[-1] in "sx" and word[-2] not in "sx":
        word = word[:-1]  # billets → billet、aides → aide
    if len(word) > 2 and word.endswith(("er", "ez", "et")):
        return word[:-2] + "é"
    if len(word) > 1 and word.endswith("e"):
        return word[:-1] + _SILENT_E  # e の前の子音は読む
    while len(word) > 1 and word[-1] in _SILENT_FINALS:
        word = word[:-1]
    return word


def _is_vowel(ch: str) -> bool:
    return ch in _VOWEL_LETTERS


def _nasal(word: str, i: int, length: int) -> bool:
    """word[i:i+length] の後の n・m が鼻音になるか（その後に母音も n・m も続かない）。"""
    j = i + length
    return j < len(word) and word[j] in "nm" and (j + 1 == len(word) or (not _is_vowel(word[j + 1]) and word[j + 1] not in "nm"))


def _phonemes(word: str) -> list[str]:
    """つづりを、発音の単位（子音・母音）の並びにする。"""
    out: list[str] = []
    i = 0
    n = len(word)
    while i < n:
        rest = word[i:]
        prev_vowel = i > 0 and _is_vowel(word[i - 1])
        next_char = word[i + 1] if i + 1 < n else ""

        def take(units: list[str], length: int) -> None:
            nonlocal i
            out.extend(units)
            i += length

        if rest.startswith(("eaux", "eau")):
            take(["oo"], 4 if rest.startswith("eaux") else 3)
        elif rest.startswith("tion"):
            take(["s", "i", "on"], 4)
        elif rest.startswith(("oin", "oim")) and _nasal(word, i, 2):
            take(["w", "in"], 3)
        elif rest.startswith("ieu"):
            take(["ieu"], 3)  # délicieux → デリシュー、mieux → ミュー
        elif rest.startswith("oy") and i + 2 < n and _is_vowel(word[i + 2]):
            take(["w", "a", "j"], 2)  # voyage → ヴォワイヤジュ、envoyer → アンヴォワイエ
        elif rest.startswith(("oi", "oî", "oy")):
            take(["w", "a"], 2)
        elif rest.startswith("ouill"):
            take(["u", "j"], 5)  # grenouille → グルヌイユ
        elif rest.startswith(("ou", "où", "oû")):
            take(["u"], 2)
        elif rest.startswith(("au", "aû")):
            take(["o"], 2)
        elif rest.startswith(("ain", "aim", "ein", "eim")) and _nasal(word, i, 2):
            take(["in"], 3)
        elif rest.startswith(("aill", "eill")) or (rest in ("ail", "eil")):
            # travailler → トラヴァイエ、travail → トラヴァイユ、soleil → ソレイユ
            take(["a" if rest[0] == "a" else "e", "j"], 4 if rest[3:4] == "l" else 3)
        elif rest.startswith("ay") and i + 2 < n and _is_vowel(word[i + 2]):
            take(["e", "j"], 2)  # payer → ペイエ
        elif rest.startswith(("ai", "aî", "ei")):
            take(["e"], 2)
        elif rest.startswith(("eu", "œu")):
            take(["eu"], 2)
        elif rest.startswith(("an", "am", "en", "em")) and _nasal(word, i, 1):
            take(["an"], 2)
        elif rest.startswith(("in", "im", "yn", "ym", "un", "um")) and _nasal(word, i, 1):
            take(["in"], 2)
        elif rest.startswith(("on", "om")) and _nasal(word, i, 1):
            take(["on"], 2)
        elif rest.startswith("ill") and i > 0:
            # 後ろに母音が来れば「イユ」の音（billet → ビエ、travailler → トラヴァイエ）
            take(["j"] if prev_vowel else ["i", "j"], 3)
        elif rest.startswith("ch"):
            take(["sh"], 2)
        elif rest.startswith("gn"):
            take(["ny"], 2)
        elif rest.startswith("qu"):
            take(["k"], 2)
        elif rest.startswith("ph"):
            take(["f"], 2)
        elif rest.startswith("th"):
            take(["t"], 2)
        elif rest.startswith("gu") and i + 2 < n and word[i + 2] in "eéèêiy":
            take(["g"], 2)
        elif rest.startswith("ge") and i + 2 < n and word[i + 2] in "aoâôu":
            take(["zh"], 2)
        elif rest[0] == "x":
            take(["g", "z"] if i == 1 and word[0] == "e" and next_char and _is_vowel(next_char) else ["k", "s"], 1)
        elif rest[0] == "ç":
            take(["s"], 1)
        elif rest[0] == "c":
            if next_char and next_char in _SOFTENERS:
                take(["s"], 1)
            elif not next_char and out and out[-1] in _NASALS:
                take([], 1)  # 鼻母音のあとの語末の c は読まない（blanc → ブラン）
            else:
                take(["k"], 1)  # 語末の c は読む（avec → アヴェック）
        elif rest[0] == "g":
            take(["zh"] if next_char and next_char in _SOFTENERS else ["g"], 1)
        elif rest[0] == "j":
            take(["zh"], 1)
        elif rest[0] == "q":
            take(["k"], 1)
        elif rest[0] == "s":
            if next_char == "s":
                take(["s"], 2)
            else:
                take(["z"] if prev_vowel and next_char and _is_vowel(next_char) else ["s"], 1)
        elif rest[0] in ("h", _SILENT_E):
            take([], 1)  # h と、読まない語末の e
        elif rest[0] == "y":
            take(["j"] if prev_vowel and next_char and _is_vowel(next_char) else ["i"], 1)
        elif rest[0] in "éèêë":
            take(["e"], 1)
        elif rest[0] == "e":
            # 子音が2つ続く前（merci・elle）と、語末の子音の前（mer・sec）は「エ」、それ以外は弱い「ウ」（le・petit）
            closed = i + 2 < n and not _is_vowel(word[i + 1]) and not _is_vowel(word[i + 2])
            before_final_consonant = i + 2 == n and not _is_vowel(next_char)
            take(["e"] if closed or before_final_consonant or i + 1 == n else ["eu"], 1)
        elif rest[0] in "aàâä":
            take(["a"], 1)
        elif rest[0] in "iîï":
            take(["i"], 1)
        elif rest[0] in "oôö":
            take(["o"], 1)
        elif rest[0] in "uûü":
            take(["y"], 1)
        elif rest[0] == "œ":
            take(["eu"], 1)
        elif rest[0] in "bdfklmnprtvwz":
            doubled = next_char == rest[0]
            take(["v" if rest[0] == "w" else rest[0]], 2 if doubled else 1)
        else:
            take([], 1)
    return out


def _compose(units: list[str]) -> str:
    """発音の単位の並びを、カタカナにする。"""
    out = []
    i = 0
    n = len(units)
    while i < n:
        unit = units[i]
        nxt = units[i + 1] if i + 1 < n else None
        after_vowel = i > 0 and units[i - 1] in _VOWELS
        if unit in _VOWELS:
            out.append(_vowel_kana("", unit))
            i += 1
            continue
        if nxt == "w" and unit not in ("w", "j"):
            # moi → モワ、trois → トロワ（子音の後の「ワ」は、子音をオ段で書く）
            out.append(_ROWS.get(unit, _ROWS[""])[3])
            i += 1
            continue
        if nxt in _VOWELS:
            # 「i」以外の母音のあとの「ユ」の音は、「イ」をはさんで書く（payer → ペイエ、travailler → トラヴァイエ）
            glide = "イ" if unit == "j" and after_vowel and units[i - 1] != "i" else ""
            out.append(glide + _vowel_kana(unit, nxt))
            i += 2
            continue
        # 母音のすぐ後の語末の r は、その母音を伸ばす（gare → ガール、bonjour → ボンジュール。votre はヴォトル）
        if unit == "r" and nxt is None and after_vowel and out[-1][-1:] not in ("ン", "ー"):
            out.append("ール")
        elif unit == "j" and nxt is None and i > 0 and units[i - 1] == "i":
            out.append("ーユ")  # famille → ファミーユ、fille → フィーユ
        elif unit in ("t", "k") and nxt is None and after_vowel and units[i - 1] not in _NASALS + _LONG_VOWELS:
            # 母音のすぐ後の語末の t・k は、つまる音で書く（toilettes → トワレット、avec → アヴェック）。
            # オ・ウの音のあとの t は、伸ばして書く方がふつう（route → ルート、note → ノート）
            long_t = unit == "t" and units[i - 1] in ("o", "u")
            out.append(("ー" if long_t else "ッ") + _ALONE[unit])
        else:
            out.append(_ALONE.get(unit, ""))
        i += 1
    return "".join(out)


def _vowel_kana(consonant: str, vowel: str) -> str:
    row = _ROWS.get(consonant, _ROWS[""])
    kana = row[_VOWEL_COLUMN[vowel]]
    if vowel in _LONG_VOWELS:
        return kana + "ー"
    return kana + "ン" if vowel in _NASALS else kana
