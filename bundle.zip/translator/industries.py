"""業種ごとの用語集（メニューの「業種」ボタンで選ぶ）。

お店の種類（居酒屋・ホテル・タクシー・カラオケ・メイドカフェ …）を選ぶと、その業種の言葉の見本を、
訳す文に入っている語だけ Hy-MT2 の指示文に足す（glossary.py の find_terms）。業種は 7 つの区分に分けてあり、
区分を開いて、当てはまる業種をいくつでも選べる（居酒屋とカフェを両方やっている店など）。

- 何も選んでいない間は、従来どおり glossary.py の用語集の全部（お店の共通の語と、メイドカフェ・コンカフェ・キャバクラの語）を使う。
- 1 つでも選ぶと、お店の共通の語（税込み・レシート・カードなど）と、選んだ業種の語だけを使う。
  選んでいない業種の語は、訳に混ざらない（「ご主人様」をホテルで使わないなど）。
- メイドカフェ・コンカフェ・キャバクラの語は glossary.py の JA_TERMS にある（約 190 語）。どれを選んだときにどの語を使うかは、ここで決める。
- 語の中身は industry_terms_*.py（1 行 = 1 語、8 言語）。
"""

from __future__ import annotations

import re
import threading
from collections.abc import Iterable
from dataclasses import dataclass

from . import glossary
from . import industry_terms_beauty as beauty
from . import industry_terms_food as food
from . import industry_terms_lodging as lodging
from . import industry_terms_nightlife as nightlife
from . import industry_terms_retail as retail
from . import industry_terms_sightseeing as sightseeing
from . import industry_terms_transport as transport
from .langs import EN, FR, KO, PT, RU, TH, YUE, ZH

# industry_terms_*.py の 1 行の言語の並び（日本語の次から）
ROW_LANGS = (KO, EN, ZH, YUE, TH, FR, RU, PT)


@dataclass(frozen=True)
class Industry:
    id: str
    ja: str
    en: str


@dataclass(frozen=True)
class Category:
    id: str
    ja: str
    en: str
    items: tuple[Industry, ...]


CATEGORIES: tuple[Category, ...] = (
    Category("food", "飲食店", "Restaurants", (
        Industry("izakaya", "居酒屋", "Izakaya"),
        Industry("ramen", "ラーメン店", "Ramen shop"),
        Industry("restaurant", "レストラン", "Restaurant"),
        Industry("cafe", "カフェ", "Cafe"),
    )),
    Category("lodging", "宿泊施設", "Accommodation", (
        Industry("hotel", "ホテル", "Hotel"),
        Industry("ryokan", "旅館", "Ryokan"),
        Industry("minpaku", "民宿", "Minshuku"),
        Industry("guesthouse", "ゲストハウス", "Guesthouse"),
    )),
    Category("retail", "小売店", "Retail stores", (
        Industry("drugstore", "ドラッグストア", "Drugstore"),
        Industry("electronics", "家電量販店", "Electronics store"),
        Industry("souvenir", "土産物店", "Souvenir shop"),
        Industry("dutyfree", "免税店", "Tax-free shop"),
        Industry("conbini", "コンビニ", "Convenience store"),
    )),
    Category("sightseeing", "観光施設", "Sightseeing", (
        Industry("tourist_info", "観光案内所", "Tourist information"),
        Industry("museum", "博物館", "Museum"),
        Industry("art_museum", "美術館", "Art museum"),
        Industry("themepark", "テーマパーク", "Theme park"),
        Industry("shrine_temple", "神社仏閣", "Shrines and temples"),
    )),
    Category("transport", "交通機関", "Transportation", (
        Industry("taxi", "タクシー", "Taxi"),
        Industry("bus", "バス", "Bus"),
        Industry("station", "鉄道駅", "Train station"),
        Industry("airport", "空港", "Airport"),
        Industry("rentacar", "レンタカー", "Car rental"),
    )),
    Category("nightlife", "娯楽・夜の店", "Entertainment and nightlife", (
        Industry("karaoke", "カラオケ", "Karaoke"),
        Industry("bar", "バー", "Bar"),
        Industry("maid_cafe", "メイドカフェ", "Maid cafe"),
        Industry("concafe", "コンカフェ", "Concept cafe"),
        Industry("cabaret", "キャバクラ", "Cabaret club"),
    )),
    Category("beauty", "美容・リラクゼーション", "Beauty and relaxation", (
        Industry("salon", "美容室", "Hair salon"),
        Industry("esthe", "エステ", "Esthetic salon"),
        Industry("massage", "マッサージ", "Massage"),
        Industry("nail", "ネイルサロン", "Nail salon"),
    )),
)

CATEGORY_BY_ID = {category.id: category for category in CATEGORIES}
INDUSTRY_BY_ID = {item.id: item for category in CATEGORIES for item in category.items}
CATEGORY_OF = {item.id: category.id for category in CATEGORIES for item in category.items}

# 区分に共通の語（その区分の業種をどれか 1 つでも選ぶと使う）と、業種ごとの語
_COMMON_ROWS = {
    "food": food.FOOD_COMMON,
    "lodging": lodging.LODGING_COMMON,
    "retail": retail.RETAIL_COMMON,
    "sightseeing": sightseeing.SIGHTSEEING_COMMON,
    "transport": transport.TRANSPORT_COMMON,
    "beauty": beauty.BEAUTY_COMMON,
}
_ROWS = {
    "izakaya": food.IZAKAYA,
    "ramen": food.RAMEN,
    "restaurant": food.RESTAURANT,
    "cafe": food.CAFE,
    "hotel": lodging.HOTEL,
    "ryokan": lodging.RYOKAN,
    "minpaku": lodging.MINPAKU,
    "guesthouse": lodging.GUESTHOUSE,
    "drugstore": retail.DRUGSTORE,
    "electronics": retail.ELECTRONICS,
    "souvenir": retail.SOUVENIR,
    "dutyfree": retail.DUTYFREE,
    "conbini": retail.CONBINI,
    "tourist_info": sightseeing.TOURIST_INFO,
    "museum": sightseeing.MUSEUM,
    "art_museum": sightseeing.ART_MUSEUM,
    "themepark": sightseeing.THEMEPARK,
    "shrine_temple": sightseeing.SHRINE_TEMPLE,
    "taxi": transport.TAXI,
    "bus": transport.BUS,
    "station": transport.STATION,
    "airport": transport.AIRPORT,
    "rentacar": transport.RENTACAR,
    "karaoke": nightlife.KARAOKE,
    "bar": nightlife.BAR,
    "salon": beauty.SALON,
    "esthe": beauty.ESTHE,
    "massage": beauty.MASSAGE,
    "nail": beauty.NAIL,
}

# --- glossary.py の JA_TERMS のうち、お店の共通の語と、夜の店の語の分け方 ---
# JA_TERMS は、お店の共通の語（最後は「またのお越しをお待ちしております」）のあとに、夜の店の語が続く。
_SHOP_LAST_KEY = "またのお越しをお待ちしております"
# 夜の店の語の中の、区切りの語（その語から、次の区切りの前まで）
_CABARET_FIRST, _CABARET_LAST = "お通し", "サービス料"
_MAID_FIRST, _MAID_LAST = "メイドカフェ", "席料"
_CONCAFE_FIRST, _CONCAFE_LAST = "執事カフェ", "ポイント"
# 最初の塊の中で、メイドカフェだけで使う語
_MAID_ONLY = frozenset(
    {
        "おかえりなさいませ、ご主人様", "おかえりなさいませご主人様", "お帰りなさいませ、ご主人様", "お帰りなさいませご主人様",
        "おかえりなさいませ、お嬢様", "おかえりなさいませお嬢様", "お帰りなさいませ、お嬢様", "お帰りなさいませお嬢様",
        "おかえりなさいませ", "お帰りなさいませ", "ご出国", "めいどりーみんハイパー", "メイドリーミンハイパー", "めいどりーみん",
        "メイドリーミン", "ドリームタイム", "ドリタイ", "魔法をかけますね", "ご主人様", "オムライス", "ケチャップ", "おまじない",
        "萌え萌えキュン", "ご一緒に「萌え萌えキュン」をお願いします", "お嬢様", "ご帰宅", "初めてのご帰宅", "初めてのご帰宅ですか",
        "本日はご帰宅ありがとうございました", "またのお帰りをお待ちしております", "いってらっしゃいませ", "お気をつけてお出かけください",
        "メイド",
        *glossary.MOE_VARIANT_KEYS,  # 「もえもえきゅん」など、かなで聞き取られた形
    }
)
# 夜の店の語のうち、キャバクラだけで使う語（指名・同伴・ボトルなど）。コンカフェ・バーでも使う語は _SHARED_NIGHT に入れる
_CABARET_ONLY = frozenset(
    {
        "女の子をおつけします", "女の子", "同伴のお客様", "同伴", "同伴のご予約", "アフター", "指名の変更", "指名の女の子", "ご指名はございますか",
        "女の子が、エレベーターまでお見送りします", "退店していただきます", "しつこいお誘い", "しつこいお誘いは、お断りしています",
        "お帰りいただく場合があります", "場内指名", "本指名", "指名料", "ご指名", "セット料金", "延長なさいますか", "延長はいかがなさいますか",
        "延長", "フルーツの盛り合わせ",
    }
)
# メイドカフェの語の塊にあるが、キャバクラ・バーなどでも使う語（席料・ポイントカード・グッズなど）
_MAID_BLOCK_SHARED = frozenset({"席料", "ポイントカード", "グッズ", "ブロマイド", "生誕祭"})
# キャバクラの語の塊にあるが、バー・カラオケなど夜の店のどれでも使う語（持ち込み・チャージなど）
_CABARET_BLOCK_SHARED = frozenset({"持ち込み", "チャージ", "サービス料", "お通し", "ラストまで"})

# _night_groups() の分け方の名前
SHOP, MAID, CABARET, SHARED = "shop", "maid", "cabaret", "shared"


def _night_groups() -> dict[str, list[str]]:
    """JA_TERMS を、お店の共通の語・メイドカフェとコンカフェの語・キャバクラの語・夜の店の共通の語に分ける。"""
    keys = list(glossary.JA_TERMS)
    first = keys.index(_SHOP_LAST_KEY) + 1
    night = keys[first:]

    def block(start: str, end: str) -> set[str]:
        return set(keys[keys.index(start) : keys.index(end) + 1])

    cabaret = (block(_CABARET_FIRST, _CABARET_LAST) | _CABARET_ONLY) - _CABARET_BLOCK_SHARED
    maid = (block(_MAID_FIRST, _MAID_LAST) | block(_CONCAFE_FIRST, _CONCAFE_LAST) | _MAID_ONLY) - _MAID_BLOCK_SHARED
    shared = [key for key in night if key not in cabaret and key not in maid]
    return {
        SHOP: keys[:first],
        MAID: [key for key in night if key in maid and key not in cabaret],
        CABARET: [key for key in night if key in cabaret],
        SHARED: shared,
    }


_NIGHT_GROUPS = _night_groups()
# 夜の店の語（共通の語を含む）を使う業種。メイドカフェ・コンカフェはどちらかを選ぶとその語を使う
_NIGHT_INDUSTRIES = frozenset({"karaoke", "bar", "maid_cafe", "concafe", "cabaret"})
_MAID_INDUSTRIES = frozenset({"maid_cafe", "concafe"})

_ROMAJI_WORDS = frozenset(
    {
        "yukata", "omamori", "ema", "goshuin", "kaedama", "tsukemen", "shinkansen", "omikuji", "onigiri", "yakitori", "karaage",
        "edamame", "chuhai", "otoshi", "ryokan", "minshuku", "matcha", "senbei", "yokan", "noshi", "furoshiki", "tonkotsu",
        "kaiseki", "onsen", "shoyu", "miso", "shio", "chashu", "nori", "futon", "tatami", "torii", "kimono", "bento", "seitai",
        "shiatsu", "kyabakura", "sake", "saké", "umeshu", "ukiyo-e", "dashi", "maneki-neko", "gyoza", "ramen", "izakaya",
    }
)
_PARENTHESIS = re.compile(r"\s*[（(].*$")


def normalize(ids: Iterable[str]) -> tuple[str, ...]:
    """選んだ業種の番号を、知っているものだけ・重複なしで、一覧の順に並べる。"""
    wanted = {i for i in ids if i in INDUSTRY_BY_ID}
    return tuple(item.id for category in CATEGORIES for item in category.items if item.id in wanted)


def parse(text: str) -> tuple[str, ...]:
    """user_settings.json に保存した「居酒屋,カフェ」の形（番号をカンマで並べた文字列）を読む。"""
    return normalize(part.strip() for part in text.split(","))


def serialize(ids: Iterable[str]) -> str:
    return ",".join(normalize(ids))


def _rows_of(industry_id: str) -> tuple[tuple, ...]:
    return _ROWS.get(industry_id, ())


def _row_terms(row: tuple) -> dict[str, str]:
    return {lang: text for lang, text in zip(ROW_LANGS, row[1:9]) if text}


def build(selected: Iterable[str]) -> tuple[dict[str, dict[str, str]], dict[str, dict[str, str]]]:
    """選んだ業種の用語集を作る。(日本語 → 各言語, 各言語の語 → 日本語)。"""
    ids = normalize(selected)
    ja_terms: dict[str, dict[str, str]] = {}
    groups = [SHOP]
    if _NIGHT_INDUSTRIES & set(ids):
        groups.append(SHARED)
    if _MAID_INDUSTRIES & set(ids):
        groups.append(MAID)
    if "cabaret" in ids:
        groups.append(CABARET)
    for group in groups:
        for key in _NIGHT_GROUPS[group]:
            ja_terms[key] = dict(glossary.JA_TERMS[key])

    rows: list[tuple] = []
    seen_categories: set[str] = set()
    for industry_id in ids:
        category = CATEGORY_OF[industry_id]
        if category not in seen_categories:
            seen_categories.add(category)
            rows.extend(_COMMON_ROWS.get(category, ()))
        rows.extend(_rows_of(industry_id))
    for row in rows:
        ja_terms.setdefault(row[0], {}).update(_row_terms(row))

    to_ja = {lang: dict(terms) for lang, terms in glossary.TO_JA_TERMS.items()}
    for row in rows:
        if len(row) > 9 and row[9]:
            _add_customer_terms(to_ja, row)
    return ja_terms, to_ja


def _add_customer_terms(to_ja: dict[str, dict[str, str]], row: tuple) -> None:
    """お客様がその言葉で言ったときに、日本語の見本を付けるための表（TO_JA_TERMS）に足す。"""
    for lang, text in _row_terms(row).items():
        key = _PARENTHESIS.sub("", text).strip().lower()
        if not _usable_customer_key(lang, key):
            continue
        # 手で書いた語（glossary.py の TO_JA_TERMS）があれば、そちらを優先する
        to_ja.setdefault(lang, {}).setdefault(key, row[0])


def _usable_customer_key(lang: str, key: str) -> bool:
    if not key:
        return False
    latin = key.isascii() or lang in (FR, PT)
    if len(key) < (3 if latin else 2):
        return False
    if lang == EN:
        # 英語は ENJP-MT（速い）で日本語に訳すが、見本があると Hy-MT2（遅い）で訳す。ふつうの英単語 1 つでは切り替えない
        words = key.split()
        return len(words) >= 2 or key in _ROMAJI_WORDS
    return True


class IndustrySelection:
    """選んでいる業種。画面の操作と、翻訳（用語集）の両方から見る。変わったら glossary の用語を差し替える。"""

    def __init__(self, ids: Iterable[str] = ()) -> None:
        self._lock = threading.Lock()
        self._ids: tuple[str, ...] = normalize(ids)
        self.apply()

    @property
    def ids(self) -> tuple[str, ...]:
        return self._ids

    def is_selected(self, industry_id: str) -> bool:
        return industry_id in self._ids

    def count(self, category_id: str) -> int:
        """区分の中で選んでいる業種の数。"""
        return sum(1 for item in CATEGORY_BY_ID[category_id].items if item.id in self._ids)

    def toggle(self, industry_id: str) -> None:
        with self._lock:
            current = set(self._ids)
            current.symmetric_difference_update({industry_id})
            self._ids = normalize(current)
        self.apply()

    def set_category(self, category_id: str, selected: bool) -> None:
        """区分の中の業種を、全部選ぶ・全部外す。"""
        members = {item.id for item in CATEGORY_BY_ID[category_id].items}
        with self._lock:
            current = set(self._ids)
            current = (current | members) if selected else (current - members)
            self._ids = normalize(current)
        self.apply()

    def clear(self) -> None:
        with self._lock:
            self._ids = ()
        self.apply()

    def apply(self) -> None:
        """今の選び方を翻訳の用語集に反映する（何も選んでいなければ、従来どおりの全部）。"""
        ids = self._ids
        if not ids:
            glossary.set_active_terms(None, None)
            return
        ja_terms, to_ja = build(ids)
        glossary.set_active_terms(ja_terms, to_ja)
