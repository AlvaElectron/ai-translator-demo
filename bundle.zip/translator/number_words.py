"""数字を、韓国語・中国語の読み方（ことば）にする。発音の表示（カタカナ）を作る前に使う。

発音の表示は、数字をそのまま出すと、読み方が分からない（「1,500엔이에요」→「1,500エニエヨ」）。
金額・個数など、読み方が決まっているものだけ、ことばにする（電話番号・部屋番号・小数・時刻は、そのまま）。

- 韓国語: 漢数字の読み（1,500 → 천오백）。「엔」「원」「달러」の前の数字と、桁区切りのカンマがある数字だけ。
  個数・時刻に使う固有語の数字（한 개・세 시）は、決まりが多いので、ここでは直さない。
- 中国語: 数の読み（1,500 → 一千五百。2 は百・千・万の前で「两」）。金額・個数などの量詞の前の数字と、カンマのある数字。
"""

from __future__ import annotations

import re

_MAX_DIGITS = 12  # これより大きい数は、そのまま

# --- 韓国語（漢数字） ---

_KO_DIGITS = "영일이삼사오육칠팔구"
_KO_SMALL_UNITS = ("", "십", "백", "천")
_KO_BIG_UNITS = ("", "만", "억", "조")


def _ko_group(n: int) -> str:
    """0〜9999 を、韓国語の漢数字にする（일십・일백・일천 は、십・백・천）。"""
    out = ""
    for i, unit in enumerate(reversed(_KO_SMALL_UNITS)):
        place = 3 - i
        digit = (n // 10**place) % 10
        if not digit:
            continue
        out += ("" if digit == 1 and unit else _KO_DIGITS[digit]) + unit
    return out


def korean_number(n: int) -> str:
    """整数を、韓国語の漢数字の読み（ハングル）にする: 1500 → 천오백、10000 → 만、25000 → 이만오천。"""
    if n == 0:
        return "영"
    groups = []
    while n:
        groups.append(n % 10000)
        n //= 10000
    parts = []
    for index in range(len(groups) - 1, -1, -1):
        value = groups[index]
        if not value:
            continue
        text = _ko_group(value)
        if value == 1 and index > 0:
            text = ""  # 一万 → 만（一億 は 일억 と言うことが多いので、억・조 は 일 を残す）
            if index >= 2:
                text = "일"
        parts.append(text + _KO_BIG_UNITS[index])
    return "".join(parts)


# 数字の直前が英数字・記号（電話番号・小数・時刻）のものは除く。漢字・ハングルの直後は、数字として読む
_KO_AMOUNT = re.compile(r"(?<![A-Za-z0-9.,:/-])(\d{1,3}(?:,\d{3})+|\d+)(?=\s*(?:엔|원|달러|위안|유로))")
_KO_COMMA_NUMBER = re.compile(r"(?<![A-Za-z0-9.,:/-])(\d{1,3}(?:,\d{3})+)(?![\d,]|\.\d)")


def spell_korean_numbers(text: str) -> str:
    """韓国語の文の、金額（엔・원 など）の数字と、カンマのある数字を、漢数字の読み（ハングル）にする。"""

    def replace(match: re.Match[str]) -> str:
        digits = match.group(1).replace(",", "")
        if len(digits) > _MAX_DIGITS:
            return match.group(0)
        words = korean_number(int(digits))
        # 数字とハングルの間は、あけて読む（천오백 엔이에요 → チョノベク エニエヨ。あけないと、連音で「チョノベゲニエヨ」になる）
        return words + (" " if re.match(r"[가-힣]", match.string[match.end() : match.end() + 1]) else "")

    return _KO_COMMA_NUMBER.sub(replace, _KO_AMOUNT.sub(replace, text))


# --- 中国語 ---

_ZH_DIGITS = "零一二三四五六七八九"


def _zh_group(n: int) -> str:
    """1〜9999 を、中国語の数にする（零は、桁の間の空きに入れる。先頭の「一十」は、呼び出し側で直す）。"""
    out, zero = "", False
    for place, unit in ((3, "千"), (2, "百"), (1, "十"), (0, "")):
        digit = (n // 10**place) % 10
        if digit == 0:
            zero = bool(out)
            continue
        if zero:
            out += "零"
            zero = False
        out += _ZH_DIGITS[digit] + unit
    return out


def chinese_number(n: int) -> str:
    """整数を、中国語の数の読み（漢字）にする: 1500 → 一千五百、2000 → 两千、10000 → 一万、110 → 一百一十。"""
    if n == 0:
        return "零"
    groups = []
    while n:
        groups.append(n % 10000)
        n //= 10000
    big = ("", "万", "亿", "万亿")
    out = ""
    for index in range(len(groups) - 1, -1, -1):
        value = groups[index]
        if not value:
            continue
        text = _zh_group(value)
        if out and value < 1000:
            text = "零" + text  # 10005 → 一万零五
        out += text + big[index]
    if out.startswith("一十"):
        out = out[1:]  # 10〜19（と 10〜19 万など）は「十」から始める（110 は「一百一十」）
    # 2 は、百・千・万・亿の前で「两」（200 → 两百）。先頭の 2 だけ。十の位の 2（二十）は、そのまま
    out = re.sub(r"(?:^|(?<=[万亿零]))二(?=[千百万亿])", "两", out)
    return out


_ZH_MEASURE = (
    "日元|日币|日圆|円|人民币|美元|韩元|欧元|元|块|分钟|小时|个|位|人|岁|件|杯|瓶|张|次|天|点|折"
)
_ZH_AMOUNT = re.compile(rf"(?<![A-Za-z0-9.,:/-])(\d{{1,3}}(?:,\d{{3}})+|\d+)(?=\s*(?:{_ZH_MEASURE}))")
_ZH_COMMA_NUMBER = re.compile(r"(?<![A-Za-z0-9.,:/-])(\d{1,3}(?:,\d{3})+)(?![\d,]|\.\d)")


def spell_chinese_numbers(text: str) -> str:
    """中国語の文の、金額・量詞の前の数字と、カンマのある数字を、数の読み（漢字）にする。"""

    def replace(match: re.Match[str]) -> str:
        digits = match.group(1).replace(",", "")
        if len(digits) > _MAX_DIGITS or (len(digits) > 1 and digits.startswith("0")):
            return match.group(0)
        return chinese_number(int(digits))

    return _ZH_COMMA_NUMBER.sub(replace, _ZH_AMOUNT.sub(replace, text))
