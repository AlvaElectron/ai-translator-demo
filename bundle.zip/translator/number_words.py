"""数字を、各言語の読み方（ことば）にする。発音の表示（カタカナ）を作る前に使う。

発音の表示は、数字をそのまま出すと、読み方が分からない（「1,500엔이에요」→「1,500エニエヨ」）。
金額・個数など、読み方が決まっているものだけ、ことばにする（電話番号・部屋番号・小数・時刻（10:30）は、そのまま）。

- 韓国語: 漢数字の読み（1,500 → 천오백）。「엔」「원」「달러」「층」「년」の前の数字と、桁区切りのカンマがある数字だけ。
  個数・時刻に使う固有語の数字（한 개・세 시）は、決まりが多いので、ここでは直さない。
- 中国語・広東語: 数の読み（1,500 → 一千五百。2 は百・千・万の前で「两」）。金額・個数などの量詞の前の数字と、カンマのある数字。
- 英語・フランス語・ポルトガル語（ブラジル）・ロシア語・タイ語: 数の読み（1,500 → one thousand five hundred）。
  金額・人数・時間などの単位の前の数字と、桁区切りのある数字。フランス語・ポルトガル語・ロシア語の「1・2」は、
  後ろの単位の性（une personne・uma pessoa・одна иена）に合わせる。ロシア語は主格で読む（前置詞で格が変わる文は、少しずれることがある）。
"""

from __future__ import annotations

import re

_MAX_DIGITS = 12  # これより大きい数は、そのまま

# --- 韓国語（漢数字） ---

_KO_DIGITS = "영일이삼사오육칠팔구"
_KO_SMALL_UNITS = ("", "십", "백", "천")
_KO_BIG_UNITS = ("", "만", "억", "조")


def _ko_group(n: int) -> str:
    """0〜9999 を、韓国語の漢数字にする（일십・일백・일천 は、십・백・천）。"""
    out = ""
    for i, unit in enumerate(reversed(_KO_SMALL_UNITS)):
        place = 3 - i
        digit = (n // 10**place) % 10
        if not digit:
            continue
        out += ("" if digit == 1 and unit else _KO_DIGITS[digit]) + unit
    return out


def korean_number(n: int) -> str:
    """整数を、韓国語の漢数字の読み（ハングル）にする: 1500 → 천오백、10000 → 만、25000 → 이만오천。"""
    if n == 0:
        return "영"
    groups = []
    while n:
        groups.append(n % 10000)
        n //= 10000
    parts = []
    for index in range(len(groups) - 1, -1, -1):
        value = groups[index]
        if not value:
            continue
        text = _ko_group(value)
        if value == 1 and index > 0:
            text = ""  # 一万 → 만（一億 は 일억 と言うことが多いので、억・조 は 일 を残す）
            if index >= 2:
                text = "일"
        parts.append(text + _KO_BIG_UNITS[index])
    return "".join(parts)


# 数字の直前が英数字・記号（電話番号・小数・時刻）のものは除く。漢字・ハングルの直後は、数字として読む
_KO_AMOUNT = re.compile(r"(?<![A-Za-z0-9.,:/-])(\d{1,3}(?:,\d{3})+|\d+)(?=\s*(?:엔|원|달러|위안|유로|층|년|퍼센트))")
_KO_COMMA_NUMBER = re.compile(r"(?<![A-Za-z0-9.,:/-])(\d{1,3}(?:,\d{3})+)(?![\d,]|\.\d)")


def spell_korean_numbers(text: str) -> str:
    """韓国語の文の、金額（엔・원 など）の数字と、カンマのある数字を、漢数字の読み（ハングル）にする。"""

    def replace(match: re.Match[str]) -> str:
        digits = match.group(1).replace(",", "")
        if len(digits) > _MAX_DIGITS:
            return match.group(0)
        words = korean_number(int(digits))
        # 数字とハングルの間は、あけて読む（천오백 엔이에요 → チョノベク エニエヨ。あけないと、連音で「チョノベゲニエヨ」になる）
        return words + (" " if re.match(r"[가-힣]", match.string[match.end() : match.end() + 1]) else "")

    return _KO_COMMA_NUMBER.sub(replace, _KO_AMOUNT.sub(replace, text))


# --- 中国語 ---

_ZH_DIGITS = "零一二三四五六七八九"


def _zh_group(n: int) -> str:
    """1〜9999 を、中国語の数にする（零は、桁の間の空きに入れる。先頭の「一十」は、呼び出し側で直す）。"""
    out, zero = "", False
    for place, unit in ((3, "千"), (2, "百"), (1, "十"), (0, "")):
        digit = (n // 10**place) % 10
        if digit == 0:
            zero = bool(out)
            continue
        if zero:
            out += "零"
            zero = False
        out += _ZH_DIGITS[digit] + unit
    return out


def chinese_number(n: int) -> str:
    """整数を、中国語の数の読み（漢字）にする: 1500 → 一千五百、2000 → 两千、10000 → 一万、110 → 一百一十。"""
    if n == 0:
        return "零"
    groups = []
    while n:
        groups.append(n % 10000)
        n //= 10000
    big = ("", "万", "亿", "万亿")
    out = ""
    for index in range(len(groups) - 1, -1, -1):
        value = groups[index]
        if not value:
            continue
        text = _zh_group(value)
        if out and value < 1000:
            text = "零" + text  # 10005 → 一万零五
        out += text + big[index]
    if out.startswith("一十"):
        out = out[1:]  # 10〜19（と 10〜19 万など）は「十」から始める（110 は「一百一十」）
    # 2 は、百・千・万・亿の前で「两」（200 → 两百）。先頭の 2 だけ。十の位の 2（二十）は、そのまま
    out = re.sub(r"(?:^|(?<=[万亿零]))二(?=[千百万亿])", "两", out)
    return out


_ZH_MEASURE = (
    "日元|日币|日圆|円|人民币|美元|韩元|欧元|元|块|分钟|小时|个|位|人|岁|件|杯|瓶|张|次|天|点|折"
)
_ZH_AMOUNT = re.compile(rf"(?<![A-Za-z0-9.,:/-])(\d{{1,3}}(?:,\d{{3}})+|\d+)(?=\s*(?:{_ZH_MEASURE}))")
_ZH_COMMA_NUMBER = re.compile(r"(?<![A-Za-z0-9.,:/-])(\d{1,3}(?:,\d{3})+)(?![\d,]|\.\d)")


def spell_chinese_numbers(text: str) -> str:
    """中国語の文の、金額・量詞の前の数字と、カンマのある数字を、数の読み（漢字）にする。"""

    def replace(match: re.Match[str]) -> str:
        digits = match.group(1).replace(",", "")
        if len(digits) > _MAX_DIGITS or (len(digits) > 1 and digits.startswith("0")):
            return match.group(0)
        return chinese_number(int(digits))

    return _ZH_COMMA_NUMBER.sub(replace, _ZH_AMOUNT.sub(replace, text))


# --- 英語・フランス語・ポルトガル語・ロシア語・タイ語・広東語 ---

_NOT_PART_OF_NUMBER_BEFORE = r"(?<![A-Za-z0-9.,:/-])"
_NOT_PART_OF_NUMBER_AFTER = r"(?!\d|[.,]\d)"


def _make_speller(group_separator: str, units: str, to_words):
    """数字を ことばにする関数を作る。単位（units）の前の数字と、桁区切りのある数字だけを直す。

    to_words(n, unit) は、整数と後ろの単位（小文字。性を決めるのに使う）から、ことばを返す。
    """
    number = rf"\d{{1,3}}(?:{group_separator}\d{{3}})+"
    amount = re.compile(
        rf"{_NOT_PART_OF_NUMBER_BEFORE}({number}|\d+){_NOT_PART_OF_NUMBER_AFTER}(\s*(?:{units}))", re.IGNORECASE
    )
    grouped = re.compile(rf"{_NOT_PART_OF_NUMBER_BEFORE}({number}){_NOT_PART_OF_NUMBER_AFTER}")

    def replace(match: re.Match[str]) -> str:
        digits = re.sub(r"\D", "", match.group(1))
        if len(digits) > _MAX_DIGITS or (len(digits) > 1 and digits.startswith("0")):
            return match.group(0)
        unit = match.group(2) if match.re is amount else ""
        return to_words(int(digits), unit.strip().lower()) + unit

    return lambda text: grouped.sub(replace, amount.sub(replace, text))


def _three_digit_groups(n: int) -> list[int]:
    """n を 3 桁ずつに分ける（下の桁から）: 1500 → [500, 1]。"""
    groups = []
    while n:
        groups.append(n % 1000)
        n //= 1000
    return groups


# 英語

_EN_ONES = (
    "zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen "
    "eighteen nineteen"
).split()
_EN_TENS = ("", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety")
_EN_SCALES = ((10**12, "trillion"), (10**9, "billion"), (10**6, "million"), (1000, "thousand"), (100, "hundred"))


def english_number(n: int) -> str:
    """整数を、英語の読みにする: 1500 → one thousand five hundred、25 → twenty-five。"""
    if n < 20:
        return _EN_ONES[n]
    if n < 100:
        tens, ones = divmod(n, 10)
        return _EN_TENS[tens] + (f"-{_EN_ONES[ones]}" if ones else "")
    for value, name in _EN_SCALES:
        if n >= value:
            head, rest = divmod(n, value)
            return f"{english_number(head)} {name}" + (f" {english_number(rest)}" if rest else "")
    raise AssertionError(n)


_EN_UNITS = (
    r"(?:yen|dollars?|euros?|won|yuan|rmb|people|persons?|guests?|adults?|children|kids?|seats?|tickets?|items?|pieces?"
    r"|cups?|glasses|bottles?|plates?|bowls?|orders?|servings?|portions?|minutes?|hours?|days?|weeks?|months?|years?"
    r"|times|percent|floors?|rooms?|tables?|o'clock|[ap]\.?m)\b|%"
)
spell_english_numbers = _make_speller(",", _EN_UNITS, lambda n, unit: english_number(n))


# フランス語

_FR_ONES = ("zéro", "un", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", "dix", "onze", "douze", "treize",
            "quatorze", "quinze", "seize")
_FR_TENS = ("", "", "vingt", "trente", "quarante", "cinquante", "soixante")


def _fr_below_100(n: int, feminine: bool, final: bool) -> str:
    one = "une" if feminine else "un"
    if n < 17:
        return one if n == 1 else _FR_ONES[n]
    if n < 20:
        return f"dix {_FR_ONES[n - 10]}"
    tens, ones = divmod(n, 10)
    if tens in (7, 9):  # soixante-dix・quatre-vingt-dix（70 台・90 台は、10 台を後ろに足す）
        head = "soixante" if tens == 7 else "quatre vingt"
        if tens == 7 and ones == 1:
            return "soixante et onze"
        return f"{head} {_fr_below_100(10 + ones, feminine, final)}"
    if tens == 8:
        return ("quatre vingts" if final else "quatre vingt") if not ones else f"quatre vingt {one if ones == 1 else _FR_ONES[ones]}"
    if not ones:
        return _FR_TENS[tens]
    return f"{_FR_TENS[tens]} et {one}" if ones == 1 else f"{_FR_TENS[tens]} {_FR_ONES[ones]}"


def _fr_below_1000(n: int, feminine: bool, final: bool) -> str:
    hundreds, rest = divmod(n, 100)
    parts = []
    if hundreds:
        parts.append(("" if hundreds == 1 else f"{_FR_ONES[hundreds]} ") + "cent" + ("s" if hundreds > 1 and not rest and final else ""))
    if rest:
        parts.append(_fr_below_100(rest, feminine, final))
    return " ".join(parts)


def french_number(n: int, feminine: bool = False) -> str:
    """整数を、フランス語の読みにする（つなぎのハイフンは、空白にする）: 1500 → mille cinq cents、80 → quatre vingts。"""
    if n == 0:
        return "zéro"
    groups = _three_digit_groups(n)
    parts = []
    for index in range(len(groups) - 1, -1, -1):
        value = groups[index]
        if not value:
            continue
        if index == 0:
            parts.append(_fr_below_1000(value, feminine, final=True))
        elif index == 1:
            parts.append("mille" if value == 1 else f"{_fr_below_1000(value, feminine, final=False)} mille")
        else:
            name = ("million", "milliard")[index - 2]
            parts.append(f"{_fr_below_1000(value, False, final=True)} {name}" + ("s" if value > 1 else ""))
    return " ".join(parts)


_FR_FEMININE = re.compile(
    r"personnes?|places?|pièces?|tasses?|bouteilles?|assiettes?|portions?|commandes?|minutes?|heures?|semaines?|années?"
    r"|chambres?|tables?|nuits?|boissons?|fois"
)
_FR_UNITS = (
    r"(?:yens?|euros?|dollars?|wons?|yuans?|personnes?|adultes?|enfants?|places?|tickets?|billets?|articles?|pièces?"
    r"|tasses?|verres?|bouteilles?|assiettes?|bols?|portions?|commandes?|minutes?|heures?|jours?|semaines?|mois|ans"
    r"|années?|fois|pour cent|étages?|chambres?|tables?|nuits?|couverts?|plats?|boissons?)\b|%"
)
spell_french_numbers = _make_speller(
    r"[   ]", _FR_UNITS, lambda n, unit: french_number(n, feminine=bool(_FR_FEMININE.match(unit)))
)


# ポルトガル語（ブラジル）

_PT_ONES = ("zero", "um", "dois", "três", "quatro", "cinco", "seis", "sete", "oito", "nove", "dez", "onze", "doze", "treze",
            "quatorze", "quinze", "dezesseis", "dezessete", "dezoito", "dezenove")
_PT_TENS = ("", "", "vinte", "trinta", "quarenta", "cinquenta", "sessenta", "setenta", "oitenta", "noventa")
_PT_HUNDREDS = ("", "cento", "duzentos", "trezentos", "quatrocentos", "quinhentos", "seiscentos", "setecentos", "oitocentos",
                "novecentos")
_PT_FEMININE_ONES = {"um": "uma", "dois": "duas"}


def _pt_below_1000(n: int, feminine: bool) -> str:
    if n == 100:
        return "cem"
    hundreds, rest = divmod(n, 100)
    parts = []
    if hundreds:
        word = _PT_HUNDREDS[hundreds]
        parts.append(word[:-2] + "as" if feminine and hundreds >= 2 else word)
    if rest:
        if rest < 20:
            word = _PT_ONES[rest]
        else:
            tens, ones = divmod(rest, 10)
            word = _PT_TENS[tens] + (f" e {_PT_ONES[ones]}" if ones else "")
        if feminine:
            word = re.sub(r"\b(um|dois)\b", lambda m: _PT_FEMININE_ONES[m.group(1)], word)
        parts.append(word)
    return " e ".join(parts)


def portuguese_number(n: int, feminine: bool = False) -> str:
    """整数を、ブラジルのポルトガル語の読みにする: 1500 → mil e quinhentos、2 → dois（feminine なら duas）。"""
    if n == 0:
        return "zero"
    groups = _three_digit_groups(n)
    parts: list[tuple[int, str]] = []
    for index in range(len(groups) - 1, -1, -1):
        value = groups[index]
        if not value:
            continue
        if index == 0:
            text = _pt_below_1000(value, feminine)
        elif index == 1:
            text = "mil" if value == 1 else f"{_pt_below_1000(value, feminine)} mil"
        else:
            name = (("milhão", "milhões"), ("bilhão", "bilhões"))[index - 2][value > 1]
            text = f"{_pt_below_1000(value, False)} {name}"
        parts.append((value, text))
    out = parts[0][1]
    for value, text in parts[1:]:
        out += (" e " if value < 100 or value % 100 == 0 else " ") + text
    return out


_PT_FEMININE = re.compile(
    r"pessoas?|crianças?|peças?|xícaras?|garrafas?|tigelas?|porç|horas?|semanas?|vezes|vez\b|noites?|mesas?|bebidas?"
)
_PT_UNITS = (
    r"(?:ienes?|reais|real|dólares?|euros?|wons?|yuans?|pessoas?|adultos?|crianças?|lugares?|assentos?|ingressos?"
    r"|bilhetes?|itens?|peças?|copos?|xícaras?|garrafas?|pratos?|tigelas?|porções|porção|pedidos?|minutos?|horas?"
    r"|dias?|semanas?|meses|mês|anos?|vezes|vez|por cento|andar(?:es)?|quartos?|mesas?|noites?|bebidas?)\b|%"
)
spell_portuguese_numbers = _make_speller(
    r"\.", _PT_UNITS, lambda n, unit: portuguese_number(n, feminine=bool(_PT_FEMININE.match(unit)))
)


# ロシア語（主格）

_RU_ONES = ("ноль", "один", "два", "три", "четыре", "пять", "шесть", "семь", "восемь", "девять")
_RU_TEENS = ("десять", "одиннадцать", "двенадцать", "тринадцать", "четырнадцать", "пятнадцать", "шестнадцать", "семнадцать",
             "восемнадцать", "девятнадцать")
_RU_TENS = ("", "", "двадцать", "тридцать", "сорок", "пятьдесят", "шестьдесят", "семьдесят", "восемьдесят", "девяносто")
_RU_HUNDREDS = ("", "сто", "двести", "триста", "четыреста", "пятьсот", "шестьсот", "семьсот", "восемьсот", "девятьсот")
_RU_SCALES = (
    ("тысяча", "тысячи", "тысяч"),
    ("миллион", "миллиона", "миллионов"),
    ("миллиард", "миллиарда", "миллиардов"),
)


def _ru_one_or_two(digit: int, gender: str) -> str:
    if digit == 1:
        return {"m": "один", "f": "одна", "n": "одно"}[gender]
    if digit == 2:
        return "две" if gender == "f" else "два"
    return _RU_ONES[digit]


def _ru_below_1000(n: int, gender: str) -> str:
    hundreds, rest = divmod(n, 100)
    parts = [_RU_HUNDREDS[hundreds]] if hundreds else []
    if 10 <= rest < 20:
        parts.append(_RU_TEENS[rest - 10])
    else:
        tens, ones = divmod(rest, 10)
        if tens:
            parts.append(_RU_TENS[tens])
        if ones:
            parts.append(_ru_one_or_two(ones, gender))
    return " ".join(parts)


def _ru_plural(n: int, forms: tuple[str, str, str]) -> str:
    if 11 <= n % 100 <= 19:
        return forms[2]
    return forms[0] if n % 10 == 1 else forms[1] if 2 <= n % 10 <= 4 else forms[2]


def russian_number(n: int, gender: str = "m") -> str:
    """整数を、ロシア語の読み（主格）にする: 1500 → тысяча пятьсот、2 → два（gender="f" なら две）。"""
    if n == 0:
        return "ноль"
    groups = _three_digit_groups(n)
    parts = []
    for index in range(len(groups) - 1, -1, -1):
        value = groups[index]
        if not value:
            continue
        if index == 0:
            parts.append(_ru_below_1000(value, gender))
            continue
        forms = _RU_SCALES[index - 1]
        head = "" if (index == 1 and value == 1) else _ru_below_1000(value, "f" if index == 1 else "m") + " "
        parts.append(head + _ru_plural(value, forms))
    return " ".join(parts)


_RU_FEMININE = ("иен", "йен", "вон", "чашк", "бутылк", "минут", "секунд", "штук", "порци", "тарелк", "недел", "ноч", "комнат",
                "персон")
_RU_NEUTER = ("мест", "блюд")
_RU_UNITS = (
    r"(?:иен\w*|йен\w*|рубл\w*|долл\w*|евро|юан\w*|вон\w*|человек\w*|чел\.|персон\w*|час\w*|минут\w*|секунд\w*|дн\w*|день"
    r"|год\w*|лет|недел\w*|месяц\w*|штук\w*|раз\w*|чашк\w*|бутылк\w*|порци\w*|тарелк\w*|билет\w*|мест\w*|процент\w*"
    r"|этаж\w*|комнат\w*|стол\w*|ноч\w*|блюд\w*)(?![\w])|%"
)


def _ru_gender(unit: str) -> str:
    return "f" if unit.startswith(_RU_FEMININE) else "n" if unit.startswith(_RU_NEUTER) else "m"


spell_russian_numbers = _make_speller(r"[   ]", _RU_UNITS, lambda n, unit: russian_number(n, _ru_gender(unit)))


# タイ語

_TH_DIGITS = ("ศูนย์", "หนึ่ง", "สอง", "สาม", "สี่", "ห้า", "หก", "เจ็ด", "แปด", "เก้า")
_TH_PLACES = ("", "สิบ", "ร้อย", "พัน", "หมื่น", "แสน")


def _th_below_million(n: int, has_higher: bool) -> str:
    out = ""
    for i, ch in enumerate(str(n).zfill(6)):
        digit, place = int(ch), 5 - i
        if not digit:
            continue
        if place == 1:
            out += "ยี่สิบ" if digit == 2 else "สิบ" if digit == 1 else _TH_DIGITS[digit] + "สิบ"
        elif place == 0:
            out += "เอ็ด" if digit == 1 and (n > 10 or has_higher) else _TH_DIGITS[digit]
        else:
            out += _TH_DIGITS[digit] + _TH_PLACES[place]
    return out


def thai_number(n: int) -> str:
    """整数を、タイ語の読み（タイ文字）にする: 1500 → หนึ่งพันห้าร้อย、21 → ยี่สิบเอ็ด。"""
    if n == 0:
        return "ศูนย์"
    millions, rest = divmod(n, 10**6)
    out = thai_number(millions) + "ล้าน" if millions else ""
    return out + (_th_below_million(rest, bool(millions)) if rest else "")


_TH_UNITS = (
    "เยน|บาท|ดอลลาร์|ยูโร|หยวน|วอน|คน|ท่าน|ที่นั่ง|ที่|ชั่วโมง|นาที|วินาที|วัน|เดือน|ปี|ชิ้น|แก้ว|ขวด|ใบ|อัน|ครั้ง|จาน|ชาม"
    "|ถ้วย|โต๊ะ|ห้อง|ชั้น|เปอร์เซ็นต์|%"
)
spell_thai_numbers = _make_speller(",", _TH_UNITS, lambda n, unit: thai_number(n))


# 広東語（中国語と同じ数の読み。量詞は、広東語で書く文字も入れる）

_YUE_MEASURE = (
    "日圓|日元|日幣|日円|港幣|港元|美元|歐元|韓元|人民幣|元|蚊|個|位|人|歲|件|杯|瓶|張|次|點|分鐘|小時|日|折|碗|份|隻|枝"
    "|间|間|樣|層|樓"
)
spell_cantonese_numbers = _make_speller(",", _YUE_MEASURE, lambda n, unit: chinese_number(n))
