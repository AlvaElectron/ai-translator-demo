"""省電力モード（電源・再起動の画面の「省電力モード」でオン・オフする）。

オンの間は、次の 2 つで電気の使用を減らす。
1. 画面: 明るさを下げ（既定 40%）、待機中に操作がないまま idle_sec 秒（既定 60 秒）たったら画面を消す。
   画面に触れる・キーを押す・話し始める・訳が始まる、のどれかで点く（画面を点けるためのタッチは、ボタンとしては使わない）。
   明るさは /sys/class/backlight/*/brightness に書く（video グループで書き込めるので、root は要らない）。
   明るさの口が無い HDMI の画面（Orange Pi 4 Pro）では、画面を真っ黒に描く（BlackScreen。暗くはできない。2026-11-26。
   DPMS で消すと、この画面は点き直らなかったので使わない）。
2. CPU: 画面が消えている間だけ、最高周波数を本体の最高の cpu_off_ratio（既定 1/4。Pi 5 なら 2.4GHz → 600MHz）に下げる。
   画面が点いている間は下げない（翻訳を遅くしないため）。画面が点いたら、すぐ元に戻す。
   /sys/devices/system/cpu/cpufreq/policy*/scaling_max_freq は root しか書けないので、
   最初に一度 scripts/allow_power_mode.sh を実行して、video グループで書けるようにしておく。
   Pi 5 は、そのままでは 1.5GHz より下げられないので、同じスクリプトで config.txt に arm_freq_min=600 を足す（再起動で有効）。
   書けないときは、画面の省電力だけを行う。
3. お知らせ: 画面が消えている間、notice_interval_sec（既定 180 秒 = 3 分）ごとに、notice_sec（既定 5 秒）だけ画面を点けて
   「低消費電力モード中です。使わないときは電源を切ってください」と出す（画面は ui.py が描く）。
   使わないまま電源を入れっぱなしにしないように、気づいてもらうため。触るとふつうに点く。
"""

from __future__ import annotations

import logging
import time
from collections.abc import Callable
from pathlib import Path

log = logging.getLogger(__name__)

BACKLIGHT_ROOT = Path("/sys/class/backlight")
CPUFREQ_ROOT = Path("/sys/devices/system/cpu/cpufreq")


class Backlight:
    """画面の明るさ（0〜1）。明るさを変えられない画面（HDMI など）では、何もしない（HDMI は DpmsScreen を使う）。"""

    can_dim = True

    def __init__(self, root: Path = BACKLIGHT_ROOT) -> None:
        devices = sorted(root.glob("*/brightness")) if root.exists() else []
        self._path = devices[0] if devices else None
        self._max = 0
        if self._path is not None:
            try:
                self._max = int((self._path.parent / "max_brightness").read_text().strip())
            except (OSError, ValueError):
                self._path = None

    @property
    def available(self) -> bool:
        return self._path is not None and self._max > 0

    def set(self, level: float) -> bool:
        """明るさを level（0 = 消す、1 = いちばん明るい）にする。できなかったら False。"""
        if not self.available:
            return False
        value = max(0, min(self._max, round(self._max * level)))
        try:
            self._path.write_text(f"{value}\n")
            return True
        except OSError:
            log.warning("画面の明るさを変えられません: %s", self._path, exc_info=True)
            return False


class DpmsScreen:
    """明るさを変えられない HDMI の画面（Orange Pi 4 Pro など）を、X の DPMS で消す・点ける（2026-11-26）。

    Backlight と同じ使い方。明るさは変えられないので、level が 0 なら消し、0 より大きければ点ける。
    xset は DISPLAY（と XAUTHORITY）のある X の上でだけ使える。使えなければ available が False。
    """

    can_dim = False

    def __init__(self, run: Callable[[list[str]], bool] | None = None) -> None:
        self._run = run or _run_xset
        self._on: bool | None = None  # 最後に送った状態（同じことを何度も送らない）
        self._available = self._run(["xset", "q"])

    @property
    def available(self) -> bool:
        return self._available

    def set(self, level: float) -> bool:
        if not self._available:
            return False
        on = level > 0
        if on == self._on:
            return True
        if not self._run(["xset", "dpms", "force", "on" if on else "off"]):
            log.warning("画面を%sられません（xset dpms）", "点け" if on else "消せ")
            return False
        if on:
            # 消す前の、X の決まった時間で消える設定（スクリーンセーバー）に戻らないよう、点けたら時計も戻す
            self._run(["xset", "s", "reset"])
        self._on = on
        return True


def _run_xset(args: list[str]) -> bool:
    import os
    import shutil
    import subprocess

    if not os.environ.get("DISPLAY") or shutil.which(args[0]) is None:
        return False
    try:
        return subprocess.run(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=3).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def screen_power(root: Path = BACKLIGHT_ROOT):
    """画面の明るさを変える口があれば Backlight、無ければ（HDMI）X の DPMS で消す DpmsScreen、どちらも無ければ何もしない Backlight。"""
    # 2026-11-26: Orange Pi 4 Pro の 7 インチ HDMI 画面は、DPMS で一度消すと、信号を戻しても点き直らなかった
    # （解像度を変えて戻すと点いた）。なので DPMS は使わず（DpmsScreen は残すが選ばない）、画面を真っ黒に描く（BlackScreen）
    backlight = Backlight(root)
    return backlight if backlight.available else BlackScreen()


class BlackScreen:
    """明るさの口が無い画面で「消す」の代わりに、画面を真っ黒に描く（描くのは ui.py。2026-11-26）。

    画面の照明は点いたままなので、節電になるのは、画面が消えている間の CPU を遅くする分だけ。触ればすぐ戻る。
    """

    can_dim = False
    draws_black = True
    available = True

    def set(self, level: float) -> bool:
        return True


class CpuLimit:
    """CPU の最高周波数。scripts/allow_power_mode.sh で書き込めるようにしていないと、何もしない。"""

    def __init__(self, root: Path = CPUFREQ_ROOT) -> None:
        self._policies = sorted(root.glob("policy*")) if root.exists() else []

    @property
    def writable(self) -> bool:
        return bool(self._policies) and all(
            _is_writable(policy / "scaling_max_freq") for policy in self._policies
        )

    def lowest_ratio(self) -> float:
        """本体で下げられる最低（最高に対する割合。Pi 5 はそのままだと 1.5 / 2.4 = 0.625）。分からなければ 1。"""
        try:
            policy = self._policies[0]
            highest = int((policy / "cpuinfo_max_freq").read_text().strip())
            lowest = int((policy / "cpuinfo_min_freq").read_text().strip())
            return lowest / highest
        except (IndexError, OSError, ValueError, ZeroDivisionError):
            return 1.0

    def limit(self, ratio: float | None) -> bool:
        """最高周波数を本体の最高の ratio 倍にする（None なら、本体の最高に戻す）。できなかったら False。

        本体の最低より下には下げない。
        """
        if not self.writable:
            return False
        for policy in self._policies:
            try:
                highest = int((policy / "cpuinfo_max_freq").read_text().strip())
                lowest = int((policy / "cpuinfo_min_freq").read_text().strip())
                value = highest if ratio is None else max(lowest, min(highest, round(highest * ratio)))
                (policy / "scaling_max_freq").write_text(f"{value}\n")
            except (OSError, ValueError):
                log.warning("CPU の周波数を変えられません: %s", policy, exc_info=True)
                return False
        return True


def _is_writable(path: Path) -> bool:
    try:
        with path.open("r+"):
            return True
    except OSError:
        return False


class PowerSaver:
    """省電力モード。画面のループから tick() を呼び、操作があったら wake() を呼ぶ。"""

    def __init__(
        self,
        backlight: Backlight,
        cpu: CpuLimit,
        idle_sec: float = 60.0,
        dim_level: float = 0.4,
        cpu_off_ratio: float | None = 0.25,
        notice_interval_sec: float = 180.0,
        notice_sec: float = 5.0,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self._backlight = backlight
        self._cpu = cpu
        self._idle_sec = idle_sec
        self._dim_level = dim_level
        self._cpu_off_ratio = cpu_off_ratio
        self._notice_interval = notice_interval_sec
        self._notice_sec = notice_sec
        self._clock = clock
        # お知らせ: 次に出す時刻、出している間の終わりの時刻（出していなければ None）、画面を点けたか
        self._notice_at = 0.0
        self._notice_until: float | None = None
        self._notice_lit = False
        self._enabled = False
        self._screen_off = False
        self._last_activity = clock()

    @property
    def enabled(self) -> bool:
        return self._enabled

    @property
    def screen_off(self) -> bool:
        return self._screen_off

    @property
    def idle_sec(self) -> float:
        return self._idle_sec

    @property
    def can_dim(self) -> bool:
        """画面の明るさを変えられるか（HDMI の画面は変えられない）。"""
        return getattr(self._backlight, "can_dim", True)

    @property
    def draws_black(self) -> bool:
        """画面を消す代わりに、ui.py が真っ黒に描くか（BlackScreen）。"""
        return getattr(self._backlight, "draws_black", False)

    @property
    def notice_showing(self) -> bool:
        """画面が消えている間の、お知らせを出す時間か（画面を描いてから notice_shown() を呼ぶと、画面が点く）。"""
        return self._screen_off and self._notice_until is not None

    @property
    def notice_lit(self) -> bool:
        return self.notice_showing and self._notice_lit

    @property
    def cpu_limited(self) -> bool:
        """画面が消えている間、CPU の周波数も下げられるか（scripts/allow_power_mode.sh を実行してあるか）。"""
        return self._cpu_off_ratio is not None and self._cpu.writable

    @property
    def cpu_off_ratio(self) -> float | None:
        """画面が消えている間の CPU の速さ（本体の最高に対する割合。本体の最低より下には下げない）。"""
        if self._cpu_off_ratio is None:
            return None
        return max(self._cpu_off_ratio, self._cpu.lowest_ratio())

    def set_enabled(self, enabled: bool) -> None:
        """省電力モードのオン・オフ。画面の明るさを変え、CPU の周波数は元に戻す（画面が点いているので）。"""
        self._enabled = enabled
        self._screen_off = False
        self._notice_until = None
        self._notice_lit = False
        self._last_activity = self._clock()
        self._backlight.set(self._dim_level if enabled else 1.0)
        self._restore_cpu()
        ratio = self.cpu_off_ratio
        log.info(
            "省電力モードを%sにしました（画面の明るさ %s、%.0f 秒操作がなければ画面を消す%s）",
            "オン" if enabled else "オフ",
            f"{round((self._dim_level if enabled else 1.0) * 100)}%" if getattr(self._backlight, "can_dim", True) else "変えられない画面（HDMI）",
            self._idle_sec,
            f"、画面が消えている間は CPU を {ratio:.0%} の速さにする" if enabled and self.cpu_limited and ratio else "",
        )

    def wake(self) -> bool:
        """操作があった（画面に触れた・キーを押した・話し始めた・訳が始まった）。

        画面が消えていたら点けて True を返す（そのタッチは、画面を点けるためだけに使う）。
        """
        self._last_activity = self._clock()
        if not self._screen_off:
            return False
        self._screen_off = False
        self._notice_until = None
        self._notice_lit = False
        self._restore_cpu()  # 先に CPU を元の速さに戻す（すぐに翻訳が始まることがあるので）
        self._backlight.set(self._dim_level if self._enabled else 1.0)
        log.info("画面を点けました")
        return True

    def tick(self, busy: bool) -> None:
        """画面のループから呼ぶ。busy（聞き取り・翻訳・読み上げの途中）なら画面を点けたままにする。

        省電力モードで、待機中に idle_sec 秒操作がなければ、画面を消して CPU を遅くする。
        """
        if busy:
            self.wake()
            return
        now = self._clock()
        if self._enabled and self._screen_off:
            self._tick_notice(now)
            return
        if self._enabled and now - self._last_activity >= self._idle_sec:
            if self._backlight.set(0.0):
                self._screen_off = True
                self._notice_at = now + self._notice_interval
                slowed = self._cpu_off_ratio is not None and self._cpu.limit(self._cpu_off_ratio)
                log.info(
                    "%.0f 秒操作がなかったので、画面を消しました%s",
                    self._idle_sec,
                    f"（CPU は {self.cpu_off_ratio:.0%} の速さ）" if slowed else "",
                )

    def notice_shown(self) -> None:
        """お知らせを描き終わった: 画面を点ける（描く前に点けると、消える前の画面が一瞬見えるため）。"""
        if self.notice_showing and not self._notice_lit and self._backlight.set(self._dim_level):
            self._notice_lit = True
            log.info("低消費電力モードのお知らせを出しました（%.0f 秒）", self._notice_sec)

    def _tick_notice(self, now: float) -> None:
        """画面が消えている間: notice_interval_sec ごとに notice_sec だけお知らせを出し、時間が来たらまた消す。"""
        if self._notice_interval <= 0 or self._notice_sec <= 0:
            return
        if self._notice_until is None:
            if now >= self._notice_at:
                self._notice_until = now + self._notice_sec
        elif now >= self._notice_until:
            self._backlight.set(0.0)
            self._notice_until = None
            self._notice_lit = False
            self._notice_at = now + self._notice_interval

    def close(self) -> None:
        """アプリを終えるとき: 画面を点けて、CPU の周波数を元に戻す。"""
        self._backlight.set(1.0)
        self._restore_cpu()

    def _restore_cpu(self) -> None:
        if self._cpu_off_ratio is not None:
            self._cpu.limit(None)


class IdleCpuSaver:
    """省電力モードとは別に、いつも働く「操作がないときは CPU を遅くする」（2026-11-26）。

    待機中に idle_sec 秒（既定 180 秒 = 3 分）、画面に触れる・キーを押す・話す・訳す・読み上げる・動画を流す、の
    どれもなければ、CPU（全部のコア）の最高周波数を本体の最低（Orange Pi 4 Pro は 416MHz）まで下げる。画面はそのまま。
    操作があったり、話し始めたり（イヤホンのタップも）したら、すぐに元の速さに戻す（翻訳が始まる前に戻るので、訳は遅くならない）。
    周波数を書くには、scripts/allow_power_mode.sh で書き込めるようにしておく（書けなければ何もしない）。
    """

    def __init__(self, cpu: CpuLimit, idle_sec: float = 180.0, clock: Callable[[], float] = time.monotonic) -> None:
        self._cpu = cpu
        self._idle_sec = idle_sec
        self._clock = clock
        self._last_activity = clock()
        self._limited = False

    @property
    def enabled(self) -> bool:
        return self._idle_sec > 0 and self._cpu.writable

    @property
    def limited(self) -> bool:
        return self._limited

    def wake(self) -> None:
        """操作があった: 時間を数え直し、CPU を下げていたら元に戻す。"""
        self._last_activity = self._clock()
        if self._limited:
            self._limited = False
            if self._cpu.limit(None):
                log.info("操作があったので、CPU を元の速さに戻しました")

    def tick(self, busy: bool) -> None:
        """画面のループから呼ぶ。busy（聞き取り・翻訳・読み上げ・動画の途中）なら、操作があったのと同じに扱う。"""
        if busy:
            self.wake()
            return
        if self._limited or not self.enabled:
            return
        if self._clock() - self._last_activity >= self._idle_sec and self._cpu.limit(0.0):
            self._limited = True
            log.info("%.0f 秒操作がなかったので、CPU を最低の速さにしました", self._idle_sec)

    def close(self) -> None:
        """アプリを終えるとき: CPU を元の速さに戻す。"""
        if self._limited:
            self._limited = False
            self._cpu.limit(None)
