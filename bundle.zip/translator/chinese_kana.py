"""中国語（普通話）のピンインを、日本語話者が読めるカタカナにする（外部ライブラリに依存しない）。

漢字からピンインへの変換は pypinyin で行い、ここではピンインの1音節（例: "tian1"）をカタカナにする。
声調は表さない。母音で終わる音節は「ー」で伸ばす（你 → ニー、不 → ブー）。軽声（的・了・吗 など）は伸ばさない。
日本の入門書でよく使われる書き方に合わせている（谢谢 → シエ シエ、天 → ティエン、对 → ドゥイ、水 → シュイ）。

以前は pinyin_kana を使っていたが、変換できない音節（tian・ting・zuo・yu・nv など）や、
ほかの音と同じになる音節（hui → フェイ、hua → ファ、tu → ツ）が多かったので、自前の表に替えた。
"""

from __future__ import annotations

import re

# 声母ごとの ア・イ・ウ・エ・オ段
_ROWS: dict[str, tuple[str, str, str, str, str]] = {
    "b": ("バ", "ビ", "ブ", "ベ", "ボ"), "p": ("パ", "ピ", "プ", "ペ", "ポ"), "m": ("マ", "ミ", "ム", "メ", "モ"),
    "f": ("ファ", "フィ", "フ", "フェ", "フォ"), "d": ("ダ", "ディ", "ドゥ", "デ", "ド"),
    "t": ("タ", "ティ", "トゥ", "テ", "ト"), "n": ("ナ", "ニ", "ヌ", "ネ", "ノ"), "l": ("ラ", "リ", "ル", "レ", "ロ"),
    "g": ("ガ", "ギ", "グ", "ゲ", "ゴ"), "k": ("カ", "キ", "ク", "ケ", "コ"), "h": ("ハ", "ヒ", "フ", "ヘ", "ホ"),
    "j": ("ジャ", "ジ", "ジュ", "ジェ", "ジョ"), "q": ("チャ", "チ", "チュ", "チェ", "チョ"),
    "x": ("シャ", "シ", "シュ", "シェ", "ショ"), "zh": ("ジャ", "ジ", "ジュ", "ジェ", "ジョ"),
    "ch": ("チャ", "チ", "チュ", "チェ", "チョ"), "sh": ("シャ", "シ", "シュ", "シェ", "ショ"),
    "r": ("ラ", "リ", "ル", "レ", "ロ"), "z": ("ザ", "ズィ", "ズ", "ゼ", "ゾ"),
    "c": ("ツァ", "ツィ", "ツ", "ツェ", "ツォ"), "s": ("サ", "スィ", "ス", "セ", "ソ"),
}
_INITIALS = ("zh", "ch", "sh", "b", "p", "m", "f", "d", "t", "n", "l", "g", "k", "h", "j", "q", "x", "r", "z", "c", "s")
# 韻母 →（使う段, 後ろに足すカナ）。段は 0〜4 = ア〜オ段
_FINALS: dict[str, tuple[int, str]] = {
    "a": (0, "ー"), "o": (4, "ー"), "e": (4, "ー"), "ai": (0, "イ"), "ei": (3, "イ"), "ao": (0, "オ"), "ou": (4, "ウ"),
    "an": (0, "ン"), "en": (3, "ン"), "ang": (0, "ン"), "eng": (4, "ン"), "ong": (4, "ン"),
    "ia": (1, "ア"), "iao": (1, "アオ"), "ie": (1, "エ"), "iu": (1, "ウ"), "ian": (1, "エン"), "in": (1, "ン"),
    "iang": (1, "アン"), "ing": (1, "ン"), "iong": (4, "ン"),
    "u": (2, "ー"), "ua": (2, "ア"), "uo": (2, "オ"), "uai": (2, "アイ"), "ui": (2, "イ"), "uan": (2, "アン"),
    "un": (2, "ン"), "uang": (2, "アン"),
}
# ü の韻母（j・q・x のあとの u と、nü・lü）→ 後ろに足すカナ。頭は _YU のカナ
_YU_FINALS = {"v": "ー", "ve": "エ", "van": "エン", "vn": "ン"}
_YU = {"j": "ジュ", "q": "チュ", "x": "シュ", "n": "ニュ", "l": "リュ"}
# 声母のない音節
_WHOLE = {
    "a": "アー", "o": "オー", "e": "オー", "ai": "アイ", "ei": "エイ", "ao": "アオ", "ou": "オウ", "an": "アン",
    "en": "エン", "ang": "アン", "eng": "オン", "er": "アル",
    "yi": "イー", "ya": "ヤー", "ye": "イエ", "yao": "ヤオ", "you": "ヨウ", "yan": "イエン", "yin": "イン",
    "yang": "ヤン", "ying": "イン", "yong": "ヨン", "yo": "ヨー",
    "wu": "ウー", "wa": "ワー", "wo": "ウォー", "wai": "ワイ", "wei": "ウェイ", "wan": "ワン", "wen": "ウェン",
    "wang": "ワン", "weng": "ウォン",
    "yu": "ユー", "yue": "ユエ", "yuan": "ユエン", "yun": "ユン",
}
# 軽声の e は、口をあまり開けない「ア」に近い音（的 → ダ、了 → ラ、个 → ガ）
_NEUTRAL_E_COLUMN = 0

_SYLLABLE = re.compile(r"([a-zü:]+?)([1-5])?")


def syllable_to_kana(syllable: str) -> str | None:
    """ピンインの1音節（"tian1"・"de5"・"lv4" など。ü は v でもよい）をカタカナにする。ピンインでなければ None。"""
    match = _SYLLABLE.fullmatch(syllable.strip().lower())
    if not match:
        return None
    body = match.group(1).replace("u:", "v").replace("ü", "v")
    neutral = match.group(2) == "5"
    if body in _WHOLE:
        kana = _WHOLE[body]
        return kana.rstrip("ー") if neutral else kana
    initial = next((i for i in _INITIALS if body.startswith(i)), None)
    if initial is None:
        return None
    final = body[len(initial) :]
    row = _ROWS[initial]
    if final == "i":
        # zi・ci・si は「ウ」に近い音、zhi・chi・shi・ri と、そのほかは「イ」
        kana = row[2 if initial in ("z", "c", "s") else 1] + "ー"
    elif final == "e" and neutral:
        return row[_NEUTRAL_E_COLUMN]
    else:
        if initial in ("j", "q", "x") and final.startswith("u"):
            final = "v" + final[1:]  # ju・qu・xu の u は ü
        if final == "ue":
            final = "ve"  # nüe・lüe は nue・lue とも書く
        if final in _YU_FINALS:
            if initial not in _YU:
                return None
            kana = _YU[initial] + _YU_FINALS[final]
        elif final in _FINALS:
            column, suffix = _FINALS[final]
            if initial == "h" and final in ("ua", "uai", "uan", "uang"):
                column = 4  # 花 → ホア、换 → ホアン（「フア」より近い）
            kana = row[column] + suffix
        else:
            return None
    return kana.rstrip("ー") if neutral else kana
