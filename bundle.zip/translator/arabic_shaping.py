"""アラビア文字（アラビア語・ペルシア語）を、pygame.freetype で正しく描くための文字の形と並びの処理（外部ライブラリに依存しない）。

pygame.freetype は、アラビア文字の形（語頭・語中・語末・独立形）を自分では選ばず、並びも左から右のままにする。
2026-11-15 に CM5 で、ペルシア語の「طبقه」が「هقبط」とばらばらに出たので、ここで次の 2 つを行ってから描く。

1. 形: 前後の文字とつながるかで、Unicode の「アラビア文字表示形」（U+FB50〜・U+FE70〜）に置き換える（ل+ا などは合字）。
2. 並び: 右から左に読む部分の文字の順を逆にする（数字とラテン文字の語は、左から右のまま）。母音記号は、元の文字から離さない。

画面のフォント（Noto Sans Arabic）には、この表示形の字形が入っている（U+FE75 を除く。使わない文字）。
"""

from __future__ import annotations

import pygame.freetype

# 文字 → (独立形, 語末形, 語頭形, 語中形)。語頭形・語中形が無い文字（右にだけつながる文字）は 2 つだけ
_FORMS: dict[str, tuple[int, ...]] = {
    "ء": (0xFE80,),
    "آ": (0xFE81, 0xFE82), "أ": (0xFE83, 0xFE84), "ؤ": (0xFE85, 0xFE86), "إ": (0xFE87, 0xFE88),
    "ئ": (0xFE89, 0xFE8A, 0xFE8B, 0xFE8C), "ا": (0xFE8D, 0xFE8E), "ب": (0xFE8F, 0xFE90, 0xFE91, 0xFE92),
    "ة": (0xFE93, 0xFE94), "ت": (0xFE95, 0xFE96, 0xFE97, 0xFE98), "ث": (0xFE99, 0xFE9A, 0xFE9B, 0xFE9C),
    "ج": (0xFE9D, 0xFE9E, 0xFE9F, 0xFEA0), "ح": (0xFEA1, 0xFEA2, 0xFEA3, 0xFEA4), "خ": (0xFEA5, 0xFEA6, 0xFEA7, 0xFEA8),
    "د": (0xFEA9, 0xFEAA), "ذ": (0xFEAB, 0xFEAC), "ر": (0xFEAD, 0xFEAE), "ز": (0xFEAF, 0xFEB0),
    "س": (0xFEB1, 0xFEB2, 0xFEB3, 0xFEB4), "ش": (0xFEB5, 0xFEB6, 0xFEB7, 0xFEB8), "ص": (0xFEB9, 0xFEBA, 0xFEBB, 0xFEBC),
    "ض": (0xFEBD, 0xFEBE, 0xFEBF, 0xFEC0), "ط": (0xFEC1, 0xFEC2, 0xFEC3, 0xFEC4), "ظ": (0xFEC5, 0xFEC6, 0xFEC7, 0xFEC8),
    "ع": (0xFEC9, 0xFECA, 0xFECB, 0xFECC), "غ": (0xFECD, 0xFECE, 0xFECF, 0xFED0), "ف": (0xFED1, 0xFED2, 0xFED3, 0xFED4),
    "ق": (0xFED5, 0xFED6, 0xFED7, 0xFED8), "ك": (0xFED9, 0xFEDA, 0xFEDB, 0xFEDC), "ل": (0xFEDD, 0xFEDE, 0xFEDF, 0xFEE0),
    "م": (0xFEE1, 0xFEE2, 0xFEE3, 0xFEE4), "ن": (0xFEE5, 0xFEE6, 0xFEE7, 0xFEE8), "ه": (0xFEE9, 0xFEEA, 0xFEEB, 0xFEEC),
    "و": (0xFEED, 0xFEEE), "ى": (0xFEEF, 0xFEF0), "ي": (0xFEF1, 0xFEF2, 0xFEF3, 0xFEF4),
    # ペルシア語の文字
    "پ": (0xFB56, 0xFB57, 0xFB58, 0xFB59), "چ": (0xFB7A, 0xFB7B, 0xFB7C, 0xFB7D), "ژ": (0xFB8A, 0xFB8B),
    "ک": (0xFB8E, 0xFB8F, 0xFB90, 0xFB91), "گ": (0xFB92, 0xFB93, 0xFB94, 0xFB95), "ی": (0xFBFC, 0xFBFD, 0xFBFE, 0xFBFF),
}
_TATWEEL = "ـ"  # 字をつなぐ横棒（両側につながる）
# ل の後に続く ا の仲間 → (独立形, 語末形) の合字
_LAM_ALEF = {"آ": (0xFEF5, 0xFEF6), "أ": (0xFEF7, 0xFEF8), "إ": (0xFEF9, 0xFEFA), "ا": (0xFEFB, 0xFEFC)}
_ZWNJ = "‌"  # ペルシア語の語の中の「つなげない」印（形を決めたあとで消す）


def _is_mark(ch: str) -> bool:
    """母音記号など（前後の文字のつながりを決めるときは、無いものとして飛ばす）。"""
    code = ord(ch)
    return 0x064B <= code <= 0x065F or code == 0x0670 or 0x06D6 <= code <= 0x06ED


def _joins_both(ch: str) -> bool:
    return ch == _TATWEEL or len(_FORMS.get(ch, ())) == 4


def _joins_right(ch: str) -> bool:
    """前（右）の文字とつながれる文字か。"""
    return ch == _TATWEEL or len(_FORMS.get(ch, ())) >= 2


def _neighbor(text: str, index: int, step: int) -> str:
    """index から step 方向に、母音記号を飛ばした隣の文字（無ければ空）。"""
    index += step
    while 0 <= index < len(text) and _is_mark(text[index]):
        index += step
    return text[index] if 0 <= index < len(text) else ""


def shape(text: str) -> str:
    """アラビア文字を、前後とのつながりに合わせた表示形にする（並びはそのまま）。"""
    out: list[str] = []
    i = 0
    while i < len(text):
        ch = text[i]
        forms = _FORMS.get(ch)
        if forms is None:
            if ch != _ZWNJ:
                out.append(ch)
            i += 1
            continue
        prev = _neighbor(text, i, -1)
        joins_prev = _joins_both(prev) and _joins_right(ch)
        following = _neighbor(text, i, 1)
        if ch == "ل" and following in _LAM_ALEF:
            ligature = _LAM_ALEF[following]
            out.append(chr(ligature[1] if joins_prev else ligature[0]))
            i = text.index(following, i + 1) + 1
            continue
        joins_next = len(forms) == 4 and _joins_right(following)
        if len(forms) == 1:
            form = forms[0]
        elif joins_prev and joins_next:
            form = forms[3]
        elif joins_prev:
            form = forms[1]
        elif joins_next:
            form = forms[2]
        else:
            form = forms[0]
        out.append(chr(form))
        i += 1
    return "".join(out)


def _is_ltr(ch: str) -> bool:
    """左から右に並べる文字（数字・ラテン文字など）。数字の間の「,」「.」も含める（3,300 を崩さない）。"""
    return ch.isdigit() or (ch.isascii() and ch.isalpha())


_MIRROR = str.maketrans("()[]{}«»<>", ")(][}{»«><")


def visual_order(text: str) -> str:
    """右から左に読む 1 行を、左から右に描いたときに正しく読める並びにする（数字・ラテン文字の語の中は、そのまま）。"""
    # 1. 左から右の部分（数字・ラテン文字と、その間の , . : - ）と、それ以外に分ける
    runs: list[tuple[bool, str]] = []
    i = 0
    while i < len(text):
        if _is_ltr(text[i]):
            j = i + 1
            while j < len(text) and (_is_ltr(text[j]) or (text[j] in ",.:-/" and j + 1 < len(text) and _is_ltr(text[j + 1]))):
                j += 1
            runs.append((True, text[i:j]))
            i = j
        else:
            j = i
            while j < len(text) and not _is_ltr(text[j]):
                j += 1
            runs.append((False, text[i:j]))
            i = j
    # 2. 右から左の部分は、文字（母音記号は元の文字と一緒）の順を逆にし、かっこの向きも逆にする
    pieces = []
    for ltr, run in reversed(runs):
        if ltr:
            pieces.append(run)
            continue
        clusters: list[str] = []
        for ch in run:
            if clusters and _is_mark(ch):
                clusters[-1] += ch
            else:
                clusters.append(ch)
        pieces.append("".join(reversed(clusters)).translate(_MIRROR))
    return "".join(pieces)


def to_display(text: str) -> str:
    """アラビア文字の 1 行を、pygame.freetype で左から右に描けば正しく読める文字列にする。"""
    return visual_order(shape(text))


class ArabicFont(pygame.freetype.Font):
    """アラビア文字の書体。描く・測る前に、文字の形と並びを直す（ui.py の描き方を変えずに使える）。"""

    def render(self, text, *args, **kwargs):  # noqa: D102
        return super().render(to_display(text) if text else text, *args, **kwargs)

    def render_to(self, surf, dest, text, *args, **kwargs):  # noqa: D102
        return super().render_to(surf, dest, to_display(text) if text else text, *args, **kwargs)

    def get_rect(self, text, *args, **kwargs):  # noqa: D102
        return super().get_rect(to_display(text) if text else text, *args, **kwargs)
