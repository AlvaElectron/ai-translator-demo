"""Bluetooth イヤホンマイクを探して接続する（bluetoothctl と bluealsactl（古い版は bluealsa-cli）を使う）。

外部コマンドの出力を読み取る関数は、テストできるように、コマンドを実行する部分と分けてある。
"""

from __future__ import annotations

import logging
import os
import re
import shutil
import subprocess
import threading
import time
from dataclasses import dataclass
from pathlib import Path

log = logging.getLogger(__name__)

# ~/.asoundrc に作る音声機器の名前（マイクとスピーカーとして開く）
ALSA_DEVICE_NAME = "btphone"
PAIR_TIMEOUT_SEC = 20.0
CONNECT_TIMEOUT_SEC = 15.0
# 接続したあと、マイクが使える方式（HFP）の音声機器ができるのを待つ時間（方式を指定してつなぐたびに待つ）
HFP_WAIT_SEC = 6.0
RECONNECT_INTERVAL_SEC = 15.0
COMMAND_TIMEOUT_SEC = 10.0
# BlueALSA を操作するコマンド。版によって名前が違う（新しい版は bluealsactl、古い版は bluealsa-cli）
BLUEALSA_COMMANDS = ("bluealsactl", "bluealsa-cli")
# BlueALSA の本体の名前（新しい版は bluealsad、古い版は bluealsa）
BLUEALSA_DAEMONS = ("bluealsa", "bluealsad")
# BlueALSA が Pi 側（電話の役）として、マイクが使える方式を受け持つ設定（-p の値）
HANDSFREE_GATEWAY_PROFILES = ("hfp-ag", "hsp-ag", "hfp-ofono")
# イヤホン側の、マイクが使える機能の UUID（HFP のハンズフリー、HSP のヘッドセット）
HANDSFREE_UUIDS = ("0000111e-0000-1000-8000-00805f9b34fb", "00001108-0000-1000-8000-00805f9b34fb")
# systemd から起動したときの PATH に入っていなくても見つかるように、コマンドがよく置かれる場所も探す
COMMAND_DIRS = ("/usr/local/bin", "/usr/bin", "/bin", "/usr/local/sbin", "/usr/sbin", "/sbin")

_ANSI_ESCAPE = re.compile(r"\x1b\[[0-9;]*[A-Za-z]|[\x01\x02]")
_DEVICE_LINE = re.compile(r"^Device\s+((?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2})\s*(.*)$")
# イヤホン・ヘッドセットが持つ機能（UUID の名前）
_AUDIO_UUIDS = ("Handsfree", "Headset", "Audio Sink")
# マウス・キーボードが持つ機能（従来の Bluetooth の HID と、Bluetooth LE の HID over GATT）
_INPUT_UUIDS = ("Human Interface Device", "00001124-0000-1000-8000-00805f9b34fb", "00001812-0000-1000-8000-00805f9b34fb")
# ペアリングの確認に答える役（agent）の種類。イヤホンは確認なし、マウス・キーボードは番号を画面に出して打ってもらう
AUDIO_AGENT = "NoInputNoOutput"
INPUT_AGENT = "KeyboardDisplay"
# キーボードで番号を打ってもらうので、イヤホンより長く待つ
INPUT_PAIR_TIMEOUT_SEC = 60.0

# bluetoothctl の agent が出す問い合わせ（行末で改行せずに答えを待つものもある）
_PASSKEY_DISPLAY = re.compile(r"\[agent\]\s*(?:Passkey|PIN code):\s*(\d+)")
_PASSKEY_CONFIRM = re.compile(r"\[agent\]\s*Confirm passkey\s*(\d+)")
_YES_NO = re.compile(r"\[agent\].*\(yes/no\)")
_ENTER_CODE = re.compile(r"\[agent\]\s*Enter (?:PIN code|passkey)")


@dataclass(frozen=True)
class BluetoothDevice:
    address: str
    name: str
    paired: bool = False
    connected: bool = False


def parse_devices(output: str) -> list[tuple[str, str]]:
    """`bluetoothctl devices` の出力から、(アドレス, 名前) の一覧を取り出す。"""
    devices = []
    for line in _ANSI_ESCAPE.sub("", output).splitlines():
        match = _DEVICE_LINE.match(line.strip())
        if match:
            devices.append((match.group(1).upper(), match.group(2).strip()))
    return devices


def parse_info(output: str) -> dict[str, list[str]]:
    """`bluetoothctl info` の出力を「項目名 → 値の一覧」にする（UUID のように複数行ある項目もある）。"""
    info: dict[str, list[str]] = {}
    for line in _ANSI_ESCAPE.sub("", output).splitlines():
        line = line.strip()
        if line.startswith("Device "):
            continue
        key, separator, value = line.partition(": ")
        if separator:
            info.setdefault(key, []).append(value.strip())
    return info


def is_yes(info: dict[str, list[str]], key: str) -> bool:
    return info.get(key, [""])[0] == "yes"


def is_audio_device(info: dict[str, list[str]]) -> bool:
    """イヤホン・ヘッドセットなどの音声機器か（アイコンか、持っている機能で判断する）。"""
    if any(icon.startswith("audio-") for icon in info.get("Icon", [])):
        return True
    return any(uuid.startswith(_AUDIO_UUIDS) for uuid in info.get("UUID", []))


def is_input_device(info: dict[str, list[str]]) -> bool:
    """マウス・キーボードか（アイコンか、持っている機能で判断する）。"""
    if any(icon.startswith("input-") for icon in info.get("Icon", [])):
        return True
    return any(any(key in uuid for key in _INPUT_UUIDS) for uuid in info.get("UUID", []))


def parse_agent_prompt(text: str) -> tuple[str, str] | None:
    """bluetoothctl の agent の問い合わせを読む。

    返り値: ("show", 番号) = キーボードで打ってもらう番号 / ("confirm", 番号) = 番号の確認（yes と答える）/
    ("yes", "") = 許可の問い合わせ（yes と答える）/ ("enter", "") = こちらで番号を決めて入力する / None = 問い合わせでない
    """
    text = _ANSI_ESCAPE.sub("", text)
    if match := _PASSKEY_CONFIRM.search(text):
        return "confirm", match.group(1)
    if match := _PASSKEY_DISPLAY.search(text):
        return "show", match.group(1)
    if _ENTER_CODE.search(text):
        return "enter", ""
    if _YES_NO.search(text):
        return "yes", ""
    return None


def device_id(address: str) -> str:
    """BlueZ・BlueALSA が D-Bus で使う機器の名前（dev_AA_BB_CC_DD_EE_FF）。"""
    return "dev_" + address.upper().replace(":", "_")


def device_object_path(address: str, adapter: str) -> str:
    return f"/org/bluez/{adapter}/{device_id(address)}"


def adapter_name(sys_dir: Path = Path("/sys/class/bluetooth")) -> str:
    """Bluetooth の親機の名前（hci0 など。hci0:12 のような接続ごとの項目は除く）。"""
    names = sorted(path.name for path in sys_dir.glob("hci*") if ":" not in path.name)
    return names[0] if names else "hci0"


def has_hfp_pcm(list_pcms_output: str, address: str) -> bool:
    """`bluealsactl list-pcms` の出力に、この機器の通話用（HFP/HSP、マイクが使える）の音声機器があるか。"""
    device = device_id(address)
    return any(device in line and ("/hfpag/" in line or "/hspag/" in line) for line in list_pcms_output.splitlines())


def parse_profiles(argv: list[str]) -> list[str]:
    """bluealsa の起動引数から、有効にしている方式（-p / --profile の値）を取り出す。"""
    profiles = []
    args = iter(argv[1:])
    for arg in args:
        if arg in ("-p", "--profile"):
            profiles.append(next(args, ""))
        elif arg.startswith("--profile="):
            profiles.append(arg.partition("=")[2])
        elif arg.startswith("-p"):
            profiles.append(arg[2:])
    return profiles


def running_bluealsa_profiles(proc_dir: Path = Path("/proc")) -> list[str] | None:
    """動いている bluealsa が有効にしている方式。bluealsa が動いていなければ None。"""
    for cmdline in proc_dir.glob("[0-9]*/cmdline"):
        try:
            argv = [arg.decode(errors="replace") for arg in cmdline.read_bytes().split(b"\0") if arg]
        except OSError:
            continue
        if argv and Path(argv[0]).name in BLUEALSA_DAEMONS:
            return parse_profiles(argv)
    return None


def handsfree_problem(profiles: list[str] | None) -> str | None:
    """bluealsa の方式の設定から、マイクが使える方式（HFP）を使えない理由を返す（使えるなら None）。"""
    if profiles is None:
        return "bluealsa が動いていません"
    if not any(profile in HANDSFREE_GATEWAY_PROFILES for profile in profiles):
        return "bluealsa で通話用の方式（HFP）が無効です"
    return None


def find_command(names: tuple[str, ...], extra_dirs: tuple[str, ...] = COMMAND_DIRS) -> str | None:
    """names のうち、最初に見つかったコマンドの場所を返す（PATH と extra_dirs から探す）。"""
    search_path = os.pathsep.join([os.environ.get("PATH", ""), *extra_dirs])
    for name in names:
        found = shutil.which(name, path=search_path)
        if found:
            return found
    return None


# HDMI のスピーカー（モニターの内蔵スピーカー）。config.toml の output_device = "hdmiplug" で使う。
# このファイルは通訳機が書き換えるので、ここに入れておく（手で足しても、書き換えで消えてしまう。2026-10-12 に確認）。
# カードは番号ではなく名前（vc4hdmi0）で指す（カーネルを替えると、番号が変わるため）。plug で形式とレートを変換する
HDMI_PLUG_BLOCK = (
    "\n# pi-translator: HDMI のスピーカー（モニターの内蔵スピーカー）\n"
    "pcm.hdmiplug {\n"
    "    type plug\n"
    '    slave.pcm "hw:CARD=vc4hdmi0,DEV=0"\n'
    "    hint {\n"
    "        show on\n"
    '        description "HDMI speaker (plug)"\n'
    "    }\n"
    "}\n"
)

def asoundrc_content(address: str) -> str:
    """ALSA に Bluetooth 機器を「btphone」という名前で登録する設定（通話用の方式を、形式の変換付きで使う）。"""
    return (
        "# pi-translator: Bluetooth イヤホンマイク（通話用の方式 HFP で、マイクとスピーカーを使う）\n"
        f"pcm.{ALSA_DEVICE_NAME} {{\n"
        "    type plug\n"
        "    slave.pcm {\n"
        "        type bluealsa\n"
        f'        device "{address}"\n'
        '        profile "sco"\n'
        "    }\n"
        "    hint {\n"
        "        show on\n"
        '        description "Bluetooth headset (HFP)"\n'
        "    }\n"
        "}\n"
    ) + HDMI_PLUG_BLOCK


def write_asoundrc(address: str, path: Path) -> None:
    """~/.asoundrc を書き換える。通訳機が作ったものでないファイルは、.bak として残してから書く。"""
    if path.exists():
        current = path.read_text(encoding="utf-8", errors="replace")
        if "pi-translator" not in current:
            path.with_name(path.name + ".bak").write_text(current, encoding="utf-8")
    path.write_text(asoundrc_content(address), encoding="utf-8")


class BluetoothController:
    """bluetoothctl を使って、機器を探す・ペアリングする・接続する。"""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._session: subprocess.Popen | None = None
        self._last_reconnect = 0.0
        self._reconnect_thread: threading.Thread | None = None
        self._bluetoothctl = "bluetoothctl"
        self._bluealsactl = "bluealsactl"
        self._busctl = "busctl"
        # 検索用の bluetoothctl で使っている agent の種類と、キーボードで打ってもらう番号を知らせる先
        self._agent = ""
        self._on_passkey = lambda passkey: None

    def set_passkey_handler(self, handler) -> None:
        """キーボードのペアリングで、キーボードで打ってもらう番号が決まったときに呼ぶ処理（番号を画面に出す）。"""
        self._on_passkey = handler

    def missing_commands(self) -> list[str]:
        """必要なコマンド（scripts/setup_bluetooth.sh で入る）のうち、見つからないものの名前。

        アプリを起動し直さなくても、あとから入れたコマンドを使えるように、呼ぶたびに探し直す。
        """
        missing = []
        bluetoothctl = find_command(("bluetoothctl",))
        if bluetoothctl:
            self._bluetoothctl = bluetoothctl
        else:
            missing.append("bluetoothctl")
        bluealsactl = find_command(BLUEALSA_COMMANDS)
        if bluealsactl:
            self._bluealsactl = bluealsactl
        else:
            missing.append("bluealsactl")
        # busctl は systemd に含まれているので、ないときも足りないものとしては扱わない
        self._busctl = find_command(("busctl",)) or "busctl"
        return missing

    def handsfree_problem(self) -> str | None:
        """Pi 側で、マイクが使える方式（HFP）を使えない理由（bluealsa の設定を調べる）。使えるなら None。"""
        return handsfree_problem(running_bluealsa_profiles())

    def start_scan(self, agent: str = AUDIO_AGENT) -> None:
        """近くの機器を探し始める。

        探している間に見つかった機器は、ペアリングするまで覚えておかれる（止めると約30秒で忘れられる）。
        ペアリングの確認に答える役（agent）も、ここで起動する bluetoothctl が受け持つ。
        agent は、イヤホンなら確認なし（NoInputNoOutput）、マウス・キーボードなら番号を出す（KeyboardDisplay）。
        agent の問い合わせには、bluetoothctl の出力を読んで答える（_read_session）。
        """
        with self._lock:
            if self._session is None or self._session.poll() is not None:
                self._session = subprocess.Popen(
                    [self._bluetoothctl],
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.DEVNULL,
                    text=True,
                )
                self._agent = ""
                threading.Thread(
                    target=self._read_session, args=(self._session,), name="bluetoothctl", daemon=True
                ).start()
                self._send("power on")
            if agent != self._agent:
                if self._agent:
                    self._send("agent off")
                self._send(f"agent {agent}")
                self._send("default-agent")
                self._agent = agent
            self._send("scan on")

    def stop_scan(self) -> None:
        with self._lock:
            if self._session is None:
                return
            if self._session.poll() is None:
                self._send("scan off")
                self._send("quit")
                try:
                    self._session.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    self._session.kill()
            self._session = None

    def scanning(self) -> bool:
        with self._lock:
            return self._session is not None and self._session.poll() is None

    def nearby_audio_devices(self) -> list[BluetoothDevice]:
        """見つかっている機器のうち、イヤホン・ヘッドセットなどの音声機器（接続済み・ペアリング済みを先に並べる）。"""
        devices = []
        for address, name in parse_devices(_run([self._bluetoothctl, "devices"])):
            info = parse_info(_run([self._bluetoothctl, "info", address]))
            if is_audio_device(info):
                alias = info.get("Alias", [name])[0] or name or address
                devices.append(BluetoothDevice(address, alias, is_yes(info, "Paired"), is_yes(info, "Connected")))
        return sorted(devices, key=lambda device: (not device.connected, not device.paired, device.name))

    def nearby_input_devices(self) -> list[BluetoothDevice]:
        """見つかっている機器のうち、マウス・キーボード（接続済み・ペアリング済みを先に並べる）。"""
        devices = []
        for address, name in parse_devices(_run([self._bluetoothctl, "devices"])):
            info = parse_info(_run([self._bluetoothctl, "info", address]))
            if is_input_device(info):
                alias = info.get("Alias", [name])[0] or name or address
                devices.append(BluetoothDevice(address, alias, is_yes(info, "Paired"), is_yes(info, "Connected")))
        return sorted(devices, key=lambda device: (not device.connected, not device.paired, device.name))

    def pair_input(self, address: str) -> str | None:
        """マウス・キーボードをペアリング・信頼登録・接続する。失敗したら理由を返す。

        キーボードは、画面に出した番号をキーボードで打ってもらうことがある（set_passkey_handler で知らせる）。
        信頼登録しておくと、次からは電源を入れたときに機器の方から自動でつながる。
        """
        if not self._is(address, "Paired"):
            self.start_scan(INPUT_AGENT)
            with self._lock:
                self._send(f"pair {address}")
            if not self._wait_until(address, "Paired", INPUT_PAIR_TIMEOUT_SEC):
                return "ペアリングできませんでした（機器をペアリングモードにしてから、もう一度タップしてください）"
        self.stop_scan()  # 検索中は接続が不安定になるので止める
        _run([self._bluetoothctl, "trust", address])
        if not self._is(address, "Connected"):
            _run([self._bluetoothctl, "connect", address], timeout=CONNECT_TIMEOUT_SEC)
            if not self._wait_until(address, "Connected", 10.0):
                return "接続できませんでした（機器のボタンを押すか、電源を入れ直してください）"
        return None

    def pair_and_connect(self, address: str) -> str | None:
        """ペアリング・信頼登録・接続をして、マイクが使える方式（HFP）になるまで待つ。失敗したら理由を返す。"""
        if not self._is(address, "Paired"):
            self.start_scan()  # 自動で答える agent と、機器を覚えておくための検索を動かしておく
            with self._lock:
                self._send(f"pair {address}")
            if not self._wait_until(address, "Paired", PAIR_TIMEOUT_SEC):
                return "ペアリングできませんでした（イヤホンをペアリングモードにしてください）"
        self.stop_scan()  # 検索中は接続が不安定になるので止める
        _run([self._bluetoothctl, "trust", address])
        return self._connect_handsfree(address)

    def try_connect(self, address: str) -> None:
        """つながっていない機器に、一定の間隔で接続を試みる（接続は裏のスレッドで行い、すぐに戻る）。"""
        now = time.monotonic()
        busy = self._reconnect_thread is not None and self._reconnect_thread.is_alive()
        if busy or now - self._last_reconnect < RECONNECT_INTERVAL_SEC:
            return
        self._last_reconnect = now
        log.info("Bluetooth 機器 %s に接続を試みます", address)
        self._reconnect_thread = threading.Thread(
            target=self._reconnect, args=(address,), name="bluetooth-reconnect", daemon=True
        )
        self._reconnect_thread.start()

    def disconnect(self, address: str) -> None:
        _start([self._bluetoothctl, "disconnect", address])

    def remove(self, address: str) -> None:
        """ペアリングの登録を消す（つながっていれば切断される）。"""
        _run([self._bluetoothctl, "remove", address])

    def _reconnect(self, address: str) -> None:
        error = self._connect_handsfree(address)
        if error:
            log.info("Bluetooth 機器 %s に接続できません: %s", address, error)

    def _connect_handsfree(self, address: str) -> str | None:
        """接続して、マイクが使える方式（HFP/HSP）の音声機器ができるまで待つ。失敗したら理由を返す。"""
        if not self._is(address, "Connected"):
            _run([self._bluetoothctl, "connect", address], timeout=CONNECT_TIMEOUT_SEC)
            if not self._wait_until(address, "Connected", 5.0):
                return "接続できませんでした"
        if self._wait_for_handsfree(address, HFP_WAIT_SEC):
            return None
        # Pi から接続したときは、音楽用の方式（A2DP）だけがつながることがあるので、マイクが使える方式を指定してつなぐ
        for uuid in HANDSFREE_UUIDS:
            if self._connect_profile(address, uuid) and self._wait_for_handsfree(address, HFP_WAIT_SEC):
                return None
        log.warning(
            "マイクが使える方式でつながりません。bluealsa の音声機器:\n%s", _run([self._bluealsactl, "list-pcms"]).strip()
        )
        return self.handsfree_problem() or "通話用の方式（HFP）でつながりませんでした"

    def handsfree_connected(self, address: str) -> bool:
        """機器が、マイクが使える方式（HFP/HSP）でつながっているか（bluealsa の音声機器ができているか）。"""
        return has_hfp_pcm(_run([self._bluealsactl, "list-pcms"]), address)

    def _wait_for_handsfree(self, address: str, timeout_sec: float) -> bool:
        deadline = time.monotonic() + timeout_sec
        while not self.handsfree_connected(address):
            if time.monotonic() >= deadline:
                return False
            time.sleep(1.0)
        return True

    def _connect_profile(self, address: str, uuid: str) -> bool:
        """機器の機能（UUID）を指定してつなぐ（BlueZ の Device1.ConnectProfile を呼ぶ）。"""
        path = device_object_path(address, adapter_name())
        args = [self._busctl, "--system", f"--timeout={CONNECT_TIMEOUT_SEC:.0f}", "call", "org.bluez", path]
        result = _run_process(
            [*args, "org.bluez.Device1", "ConnectProfile", "s", uuid], timeout=CONNECT_TIMEOUT_SEC + 5
        )
        if result is None:
            return False
        if result.returncode != 0 and "already connected" not in result.stderr.lower():
            log.info("%s の機能 %s につなげません: %s", address, uuid, result.stderr.strip())
            return False
        return True

    def _is(self, address: str, key: str) -> bool:
        return is_yes(parse_info(_run([self._bluetoothctl, "info", address])), key)

    def _wait_until(self, address: str, key: str, timeout_sec: float) -> bool:
        deadline = time.monotonic() + timeout_sec
        while time.monotonic() < deadline:
            if self._is(address, key):
                return True
            time.sleep(0.5)
        return False

    def _read_session(self, session: subprocess.Popen) -> None:
        """検索用の bluetoothctl の出力を読み、agent の問い合わせに答える。

        「(yes/no):」のように改行せずに答えを待つ問い合わせがあるので、行ではなく届いた分ずつ読む。
        出力を読み続けないと、bluetoothctl が書き込めずに止まってしまう。
        """
        stdout = session.stdout
        if stdout is None:
            return
        pending = ""
        try:
            while chunk := os.read(stdout.fileno(), 4096).decode("utf-8", errors="replace"):
                pending += chunk
                # 問い合わせを1つずつ取り出す（行の終わりか、答えを待つ「: 」まで）
                while (end := _prompt_end(pending)) is not None:
                    self._answer(pending[:end])
                    pending = pending[end:]
                pending = pending[-2000:]
        except (OSError, ValueError):
            pass

    def _answer(self, text: str) -> None:
        prompt = parse_agent_prompt(text)
        if prompt is None:
            return
        kind, number = prompt
        log.info("Bluetooth のペアリングの問い合わせ: %s %s", kind, number)
        if kind == "show":
            self._on_passkey(number)
        elif kind in ("confirm", "yes"):
            with self._lock:
                self._send("yes")
        elif kind == "enter":
            # 古いキーボードは、こちらで決めた番号をキーボードで打ってもらう
            number = f"{int.from_bytes(os.urandom(3), 'big') % 1000000:06d}"
            with self._lock:
                self._send(number)
            self._on_passkey(number)

    def _send(self, command: str) -> None:
        """検索用の bluetoothctl にコマンドを送る（_lock を持った状態で呼ぶ）。"""
        if self._session is None or self._session.stdin is None:
            return
        try:
            self._session.stdin.write(command + "\n")
            self._session.stdin.flush()
        except OSError:
            log.warning("bluetoothctl にコマンドを送れません: %s", command)


def _prompt_end(text: str) -> int | None:
    """text の先頭の問い合わせ（または1行）の終わりの位置。まだ途中なら None。"""
    newline = text.find("\n")
    for marker in ("(yes/no): ", "(yes/no):", "PIN code: ", "passkey (number in 0-999999): "):
        position = text.find(marker)
        if position >= 0 and (newline < 0 or position < newline):
            return position + len(marker)
    return newline + 1 if newline >= 0 else None


def _run(args: list[str], timeout: float = COMMAND_TIMEOUT_SEC) -> str:
    result = _run_process(args, timeout)
    return result.stdout if result is not None else ""


def _run_process(args: list[str], timeout: float = COMMAND_TIMEOUT_SEC) -> subprocess.CompletedProcess | None:
    try:
        return subprocess.run(args, capture_output=True, text=True, timeout=timeout)
    except (OSError, subprocess.TimeoutExpired) as error:
        log.warning("%s を実行できません: %s", " ".join(args), error)
        return None


def _start(args: list[str]) -> None:
    """終わるのを待たずにコマンドを実行する（画面や音声の処理を止めないため）。"""
    try:
        subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError as error:
        log.error("%s を実行できません: %s", " ".join(args), error)
