"""ハングルの学習（メニューの「ハングル学習」）の中身: 文字の表、接客フレーズ、読む練習のクイズ、発音の判定。

画面（ui.py）とは別にしてあり、ここは pygame も音声認識も使わない（PC でそのまま試験できる）。

- 文字と発音: 母音・子音・濃音・複合母音。1 字ごとに、音節（子音は ㅏ を付けた字、母音は ㅇ を付けた字）、
  カタカナの読み、日本語話者向けの発音のコツ、例の単語。カタカナは korean_kana.to_katakana で作る（アプリの発音記号と同じ読み）。
- 接客フレーズ: お店で使う短い文（日本語 → 韓国語）。選んでいる業種（industries.py）の文も足す。
- 読む練習: 韓国語の単語を見て、日本語の意味を選ぶ。単語は業種の用語集（industry_terms_*.py）から取る。
- 発音の判定: 認識した文と手本の近さ（字を子音・母音に分けて比べる）を 0〜1 で返す。
"""

from __future__ import annotations

import random
import re
from dataclasses import dataclass

from .korean_kana import to_katakana

_BASE = 0xAC00
_CHO_ORDER = "ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ"
_JUNG_ORDER = "ㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ"
_JONG_ORDER = ("", "ㄱ", "ㄲ", "ㄳ", "ㄴ", "ㄵ", "ㄶ", "ㄷ", "ㄹ", "ㄺ", "ㄻ", "ㄼ", "ㄽ", "ㄾ", "ㄿ", "ㅀ", "ㅁ", "ㅂ", "ㅄ", "ㅅ", "ㅆ", "ㅇ", "ㅈ", "ㅊ", "ㅋ", "ㅌ", "ㅍ", "ㅎ")


_KANA_OVERRIDE = {"ㅢ": "ウィ"}

LANG = "ko"


def kana_of(text: str) -> str:
    """ハングルの文のカタカナの読み（画面の発音表示と同じ変換）。"""
    return to_katakana(text)


@dataclass(frozen=True)
class Letter:
    char: str  # ㄱ ㅏ など
    roman: str  # 改訂ローマ字（g/k, a …）
    tip: str  # 発音のコツ（日本語）
    example: str  # 例の単語（ハングル）
    example_ja: str  # 例の単語の意味

    @property
    def syllable(self) -> str:
        """この字を 1 つの音節にした字。子音は ㅏ を付ける（ㄱ → 가）、母音は ㅇ を付ける（ㅏ → 아）。"""
        if self.char in _CHO_ORDER and self.char != "ㅇ":
            return chr(_BASE + (_CHO_ORDER.index(self.char) * 21 + _JUNG_ORDER.index("ㅏ")) * 28)
        if self.char == "ㅇ":
            return "아"
        return chr(_BASE + (_CHO_ORDER.index("ㅇ") * 21 + _JUNG_ORDER.index(self.char)) * 28)

    @property
    def display(self) -> str:
        """大きく見せる文字（音節）。"""
        return self.syllable

    @property
    def say(self) -> str:
        """押したときに読み上げる文（音節）。"""
        return self.syllable

    @property
    def kana(self) -> str:
        """音節のカタカナ読み（語頭の読み）。発音記号の変換（to_katakana）は ㅢ を「イ」にするが、字の読みとしては「ウィ」と教える。"""
        return _KANA_OVERRIDE.get(self.char) or to_katakana(self.syllable)

    @property
    def example_kana(self) -> str:
        return to_katakana(self.example)


def _letters(rows: str) -> tuple[Letter, ...]:
    """「文字|ローマ字|コツ|例|意味」を 1 行にして、改行でつなぐ。"""
    return tuple(Letter(*(part.strip() for part in line.split("|"))) for line in rows.strip().splitlines())


VOWELS = _letters(
    """
ㅏ|a|口を大きく開けて「ア」|아기|赤ちゃん
ㅑ|ya|「ヤ」。ㅏ に「イ」の音を足す|야구|野球
ㅓ|eo|口を大きく開けた「オ」（ㅗ より口が広い）|어머니|お母さん
ㅕ|yeo|「ヨ」に近いが口は大きく開ける|여자|女性
ㅗ|o|唇を丸めてすぼめた「オ」|오리|アヒル
ㅛ|yo|唇を丸めた「ヨ」|요리|料理
ㅜ|u|唇を丸めて突き出した「ウ」|우유|牛乳
ㅠ|yu|唇を丸めた「ユ」|유리|ガラス
ㅡ|eu|唇を横に引いた「ウ」（歯を見せる）|음악|音楽
ㅣ|i|口を横に引いた「イ」|이름|名前
"""
)

COMPOUND_VOWELS = _letters(
    """
ㅐ|ae|「エ」（ㅔ とほぼ同じ音）|개|犬
ㅔ|e|「エ」（ㅐ とほぼ同じ音）|게|カニ
ㅒ|yae|「イェ」|얘기|話
ㅖ|ye|「イェ」|시계|時計
ㅘ|wa|「ワ」（ㅗ + ㅏ）|과일|果物
ㅙ|wae|「ウェ」（ㅗ + ㅐ）|왜|なぜ
ㅚ|oe|「ウェ」（ㅗ + ㅣ）|외국|外国
ㅝ|wo|「ウォ」（ㅜ + ㅓ）|뭐|何
ㅞ|we|「ウェ」（ㅜ + ㅔ）|웨이터|ウェイター
ㅟ|wi|「ウィ」（ㅜ + ㅣ）|귀|耳
ㅢ|ui|「ウィ」。語頭は「ウイ」、語中の助詞は「エ」と読む|의사|医者
"""
)

CONSONANTS = _letters(
    """
ㄱ|g/k|語頭は「カ」に近い清音、語中は濁って「ガ」|가방|かばん
ㄴ|n|「ナ」行|나무|木
ㄷ|d/t|語頭は「タ」に近い清音、語中は濁って「ダ」|다리|足・橋
ㄹ|r/l|「ラ」行（母音の前は軽く弾く。パッチムは舌を上につける）|라면|ラーメン
ㅁ|m|「マ」行|마음|心
ㅂ|b/p|語頭は「パ」に近い清音、語中は濁って「バ」|바다|海
ㅅ|s|「サ」行（ㅣ の前は「シ」）|사과|りんご
ㅇ|-/ng|母音の前では音なし。パッチムでは「ン」（ng）|아이|子ども
ㅈ|j|「チャ」行（語中は「ジャ」）|자전거|自転車
ㅊ|ch|「チャ」行。息を強く出す|차|車・お茶
ㅋ|k|「カ」行。息を強く出す|코|鼻
ㅌ|t|「タ」行。息を強く出す|토끼|うさぎ
ㅍ|p|「パ」行。息を強く出す|포도|ぶどう
ㅎ|h|「ハ」行|하늘|空
"""
)

TENSE_CONSONANTS = _letters(
    """
ㄲ|kk|のどを締めて、息を出さずに「ッカ」|꿈|夢
ㄸ|tt|のどを締めて、息を出さずに「ッタ」|딸|娘
ㅃ|pp|のどを締めて、息を出さずに「ッパ」|빵|パン
ㅆ|ss|のどを締めて「ッサ」|아저씨|おじさん
ㅉ|jj|のどを締めて「ッチャ」|짜다|塩辛い
"""
)

LETTER_GROUPS: tuple[tuple[str, str, tuple[Letter, ...]], ...] = (
    ("vowel", "母音", VOWELS),
    ("consonant", "子音", CONSONANTS),
    ("tense", "濃音", TENSE_CONSONANTS),
    ("compound", "複合母音", COMPOUND_VOWELS),
)
ALL_LETTERS = tuple(letter for _, _, letters in LETTER_GROUPS for letter in letters)

# 接客フレーズ（日本語, 韓国語）。お店の人が、お客様に言う言葉と、聞かれる言葉
PHRASES: tuple[tuple[str, str], ...] = (
    ("いらっしゃいませ", "어서 오세요"),
    ("ありがとうございます", "감사합니다"),
    ("こちらへどうぞ", "이쪽으로 오세요"),
    ("少々お待ちください", "잠시만 기다려 주세요"),
    ("お待たせしました", "오래 기다리셨습니다"),
    ("何名様ですか？", "몇 분이세요?"),
    ("ご注文はお決まりですか？", "주문하시겠어요?"),
    ("ごゆっくりどうぞ", "천천히 드세요"),
    ("お水はセルフサービスです", "물은 셀프예요"),
    ("ラストオーダーです", "주문 마감 시간이에요"),
    ("お会計は1,500円です", "계산은 1,500엔입니다"),
    ("カードが使えます", "카드 사용 가능합니다"),
    ("現金のみです", "현금만 가능합니다"),
    ("袋は必要ですか？", "봉투 필요하세요?"),
    ("お箸はお付けしますか？", "젓가락은 필요하신가요?"),
    ("温めますか？", "데워 드릴까요?"),
    ("領収書をお渡しします", "영수증 드릴게요"),
    ("写真撮影はご遠慮ください", "사진 촬영은 삼가 주세요"),
    ("トイレはあちらです", "화장실은 저쪽이에요"),
    ("パスポートを見せてください", "여권을 보여 주세요"),
    ("免税の手続きができます", "면세 수속이 가능합니다"),
    ("試着室はこちらです", "탈의실은 이쪽이에요"),
    ("サイズはいかがですか？", "사이즈는 어떠세요?"),
    ("在庫を確認します", "재고를 확인해 보겠습니다"),
    ("チェックインは15時からです", "체크인은 15시부터예요"),
    ("朝食は7時からです", "조식은 7시부터예요"),
    ("駅はまっすぐ行って右です", "역은 쭉 가서 오른쪽이에요"),
    ("次の電車は10分後です", "다음 열차는 10분 후예요"),
    ("もう一度お願いします", "다시 한번 말씀해 주세요"),
    ("大丈夫ですか？", "괜찮으세요?"),
    ("気をつけてお帰りください", "조심해서 가세요"),
    ("またお越しください", "또 오세요"),
)

_SENTENCE_JA = re.compile(r"(です|ます|ください|ませんか|ございます|お願いします|ますか)[。？]?$|[？?]$")
_HANGUL = re.compile(r"[가-힣]")


def _all_rows() -> list[tuple[str, str]]:
    """業種の用語集の（日本語, 韓国語）の組。業種の番号は問わない。"""
    from . import industries  # 循環を避けるため、使うときに読む

    pairs: list[tuple[str, str]] = []
    for rows in (*industries._COMMON_ROWS.values(), *industries._ROWS.values()):
        for row in rows:
            if row[1]:
                pairs.append((row[0], row[1]))
    return pairs


def industry_phrases(selected: tuple[str, ...]) -> list[tuple[str, str]]:
    """選んでいる業種の用語集にある、文の形のもの（「〜です」「〜ください」「〜ですか」）。何も選んでいなければ空。"""
    if not selected:
        return []
    from . import industries

    seen: set[str] = set()
    out: list[tuple[str, str]] = []
    categories = {industries.CATEGORY_OF[i] for i in selected if i in industries.CATEGORY_OF}
    rows = [row for c in categories for row in industries._COMMON_ROWS.get(c, ())]
    rows += [row for i in selected for row in industries._ROWS.get(i, ())]
    for row in rows:
        ja, ko = row[0], row[1]
        if ko and _SENTENCE_JA.search(ja) and _HANGUL.search(ko) and ja not in seen and len(ko) <= 40:
            seen.add(ja)
            out.append((ja, ko))
    return out


def phrase_deck(selected: tuple[str, ...] = ()) -> list[tuple[str, str]]:
    """接客フレーズの一覧（決まった文 + 選んでいる業種の文）。"""
    base = list(PHRASES)
    known = {ja for ja, _ in base}
    return base + [pair for pair in industry_phrases(selected) if pair[0] not in known]


def word_pool() -> list[tuple[str, str]]:
    """読む練習の単語（韓国語, 日本語の意味）。短い名詞や用語だけを使う。"""
    seen: set[str] = set()
    pool: list[tuple[str, str]] = []
    for ja, ko in _all_rows():
        if not _HANGUL.search(ko) or len(ko) > 9 or len(ja) > 12 or _SENTENCE_JA.search(ja):
            continue
        if re.search(r"[A-Za-z0-9（）()?？]", ko) or ko in seen:
            continue
        seen.add(ko)
        pool.append((ko, ja))
    for letter in ALL_LETTERS:
        if letter.example not in seen:
            seen.add(letter.example)
            pool.append((letter.example, letter.example_ja))
    return pool


@dataclass(frozen=True)
class Question:
    """4 択の問題。prompt（見せる文字）、choices（選択肢）、answer（正解の番号）、speak（聞かせる韓国語）、detail（答えたあとの説明）。"""

    prompt: str
    choices: tuple[str, ...]
    answer: int
    speak: str
    detail: str


def _choices(correct: str, others: list[str], rng: random.Random, count: int = 4) -> tuple[tuple[str, ...], int]:
    wrong = [o for o in dict.fromkeys(others) if o != correct]
    rng.shuffle(wrong)
    items = wrong[: count - 1] + [correct]
    rng.shuffle(items)
    return tuple(items), items.index(correct)


def letter_question(rng: random.Random, groups: tuple[str, ...] = ("vowel", "consonant", "tense", "compound")) -> Question:
    """文字の読み当て: 音節を見て、カタカナの読みを選ぶ。"""
    pool = [letter for gid, _, letters in LETTER_GROUPS if gid in groups for letter in letters]
    letter = rng.choice(pool)
    # 同じカタカナになる字（어 と 오 など）を選択肢に混ぜない
    choices, answer = _choices(letter.kana, [other.kana for other in pool], rng)
    detail = f"{letter.char}（{letter.roman}）: {letter.tip}"
    return Question(letter.syllable, choices, answer, letter.syllable, detail)


def word_question(rng: random.Random, pool: list[tuple[str, str]] | None = None) -> Question:
    """読む練習: 韓国語の単語を見て、日本語の意味を選ぶ。"""
    pool = pool if pool is not None else word_pool()
    ko, ja = rng.choice(pool)
    choices, answer = _choices(ja, [other for _, other in pool], rng)
    return Question(ko, choices, answer, ko, f"{ko}（{to_katakana(ko)}）= {ja}")


# --- 発音の判定 ---


def _jamo(text: str) -> list[str]:
    """ハングルの字を、子音・母音の並びに分ける（それ以外の字は、そのまま。記号と空白は捨てる）。"""
    out: list[str] = []
    for ch in text:
        code = ord(ch)
        if 0xAC00 <= code <= 0xD7A3:
            index = code - _BASE
            cho, rest = divmod(index, 21 * 28)
            jung, jong = divmod(rest, 28)
            out.append(_CHO_ORDER[cho])
            out.append(_JUNG_ORDER[jung])
            if jong:
                out.append(_JONG_ORDER[jong])
        elif ch.isalnum():
            out.append(ch.lower())
    return out


def similarity(target: str, heard: str) -> float:
    """手本と、認識した文の近さ（0〜1）。子音・母音ごとの編集距離で比べる。"""
    a, b = _jamo(target), _jamo(heard)
    if not a or not b:
        return 0.0
    previous = list(range(len(b) + 1))
    for i, x in enumerate(a, 1):
        current = [i]
        for j, y in enumerate(b, 1):
            current.append(min(previous[j] + 1, current[j - 1] + 1, previous[j - 1] + (x != y)))
        previous = current
    return max(0.0, 1.0 - previous[-1] / max(len(a), len(b)))


def verdict(score: float) -> tuple[str, str]:
    """点数から（印, ひと言）。"""
    if score >= 0.9:
        return "◎", "とても上手です"
    if score >= 0.7:
        return "○", "通じます"
    if score >= 0.5:
        return "△", "もう少しです。もう一度"
    return "×", "もう一度、手本をよく聞いて"
