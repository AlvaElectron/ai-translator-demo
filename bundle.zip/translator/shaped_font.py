"""文字の組み立て（シェーピング）が必要な文字を、pygame.font（SDL_ttf + HarfBuzz）で描く書体。

画面の文字は pygame.freetype で描いているが、pygame.freetype はデーヴァナーガリー文字（ヒンディー語）を組み立てない
（2026-11-14 に CM5 で確認: 「मंजिल」の母音記号 ि が後ろの文字の後ろに付いて「मंजलि」になり、「क्या」の結合文字も崩れた）。
pygame.font（SDL_ttf 2.24、HarfBuzz 付き）は、set_script("Deva") で正しく描く。
そこで、ui.py が pygame.freetype.Font に対して使っている分だけの関数（render・render_to・get_rect・
get_sized_ascender・origin）を持つ入れ物を作り、ヒンディー語の書体として fonts の辞書に入れる。
"""

from __future__ import annotations

import pygame


class ShapedFont:
    """pygame.freetype.Font の代わりに使う、SDL_ttf で文字を組み立てて描く書体（大きさごとに読み込んで使い回す）。"""

    def __init__(self, path: str, script: str) -> None:
        if not pygame.font.get_init():
            pygame.font.init()
        self._path = path
        self._script = script
        self._sized: dict[int, pygame.font.Font] = {}
        self.origin = False  # True なら、render_to の y 座標をベースラインとして扱う（pygame.freetype と同じ）
        self._font(16)  # ファイルが読めないときは、ここで例外にする（呼び出し側で、ほかの書体に切り替える）
        self.name = path

    def _font(self, size: int) -> pygame.font.Font:
        size = max(1, int(size))
        font = self._sized.get(size)
        if font is None:
            font = pygame.font.Font(self._path, size)
            font.set_script(self._script)
            self._sized[size] = font
        return font

    def render(self, text: str, fgcolor=(255, 255, 255), bgcolor=None, style: int = 0, rotation: int = 0, size: int = 16):
        surface = self._font(size).render(text, True, fgcolor, bgcolor)
        return surface, surface.get_rect()

    def render_to(self, surf: pygame.Surface, dest, text: str, fgcolor=(255, 255, 255), bgcolor=None, style: int = 0, rotation: int = 0, size: int = 16):
        font = self._font(size)
        surface = font.render(text, True, fgcolor, bgcolor)
        x, y = (dest.x, dest.y) if isinstance(dest, pygame.Rect) else dest
        if self.origin:
            y -= font.get_ascent()  # 受け取った y はベースライン。SDL_ttf の画像は、上端から描く
        return surf.blit(surface, (x, y))

    def get_rect(self, text: str, style: int = 0, rotation: int = 0, size: int = 16) -> pygame.Rect:
        font = self._font(size)
        width, height = font.size(text)
        return pygame.Rect(0, font.get_ascent(), width, height)

    def get_sized_ascender(self, size: int = 16) -> int:
        return self._font(size).get_ascent()

    def get_sized_height(self, size: int = 16) -> int:
        return self._font(size).get_height()
