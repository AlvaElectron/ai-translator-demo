"""ヘブライ語のカタカナ（2026-11-24）。

ヘブライ語は、ふつう母音の記号（ニクード）を書かないので、つづりだけでは読みが決まらない。そこで 2 段にする。
1. 母音の記号を付ける: nakdimon のモデル（ONNX、約 21MB、CPU）。
   推論の部分は nakdimon 0.2.1（MIT License、Copyright 2022 Elazar Gershuni、github.com/elazarg/nakdimon）の
   predict.py・dataset.py・hebrew.py を短くしたもの。モデル（パッケージに入っている Nakdimon.onnx、MIT）は
   models/nakdimon/ に置く。無ければ、カタカナは出さない。
2. 母音の付いた字 → 音の並び → カタカナ（more_kana.tokens_to_kana）。今のイスラエルの読み方にする
   （ב・כ・פ はダゲシュの有無で b/v・k/x・p/f、ח・כ は「ハ行」、א・ע は読まない、ש は点の位置で sh/s）。
   語の頭のシュヴァは「エ」と読み、ほかのシュヴァは読まない。ו・י は、母音の字として使われているときは子音にしない。
"""

from __future__ import annotations

import logging
import re
import unicodedata
from pathlib import Path

from .more_kana import Tokens, tokens_to_kana

log = logging.getLogger(__name__)

MODEL_DIR = Path(__file__).resolve().parent.parent / "models" / "nakdimon"

# --- 1. 母音の記号を付ける（nakdimon） ---

RAFE = "ֿ"
SHVA, HATAF_SEGOL, HATAF_PATAH, HATAF_KAMATZ = "ְ", "ֱ", "ֲ", "ֳ"
HIRIK, TSERE, SEGOL, PATAH, KAMATZ, HOLAM = "ִ", "ֵ", "ֶ", "ַ", "ָ", "ֹ"
KUBUTZ, DAGESH = "ֻ", "ּ"  # ו の DAGESH は シュルク（u）
SHIN_DOT, SIN_DOT = "ׁ", "ׂ"
_LETTERS = [chr(c) for c in range(0x05D0, 0x05EA + 1)]
_VALID = [" ", "!", '"', "'", "(", ")", ",", "-", ".", ":", ";", "?"] + _LETTERS
_INPUT_TABLE = {c: i for i, c in enumerate(["", "H", "O", "5"] + _VALID)}
_NIQQUD_TABLE = ["", RAFE] + [chr(c) for c in range(0x05B0, 0x05BC + 1)] + [PATAH]
_DAGESH_TABLE = ["", RAFE, DAGESH]
_SIN_TABLE = ["", RAFE, SHIN_DOT, SIN_DOT]
_FINALS = dict(zip("ךםןףץ", "כמנפצ"))
_ANY_MARK = re.compile("[֑-ׇ]")


def _normalize(c: str) -> str:
    if c in _VALID:
        return c
    if c in _FINALS:
        return _FINALS[c]
    if c in "\n\t":
        return " "
    if c in "־‒–—―−":
        return "-"
    if c in "´‘’׳":
        return "'"
    if c in "“”״":
        return '"'
    if c.isdigit():
        return "5"
    return "O"


def _can_dagesh(c: str) -> bool:
    return c in "בגדהוזטיכלמנספצקשתךף"


def _can_niqqud(c: str) -> bool:
    return c in "אבגדהוזחטיכלמנסעפצקרשתךן"


def strip_marks(text: str) -> str:
    """母音の記号・カンティレーションを消し、空白をまとめる。"""
    text = unicodedata.normalize("NFC", text)
    return re.sub(r"\s+", " ", _ANY_MARK.sub("", text)).strip()


class Diacritizer:
    """母音の記号を付ける（nakdimon の ONNX モデル）。"""

    def __init__(self, model_dir: Path = MODEL_DIR, num_threads: int = 1) -> None:
        import numpy as np
        import onnxruntime as ort

        options = ort.SessionOptions()
        options.intra_op_num_threads = num_threads
        self._np = np
        self._session = ort.InferenceSession(str(model_dir / "Nakdimon.onnx"), sess_options=options,
                                             providers=["CPUExecutionProvider"])
        self._input = self._session.get_inputs()[0].name

    def diacritize(self, text: str) -> str:
        base = strip_marks(text)
        if not base:
            return text
        np = self._np
        # 文の終わりに句読点が無いと、最後の語の母音をよく間違える（תודה → תּוֹדְה）。読ませるときだけ「.」を足す
        added = not base.endswith((".", "!", "?", ",", ":", ";", '"', ")"))
        if added:
            base += "."
        ids = np.asarray([[_INPUT_TABLE[_normalize(c)] for c in base]], dtype=np.int32)
        n_out, d_out, s_out = self._session.run(None, {self._input: ids})
        niqqud, dagesh, sin = (a[0].argmax(axis=-1).tolist() for a in (n_out, d_out, s_out))
        out: list[str] = []
        for c, n, d, s in zip(base, niqqud, dagesh, sin):
            out.append(c)
            if _can_dagesh(c):
                out.append(_DAGESH_TABLE[d])
            if c == "ש":
                out.append(_SIN_TABLE[s])
            if _can_niqqud(c):
                out.append(_NIQQUD_TABLE[n])
        result = "".join(out).replace(RAFE, "")
        return result[:-1] if added else result


# --- 2. 母音の付いた字 → カタカナ ---

_VOWELS = {
    PATAH: "a", KAMATZ: "a", HATAF_PATAH: "a", HATAF_KAMATZ: "o",
    TSERE: "e", SEGOL: "e", HATAF_SEGOL: "e", HIRIK: "i", HOLAM: "o", KUBUTZ: "u",
}
_PLAIN = {
    "ג": "g", "ד": "d", "ז": "z", "ח": "x", "ט": "t", "ל": "r", "מ": "m", "נ": "n", "ס": "s",
    "צ": "ts", "ק": "k", "ר": "r", "ת": "t", "ה": "h", "י": "y",
}
_GERESH = {"ג": "j", "ז": "zh", "צ": "ch"}  # ג׳ ジ・ז׳ ジュ・צ׳ チ（外来語）
_WORD = re.compile("[א-תְ-ּׁׂ'׳]+")
_PUNCTUATION = str.maketrans({"־": "-", "׃": ".", "״": '"'})


def _letters(word: str) -> list[tuple[str, set[str], bool]]:
    """字ごとに（字、記号、ゲレシュ付きか）。語末の形（ך など）はふつうの形にする。"""
    out: list[tuple[str, set[str], bool]] = []
    for c in word:
        if "א" <= c <= "ת":
            out.append((_FINALS.get(c, c), set(), False))
        elif c in "'׳" and out:
            out[-1] = (out[-1][0], out[-1][1], True)
        elif out:
            out[-1][1].add(c)
    return out


def word_tokens(word: str) -> Tokens:
    """母音の付いたヘブライ語の 1 語 → 音の並び。"""
    letters = _letters(word)
    toks: Tokens = []
    last_vowel = ""  # いちばん近くで読んだ母音（読まない字を飛ばす）
    prev_vowel = ""  # すぐ前の字の母音（無ければ ""）
    for j, (c, marks, geresh) in enumerate(letters):
        last = j == len(letters) - 1
        before, prev_vowel = prev_vowel, ""
        vowel = next((_VOWELS[m] for m in marks if m in _VOWELS), "")
        if not vowel and SHVA in marks and j == 0 and not last:
            vowel = "e"  # 語の頭のシュヴァは読む
        if c == "ו":
            if DAGESH in marks and not vowel:  # シュルク
                toks.append("u")
                last_vowel = prev_vowel = "u"
                continue
            if vowel == "o" and not before:  # ホレム・マレー（前の子音の o）
                toks.append("o")
                last_vowel = prev_vowel = "o"
                continue
            if not vowel:
                if j + 1 < len(letters) and letters[j + 1][0] == "ו":
                    toks.append("v")  # וו は v
                continue  # 母音の字（読まない）
            toks += ["v", vowel]
            last_vowel = prev_vowel = vowel
            continue
        if c == "י" and not vowel:
            if last_vowel and last_vowel != "i":
                toks.append("y")  # ai・oi・ei の i
            continue
        if c in "אע":
            if vowel and last and vowel == "a" and last_vowel and last_vowel != "a":
                toks.append("a")  # 語末のパタハ・ガヌーヴ（רוּחַ の類い）
            elif vowel:
                toks.append(vowel)
            last_vowel = vowel or last_vowel  # 母音の無い א・ע は読まない（前の母音のまま）
            prev_vowel = vowel
            continue
        nxt = letters[j + 1] if j + 1 < len(letters) else None
        vav_vowel = nxt is not None and nxt[0] == "ו" and (DAGESH in nxt[1] or HOLAM in nxt[1])
        if c == "ה" and not vowel and DAGESH not in marks and not vav_vowel:
            continue  # 母音の字（語末の ה など）。前の母音のまま
        if c == "ב":
            cons = "b" if DAGESH in marks else "v"
        elif c == "כ":
            cons = "k" if DAGESH in marks else "x"
        elif c == "פ":
            cons = "p" if DAGESH in marks else "f"
        elif c == "ש":
            cons = "s" if SIN_DOT in marks else "sh"
        elif geresh and c in _GERESH:
            cons = _GERESH[c]
        else:
            cons = _PLAIN.get(c, "")
        if last and c in "חה" and vowel == "a" and last_vowel and last_vowel != "a":
            toks += ["a", cons]  # パタハ・ガヌーヴ（ruach → ルーアハ）
            continue
        if cons:
            toks.append(cons)
        if vowel:
            toks.append(vowel)
        last_vowel = prev_vowel = vowel
    return toks


def vocalized_to_kana(text: str) -> str:
    """母音の記号が付いたヘブライ語の文 → カタカナ。"""
    def convert(match: re.Match[str]) -> str:
        word = match.group()
        return tokens_to_kana(word_tokens(word)) or word

    out = _WORD.sub(convert, unicodedata.normalize("NFC", text).translate(_PUNCTUATION))
    return re.sub(r"\s+", " ", out).strip()


def converter():
    """ヘブライ語の文 → カタカナの関数（モデルが無い・読めないときは None）。"""
    if not (MODEL_DIR / "Nakdimon.onnx").exists():
        log.warning("models/nakdimon/Nakdimon.onnx が無いため、ヘブライ語のカタカナは表示しません")
        return None
    try:
        diacritizer = Diacritizer()
    except Exception:
        log.exception("ヘブライ語の母音記号のモデルを読めません（models/nakdimon）")
        return None
    from .number_words_more import spell_numbers

    return lambda text: vocalized_to_kana(diacritizer.diacritize(spell_numbers(text, "he")))
