"""キーボードからの文字入力（Bluetooth・USB キーボード。Ver.2）: キーの名前と、言語ごとの文字の組み立て。

話す代わりに文字を打って、翻訳に送るために使う（pygame・evdev に依存しない）。

- 日本語: ローマ字をひらがなにする（漢字への変換はしない。Shift を押しながら打った英字は、英字のまま）
- 韓国語: 2ボル式（두벌식）の配列で、字母を組み立ててハングルにする
- タイ語: ケドマニー（Kedmanee）配列
- 英語・フランス語・ポルトガル語: 打った文字のまま（US 配列。フランス語・ポルトガル語のアクセント記号は打てない）
- ロシア語: ЙЦУКЕН 配列
- 中国語・広東語: 漢字の入力（ピンインからの変換など）はまだ作っていないので、打てない
"""

from __future__ import annotations

from dataclasses import dataclass

from .langs import EN, FR, FUK, HOK, JA, KO, OSA, PT, RU, TH


@dataclass(frozen=True)
class KeyPress:
    """押されたキー。name は evdev の名前から KEY_ を除いて小文字にしたもの（"a"、"space"、"enter" など）。

    char は US 配列で打たれる文字（Shift を反映したもの。文字でないキーは空）。
    """

    name: str
    char: str = ""
    shift: bool = False
    ctrl: bool = False


# evdev のキーの名前 → (そのままの文字, Shift を押したときの文字)。US 配列
US_KEYMAP: dict[str, tuple[str, str]] = {
    **{chr(code): (chr(code), chr(code).upper()) for code in range(ord("a"), ord("z") + 1)},
    "1": ("1", "!"), "2": ("2", "@"), "3": ("3", "#"), "4": ("4", "$"), "5": ("5", "%"),
    "6": ("6", "^"), "7": ("7", "&"), "8": ("8", "*"), "9": ("9", "("), "0": ("0", ")"),
    "minus": ("-", "_"), "equal": ("=", "+"), "leftbrace": ("[", "{"), "rightbrace": ("]", "}"),
    "backslash": ("\\", "|"), "semicolon": (";", ":"), "apostrophe": ("'", '"'), "grave": ("`", "~"),
    "comma": (",", "<"), "dot": (".", ">"), "slash": ("/", "?"), "space": (" ", " "),
    # 日本語配列（JIS）のキーボードにだけある「ろ」「￥」のキー
    "ro": ("\\", "_"), "yen": ("\\", "|"),
}
MODIFIERS = {"leftshift", "rightshift", "leftctrl", "rightctrl", "leftalt", "rightalt", "leftmeta", "rightmeta", "capslock"}


def key_press(name: str, shift: bool = False, ctrl: bool = False) -> KeyPress:
    """キーの名前（"a"・"enter" など）から KeyPress を作る。"""
    chars = US_KEYMAP.get(name)
    char = "" if chars is None or ctrl else chars[1 if shift else 0]
    return KeyPress(name, char, shift, ctrl)


class PlainComposer:
    """英語・フランス語: 打った文字をそのまま使う。"""

    def __init__(self) -> None:
        self.text = ""

    def feed(self, key: KeyPress) -> None:
        self.text += key.char

    def backspace(self) -> None:
        self.text = self.text[:-1]

    def finish(self) -> str:
        return self.text

    @property
    def display(self) -> str:
        return self.text


# ローマ字 → ひらがな（長い綴りから順に当てはめる）
_ROMAJI = {
    "a": "あ", "i": "い", "u": "う", "e": "え", "o": "お",
    "ka": "か", "ki": "き", "ku": "く", "ke": "け", "ko": "こ",
    "sa": "さ", "si": "し", "shi": "し", "su": "す", "se": "せ", "so": "そ",
    "ta": "た", "ti": "ち", "chi": "ち", "tu": "つ", "tsu": "つ", "te": "て", "to": "と",
    "na": "な", "ni": "に", "nu": "ぬ", "ne": "ね", "no": "の",
    "ha": "は", "hi": "ひ", "hu": "ふ", "fu": "ふ", "he": "へ", "ho": "ほ",
    "ma": "ま", "mi": "み", "mu": "む", "me": "め", "mo": "も",
    "ya": "や", "yu": "ゆ", "yo": "よ",
    "ra": "ら", "ri": "り", "ru": "る", "re": "れ", "ro": "ろ",
    "la": "ら", "li": "り", "lu": "る", "le": "れ", "lo": "ろ",
    "wa": "わ", "wi": "うぃ", "we": "うぇ", "wo": "を", "n'": "ん", "xn": "ん",
    "ga": "が", "gi": "ぎ", "gu": "ぐ", "ge": "げ", "go": "ご",
    "za": "ざ", "zi": "じ", "ji": "じ", "zu": "ず", "ze": "ぜ", "zo": "ぞ",
    "da": "だ", "di": "ぢ", "du": "づ", "de": "で", "do": "ど",
    "ba": "ば", "bi": "び", "bu": "ぶ", "be": "べ", "bo": "ぼ",
    "pa": "ぱ", "pi": "ぴ", "pu": "ぷ", "pe": "ぺ", "po": "ぽ",
    "va": "ゔぁ", "vi": "ゔぃ", "vu": "ゔ", "ve": "ゔぇ", "vo": "ゔぉ",
    "fa": "ふぁ", "fi": "ふぃ", "fe": "ふぇ", "fo": "ふぉ",
    "ja": "じゃ", "ju": "じゅ", "je": "じぇ", "jo": "じょ",
    "sha": "しゃ", "shu": "しゅ", "she": "しぇ", "sho": "しょ",
    "cha": "ちゃ", "chu": "ちゅ", "che": "ちぇ", "cho": "ちょ",
    "tsa": "つぁ", "thi": "てぃ", "dhi": "でぃ", "twu": "とぅ", "dwu": "どぅ",
    "xa": "ぁ", "xi": "ぃ", "xu": "ぅ", "xe": "ぇ", "xo": "ぉ", "xtu": "っ", "xtsu": "っ",
    "xya": "ゃ", "xyu": "ゅ", "xyo": "ょ", "xwa": "ゎ",
    "-": "ー", ",": "、", ".": "。", "?": "？", "!": "！", "[": "「", "]": "」",
}
for _consonant, _kana in (
    ("k", "き"), ("s", "し"), ("sh", "し"), ("t", "ち"), ("ch", "ち"), ("c", "ち"), ("n", "に"),
    ("h", "ひ"), ("m", "み"), ("r", "り"), ("g", "ぎ"), ("z", "じ"), ("j", "じ"), ("d", "ぢ"),
    ("b", "び"), ("p", "ぴ"),
):
    # 拗音（kya → きゃ、sha → しゃ など）
    for _vowel, _small in (("a", "ゃ"), ("u", "ゅ"), ("o", "ょ")):
        key = _consonant + ("" if _consonant in ("sh", "ch", "j") else "y") + _vowel
        _ROMAJI.setdefault(key, _kana + _small)
    _ROMAJI.setdefault(_consonant + "ye", _kana + "ぇ")
_ROMAJI_MAX = max(map(len, _ROMAJI))
_VOWELS = frozenset("aiueo")


class RomajiComposer:
    """日本語: ローマ字をひらがなにする。まだかなにならない綴りは、英字のまま後ろに出しておく。"""

    def __init__(self) -> None:
        self.text = ""
        self.pending = ""

    def feed(self, key: KeyPress) -> None:
        char = key.char
        if not char:
            return
        if key.shift and char.isalpha():
            self._flush_n()
            self.text += self.pending + char  # Shift を押した英字は、英字のまま（「Tokyo」「OK」など）
            self.pending = ""
            return
        self.pending += char.lower()
        self._convert()

    def backspace(self) -> None:
        if self.pending:
            self.pending = self.pending[:-1]
        else:
            self.text = self.text[:-1]

    def finish(self) -> str:
        self._flush_n()
        text, self.text, self.pending = self.text + self.pending, "", ""
        return text

    @property
    def display(self) -> str:
        return self.text + self.pending

    def _flush_n(self) -> None:
        """最後の「n」は、打ち終わったら「ん」にする（「ほn」→「ほん」）。"""
        if self.pending in ("n", "nn"):
            self.text += "ん"
            self.pending = ""

    def _convert(self) -> None:
        while self.pending:
            p = self.pending
            # 「nn」は「ん」。ただし、あとに母音か「y」が続いたら、2つ目の「n」は次のかなに使う（「konnichiha」→「こんにちは」）
            if p.startswith("nn"):
                if len(p) == 2:
                    return
                self.text += "ん"
                self.pending = p[1:] if p[2] in _VOWELS or p[2] == "y" else p[2:]
                continue
            # 「tch」は「っち」（「matcha」→「まっちゃ」）
            if p.startswith("tc"):
                self.text += "っ"
                self.pending = p[1:]
                continue
            # 同じ子音が続いたら「っ」（「kk」→「っk」）。「nn」は「ん」なので除く
            if len(p) >= 2 and p[0] == p[1] and p[0].isalpha() and p[0] not in _VOWELS and p[0] != "n":
                self.text += "っ"
                self.pending = p[1:]
                continue
            # 「n」のあとに母音・「y」・「n」以外が来たら「ん」（「kanji」の「n」）
            if len(p) >= 2 and p[0] == "n" and p[1] not in _VOWELS and p[1] not in "yn'":
                self.text += "ん"
                self.pending = p[1:]
                continue
            for length in range(min(len(p), _ROMAJI_MAX), 0, -1):
                kana = _ROMAJI.get(p[:length])
                if kana is not None and not (p[:length] == "n" and len(p) == 1):
                    if any(other.startswith(p) and other != p for other in _ROMAJI) and length == len(p):
                        return  # 「s」→「sh」→「sha」のように、まだ続きがあるかもしれない
                    self.text += kana
                    self.pending = p[length:]
                    break
            else:
                if any(other.startswith(p) for other in _ROMAJI):
                    return  # 続きを待つ
                # かなにならない文字（数字など）は、そのまま出す
                self.text += p[0]
                self.pending = p[1:]


# 2ボル式の配列: キーの文字 → ハングルの字母（Shift で濃音・ㅒ・ㅖ）
_DUBEOLSIK = dict(zip("qwertyuiopasdfghjklzxcvbnm", "ㅂㅈㄷㄱㅅㅛㅕㅑㅐㅔㅁㄴㅇㄹㅎㅗㅓㅏㅣㅋㅌㅊㅍㅠㅜㅡ"))
_DUBEOLSIK_SHIFT = {"Q": "ㅃ", "W": "ㅉ", "E": "ㄸ", "R": "ㄲ", "T": "ㅆ", "O": "ㅒ", "P": "ㅖ"}
_CHOSEONG = "ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ"
_JUNGSEONG = "ㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ"
_JONGSEONG = ["", *"ㄱㄲㄳㄴㄵㄶㄷㄹㄺㄻㄼㄽㄾㄿㅀㅁㅂㅄㅅㅆㅇㅈㅊㅋㅌㅍㅎ"]
_VOWEL_PAIRS = {("ㅗ", "ㅏ"): "ㅘ", ("ㅗ", "ㅐ"): "ㅙ", ("ㅗ", "ㅣ"): "ㅚ", ("ㅜ", "ㅓ"): "ㅝ", ("ㅜ", "ㅔ"): "ㅞ", ("ㅜ", "ㅣ"): "ㅟ", ("ㅡ", "ㅣ"): "ㅢ"}
_FINAL_PAIRS = {
    ("ㄱ", "ㅅ"): "ㄳ", ("ㄴ", "ㅈ"): "ㄵ", ("ㄴ", "ㅎ"): "ㄶ", ("ㄹ", "ㄱ"): "ㄺ", ("ㄹ", "ㅁ"): "ㄻ", ("ㄹ", "ㅂ"): "ㄼ",
    ("ㄹ", "ㅅ"): "ㄽ", ("ㄹ", "ㅌ"): "ㄾ", ("ㄹ", "ㅍ"): "ㄿ", ("ㄹ", "ㅎ"): "ㅀ", ("ㅂ", "ㅅ"): "ㅄ",
}
_SPLIT_VOWEL = {combined: pair for pair, combined in _VOWEL_PAIRS.items()}
_SPLIT_FINAL = {combined: pair for pair, combined in _FINAL_PAIRS.items()}


class HangulComposer:
    """韓国語: 2ボル式で打った字母を、音節（初声・中声・終声）に組み立てる。"""

    def __init__(self) -> None:
        self.text = ""
        self._cho = self._jung = self._jong = ""

    def feed(self, key: KeyPress) -> None:
        jamo = _DUBEOLSIK_SHIFT.get(key.char) or _DUBEOLSIK.get(key.char.lower())
        if jamo is None:
            self._commit()
            self.text += key.char
        elif jamo in _JUNGSEONG:
            self._vowel(jamo)
        else:
            self._consonant(jamo)

    def backspace(self) -> None:
        if self._jong:
            self._jong = _SPLIT_FINAL.get(self._jong, ("",))[0]
        elif self._jung:
            self._jung = _SPLIT_VOWEL.get(self._jung, ("",))[0]
        elif self._cho:
            self._cho = ""
        else:
            self.text = self.text[:-1]

    def finish(self) -> str:
        self._commit()
        text, self.text = self.text, ""
        return text

    @property
    def display(self) -> str:
        return self.text + self._syllable()

    def _consonant(self, jamo: str) -> None:
        if self._jung and self._cho and not self._jong and jamo in _JONGSEONG:
            self._jong = jamo  # 받침
        elif self._jong and (self._jong, jamo) in _FINAL_PAIRS:
            self._jong = _FINAL_PAIRS[(self._jong, jamo)]  # 겹받침
        else:
            self._commit()
            self._cho = jamo

    def _vowel(self, jamo: str) -> None:
        if self._jong:
            # 받침を次の音節の初声に移す（「갑」+「ㅏ」→「가바」、겹받침は後ろの字母だけを移す）
            first, second = _SPLIT_FINAL.get(self._jong, ("", self._jong))
            self._jong = first
            self._commit()
            self._cho, self._jung = second, jamo
        elif self._jung and (self._jung, jamo) in _VOWEL_PAIRS:
            self._jung = _VOWEL_PAIRS[(self._jung, jamo)]
        elif self._cho and not self._jung:
            self._jung = jamo
        else:
            self._commit()
            self._jung = jamo

    def _syllable(self) -> str:
        if self._cho and self._jung:
            index = (_CHOSEONG.index(self._cho) * 21 + _JUNGSEONG.index(self._jung)) * 28 + _JONGSEONG.index(self._jong)
            return chr(0xAC00 + index)
        return self._cho or self._jung

    def _commit(self) -> None:
        self.text += self._syllable()
        self._cho = self._jung = self._jong = ""


# ケドマニー配列: キーの名前 → (そのままの文字, Shift を押したときの文字)
THAI_KEYMAP: dict[str, tuple[str, str]] = {
    "grave": ("_", "%"), "1": ("ๅ", "+"), "2": ("/", "๑"), "3": ("-", "๒"), "4": ("ภ", "๓"), "5": ("ถ", "๔"),
    "6": ("ุ", "ู"), "7": ("ึ", "฿"), "8": ("ค", "๕"), "9": ("ต", "๖"), "0": ("จ", "๗"), "minus": ("ข", "๘"),
    "equal": ("ช", "๙"),
    "q": ("ๆ", "๐"), "w": ("ไ", '"'), "e": ("ำ", "ฎ"), "r": ("พ", "ฑ"), "t": ("ะ", "ธ"), "y": ("ั", "ํ"),
    "u": ("ี", "๊"), "i": ("ร", "ณ"), "o": ("น", "ฯ"), "p": ("ย", "ญ"), "leftbrace": ("บ", "ฐ"),
    "rightbrace": ("ล", ","), "backslash": ("ฃ", "ฅ"),
    "a": ("ฟ", "ฤ"), "s": ("ห", "ฆ"), "d": ("ก", "ฏ"), "f": ("ด", "โ"), "g": ("เ", "ฌ"), "h": ("้", "็"),
    "j": ("่", "๋"), "k": ("า", "ษ"), "l": ("ส", "ศ"), "semicolon": ("ว", "ซ"), "apostrophe": ("ง", "."),
    "z": ("ผ", "("), "x": ("ป", ")"), "c": ("แ", "ฉ"), "v": ("อ", "ฮ"), "b": ("ิ", "ฺ"), "n": ("ื", "์"),
    "m": ("ท", "?"), "comma": ("ม", "ฒ"), "dot": ("ใ", "ฬ"), "slash": ("ฝ", "ฦ"), "space": (" ", " "),
}


class ThaiComposer(PlainComposer):
    """タイ語: キーの位置からタイ文字にする（キーボードの刻印ではなく、ケドマニー配列の位置で決まる）。"""

    def feed(self, key: KeyPress) -> None:
        chars = THAI_KEYMAP.get(key.name)
        self.text += chars[1 if key.shift else 0] if chars else key.char


# ЙЦУКЕН 配列: キーの名前 → キリル文字（Shift で大文字）。数字と、ここに無い記号は US 配列のまま
RUSSIAN_KEYMAP: dict[str, str] = {
    **dict(zip("qwertyuiop", "йцукенгшщз")), "leftbrace": "х", "rightbrace": "ъ",
    **dict(zip("asdfghjkl", "фывапролд")), "semicolon": "ж", "apostrophe": "э",
    **dict(zip("zxcvbnm", "ячсмить")), "comma": "б", "dot": "ю", "grave": "ё",
}
# ロシア語の配列で、場所が US 配列と違う記号（そのままの文字, Shift を押したときの文字）
RUSSIAN_SYMBOLS: dict[str, tuple[str, str]] = {"slash": (".", ","), "7": ("7", "?"), "6": ("6", ":"), "4": ("4", ";")}


class RussianComposer(PlainComposer):
    """ロシア語: キーの位置からキリル文字にする（キーボードの刻印ではなく、ЙЦУКЕН 配列の位置で決まる）。"""

    def feed(self, key: KeyPress) -> None:
        letter = RUSSIAN_KEYMAP.get(key.name)
        if letter is not None:
            self.text += letter.upper() if key.shift else letter
        elif key.name in RUSSIAN_SYMBOLS:
            self.text += RUSSIAN_SYMBOLS[key.name][1 if key.shift else 0]
        else:
            self.text += key.char


# 文字を打てる言語と、その組み立て方
COMPOSERS = {
    JA: RomajiComposer, KO: HangulComposer, TH: ThaiComposer, EN: PlainComposer, FR: PlainComposer, RU: RussianComposer,
    PT: PlainComposer, HOK: RomajiComposer, OSA: RomajiComposer, FUK: RomajiComposer,
}
# 画面に出す、入力方法の説明
INPUT_HINTS = {
    JA: "ローマ字 → ひらがな（Shift+英字は英字のまま）",
    HOK: "ローマ字 → ひらがな（北海道弁）",
    OSA: "ローマ字 → ひらがな（大阪弁）",
    FUK: "ローマ字 → ひらがな（福岡弁）",
    KO: "두벌식（2ボル式）",
    TH: "Kedmanee（ケドマニー配列）",
    EN: "English",
    FR: "Français（アクセント記号なし / sans accents）",
    PT: "Português（アクセント記号なし / sem acentos）",
    RU: "Русский（ЙЦУКЕН 配列）",
}
# 文字を打てない言語で打ったときに出す文
UNSUPPORTED_MESSAGE = "この言語は文字入力に対応していません（声で話してください）/ Please speak"


def can_type(lang: str) -> bool:
    return lang in COMPOSERS


class TextEntry:
    """画面の入力欄。話す人の言語に合わせて文字を組み立てる（言語が替わったら、打っていた文字は消す）。"""

    def __init__(self) -> None:
        self.lang = ""
        self._composer: PlainComposer | RomajiComposer | HangulComposer | None = None

    @property
    def active(self) -> bool:
        """何か打っている途中か。"""
        return self._composer is not None and bool(self._composer.display)

    @property
    def display(self) -> str:
        return self._composer.display if self._composer is not None else ""

    def feed(self, key: KeyPress, lang: str) -> bool:
        """文字のキーを1つ打つ。その言語で打てなければ False。"""
        if lang not in COMPOSERS:
            return False
        if lang != self.lang or self._composer is None:
            self.lang, self._composer = lang, COMPOSERS[lang]()
        self._composer.feed(key)
        return True

    def backspace(self) -> None:
        if self._composer is not None:
            self._composer.backspace()

    def take(self) -> str:
        """打ち終わった文を取り出して、入力欄を空にする。"""
        text = self._composer.finish().strip() if self._composer is not None else ""
        self.clear()
        return text

    def restore(self, lang: str, text: str) -> None:
        """take() で取り出した文を入力欄に戻す（送れなかったとき）。"""
        if lang in COMPOSERS and text:
            self.lang, self._composer = lang, COMPOSERS[lang]()
            self._composer.text = text

    def clear(self) -> None:
        self._composer = None
