"""CPU 温度・CPU クロック・CPU 電圧（と、Pi 5 なら 5V 入力電圧）の記録（電源・再起動の画面の「管理者」でグラフにする）。

10 分ごとに、10 秒間（1 秒ごとに 10 回）測った平均を system_log.csv（config.toml と同じフォルダ）に 1 行ずつ足す。
- CPU 温度: /sys/class/thermal/thermal_zone0/temp
- CPU クロック（MHz）: /sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq（読めなければ vcgencmd measure_clock arm）。
- CPU 電圧（V）: vcgencmd measure_volts core。
- 5V 入力電圧: Raspberry Pi 5 の電源管理チップの値（vcgencmd pmic_read_adc の EXT5V_V）。
  Pi 4 などで読めないときは、記録しない。
電圧は、平均のほかに 10 秒間の最低も記録する（一瞬の電圧の落ち込みは、平均では見えないため）。

リセットしてからの合計稼働時間は、uptime_total.json に別に数える（時計ではなく、本体の経過時間で足すので、時計のずれに左右されない）。

時計のずれ: Pi 5 は時計の電池が無いと、電源を入れたとき、前に止めたときの時刻から始まり、Wi-Fi で時刻が合った瞬間に進む。
アプリが動いている間に時計が 1 分以上飛んだら、この起動で書いた記録の時刻を、飛んだ分だけ直す。
"""

from __future__ import annotations

import dataclasses
import json
import logging
import math
import re
import subprocess
import threading
import time
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from pathlib import Path

log = logging.getLogger(__name__)

FILE_NAME = "system_log.csv"
UPTIME_FILE_NAME = "uptime_total.json"
# 時計がこれ以上飛んだら、この起動の記録の時刻を直す
CLOCK_JUMP = timedelta(minutes=1)
THERMAL_FILE = Path("/sys/class/thermal/thermal_zone0/temp")
VOLTAGE_COMMAND = ("vcgencmd", "pmic_read_adc")
CLOCK_FILE = Path("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq")
CLOCK_COMMAND = ("vcgencmd", "measure_clock", "arm")
CORE_VOLT_COMMAND = ("vcgencmd", "measure_volts", "core")
# 記録する間隔と、1 回の記録で測る時間・測る間隔
INTERVAL_MIN = 10
WINDOW_SEC = 10.0
SAMPLE_EVERY_SEC = 1.0
# 残しておく日数（10 分ごとなら 1 日 144 行。これより古い行は、起動のときに消す）
KEEP_DAYS = 60
_TIME_FORMAT = "%Y-%m-%d %H:%M"
_EXT5V = re.compile(r"EXT5V_V\s+volt\(\d+\)=([0-9.]+)V")
_CLOCK = re.compile(r"frequency\(\d+\)=(\d+)")
_CORE_VOLT = re.compile(r"volt=([0-9.]+)V")


@dataclass(frozen=True)
class Reading:
    when: datetime
    temp: float | None  # CPU 温度（℃。10 秒間の平均）
    volt: float | None  # 5V 入力電圧（V。10 秒間の平均）
    volt_min: float | None = None  # 5V 入力電圧の、10 秒間の最低
    clock: float | None = None  # CPU クロック（MHz。10 秒間の平均）
    cpu_volt: float | None = None  # CPU 電圧（V。10 秒間の平均）
    clock_min: float | None = None  # CPU クロックの、10 秒間の最低（熱や電圧で下がったことが分かる）


@dataclass(frozen=True)
class ChartRange:
    name: str  # ボタンの文字
    hours: int  # さかのぼる時間
    tick_hours: int  # 横軸の目盛りの間隔
    tick_format: str  # 横軸の目盛りの書き方


# グラフに出す期間（管理者の画面のボタン）
CHART_RANGES = (
    ChartRange("6時間", 6, 1, "%H:%M"),
    ChartRange("24時間", 24, 4, "%H:%M"),
    ChartRange("7日", 7 * 24, 24, "%m/%d"),
    ChartRange("30日", 30 * 24, 5 * 24, "%m/%d"),
)
# 記録がこれより長く空いていたら、グラフの線をつながない（電源を切っていた間）
GAP = timedelta(minutes=INTERVAL_MIN * 2.5)
# 1 日の稼働時間のグラフ（管理者の画面の「稼働時間」。上に最近 7 日、下に最近 30 日）
UPTIME_DAYS = (7, 30)


def system_log_path(config_path: Path) -> Path:
    """config.toml と同じフォルダの system_log.csv。"""
    return Path(config_path).resolve().parent / FILE_NAME


def uptime_total_path(config_path: Path) -> Path:
    """config.toml と同じフォルダの uptime_total.json。"""
    return Path(config_path).resolve().parent / UPTIME_FILE_NAME


def read_cpu_temp(path: Path = THERMAL_FILE) -> float | None:
    """CPU 温度（℃）。読めなければ None。"""
    try:
        return int(path.read_text().strip()) / 1000.0
    except (OSError, ValueError):
        return None


def parse_input_voltage(output: str) -> float | None:
    """vcgencmd pmic_read_adc の出力から、5V 入力電圧（EXT5V_V）を取り出す。"""
    match = _EXT5V.search(output)
    return float(match.group(1)) if match else None


def read_input_voltage() -> float | None:
    """5V 入力電圧（V）。Pi 5 以外・vcgencmd が無いなどで読めなければ None。"""
    try:
        result = subprocess.run(VOLTAGE_COMMAND, capture_output=True, text=True, timeout=3, check=False)
    except (OSError, subprocess.SubprocessError):
        return None
    return parse_input_voltage(result.stdout)


def parse_cpu_clock(output: str) -> float | None:
    """vcgencmd measure_clock arm の出力（frequency(48)=1500398464）から、MHz を取り出す。"""
    match = _CLOCK.search(output)
    return round(int(match.group(1)) / 1e6, 1) if match else None


def parse_core_voltage(output: str) -> float | None:
    """vcgencmd measure_volts core の出力（volt=0.8500V）から、V を取り出す。"""
    match = _CORE_VOLT.search(output)
    return float(match.group(1)) if match else None


def _run_command(command: tuple[str, ...]) -> str:
    try:
        return subprocess.run(command, capture_output=True, text=True, timeout=3, check=False).stdout
    except (OSError, subprocess.SubprocessError):
        return ""


def read_cpu_clock(path: Path = CLOCK_FILE) -> float | None:
    """CPU クロック（MHz）。読めなければ None。"""
    try:
        return round(int(path.read_text().strip()) / 1000.0, 1)  # kHz → MHz
    except (OSError, ValueError):
        return parse_cpu_clock(_run_command(CLOCK_COMMAND))


def read_core_voltage() -> float | None:
    """CPU（コア）電圧（V）。vcgencmd が無いなどで読めなければ None。"""
    return parse_core_voltage(_run_command(CORE_VOLT_COMMAND))


def summarize(
    when: datetime,
    temps: Sequence[float | None],
    volts: Sequence[float | None],
    clocks: Sequence[float | None] = (),
    cpu_volts: Sequence[float | None] = (),
) -> Reading:
    """測った値（読めなかった回は None）から、平均と最低をまとめる。"""
    good_temps = [value for value in temps if value is not None]
    good_volts = [value for value in volts if value is not None]
    good_clocks = [value for value in clocks if value is not None]
    good_cpu_volts = [value for value in cpu_volts if value is not None]
    return Reading(
        # いちばん近い「分」にそろえる（測り終わりが 01:09:59 でも、01:10 の記録にする）
        (when + timedelta(seconds=30)).replace(second=0, microsecond=0),
        round(sum(good_temps) / len(good_temps), 1) if good_temps else None,
        round(sum(good_volts) / len(good_volts), 3) if good_volts else None,
        round(min(good_volts), 3) if good_volts else None,
        round(sum(good_clocks) / len(good_clocks), 0) if good_clocks else None,
        round(sum(good_cpu_volts) / len(good_cpu_volts), 4) if good_cpu_volts else None,
        round(min(good_clocks), 0) if good_clocks else None,
    )


def next_time(now: datetime, interval_min: int = INTERVAL_MIN) -> datetime:
    """次に記録する時刻（毎時 0 分から interval_min 分ごと）。"""
    start = now.replace(minute=now.minute - now.minute % interval_min, second=0, microsecond=0)
    return start + timedelta(minutes=interval_min)


def axis_bounds(values: Sequence[float], step: float, min_steps: int = 2) -> tuple[float, float, list[float]]:
    """グラフの縦軸: step の倍数で、値がすべて収まる (下端, 上端, 目盛り)。幅は min_steps 目盛り以上にする。"""
    low = math.floor(min(values) / step + 1e-9) * step
    high = math.ceil(max(values) / step - 1e-9) * step
    while round((high - low) / step) < min_steps:
        high += step
        if round((high - low) / step) < min_steps:
            low -= step
    count = round((high - low) / step)
    return low, high, [round(low + i * step, 6) for i in range(count + 1)]


def time_ticks(start: datetime, end: datetime, tick_hours: int) -> list[datetime]:
    """グラフの横軸の目盛りの時刻（tick_hours ごと。1 日以上の間隔なら 0 時、それ未満なら 0 時から数えた時刻）。"""
    day = start.replace(hour=0, minute=0, second=0, microsecond=0)
    step = timedelta(hours=tick_hours)
    if tick_hours >= 24:
        # 日数で数える（基準の日からの日数が、間隔の倍数の日）
        days = tick_hours // 24
        tick = day + timedelta(days=(-day.toordinal()) % days)
    else:
        tick = day
    ticks = []
    while tick <= end:
        if tick >= start:
            ticks.append(tick)
        tick += step
    return ticks


def daily_uptime(readings: Sequence[Reading], now: datetime, days: int) -> list[tuple[date, float]]:
    """now の日までの days 日の、日ごとの稼働時間（時間。古い日から順）。

    記録を書いた順に見て、次の記録までが GAP 以内なら、その間は動いていたとみなして足す
    （0 時をまたぐ分は、それぞれの日に分ける）。最後の記録が GAP 以内なら、今まで動いている分も足す。
    記録は起動したときと 10 分ごとなので、最後の記録から電源を切るまで（10 分未満）は数えない目安の値。
    時計が戻った所（Pi 5 は時計の電池が無いと、Wi-Fi で時刻を合わせるまで、前に止めたときの時刻から始まる）は数えない。
    """
    first = now.date() - timedelta(days=days - 1)
    totals = {first + timedelta(days=i): 0.0 for i in range(days)}
    times = [reading.when for reading in readings] + [now]
    for start, end in zip(times, times[1:]):
        if not timedelta(0) < end - start <= GAP:
            continue  # 電源を切っていた間、または時計が戻った所
        while start < end:
            stop = min(end, datetime.combine(start.date() + timedelta(days=1), datetime.min.time()))
            if start.date() in totals:
                totals[start.date()] += (stop - start).total_seconds() / 3600
            start = stop
    return list(totals.items())


class SystemLog:
    """system_log.csv の読み書き。1 行は「2026-10-01 01:10,46.3,4.971,4.962」（読めなかった値は空）。"""

    def __init__(self, path: Path) -> None:
        self._path = Path(path)
        self._lock = threading.Lock()

    def append(self, reading: Reading) -> None:
        with self._lock:
            try:
                with self._path.open("a", encoding="utf-8") as file:
                    file.write(_format_line(reading))
            except OSError:
                log.exception("温度・電圧の記録を書けません: %s", self._path)

    def read(self, since: datetime | None = None) -> list[Reading]:
        """since 以降の記録（古い順）。壊れた行は飛ばす。"""
        with self._lock:
            try:
                lines = self._path.read_text(encoding="utf-8").splitlines()
            except OSError:
                return []
        readings = []
        for line in lines:
            reading = _parse_line(line)
            if reading is not None and (since is None or reading.when >= since):
                readings.append(reading)
        return readings

    def trim(self, now: datetime, keep_days: int = KEEP_DAYS) -> None:
        """keep_days より古い行を消す（ファイルが大きくなり続けないように）。"""
        kept = self.read(now - timedelta(days=keep_days))
        with self._lock:
            try:
                old_count = len(self._path.read_text(encoding="utf-8").splitlines())
            except OSError:
                return
            if old_count == len(kept):
                return
            temporary = self._path.with_name(self._path.name + ".tmp")
            try:
                temporary.write_text("".join(_format_line(reading) for reading in kept), encoding="utf-8")
                temporary.replace(self._path)
            except OSError:
                log.exception("温度・電圧の記録を整理できません: %s", self._path)


    def shift_last(self, count: int, delta: timedelta) -> None:
        """最後の count 行（この起動で書いた記録）の時刻を delta だけずらす（時計が飛んだとき）。"""
        if count <= 0:
            return
        with self._lock:
            try:
                lines = self._path.read_text(encoding="utf-8").splitlines()
            except OSError:
                return
            fixed = lines[:-count]
            for line in lines[-count:]:
                reading = _parse_line(line)
                if reading is None:
                    fixed.append(line)
                else:
                    when = (reading.when + delta + timedelta(seconds=30)).replace(second=0, microsecond=0)
                    fixed.append(_format_line(dataclasses.replace(reading, when=when)).rstrip("\n"))
            temporary = self._path.with_name(self._path.name + ".tmp")
            try:
                temporary.write_text("".join(line + "\n" for line in fixed), encoding="utf-8")
                temporary.replace(self._path)
            except OSError:
                log.exception("温度・電圧の記録の時刻を直せません: %s", self._path)


class UptimeCounter:
    """リセットしてからの合計稼働時間（uptime_total.json に {"since": "2026-10-01 04:10", "seconds": 1234}）。

    update() のたびに、前の update() からの本体の経過時間（time.monotonic）を足して保存する。
    ファイルが無ければ、初めて使ったときから数える。
    """

    def __init__(
        self,
        path: Path,
        now: Callable[[], datetime] = datetime.now,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self._path = Path(path)
        self._now = now
        self._clock = clock
        self._lock = threading.Lock()
        self._mark = clock()
        self._since: datetime = now().replace(second=0, microsecond=0)
        self._seconds = 0.0
        try:
            data = json.loads(self._path.read_text(encoding="utf-8"))
            self._since = datetime.strptime(data["since"], _TIME_FORMAT)
            self._seconds = float(data["seconds"])
        except (OSError, ValueError, KeyError, TypeError):
            self._save()

    @property
    def since(self) -> datetime:
        return self._since

    def total_seconds(self) -> float:
        """リセットしてからの合計（保存した分に、最後に保存してから今までを足す）。"""
        with self._lock:
            return self._seconds + max(0.0, self._clock() - self._mark)

    def update(self) -> None:
        """前に保存してからの経過を足して保存する（10 分ごとの記録と、アプリを終えるときに呼ぶ）。"""
        with self._lock:
            now = self._clock()
            self._seconds += max(0.0, now - self._mark)
            self._mark = now
            self._save()

    def reset(self) -> None:
        """0 に戻す（管理者の画面の「リセット」）。"""
        with self._lock:
            self._seconds, self._mark = 0.0, self._clock()
            self._since = self._now().replace(second=0, microsecond=0)
            self._save()
        log.info("合計稼働時間をリセットしました（%s から数えます）", self._since.strftime(_TIME_FORMAT))

    def shift_since(self, delta: timedelta, after: datetime) -> None:
        """時計が飛んだとき: リセットした時刻が after（この起動の始め）以降なら、その時刻も直す。"""
        with self._lock:
            if self._since >= after.replace(second=0, microsecond=0):
                self._since = (self._since + delta + timedelta(seconds=30)).replace(second=0, microsecond=0)
                self._save()

    def _save(self) -> None:
        data = {"since": self._since.strftime(_TIME_FORMAT), "seconds": round(self._seconds, 1)}
        temporary = self._path.with_name(self._path.name + ".tmp")
        try:
            temporary.write_text(json.dumps(data) + "\n", encoding="utf-8")
            temporary.replace(self._path)
        except OSError:
            log.exception("合計稼働時間を保存できません: %s", self._path)


def _format_line(reading: Reading) -> str:
    fields = (reading.temp, reading.volt, reading.volt_min, reading.clock, reading.cpu_volt, reading.clock_min)
    values = ("" if value is None else f"{value:g}" for value in fields)
    return ",".join([reading.when.strftime(_TIME_FORMAT), *values]) + "\n"


def _parse_line(line: str) -> Reading | None:
    parts = line.strip().split(",")
    if len(parts) < 3:
        return None
    try:
        when = datetime.strptime(parts[0], _TIME_FORMAT)
        # 古い記録（温度・5V・5V の最低だけ）の行にも、そのまま対応する
        values = [float(part) if part else None for part in (parts + [""] * 6)[1:7]]
    except ValueError:
        return None
    return Reading(when, *values)


class SystemMonitor:
    """裏のスレッドで、起動したときと、そのあと 10 分ごとに、10 秒間の平均を記録する。"""

    def __init__(
        self,
        system_log: SystemLog,
        read_temp: Callable[[], float | None] = read_cpu_temp,
        read_volt: Callable[[], float | None] = read_input_voltage,
        read_clock: Callable[[], float | None] = read_cpu_clock,
        read_cpu_volt: Callable[[], float | None] = read_core_voltage,
        now: Callable[[], datetime] = datetime.now,
        counter: UptimeCounter | None = None,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self._log = system_log
        self._read_temp = read_temp
        self._read_volt = read_volt
        self._read_clock = read_clock
        self._read_cpu_volt = read_cpu_volt
        self._now = now
        self._counter = counter
        self._clock = clock
        # 時計のずれを見つけるための、起動したときの時計と本体の経過時間、もう直した分、この起動で書いた記録の数
        self._wall_start = now()
        self._clock_start = clock()
        self._corrected = timedelta(0)
        self._written = 0
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, name="system-monitor", daemon=True)

    def start(self) -> None:
        self._thread.start()

    def close(self) -> None:
        self._stop.set()
        if self._thread.is_alive():
            self._thread.join(timeout=3)
        if self._counter is not None:
            self._counter.update()

    def check_clock(self) -> timedelta | None:
        """時計が CLOCK_JUMP 以上飛んでいたら、この起動で書いた記録（とリセットの時刻）を直して、飛んだ分を返す。"""
        drift = (self._now() - self._wall_start) - timedelta(seconds=self._clock() - self._clock_start)
        jump = drift - self._corrected
        if abs(jump) < CLOCK_JUMP:
            return None
        self._corrected = drift
        self._log.shift_last(self._written, jump)
        if self._counter is not None:
            self._counter.shift_since(jump, self._wall_start + self._corrected - jump)
        log.info("時計が %s 飛んだので、この起動の記録 %d 件の時刻を直しました", jump, self._written)
        return jump

    def measure(self, window_sec: float = WINDOW_SEC, every_sec: float = SAMPLE_EVERY_SEC) -> Reading | None:
        """window_sec の間、every_sec ごとに測って、平均をまとめる（止めるよう言われたら None）。"""
        temps: list[float | None] = []
        volts: list[float | None] = []
        clocks: list[float | None] = []
        cpu_volts: list[float | None] = []
        for i in range(max(1, round(window_sec / every_sec))):
            if i and self._stop.wait(every_sec):
                return None
            temps.append(self._read_temp())
            volts.append(self._read_volt())
            clocks.append(self._read_clock())
            cpu_volts.append(self._read_cpu_volt())
        return summarize(self._now(), temps, volts, clocks, cpu_volts)

    def _run(self) -> None:
        self._log.trim(self._now())
        while not self._stop.is_set():
            try:
                reading = self.measure()
                if reading is None:
                    return
                self.check_clock()
                if any(value is not None for value in (reading.temp, reading.volt, reading.clock, reading.cpu_volt)):
                    self._log.append(reading)
                    self._written += 1
                if self._counter is not None:
                    self._counter.update()
            except Exception:
                log.exception("温度・電圧を記録できません")
            # 次の 10 分の区切りの 10 秒前から測り始める（平均した 10 秒の終わりが、区切りの時刻になるように）
            now = self._now()
            wait = (next_time(now) - now).total_seconds() - WINDOW_SEC
            if wait < 60:
                # 区切りまで 1 分もない（起動したときの記録が区切りの直前だった、または区切りの記録を終えたところ）。
                # 同じ時刻の記録が 2 つにならないよう、その次の区切りまで待つ
                wait += INTERVAL_MIN * 60
            if self._stop.wait(wait):
                return
