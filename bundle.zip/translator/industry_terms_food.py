"""飲食店（居酒屋・ラーメン店・レストラン・カフェ）の用語集のデータ。

1 行 = 1 語。(日本語, 韓国語, 英語, 中国語（簡体字）, 広東語, タイ語, フランス語, ロシア語, ポルトガル語（ブラジル）[, True])。
最後の True は「お客様がこの言葉で言ったときも、日本語の見本にする」印（industries.py が TO_JA_TERMS にも入れる）。
書き方の決まり（2026-10 までの Pi での試験で分かったこと）:
- 説明を（）で足すと、訳文に説明が 2 回出ることがある。かな（ひらがな・カタカナ）を（）の中に書かない（中国語・広東語で訳を拒む）。
- 「〜する」の形（辞書形）の見本は、「〜するは」になる。名詞か、丁寧な文の形で書く。
"""

from __future__ import annotations

# 飲食店に共通（居酒屋・ラーメン店・レストラン・カフェのどれを選んでも使う）
FOOD_COMMON = (
    ("割り箸", "나무젓가락", "disposable chopsticks", "一次性筷子", "即棄筷子", "ตะเกียบไม้ใช้แล้วทิ้ง", "baguettes jetables", "одноразовые палочки", "hashi descartável"),
    ("おしぼり", "물수건", "wet towel", "湿毛巾", "濕毛巾", "ผ้าเช็ดมือ", "serviette humide", "влажное полотенце", "toalha úmida"),
    ("お冷", "찬물", "cold water", "冰水", "凍水", "น้ำเย็น", "eau fraîche", "холодная вода", "água gelada"),
    ("取り皿", "앞접시", "small plates", "小碟子", "小碟", "จานเล็กสำหรับแบ่ง", "petites assiettes", "маленькие тарелки", "pratos pequenos"),
    ("相席", "합석", "shared table", "拼桌", "搭枱", "นั่งโต๊ะร่วมกัน", "table partagée", "общий стол", "mesa compartilhada", True),
    ("個室", "개인실", "private room", "包间", "包廂", "ห้องส่วนตัว", "salon privé", "отдельная комната", "sala privativa", True),
    ("禁煙席", "금연석", "non-smoking seat", "禁烟座位", "禁煙座位", "ที่นั่งปลอดบุหรี่", "place non-fumeur", "место для некурящих", "mesa para não fumantes", True),
    ("喫煙席", "흡연석", "smoking seat", "吸烟座位", "吸煙座位", "ที่นั่งสูบบุหรี่ได้", "place fumeur", "место для курящих", "mesa para fumantes", True),
    ("アレルギー", "알레르기", "allergy", "过敏", "敏感", "อาการแพ้", "allergie", "аллергия", "alergia"),
    ("持ち帰り", "포장", "takeout", "外带", "外賣", "สั่งกลับบ้าน", "à emporter", "с собой", "para viagem", True),
    ("店内でお召し上がり", "매장에서 드시기", "eating in", "堂食", "堂食", "ทานที่ร้าน", "sur place", "в зале", "consumir no local"),
    ("ラストオーダー", "주문 마감", "last order", "最后点单", "最後點單", "รับออเดอร์สุดท้าย", "dernière commande", "последний заказ", "último pedido"),
    ("大盛り", "곱빼기", "large portion", "大份", "大份", "ขนาดจานใหญ่", "grande portion", "большая порция", "porção grande"),
    ("食べ放題", "무한 리필", "all-you-can-eat", "自助畅吃", "任食", "บุฟเฟ่ต์", "à volonté", "безлимитное питание", "à vontade", True),
    ("お会計", "계산", "the bill", "结账", "埋單", "การชำระเงิน", "l'addition", "счёт", "a conta"),
    ("ご注文はお決まりですか", "주문하시겠어요?", "Are you ready to order?", "您想好点什么了吗？", "你想好食咩未？", "เลือกเมนูได้แล้วหรือยังคะ", "Avez-vous choisi ?", "Вы готовы сделать заказ?", "Já escolheu o seu pedido?"),
    ("辛さ", "맵기", "spice level", "辣度", "辣度", "ระดับความเผ็ด", "niveau de piment", "острота", "nível de picância", True),
    ("おすすめ", "추천", "recommendation", "推荐", "推介", "เมนูแนะนำ", "recommandation", "рекомендация", "recomendação"),
    ("日替わり", "오늘의 메뉴", "today's special", "今日特餐", "今日特餐", "เมนูประจำวัน", "plat du jour", "блюдо дня", "prato do dia", True),
    ("ベジタリアン", "채식", "vegetarian", "素食", "素食", "มังสวิรัติ", "végétarien", "вегетарианский", "vegetariano", True),
    ("ハラール", "할랄", "halal", "清真", "清真", "ฮาลาล", "halal", "халяль", "halal", True),
    ("豚肉", "돼지고기", "pork", "猪肉", "豬肉", "เนื้อหมู", "porc", "свинина", "carne de porco", True),
    ("乳製品", "유제품", "dairy products", "乳制品", "乳製品", "ผลิตภัณฑ์จากนม", "produits laitiers", "молочные продукты", "laticínios", True),
    ("甲殻類", "갑각류", "shellfish such as shrimp and crab", "甲壳类", "甲殼類", "สัตว์น้ำเปลือกแข็ง", "crustacés", "ракообразные", "crustáceos"),
    ("ナッツ類", "견과류", "nuts", "坚果", "堅果", "ถั่ว", "noix", "орехи", "nozes", True),
    ("小麦", "밀", "wheat", "小麦", "小麥", "ข้าวสาลี", "blé", "пшеница", "trigo"),
    ("卵", "달걀", "egg", "鸡蛋", "雞蛋", "ไข่", "œuf", "яйца", "ovo"),
)

IZAKAYA = (
    ("お通し代", "오토시 요금", "table snack charge (otoshi)", "小菜费", "小食費", "ค่าของว่างประจำโต๊ะ", "supplément pour l'amuse-bouche (otoshi)", "закуска к столу (отоси)", "taxa do petisco da casa (otoshi)", True),
    ("とりあえず生", "일단 생맥주", "draft beer to start", "先来杯生啤", "", "เริ่มด้วยเบียร์สดก่อน", "une bière pression pour commencer", "для начала разливное пиво", "um chope para começar"),
    ("生ビール", "생맥주", "draft beer", "生啤", "生啤", "เบียร์สด", "bière pression", "разливное пиво", "chope", True),
    ("瓶ビール", "병맥주", "bottled beer", "瓶装啤酒", "樽裝啤酒", "เบียร์ขวด", "bière en bouteille", "бутылочное пиво", "cerveja em garrafa", True),
    ("ハイボール", "하이볼", "highball (whisky and soda)", "威士忌苏打", "威士忌梳打", "ไฮบอล", "highball (whisky soda)", "хайбол (виски с содовой)", "highball (uísque com soda)", True),
    ("酎ハイ", "츄하이", "chuhai (shochu and soda)", "烧酎嗨（烧酒加苏打）", "燒酎嗨（燒酒加梳打）", "ชูไฮ (เหล้าโชจูผสมโซดา)", "chuhai (shochu et soda)", "тюхай (сётю с содовой)", "chuhai (shochu com soda)", True),
    ("日本酒", "일본 청주", "sake", "日本清酒", "日本清酒", "สาเกญี่ปุ่น", "saké", "сакэ", "saquê", True),
    ("熱燗", "데운 청주", "warm sake", "热清酒", "熱清酒", "สาเกร้อน", "saké chaud", "горячий сакэ", "saquê quente", True),
    ("冷酒", "차게 한 청주", "chilled sake", "冰清酒", "凍清酒", "สาเกเย็น", "saké frais", "охлаждённый сакэ", "saquê gelado", True),
    ("梅酒", "매실주", "plum wine", "梅酒", "梅酒", "เหล้าบ๊วย", "vin de prune", "сливовое вино", "vinho de ameixa", True),
    ("乾杯", "건배", "cheers", "干杯", "乾杯", "ชนแก้ว", "santé", "за здоровье", "saúde"),
    ("焼き鳥", "닭꼬치", "yakitori (grilled chicken skewers)", "烤鸡肉串", "燒雞串", "ยากิโทริ (ไก่ย่างเสียบไม้)", "yakitori (brochettes de poulet grillées)", "якитори (куриные шашлычки)", "yakitori (espetinhos de frango grelhados)", True),
    ("唐揚げ", "일본식 닭튀김", "Japanese fried chicken (karaage)", "日式炸鸡块", "日式炸雞", "ไก่ทอดแบบญี่ปุ่น (คาราอาเกะ)", "poulet frit japonais (karaage)", "японская жареная курица (карааге)", "frango frito japonês (karaage)", True),
    ("刺身盛り合わせ", "모둠회", "assorted sashimi", "生鱼片拼盘", "刺身拼盤", "ซาชิมิรวม", "assortiment de sashimi", "ассорти из сашими", "sashimi variado", True),
    ("枝豆", "풋콩", "edamame (boiled soybeans in the pod)", "毛豆", "毛豆", "ถั่วแระต้ม", "edamame (fèves de soja)", "эдамамэ (варёные соевые бобы)", "edamame (soja cozida na vagem)", True),
    ("串", "꼬치", "skewer", "串", "串", "ไม้เสียบ", "brochette", "шпажка", "espeto"),
    ("宴会", "연회", "banquet", "宴会", "宴會", "งานเลี้ยง", "banquet", "банкет", "banquete", True),
    ("2時間制", "2시간제", "two-hour limit", "限时两小时", "限時兩小時", "จำกัดเวลา 2 ชั่วโมง", "limité à deux heures", "ограничение два часа", "limite de duas horas"),
    ("飲み放題", "음료 무제한", "all-you-can-drink", "畅饮", "任飲", "ดื่มได้ไม่อั้น", "menu boissons à volonté", "безлимитные напитки", "consumo livre de bebidas", True),
)

RAMEN = (
    ("替え玉", "면 추가", "extra noodles (kaedama)", "加面", "加麵", "เส้นเพิ่ม (คาเอดามะ)", "supplément de nouilles (kaedama)", "добавка лапши (каэдама)", "macarrão extra (kaedama)", True),
    ("麺の硬さ", "면 익힘 정도", "firmness of the noodles", "面的硬度", "麵嘅軟硬度", "ความแข็งของเส้น", "degré de cuisson des nouilles", "степень проварки лапши", "ponto do macarrão", True),
    ("味噌ラーメン", "미소 라멘", "miso ramen", "味噌拉面", "味噌拉麵", "ราเมนมิโซะ", "ramen au miso", "рамен с мисо", "ramen de missô", True),
    ("醤油ラーメン", "쇼유 라멘", "shoyu (soy sauce) ramen", "酱油拉面", "豉油拉麵", "ราเมนโชยุ", "ramen au shoyu (sauce soja)", "рамен с соевым соусом", "ramen de shoyu (molho de soja)", True),
    ("塩ラーメン", "시오 라멘", "shio (salt) ramen", "盐味拉面", "鹽味拉麵", "ราเมนชิโอะ (รสเกลือ)", "ramen au shio (sel)", "рамен с солью", "ramen de shio (sal)", True),
    ("豚骨ラーメン", "돈코츠 라멘", "tonkotsu (pork bone) ramen", "豚骨拉面", "豚骨拉麵", "ราเมนทงคตสึ", "ramen tonkotsu (os de porc)", "рамен тонкоцу (на свином бульоне)", "ramen tonkotsu (caldo de osso de porco)", True),
    ("つけ麺", "츠케멘", "tsukemen (dipping noodles)", "蘸面", "沾麵", "ทสึเคเมน (เส้นจิ้มน้ำซุป)", "tsukemen (nouilles à tremper)", "цукэмэн (лапша с соусом для макания)", "tsukemen (macarrão para molhar no caldo)", True),
    ("チャーシュー", "차슈", "chashu (braised pork slices)", "叉烧肉", "叉燒", "หมูชาชู", "chashu (tranches de porc braisé)", "тясю (ломтики тушёной свинины)", "chashu (fatias de porco cozido)", True),
    ("煮卵", "간장에 조린 달걀", "seasoned soft-boiled egg", "卤蛋", "滷水蛋", "ไข่ต้มราดซอส", "œuf mariné", "маринованное яйцо", "ovo marinado", True),
    ("背脂", "등지방", "pork back fat", "猪背脂", "豬背脂", "ไขมันหลังหมู", "gras de dos de porc", "свиной жир", "gordura de porco", True),
    ("海苔", "김", "nori seaweed", "海苔", "海苔", "สาหร่ายโนริ", "nori", "нори", "nori"),
    ("ネギ", "파", "green onion", "葱", "蔥", "ต้นหอม", "oignon vert", "зелёный лук", "cebolinha", True),
    ("トッピング", "토핑", "topping", "配料", "配料", "ท็อปปิ้ง", "garniture", "добавка", "adicional", True),
    ("餃子", "군만두", "gyoza (pan-fried dumplings)", "煎饺", "煎餃", "เกี๊ยวซ่า", "gyoza (raviolis grillés)", "гёдза (жареные пельмени)", "gyoza (pastéis grelhados)", True),
    ("半チャーハン", "반 볶음밥", "half-size fried rice", "半份炒饭", "半份炒飯", "ข้าวผัดครึ่งจาน", "demi-portion de riz sauté", "половина порции жареного риса", "meia porção de arroz frito", True),
    ("ライス無料", "공기밥 무료", "free rice", "米饭免费", "白飯免費", "ข้าวฟรี", "riz gratuit", "рис бесплатно", "arroz grátis", True),
    ("食券", "식권", "meal ticket", "餐券", "餐券", "ตั๋วอาหาร", "ticket repas", "талон на еду", "ticket de refeição", True),
    ("券売機", "식권 발매기", "ticket vending machine", "餐券售票机", "餐券機", "ตู้ซื้อตั๋วอาหาร", "distributeur de tickets", "автомат по продаже талонов", "máquina de tickets", True),
)

RESTAURANT = (
    ("コース料理", "코스 요리", "course meal", "套餐料理", "套餐", "อาหารชุดคอร์ส", "menu dégustation", "обед из нескольких блюд", "menu completo", True),
    ("アラカルト", "단품 주문", "à la carte", "单点", "散叫", "สั่งเป็นรายการ", "à la carte", "по меню (а-ля карт)", "à la carte", True),
    ("前菜", "전채 요리", "appetizer", "前菜", "前菜", "อาหารเรียกน้ำย่อย", "entrée", "закуска", "entrada"),
    ("メインディッシュ", "메인 요리", "main dish", "主菜", "主菜", "จานหลัก", "plat principal", "основное блюдо", "prato principal"),
    ("デザート", "디저트", "dessert", "甜点", "甜品", "ของหวาน", "dessert", "десерт", "sobremesa"),
    ("ランチタイム", "점심 시간", "lunch time", "午餐时段", "午餐時段", "ช่วงเวลาอาหารกลางวัน", "heure du déjeuner", "время ланча", "horário do almoço", True),
    ("ディナータイム", "저녁 시간", "dinner time", "晚餐时段", "晚餐時段", "ช่วงเวลาอาหารเย็น", "heure du dîner", "время ужина", "horário do jantar", True),
    ("ドレスコード", "복장 규정", "dress code", "着装要求", "著裝要求", "ข้อกำหนดการแต่งกาย", "code vestimentaire", "дресс-код", "código de vestimenta", True),
    ("ご予約", "예약", "reservation", "预约", "預約", "การจอง", "réservation", "бронь", "reserva", True),
    ("ソムリエ", "소믈리에", "sommelier", "侍酒师", "侍酒師", "ซอมเมลิเยร์", "sommelier", "сомелье", "sommelier"),
    ("グラスワイン", "글라스 와인", "wine by the glass", "杯装葡萄酒", "杯裝紅酒", "ไวน์แก้ว", "vin au verre", "вино бокалом", "vinho em taça", True),
    ("お肉の焼き加減", "고기 굽기 정도", "how you would like your meat cooked", "肉的火候", "肉嘅生熟程度", "ความสุกของเนื้อ", "cuisson de la viande", "степень прожарки мяса", "ponto da carne", True),
    ("お取り分け", "나눠 담기", "dividing the dish among you", "分餐", "分菜", "แบ่งอาหารให้", "partager le plat", "разложить по тарелкам", "dividir o prato", True),
    ("サービス料", "서비스 요금", "service charge", "服务费", "服務費", "ค่าบริการ", "frais de service", "плата за обслуживание", "taxa de serviço"),
    ("お子様ランチ", "어린이 세트", "kids' meal", "儿童套餐", "兒童餐", "ชุดอาหารเด็ก", "menu enfant", "детский набор", "prato infantil", True),
    ("出汁", "육수", "dashi (soup stock)", "高汤", "高湯", "น้ำซุปดาชิ", "dashi (bouillon)", "даси (бульон)", "dashi (caldo)", True),
)

CAFE = (
    ("ホットコーヒー", "핫 커피", "hot coffee", "热咖啡", "熱咖啡", "กาแฟร้อน", "café chaud", "горячий кофе", "café quente", True),
    ("アイスコーヒー", "아이스 커피", "iced coffee", "冰咖啡", "凍咖啡", "กาแฟเย็น", "café glacé", "холодный кофе со льдом", "café gelado", True),
    ("カフェオレ", "카페오레", "café au lait", "欧蕾咖啡", "歐蕾咖啡", "คาเฟ่โอเล", "café au lait", "кофе с молоком", "café com leite", True),
    ("モーニング", "모닝 세트", "morning set", "早餐套餐", "早餐套餐", "ชุดอาหารเช้า", "menu petit-déjeuner", "утренний набор", "combo de café da manhã", True),
    ("トースト", "토스트", "toast", "吐司", "多士", "ขนมปังปิ้ง", "toast", "тост", "torrada"),
    ("ケーキセット", "케이크 세트", "cake set (cake and a drink)", "蛋糕套餐", "蛋糕套餐", "ชุดเค้กพร้อมเครื่องดื่ม", "menu gâteau et boisson", "набор: торт и напиток", "combo de bolo e bebida", True),
    ("ドリンクバー", "음료 무제한 코너", "drink bar (unlimited drinks)", "自助饮料吧", "自助飲品吧", "ดริงก์บาร์ (เครื่องดื่มไม่อั้น)", "bar à boissons à volonté", "безлимитные напитки", "bar de bebidas à vontade", True),
    ("お水はセルフサービス", "물은 셀프입니다", "water is self-service", "水请自取", "水請自取", "น้ำบริการตัวเอง", "l'eau est en libre-service", "вода самообслуживания", "a água é self-service"),
    ("コンセント", "콘센트", "power outlet", "插座", "電插座", "ปลั๊กไฟ", "prise électrique", "розетка", "tomada", True),
    ("お席でお待ちください", "자리에서 기다려 주세요", "please wait at your seat", "请在座位上稍等", "請喺座位等一等", "กรุณารอที่โต๊ะค่ะ", "veuillez attendre à votre place", "подождите, пожалуйста, на своём месте", "aguarde no seu lugar"),
    ("ご注文は先にレジでお願いします", "주문은 먼저 계산대에서 해 주세요", "please order at the register first", "请先到收银台点单", "請先去收銀處點餐", "กรุณาสั่งที่แคชเชียร์ก่อนค่ะ", "veuillez commander d'abord à la caisse", "пожалуйста, сначала сделайте заказ на кассе", "por favor, faça o pedido primeiro no caixa"),
    ("ミルクと砂糖", "우유와 설탕", "milk and sugar", "牛奶和糖", "奶同糖", "นมและน้ำตาล", "lait et sucre", "молоко и сахар", "leite e açúcar"),
    ("テイクアウト", "포장", "takeout", "外带", "外賣", "สั่งกลับบ้าน", "à emporter", "с собой", "para viagem", True),
    ("おかわり", "리필", "a refill", "续杯", "再嚟一杯", "เติมเครื่องดื่ม", "un resservice", "добавка", "uma recarga", True),
)
