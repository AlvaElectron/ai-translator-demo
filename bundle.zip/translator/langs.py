"""言語まわりの処理: 翻訳の組み合わせ、訳文の検証、文の切り出し（外部ライブラリに依存しない）。"""

from __future__ import annotations

import unicodedata
from collections.abc import Collection, Sequence
from dataclasses import dataclass

JA = "ja"
KO = "ko"
EN = "en"
ZH = "zh"
YUE = "yue"  # 広東語（香港）
TH = "th"  # タイ語
FR = "fr"  # フランス語
RU = "ru"  # ロシア語
PT = "pt"  # ポルトガル語（ブラジル式）
# 2026-11-14 に追加した 15 言語（翻訳は PLaMo 3 Translate、読み上げは Supertonic 3。聞き取りは西・独が Canary、ほかは Whisper）
ES = "es"  # スペイン語
DE = "de"  # ドイツ語
IT = "it"  # イタリア語
NL = "nl"  # オランダ語
PL = "pl"  # ポーランド語
HR = "hr"  # クロアチア語
SK = "sk"  # スロバキア語
SL = "sl"  # スロベニア語
HU = "hu"  # ハンガリー語
ET = "et"  # エストニア語
LV = "lv"  # ラトビア語
LT = "lt"  # リトアニア語
BG = "bg"  # ブルガリア語（キリル文字）
ID = "id"  # インドネシア語
VI = "vi"  # ベトナム語
AR = "ar"  # アラビア語（右から左に書く。画面では行ごとに語の並びを逆にして右寄せで描く）
HI = "hi"  # ヒンディー語（デーヴァナーガリー文字）
# 追加した言語のうち、ラテン文字で書く言語（ブルガリア語はキリル文字、アラビア語・ヒンディー語はそれぞれの文字）
NEW_LATIN_LANGS = (ES, DE, IT, NL, PL, HR, SK, SL, HU, ET, LV, LT, ID, VI)
NEW_LANGS = NEW_LATIN_LANGS + (BG, AR, HI)
# 2026-11-15 に追加した 7 言語。翻訳は、PLaMo が対応しないトルコ語・チェコ語・ウクライナ語は Hy-MT2、ほかは PLaMo。
# 読み上げは トルコ語・チェコ語・ウクライナ語が Supertonic 3。ほかは読み上げない（ネパール語は 2026-11-16 まで Piper で読んでいた）。
# チベット語・モンゴル語・ウイグル語も試したが、Hy-MT2 の訳は、訳し戻すと大半の文の意味が違い（「いらっしゃいませ」→「さようなら」など）、
# モンゴル語はモンゴル国のキリル文字ではなく縦書きの伝統文字だったので、見送った
TR = "tr"  # トルコ語
CS = "cs"  # チェコ語
UK = "uk"  # ウクライナ語（キリル文字）
NE = "ne"  # ネパール語（デーヴァナーガリー文字）
SI = "si"  # シンハラ語（シンハラ文字）
UZ = "uz"  # ウズベク語（ラテン文字）
FA = "fa"  # ペルシア語（アラビア文字、右から左）
MORE_LANGS = (TR, CS, UK, NE, FA, UZ, SI)
# Hy-MT2 で訳す（PLaMo が対応していない）追加の言語
MORE_KOMT_LANGS = (TR, CS, UK)
# ラテン文字で書く追加の言語
MORE_LATIN_LANGS = (TR, CS, UZ)
# 2026-11-21 に足した 24 言語（PLaMo 3 Translate が対応する 53 言語のうち、まだ入れていなかったもの）。
# 翻訳は PLaMo、読み上げはしない（画面に出すだけ）。聞き取りは Whisper small（セブアノ語は Whisper に無いので言語を自動で見分ける）
AZ = "az"  # アゼルバイジャン語（ラテン文字）
BE = "be"  # ベラルーシ語（キリル文字）
BN = "bn"  # ベンガル語（ベンガル文字）
CA = "ca"  # カタルーニャ語
CEB = "ceb"  # セブアノ語（フィリピン）
EU = "eu"  # バスク語
GU = "gu"  # グジャラート語（グジャラート文字）
HE = "he"  # ヘブライ語（ヘブライ文字、右から左）
HY = "hy"  # アルメニア語（アルメニア文字）
JV = "jv"  # ジャワ語（ラテン文字）
KA = "ka"  # ジョージア語（ジョージア文字）
KK = "kk"  # カザフ語（キリル文字）
KM = "km"  # クメール語（クメール文字）
ML = "ml"  # マラヤーラム語（マラヤーラム文字）
MR = "mr"  # マラーティー語（デーヴァナーガリー文字）
MS = "ms"  # マレー語
MY = "my"  # ミャンマー語（ビルマ文字）
PA = "pa"  # パンジャブ語（グルムキー文字）
SR = "sr"  # セルビア語（キリル文字。ラテン文字でも書く）
SW = "sw"  # スワヒリ語
TA = "ta"  # タミル語（タミル文字）
TE = "te"  # テルグ語（テルグ文字）
TL = "tl"  # タガログ語（フィリピン語）
UR = "ur"  # ウルドゥー語（アラビア文字、右から左）
NEXT_LANGS = (AZ, BE, BN, CA, CEB, EU, GU, HE, HY, JV, KA, KK, KM, ML, MR, MS, MY, PA, SR, SW, TA, TE, TL, UR)
NEXT_LATIN_LANGS = (AZ, CA, CEB, EU, JV, MS, SW, TL)
# 訳すのに時間がかかる言語と、1 文のおよその秒数（2026-11-22、Orange Pi 4 Pro で日本語 100 文を訳した平均を切り上げた値）。
# 文字の組み立てが多い言語は、訳文のトークンが多く、ほかの言語（1〜2 秒）の 3〜6 倍かかる。画面に「約 7 秒」と出す
SLOW_TRANSLATION_SEC = {MY: 7, TE: 7, KM: 7, PA: 6, GU: 5, ML: 5}
# 独自の文字で書く言語と、その文字の Unicode の範囲（訳文がその言語で書かれているかを確かめるのに使う）
SCRIPT_RANGES = {
    BN: ((0x0980, 0x09FF),), GU: ((0x0A80, 0x0AFF),), PA: ((0x0A00, 0x0A7F),), TA: ((0x0B80, 0x0BFF),),
    TE: ((0x0C00, 0x0C7F),), ML: ((0x0D00, 0x0D7F),), MY: ((0x1000, 0x109F), (0xAA60, 0xAA7F)), KM: ((0x1780, 0x17FF),),
    KA: ((0x10A0, 0x10FF), (0x1C90, 0x1CBF)), HY: ((0x0530, 0x058F), (0xFB13, 0xFB17)), HE: ((0x0590, 0x05FF), (0xFB1D, 0xFB4F)),
}
HOK = "hok"  # 北海道弁（日本語の方言。音声認識と読み上げは日本語のものを使い、訳は言葉の置き換え表 hokkaido.py で行う）
OSA = "osa"  # 大阪弁（osaka.py）
FUK = "fuk"  # 福岡弁（fukuoka.py）
NAG = "nag"  # 名古屋弁（nagoya.py。2026-11-21 に足した）
KYO = "kyo"  # 京都弁（kyoto.py。2026-11-21 に足した）
HIR = "hir"  # 広島弁（hiroshima.py。2026-11-25 に足した）
OKI = "oki"  # 沖縄弁（okinawa.py。2026-11-25 に足した）
TOH = "toh"  # 東北弁（仙台弁が元。tohoku.py。2026-11-25 に足した）
KAG = "kag"  # 鹿児島弁（kagoshima.py。2026-11-25 に足した）
TOS = "tos"  # 土佐弁（tosa.py。2026-11-25 に足した）
DIALECT_LANGS = frozenset({HOK, OSA, FUK, NAG, KYO, HIR, OKI, TOH, KAG, TOS})

# 日本語と組み合わせて翻訳できる言語
PARTNER_LANGS = (KO, EN, ZH, YUE, TH, FR, RU, PT, HOK, OSA, FUK, NAG, KYO, HIR, OKI, TOH, KAG, TOS) + NEW_LANGS + MORE_LANGS + NEXT_LANGS
# 音声で読み上げる言語の既定値（中国語は、中国語の音声合成を設定したときだけ読み上げる）。
# 広東語・タイ語・ペルシア語・シンハラ語・ウズベク語は、商用でも使える読み上げモデルがないので、
# 読み上げずに画面にだけ出す（ペルシア語の Piper の声は、商用不可の可能性がある英語の声を土台にしているので使わない）
# ネパール語は 2026-11-16 から読み上げない（sherpa-onnx 2.0 で、Piper の声に要る espeak-ng（GPL）が外れたため）
SPEAKABLE_LANGS = frozenset({JA, KO, EN, FR, RU, PT, HOK, OSA, FUK, NAG, KYO, HIR, OKI, TOH, KAG, TOS, *NEW_LANGS, TR, CS, UK})

# 音声認識・読み上げ・文字入力に、ほかの言語のものを使う言語（方言は、日本語のものを使う）
SPEECH_LANGS = {HOK: JA, OSA: JA, FUK: JA, NAG: JA, KYO: JA, HIR: JA, OKI: JA, TOH: JA, KAG: JA, TOS: JA}


def speech_lang(lang: str) -> str:
    """音声認識・読み上げに使う言語（方言は日本語）。"""
    return SPEECH_LANGS.get(lang, lang)


# 翻訳の確認（訳文を元の言語に訳し戻して表示する）を行う、話す人の言語。
# 日本語で話す人が、相手の言語の訳文を読めなくても、意図どおりに訳せたかを確かめるためのもの
BACK_TRANSLATION_SPEAKERS = frozenset({JA})

LANG_NAMES = {
    JA: "Japanese",
    KO: "Korean",
    EN: "English",
    ZH: "Chinese",
    YUE: "Cantonese",
    TH: "Thai",
    FR: "French",
    RU: "Russian",
    PT: "Portuguese",
    ES: "Spanish",
    DE: "German",
    IT: "Italian",
    NL: "Dutch",
    PL: "Polish",
    HR: "Croatian",
    SK: "Slovak",
    SL: "Slovenian",
    HU: "Hungarian",
    ET: "Estonian",
    LV: "Latvian",
    LT: "Lithuanian",
    BG: "Bulgarian",
    ID: "Indonesian",
    VI: "Vietnamese",
    AR: "Arabic",
    HI: "Hindi",
    TR: "Turkish",
    CS: "Czech",
    UK: "Ukrainian",
    NE: "Nepali",
    SI: "Sinhala",
    UZ: "Uzbek",
    FA: "Persian",
    AZ: "Azerbaijani",
    BE: "Belarusian",
    BN: "Bengali",
    CA: "Catalan",
    CEB: "Cebuano",
    EU: "Basque",
    GU: "Gujarati",
    HE: "Hebrew",
    HY: "Armenian",
    JV: "Javanese",
    KA: "Georgian",
    KK: "Kazakh",
    KM: "Khmer",
    ML: "Malayalam",
    MR: "Marathi",
    MS: "Malay",
    MY: "Burmese",
    PA: "Punjabi",
    SR: "Serbian",
    SW: "Swahili",
    TA: "Tamil",
    TE: "Telugu",
    TL: "Tagalog",
    UR: "Urdu",
    HOK: "Hokkaido dialect",
    OSA: "Osaka dialect",
    FUK: "Fukuoka dialect",
    NAG: "Nagoya dialect",
    KYO: "Kyoto dialect",
    HIR: "Hiroshima dialect",
    OKI: "Okinawa dialect",
    TOH: "Tohoku dialect",
    KAG: "Kagoshima dialect",
    TOS: "Tosa dialect",
}

FALLBACK_MESSAGES = {
    JA: "すみません、もう一度お願いします。",
    KO: "죄송합니다. 다시 한번 말씀해 주세요.",
    EN: "Sorry, could you say that again?",
    ZH: "抱歉，请再说一遍。",
    YUE: "唔好意思，請再講多次。",
    TH: "ขอโทษค่ะ กรุณาพูดอีกครั้งค่ะ",
    FR: "Pardon, pouvez-vous répéter ?",
    RU: "Извините, повторите, пожалуйста.",
    PT: "Desculpe, pode repetir?",
    ES: "Perdón, ¿puede repetirlo?",
    DE: "Entschuldigung, können Sie das wiederholen?",
    IT: "Scusi, può ripetere?",
    NL: "Sorry, kunt u dat herhalen?",
    PL: "Przepraszam, czy może Pan(i) powtórzyć?",
    HR: "Oprostite, možete li ponoviti?",
    SK: "Prepáčte, môžete to zopakovať?",
    SL: "Oprostite, lahko ponovite?",
    HU: "Elnézést, megismételné?",
    ET: "Vabandust, kas saaksite korrata?",
    LV: "Atvainojiet, vai varat atkārtot?",
    LT: "Atsiprašau, ar galite pakartoti?",
    BG: "Извинете, може ли да повторите?",
    ID: "Maaf, bisa diulangi?",
    VI: "Xin lỗi, quý khách có thể nói lại được không ạ?",
    AR: "عذراً، هل يمكنك أن تكرر ذلك؟",
    HI: "माफ़ कीजिए, क्या आप फिर से कह सकते हैं?",
    TR: "Affedersiniz, tekrar eder misiniz?",
    CS: "Promiňte, můžete to zopakovat?",
    UK: "Вибачте, можете повторити?",
    NE: "माफ गर्नुहोस्, फेरि भन्न सक्नुहुन्छ?",
    SI: "සමාවෙන්න, නැවත කියන්න පුළුවන්ද?",
    UZ: "Kechirasiz, takrorlab bera olasizmi?",
    FA: "ببخشید، می‌توانید تکرار کنید؟",
    AZ: "Bağışlayın, təkrar edə bilərsinizmi?",
    BE: "Прабачце, можаце паўтарыць?",
    BN: "দুঃখিত, আবার বলবেন কি?",
    CA: "Perdó, ho pot repetir?",
    CEB: "Pasayloa ko, mahimo ba nimo kining sublion?",
    EU: "Barkatu, errepikatu dezakezu?",
    GU: "માફ કરશો, ફરીથી કહેશો?",
    HE: "סליחה, אפשר לחזור על זה?",
    HY: "Ներեցեք, կարո՞ղ եք կրկնել։",
    JV: "Nuwun sewu, saged dibaleni?",
    KA: "ბოდიში, შეგიძლიათ გაიმეოროთ?",
    KK: "Кешіріңіз, қайталай аласыз ба?",
    KM: "សុំទោស តើអាចនិយាយម្ដងទៀតបានទេ?",
    ML: "ക്ഷമിക്കണം, ഒന്നുകൂടി പറയാമോ?",
    MR: "माफ करा, पुन्हा सांगाल का?",
    MS: "Maaf, boleh ulang sekali lagi?",
    MY: "တောင်းပန်ပါတယ်၊ ထပ်ပြောပေးပါလား။",
    PA: "ਮਾਫ਼ ਕਰਨਾ, ਕੀ ਤੁਸੀਂ ਦੁਬਾਰਾ ਕਹਿ ਸਕਦੇ ਹੋ?",
    SR: "Извините, можете ли да поновите?",
    SW: "Samahani, unaweza kurudia?",
    TA: "மன்னிக்கவும், மீண்டும் சொல்ல முடியுமா?",
    TE: "క్షమించండి, మళ్ళీ చెప్పగలరా?",
    TL: "Paumanhin, puwede po bang ulitin?",
    UR: "معاف کیجیے، کیا آپ دوبارہ کہہ سکتے ہیں؟",
    HOK: "すんません、もういっかいお願いしますわ。",
    OSA: "すんません、もういっぺん言うてくれまっか。",
    FUK: "すんません、もういっぺん言うてくれんね。",
    NAG: "すんません、もっぺん言ってちょう。",
    KYO: "すんまへん、もういっぺん言うておくれやす。",
    HIR: "すまんのう、もういっぺん言うてくれんさい。",
    OKI: "ごめんねー、もう一回言ってねー。",
    TOH: "わりぃっちゃ、もう一回言ってけらいん。",
    KAG: "すんもはん、もういっぺん言うてくいやんせ。",
    TOS: "すまんけんど、もういっぺん言うてや。",
}

# 「キャンセル」で取り消したあとに言い直したとき、相手に「前の訳は取り消し」と伝えるため、訳文の前に付ける言葉
CORRECTION_PREFIXES = {
    JA: "訂正します：",
    KO: "정정합니다: ",
    EN: "Correction: ",
    ZH: "更正：",
    YUE: "更正：",
    TH: "ขอแก้ไข: ",
    FR: "Correction : ",
    RU: "Исправление: ",
    PT: "Correção: ",
    ES: "Corrección: ",
    DE: "Korrektur: ",
    IT: "Correzione: ",
    NL: "Correctie: ",
    PL: "Poprawka: ",
    HR: "Ispravak: ",
    SK: "Oprava: ",
    SL: "Popravek: ",
    HU: "Javítás: ",
    ET: "Parandus: ",
    LV: "Labojums: ",
    LT: "Pataisymas: ",
    BG: "Поправка: ",
    ID: "Koreksi: ",
    VI: "Đính chính: ",
    AR: "تصحيح: ",
    HI: "सुधार: ",
    TR: "Düzeltme: ",
    CS: "Oprava: ",
    UK: "Виправлення: ",
    NE: "सुधार: ",
    SI: "නිවැරදි කිරීම: ",
    UZ: "Tuzatish: ",
    FA: "اصلاح: ",
    AZ: "Düzəliş: ",
    BE: "Выпраўленне: ",
    BN: "সংশোধন: ",
    CA: "Correcció: ",
    CEB: "Pagtul-id: ",
    EU: "Zuzenketa: ",
    GU: "સુધારો: ",
    HE: "תיקון: ",
    HY: "Ուղղում՝ ",
    JV: "Koreksi: ",
    KA: "შესწორება: ",
    KK: "Түзету: ",
    KM: "ការកែតម្រូវ៖ ",
    ML: "തിരുത്ത്: ",
    MR: "दुरुस्ती: ",
    MS: "Pembetulan: ",
    MY: "ပြင်ဆင်ချက် - ",
    PA: "ਸੋਧ: ",
    SR: "Исправка: ",
    SW: "Marekebisho: ",
    TA: "திருத்தம்: ",
    TE: "సవరణ: ",
    TL: "Pagwawasto: ",
    UR: "تصحیح: ",
    HOK: "訂正するべさ：",
    OSA: "訂正やで：",
    FUK: "訂正ばい：",
    NAG: "訂正だがね：",
    KYO: "訂正どす：",
    HIR: "訂正じゃけぇ：",
    OKI: "訂正さー：",
    TOH: "訂正だっちゃ：",
    KAG: "訂正じゃっど：",
    TOS: "訂正ぜよ：",
}

# 日本語訳に「かな」が1つもないとき、漢字・ラテン文字がこれより多ければ中国語・英語のままと見なす
_MAX_HAN_WITHOUT_KANA = 5
_MAX_LATIN_WITHOUT_KANA = 11

# 「؟」はアラビア語の疑問符、「।」はヒンディー語・ベンガル語などの文末（ダンダ）、「။」はミャンマー語、「។」はクメール語、
# 「։」はアルメニア語、「۔」はウルドゥー語の文末
_TERMINATORS = frozenset("。！？!?؟।။។։۔")
# 文末記号の直後に続けて、同じ文に含める文字
_TRAILING = frozenset("。！？!?؟।။។։۔.」』）)】\"'”’")
# 最初の読み上げを早く始めるときに、区切りとして使う読点（「،」はアラビア語の読点）
_CLAUSE_BREAKS = frozenset("、，,،၊")


@dataclass(frozen=True)
class ScriptCounts:
    kana: int = 0
    hangul: int = 0
    han: int = 0
    latin: int = 0
    thai: int = 0
    cyrillic: int = 0
    arabic: int = 0
    devanagari: int = 0
    sinhala: int = 0
    hebrew: int = 0
    other: int = 0  # SCRIPT_RANGES のヘブライ文字以外の文字（ベンガル文字・タミル文字・ジョージア文字など）

    @property
    def letters(self) -> int:
        return (self.kana + self.hangul + self.han + self.latin + self.thai + self.cyrillic + self.arabic + self.devanagari
                + self.sinhala + self.hebrew + self.other)


@dataclass(frozen=True)
class Mode:
    """翻訳の組み合わせ（日本語 ⇔ partner）と、話す人の言語（speaker）。"""

    partner: str
    speaker: str

    def __post_init__(self) -> None:
        if self.partner not in PARTNER_LANGS:
            raise ValueError(f"相手の言語は {', '.join(PARTNER_LANGS)} のいずれかにしてください: {self.partner}")
        if self.speaker not in (JA, self.partner):
            raise ValueError(f"話す人の言語は {JA} か {self.partner} にしてください: {self.speaker}")

    @property
    def listener(self) -> str:
        """訳文の言語（話す人ではない側）。"""
        return self.partner if self.speaker == JA else JA

    def swapped(self) -> Mode:
        return Mode(self.partner, self.listener)

    def with_partner(self, partner: str) -> Mode:
        """組み合わせを変える。日本語を話す設定ならそのまま、相手側を話す設定なら新しい相手の言語にする。"""
        return Mode(partner, JA if self.speaker == JA else partner)


@dataclass(frozen=True)
class Route:
    """1回の発話をどう訳して、どう出力するか。"""

    source: str
    target: str
    speak: bool  # 訳文を読み上げるか
    show_source: bool  # 原文を画面に出すか


def count_scripts(text: str) -> ScriptCounts:
    """文字種ごとの文字数を数える（「々」は日本語特有なので、かなとして数える）。

    フランス語のアクセント付きの文字（é・ç・œ など）はラテン文字、タイ文字は母音記号・声調記号も含めて数える。
    ロシア語のキリル文字は、ラテン文字とは別に数える。
    """
    kana = hangul = han = latin = thai = cyrillic = arabic = devanagari = sinhala = hebrew = other = 0
    for ch in text:
        code = ord(ch)
        if 0x3041 <= code <= 0x30FF or 0x31F0 <= code <= 0x31FF or 0xFF66 <= code <= 0xFF9F or code == 0x3005:
            kana += 1
        elif 0xAC00 <= code <= 0xD7A3 or 0x1100 <= code <= 0x11FF or 0x3130 <= code <= 0x318F:
            hangul += 1
        elif 0x4E00 <= code <= 0x9FFF or 0x3400 <= code <= 0x4DBF or 0xF900 <= code <= 0xFAFF or 0x20000 <= code <= 0x3134F:
            han += 1
        elif 0x0E01 <= code <= 0x0E5B:
            thai += 1
        elif 0x0400 <= code <= 0x04FF and ch.isalpha():
            cyrillic += 1
        elif ch.isalpha() and (code < 0x0250 or code == 0x0259 or 0x1E00 <= code <= 0x1EFF or 0xFF21 <= code <= 0xFF5A):  # 0x1E00〜: ベトナム語の ạ・ố など
            latin += 1
        elif (0x0600 <= code <= 0x06FF or 0x0750 <= code <= 0x077F or 0xFB50 <= code <= 0xFEFF) and ch.isalpha():
            arabic += 1
        elif 0x0900 <= code <= 0x097F and ch.isalpha():  # 母音記号（ि・ी など）は文字の一部なので数えない
            devanagari += 1
        elif 0x0D80 <= code <= 0x0DFF and ch.isalpha():  # シンハラ文字（母音記号は数えない）
            sinhala += 1
        elif ch.isalpha() and _in_ranges(code, SCRIPT_RANGES[HE]):
            hebrew += 1
        elif ch.isalpha() and _script_lang(code):
            other += 1
    return ScriptCounts(kana, hangul, han, latin, thai, cyrillic, arabic, devanagari, sinhala, hebrew, other)


def _in_ranges(code: int, ranges: tuple[tuple[int, int], ...]) -> bool:
    return any(low <= code <= high for low, high in ranges)


def _script_lang(code: int) -> str:
    """SCRIPT_RANGES のどの言語の文字か（ヘブライ文字以外。どれでもなければ ""）。"""
    for lang, ranges in SCRIPT_RANGES.items():
        if lang != HE and _in_ranges(code, ranges):
            return lang
    return ""


def count_script(text: str, lang: str) -> int:
    """text のうち、SCRIPT_RANGES の lang の文字（母音記号などは数えない）の数。"""
    return sum(1 for ch in text if ch.isalpha() and _in_ranges(ord(ch), SCRIPT_RANGES[lang]))


# 画面では、アラビア文字の行を右から左に並べる（pygame.freetype は、語の中の文字は正しくつなげるが、語は左から右に並べるため）
_RTL_END_PUNCTUATION = ".!?؟،,:;"


def is_rtl_line(text: str) -> bool:
    """右から左に書く行か（アラビア文字・ヘブライ文字が、ラテン文字などより多い）。"""
    counts = count_scripts(text)
    rtl = counts.arabic + counts.hebrew
    return rtl > 0 and rtl >= counts.letters - rtl


def rtl_visual_line(line: str) -> str:
    """アラビア語の 1 行を、左から右に描いたときに正しく読める並びにする（語の順を逆にし、文末の記号を語の左に移す）。

    「المرحاض في الطابق الثاني.」→「.الثاني الطابق في المرحاض」（右から読むと元の文になる）。
    語の中の文字のつながりは、描くときにフォントが付ける。数字やラテン文字の語は、そのまま 1 つの語として扱う。
    """
    words = []
    for word in line.split(" "):
        stripped = word.rstrip(_RTL_END_PUNCTUATION)
        if stripped and stripped != word and (count_scripts(stripped).arabic or count_scripts(stripped).hebrew):
            word = word[len(stripped):] + stripped  # 「الثاني.」→「.الثاني」
        words.append(word)
    return " ".join(reversed(words))


def has_letters(text: str) -> bool:
    """何か聞き取れたか（文字として数えられるものがあるか）。"""
    return count_scripts(text).letters > 0


def _command_word(text: str) -> str:
    """句読点・空白を除き、小文字にする（タイ文字の母音記号・声調記号は文字の一部として残す）。"""
    return "".join(ch for ch in text if ch.isalnum() or unicodedata.category(ch).startswith("M")).lower()


# 話す人を入れ替える音声コマンド（待機中だけ。発話全体がこの言葉だけのときに反応する）。
# 韓国語・タイ語の音声認識では「change」がその言語の文字で書かれることがあるので、それも含める。
CHANGE_COMMANDS = frozenset(_command_word(w) for w in ("チェンジ", "ちぇんじ", "change", "체인지", "เชนจ์", "чендж", "чейндж", "trocar"))
# 処理を止めて待機中に戻す音声コマンド（相手の言語での「キャンセル」「取り消し」も含める）
CANCEL_COMMANDS = frozenset(
    _command_word(w) for w in ("キャンセル", "きゃんせる", "cancel", "캔슬", "취소", "取消", "ยกเลิก", "แคนเซิล", "annuler", "отмена", "отменить", "cancelar")
)
# 「会話スタート」と同じく聞き取りを始める音声コマンド（待機中だけ）。話す人が相手の言語のときは、その言語の音声認識で
# 書き起こされるので、英語・ハングル・タイ文字での書き方も含める。
START_COMMANDS = frozenset(_command_word(w) for w in ("スタート", "すたーと", "start", "스타트", "สตาร์ท", "старт", "começar", "iniciar"))


def is_change_command(text: str) -> bool:
    """発話が「チェンジ」「change」だけか（句読点・空白・大文字小文字は無視する）。"""
    return _command_word(text) in CHANGE_COMMANDS


def is_cancel_command(text: str) -> bool:
    """発話が「キャンセル」「cancel」だけか（句読点・空白・大文字小文字は無視する）。"""
    return _command_word(text) in CANCEL_COMMANDS


def is_start_command(text: str) -> bool:
    """発話が「スタート」「start」だけか（句読点・空白・大文字小文字は無視する）。"""
    return _command_word(text) in START_COMMANDS


def plan_route(
    mode: Mode, show_japanese_source: bool = False, speakable_langs: Collection[str] = SPEAKABLE_LANGS
) -> Route:
    """話す人の言語から、もう一方の言語へ訳す。外国語の原文は常に表示する。

    speakable_langs は読み上げられる言語（中国語の音声合成を設定したときは中国語も含む）。
    """
    show_source = show_japanese_source if mode.speaker == JA else True
    return Route(mode.speaker, mode.listener, mode.listener in speakable_langs, show_source)


def is_valid_translation(text: str, target: str) -> bool:
    """訳文が目的の言語で書かれているかを、文字種で確かめる。"""
    counts = count_scripts(text)
    if counts.letters == 0:
        return False
    others = counts.kana + counts.hangul + counts.han + counts.thai + counts.cyrillic
    scripts = counts.hebrew + counts.other  # 2026-11-21 に足した言語の文字
    if target in (AR, FA, UR):  # アラビア語・ペルシア語・ウルドゥー語（アラビア文字）
        return counts.arabic > 0 and others == counts.devanagari == counts.sinhala == scripts == 0
    if target in (HI, NE, MR):  # ヒンディー語・ネパール語・マラーティー語（デーヴァナーガリー文字）
        return counts.devanagari > 0 and others == counts.arabic == counts.sinhala == scripts == 0
    if target == SI:
        return counts.sinhala > 0 and others == counts.arabic == counts.devanagari == scripts == 0
    if target in SCRIPT_RANGES:
        # ベンガル語・タミル語・ヘブライ語など: その言語の文字があり、ほかの文字は（Wi-Fi のようなラテン文字の語を除いて）無い
        own = count_script(text, target)
        return own > 0 and counts.letters - counts.latin - own == 0
    if counts.arabic or counts.devanagari or counts.sinhala or scripts:
        return False  # アラビア文字・デーヴァナーガリー文字・シンハラ文字などが混ざった訳文は、ほかの言語の訳として使わない
    if target == JA or target in DIALECT_LANGS:
        if counts.hangul or counts.thai or counts.cyrillic:
            return False
        if counts.kana == 0:
            return counts.han <= _MAX_HAN_WITHOUT_KANA and (counts.han > 0 or counts.latin <= _MAX_LATIN_WITHOUT_KANA)
        return True
    if target == KO:
        # 漢字も認めない（Hy-MT2 は「试穿은 3개까지」のように中国語の字を混ぜることがある。2026-10-01 に確認）
        return counts.hangul > 0 and counts.kana == counts.han == counts.thai == counts.cyrillic == 0
    if target in (EN, FR, PT, *NEW_LATIN_LANGS, *MORE_LATIN_LANGS, *NEXT_LATIN_LANGS):
        # 英語・フランス語・ポルトガル語・スペイン語などは、文字種では見分けられない（どれもラテン文字）
        return counts.latin > 0 and counts.kana == counts.hangul == counts.han == counts.thai == counts.cyrillic == 0
    if target in (ZH, YUE):
        return counts.han > 0 and counts.kana == counts.hangul == counts.thai == counts.cyrillic == 0
    if target == TH:
        return counts.thai > 0 and counts.kana == counts.hangul == counts.han == counts.cyrillic == 0
    if target == SR:
        # セルビア語は、キリル文字でもラテン文字でも書く
        return counts.cyrillic + counts.latin > 0 and counts.kana == counts.hangul == counts.han == counts.thai == 0
    if target in (RU, BG, UK, BE, KK):
        # 「Wi-Fi」のようなラテン文字の語は、ロシア語・ブルガリア語・ウクライナ語の文にも出てくるので認める
        return counts.cyrillic > 0 and counts.kana == counts.hangul == counts.han == counts.thai == 0
    raise ValueError(f"未対応の言語です: {target}")


def join_sentences(sentences: Sequence[str], lang: str) -> str:
    """文をつなぐ。英語・韓国語・フランス語・ロシア語・ポルトガル語・タイ語は空白を挟む（タイ語は文の区切りに空白を使う）。"""
    return (" " if lang in (EN, KO, FR, RU, TH, PT, *NEW_LANGS, *MORE_LANGS, *NEXT_LANGS) else "").join(sentences)


class SentenceSplitter:
    """LLM の出力を少しずつ受け取り、文末記号で文を切り出す。

    first_clause_chars > 0 のとき、最初の1つだけは、その文字数以上たまった時点で読点でも区切る。
    読み上げを早く始めるためで、2つ目以降は文末まで待って自然な抑揚で読ませる。
    """

    def __init__(self, first_clause_chars: int = 0) -> None:
        self._buffer = ""
        self._first_clause_chars = first_clause_chars
        self._emitted = False

    def feed(self, delta: str) -> list[str]:
        self._buffer += delta
        sentences = []
        while (end := self._find_end(self._buffer)) is not None:
            sentence = self._buffer[:end].strip()
            self._buffer = self._buffer[end:]
            if sentence:
                sentences.append(sentence)
                self._emitted = True
        return sentences

    def flush(self) -> list[str]:
        rest = self._buffer.strip()
        self._buffer = ""
        return [rest] if rest else []

    def _find_end(self, buffer: str) -> int | None:
        split_clauses = self._first_clause_chars > 0 and not self._emitted
        for i, ch in enumerate(buffer):
            is_clause = split_clauses and ch in _CLAUSE_BREAKS and len(buffer[:i].strip()) >= self._first_clause_chars
            if not (is_clause or ch in _TERMINATORS or ch == "."):
                continue
            end = i + 1
            while end < len(buffer) and buffer[end] in _TRAILING:
                end += 1
            if end == len(buffer):
                return None  # 閉じ括弧などが続くかもしれないので、次の出力を待つ
            if ch in ".," and not buffer[end].isspace():
                continue  # 「3.5」「1,000」「e.g.」のような語中の記号
            if ch == "." and not any(c.isalpha() for c in buffer[:i]):
                # 「5. bagoia」（バスク語・セルビア語などの序数）の「5.」だけを文として切らない。
                # 文字の無い「5.」だけの文は、訳文の検査で不正とされ、正しい訳がお詫び文に置き換わっていた（2026-11-22）
                continue
            return end
        return None

# 音の設定の「声」: 標準（config.toml の speaker_id）・女性・男性
VOICES = ("standard", "female", "male")
