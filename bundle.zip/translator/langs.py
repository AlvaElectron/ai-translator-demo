"""言語まわりの処理: 翻訳の組み合わせ、訳文の検証、文の切り出し（外部ライブラリに依存しない）。"""

from __future__ import annotations

import unicodedata
from collections.abc import Collection, Sequence
from dataclasses import dataclass

JA = "ja"
KO = "ko"
EN = "en"
ZH = "zh"
YUE = "yue"  # 広東語（香港）
TH = "th"  # タイ語
FR = "fr"  # フランス語
RU = "ru"  # ロシア語
PT = "pt"  # ポルトガル語（ブラジル式）
HOK = "hok"  # 北海道弁（日本語の方言。音声認識と読み上げは日本語のものを使い、訳は言葉の置き換え表 hokkaido.py で行う）
OSA = "osa"  # 大阪弁（osaka.py）
FUK = "fuk"  # 福岡弁（fukuoka.py）
DIALECT_LANGS = frozenset({HOK, OSA, FUK})

# 日本語と組み合わせて翻訳できる言語
PARTNER_LANGS = (KO, EN, ZH, YUE, TH, FR, RU, PT, HOK, OSA, FUK)
# 音声で読み上げる言語の既定値（中国語は、中国語の音声合成を設定したときだけ読み上げる）。
# 広東語とタイ語は、商用でも使える読み上げモデルがないので、読み上げずに画面にだけ出す
SPEAKABLE_LANGS = frozenset({JA, KO, EN, FR, RU, PT, HOK, OSA, FUK})

# 音声認識・読み上げ・文字入力に、ほかの言語のものを使う言語（方言は、日本語のものを使う）
SPEECH_LANGS = {HOK: JA, OSA: JA, FUK: JA}


def speech_lang(lang: str) -> str:
    """音声認識・読み上げに使う言語（方言は日本語）。"""
    return SPEECH_LANGS.get(lang, lang)


# 翻訳の確認（訳文を元の言語に訳し戻して表示する）を行う、話す人の言語。
# 日本語で話す人が、相手の言語の訳文を読めなくても、意図どおりに訳せたかを確かめるためのもの
BACK_TRANSLATION_SPEAKERS = frozenset({JA})

LANG_NAMES = {
    JA: "Japanese",
    KO: "Korean",
    EN: "English",
    ZH: "Chinese",
    YUE: "Cantonese",
    TH: "Thai",
    FR: "French",
    RU: "Russian",
    PT: "Portuguese",
    HOK: "Hokkaido dialect",
    OSA: "Osaka dialect",
    FUK: "Fukuoka dialect",
}

FALLBACK_MESSAGES = {
    JA: "すみません、もう一度お願いします。",
    KO: "죄송합니다. 다시 한번 말씀해 주세요.",
    EN: "Sorry, could you say that again?",
    ZH: "抱歉，请再说一遍。",
    YUE: "唔好意思，請再講多次。",
    TH: "ขอโทษค่ะ กรุณาพูดอีกครั้งค่ะ",
    FR: "Pardon, pouvez-vous répéter ?",
    RU: "Извините, повторите, пожалуйста.",
    PT: "Desculpe, pode repetir?",
    HOK: "すんません、もういっかいお願いしますわ。",
    OSA: "すんません、もういっぺん言うてくれまっか。",
    FUK: "すんません、もういっぺん言うてくれんね。",
}

# 「キャンセル」で取り消したあとに言い直したとき、相手に「前の訳は取り消し」と伝えるため、訳文の前に付ける言葉
CORRECTION_PREFIXES = {
    JA: "訂正します：",
    KO: "정정합니다: ",
    EN: "Correction: ",
    ZH: "更正：",
    YUE: "更正：",
    TH: "ขอแก้ไข: ",
    FR: "Correction : ",
    RU: "Исправление: ",
    PT: "Correção: ",
    HOK: "訂正するべさ：",
    OSA: "訂正やで：",
    FUK: "訂正ばい：",
}

# 日本語訳に「かな」が1つもないとき、漢字・ラテン文字がこれより多ければ中国語・英語のままと見なす
_MAX_HAN_WITHOUT_KANA = 5
_MAX_LATIN_WITHOUT_KANA = 11

_TERMINATORS = frozenset("。！？!?")
# 文末記号の直後に続けて、同じ文に含める文字
_TRAILING = frozenset("。！？!?.」』）)】\"'”’")
# 最初の読み上げを早く始めるときに、区切りとして使う読点
_CLAUSE_BREAKS = frozenset("、，,")


@dataclass(frozen=True)
class ScriptCounts:
    kana: int = 0
    hangul: int = 0
    han: int = 0
    latin: int = 0
    thai: int = 0
    cyrillic: int = 0

    @property
    def letters(self) -> int:
        return self.kana + self.hangul + self.han + self.latin + self.thai + self.cyrillic


@dataclass(frozen=True)
class Mode:
    """翻訳の組み合わせ（日本語 ⇔ partner）と、話す人の言語（speaker）。"""

    partner: str
    speaker: str

    def __post_init__(self) -> None:
        if self.partner not in PARTNER_LANGS:
            raise ValueError(f"相手の言語は {', '.join(PARTNER_LANGS)} のいずれかにしてください: {self.partner}")
        if self.speaker not in (JA, self.partner):
            raise ValueError(f"話す人の言語は {JA} か {self.partner} にしてください: {self.speaker}")

    @property
    def listener(self) -> str:
        """訳文の言語（話す人ではない側）。"""
        return self.partner if self.speaker == JA else JA

    def swapped(self) -> Mode:
        return Mode(self.partner, self.listener)

    def with_partner(self, partner: str) -> Mode:
        """組み合わせを変える。日本語を話す設定ならそのまま、相手側を話す設定なら新しい相手の言語にする。"""
        return Mode(partner, JA if self.speaker == JA else partner)


@dataclass(frozen=True)
class Route:
    """1回の発話をどう訳して、どう出力するか。"""

    source: str
    target: str
    speak: bool  # 訳文を読み上げるか
    show_source: bool  # 原文を画面に出すか


def count_scripts(text: str) -> ScriptCounts:
    """文字種ごとの文字数を数える（「々」は日本語特有なので、かなとして数える）。

    フランス語のアクセント付きの文字（é・ç・œ など）はラテン文字、タイ文字は母音記号・声調記号も含めて数える。
    ロシア語のキリル文字は、ラテン文字とは別に数える。
    """
    kana = hangul = han = latin = thai = cyrillic = 0
    for ch in text:
        code = ord(ch)
        if 0x3041 <= code <= 0x30FF or 0x31F0 <= code <= 0x31FF or 0xFF66 <= code <= 0xFF9F or code == 0x3005:
            kana += 1
        elif 0xAC00 <= code <= 0xD7A3 or 0x1100 <= code <= 0x11FF or 0x3130 <= code <= 0x318F:
            hangul += 1
        elif 0x4E00 <= code <= 0x9FFF or 0x3400 <= code <= 0x4DBF or 0xF900 <= code <= 0xFAFF or 0x20000 <= code <= 0x3134F:
            han += 1
        elif 0x0E01 <= code <= 0x0E5B:
            thai += 1
        elif 0x0400 <= code <= 0x04FF and ch.isalpha():
            cyrillic += 1
        elif ch.isalpha() and (code < 0x0250 or 0xFF21 <= code <= 0xFF5A):
            latin += 1
    return ScriptCounts(kana, hangul, han, latin, thai, cyrillic)


def has_letters(text: str) -> bool:
    """何か聞き取れたか（文字として数えられるものがあるか）。"""
    return count_scripts(text).letters > 0


def _command_word(text: str) -> str:
    """句読点・空白を除き、小文字にする（タイ文字の母音記号・声調記号は文字の一部として残す）。"""
    return "".join(ch for ch in text if ch.isalnum() or unicodedata.category(ch).startswith("M")).lower()


# 話す人を入れ替える音声コマンド（待機中だけ。発話全体がこの言葉だけのときに反応する）。
# 韓国語・タイ語の音声認識では「change」がその言語の文字で書かれることがあるので、それも含める。
CHANGE_COMMANDS = frozenset(_command_word(w) for w in ("チェンジ", "ちぇんじ", "change", "체인지", "เชนจ์", "чендж", "чейндж", "trocar"))
# 処理を止めて待機中に戻す音声コマンド（相手の言語での「キャンセル」「取り消し」も含める）
CANCEL_COMMANDS = frozenset(
    _command_word(w) for w in ("キャンセル", "きゃんせる", "cancel", "캔슬", "취소", "取消", "ยกเลิก", "แคนเซิล", "annuler", "отмена", "отменить", "cancelar")
)
# 「会話スタート」と同じく聞き取りを始める音声コマンド（待機中だけ）。話す人が相手の言語のときは、その言語の音声認識で
# 書き起こされるので、英語・ハングル・タイ文字での書き方も含める。
START_COMMANDS = frozenset(_command_word(w) for w in ("スタート", "すたーと", "start", "스타트", "สตาร์ท", "старт", "começar", "iniciar"))


def is_change_command(text: str) -> bool:
    """発話が「チェンジ」「change」だけか（句読点・空白・大文字小文字は無視する）。"""
    return _command_word(text) in CHANGE_COMMANDS


def is_cancel_command(text: str) -> bool:
    """発話が「キャンセル」「cancel」だけか（句読点・空白・大文字小文字は無視する）。"""
    return _command_word(text) in CANCEL_COMMANDS


def is_start_command(text: str) -> bool:
    """発話が「スタート」「start」だけか（句読点・空白・大文字小文字は無視する）。"""
    return _command_word(text) in START_COMMANDS


def plan_route(
    mode: Mode, show_japanese_source: bool = False, speakable_langs: Collection[str] = SPEAKABLE_LANGS
) -> Route:
    """話す人の言語から、もう一方の言語へ訳す。外国語の原文は常に表示する。

    speakable_langs は読み上げられる言語（中国語の音声合成を設定したときは中国語も含む）。
    """
    show_source = show_japanese_source if mode.speaker == JA else True
    return Route(mode.speaker, mode.listener, mode.listener in speakable_langs, show_source)


def is_valid_translation(text: str, target: str) -> bool:
    """訳文が目的の言語で書かれているかを、文字種で確かめる。"""
    counts = count_scripts(text)
    if counts.letters == 0:
        return False
    if target == JA or target in DIALECT_LANGS:
        if counts.hangul or counts.thai or counts.cyrillic:
            return False
        if counts.kana == 0:
            return counts.han <= _MAX_HAN_WITHOUT_KANA and (counts.han > 0 or counts.latin <= _MAX_LATIN_WITHOUT_KANA)
        return True
    if target == KO:
        # 漢字も認めない（Hy-MT2 は「试穿은 3개까지」のように中国語の字を混ぜることがある。2026-10-01 に確認）
        return counts.hangul > 0 and counts.kana == counts.han == counts.thai == counts.cyrillic == 0
    if target in (EN, FR, PT):
        # 英語・フランス語・ポルトガル語は、文字種では見分けられない（どれもラテン文字）
        return counts.latin > 0 and counts.kana == counts.hangul == counts.han == counts.thai == counts.cyrillic == 0
    if target in (ZH, YUE):
        return counts.han > 0 and counts.kana == counts.hangul == counts.thai == counts.cyrillic == 0
    if target == TH:
        return counts.thai > 0 and counts.kana == counts.hangul == counts.han == counts.cyrillic == 0
    if target == RU:
        # 「Wi-Fi」のようなラテン文字の語は、ロシア語の文にも出てくるので認める
        return counts.cyrillic > 0 and counts.kana == counts.hangul == counts.han == counts.thai == 0
    raise ValueError(f"未対応の言語です: {target}")


def join_sentences(sentences: Sequence[str], lang: str) -> str:
    """文をつなぐ。英語・韓国語・フランス語・ロシア語・ポルトガル語・タイ語は空白を挟む（タイ語は文の区切りに空白を使う）。"""
    return (" " if lang in (EN, KO, FR, RU, TH, PT) else "").join(sentences)


class SentenceSplitter:
    """LLM の出力を少しずつ受け取り、文末記号で文を切り出す。

    first_clause_chars > 0 のとき、最初の1つだけは、その文字数以上たまった時点で読点でも区切る。
    読み上げを早く始めるためで、2つ目以降は文末まで待って自然な抑揚で読ませる。
    """

    def __init__(self, first_clause_chars: int = 0) -> None:
        self._buffer = ""
        self._first_clause_chars = first_clause_chars
        self._emitted = False

    def feed(self, delta: str) -> list[str]:
        self._buffer += delta
        sentences = []
        while (end := self._find_end(self._buffer)) is not None:
            sentence = self._buffer[:end].strip()
            self._buffer = self._buffer[end:]
            if sentence:
                sentences.append(sentence)
                self._emitted = True
        return sentences

    def flush(self) -> list[str]:
        rest = self._buffer.strip()
        self._buffer = ""
        return [rest] if rest else []

    def _find_end(self, buffer: str) -> int | None:
        split_clauses = self._first_clause_chars > 0 and not self._emitted
        for i, ch in enumerate(buffer):
            is_clause = split_clauses and ch in _CLAUSE_BREAKS and len(buffer[:i].strip()) >= self._first_clause_chars
            if not (is_clause or ch in _TERMINATORS or ch == "."):
                continue
            end = i + 1
            while end < len(buffer) and buffer[end] in _TRAILING:
                end += 1
            if end == len(buffer):
                return None  # 閉じ括弧などが続くかもしれないので、次の出力を待つ
            if ch in ".," and not buffer[end].isspace():
                continue  # 「3.5」「1,000」「e.g.」のような語中の記号
            return end
        return None
