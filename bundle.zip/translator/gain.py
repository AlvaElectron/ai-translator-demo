"""スピーカー音量・マイク増幅・話し終わりの判定の段階と、入力レベルの目安（外部ライブラリに依存しない）。"""

from __future__ import annotations

from collections.abc import Sequence

# メニューで選べるマイク増幅の倍率（2026-10-03 に、声の小さい場所・遠くの声のため ×8 から ×32 まで広げた）
GAIN_STEPS = (0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0, 8.0, 12.0, 16.0, 24.0, 32.0)
# メニューで選べるスピーカー音量（1.0 = 合成音声そのまま。1 を超えると大きな音は割れることがある）
VOLUME_STEPS = (0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.25, 1.5)
# メニューで選べる、話し終わりと判断する無音の秒数（声がこの秒数だけ途切れたら、翻訳を始める）。
# 短い方は細かく選べる（速さを詰めたいとき）。1.5 秒から上は 0.5 秒ごと。
# 短くするほど早く訳し始めるが、文の途中の息つぎで区切られやすくなる
SILENCE_STEPS = (0.4, 0.5, 0.6, 0.8, 1.0, 1.2, 1.5, 2.0, 2.5, 3.0)
# メニューで選べる、1回に話せる長さの上限（話し続けても、この秒数で区切って翻訳する）
MAX_SPEECH_STEPS = (2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0)
# メニューで選べる読み上げの速さ。config.toml の tts.speed（0.8）を「1.0倍」とした倍率で、画面にもこの値を出す。
# Supertonic に渡す speed は tts.speed × 倍率（0.64〜0.8）。
# 合成した音声を音声認識で聞き直して確かめた（2026-09-22、Pi 5、7文×4回）: speed 0.64・0.72・0.8 は 28/28 すべて最後まで読まれ、
# 0.9 は 26/28（「話せません」→「話せます」のように語尾が落ちることがある）、1.0 以上は 20/28 以下。
# 遅すぎても崩れる: 0.56（0.7倍）では「여러분, 안녕하세요.」が「여러분.」「아.」になった（26/28）。
# 語尾が切れたり崩れたりすると意味が変わるので、確かめた範囲（0.8〜1.0倍）だけを選べるようにしている
SPEECH_SPEED_STEPS = (0.8, 0.9, 1.0)
# 話しているときのピークがこの範囲に入るのが目安（緑の範囲）。増幅を上げられるようにしたのに合わせて、
# 2026-10-03 に 0.2〜0.7 から 0.3〜0.8 に上げた（上は 1.0 で音が割れるので、0.8 までにして余裕を残す）
GOOD_LEVEL = (0.3, 0.8)


def step_value(steps: Sequence[float], current: float, direction: int) -> float:
    """current より1段階上（direction > 0）または下の値を返す。端ではそのまま。"""
    if direction > 0:
        return next((step for step in steps if step > current + 1e-6), steps[-1])
    return next((step for step in reversed(steps) if step < current - 1e-6), steps[0])


def scaled_speed(base: float, speed: float, standard: float) -> float:
    """選んだ速さ（speed）を、別のモデル（中国語の VITS）の速さに換算する。

    standard（config.toml の tts.speed）のときに base（そのモデルの設定値）になるよう、同じ比率で変える。
    """
    return base * speed / standard if standard > 0 else base


def level_zone(peak: float) -> str:
    """入力レベルが目安より小さいか（"low"）、ちょうどよいか（"good"）、大きいか（"high"）。"""
    low, high = GOOD_LEVEL
    if peak < low:
        return "low"
    return "good" if peak <= high else "high"
