"""2026-11-21 に足した 24 言語のうち 22 言語の、カタカナの読み方（2026-11-23）。しくみは more_kana.py と同じ（つづり → 音の並び → カタカナ）。

- ラテン文字の 8 言語（アゼルバイジャン・カタルーニャ・セブアノ・バスク・ジャワ・マレー・スワヒリ・タガログ）: つづり → 音の表
- キリル文字の 3 言語（ベラルーシ・セルビア・カザフ）: ブルガリア語と同じ表に、その言語の字を足したもの。セルビア語はラテン文字でも読む
- インドの文字の 7 言語（ベンガル・グジャラート・マラーティー・パンジャブ・タミル・テルグ・マラヤーラム）: Unicode では、どの文字も
  デーヴァナーガリーと同じ並び方なので、同じ位置の字に置き換えて、ヒンディー語のしくみ（more_kana._deva_tokens）で読む。
  言語ごとの違い（ベンガル語の母音 o・タミル語などは語末の a も読む・マラヤーラム語の語末の ് は u）を渡す
- アルメニア文字・ジョージア文字: 1 字 1 音の表
- ミャンマー文字・クメール文字: 音節の組み立て（子音・重なる子音・母音の記号・終わりの子音）を読む。声調・母音の長さは読まない。
  クメール文字は、子音の 2 つの組で母音の読みが変わるのを読むが、音節の区切りはつづりから決めきれないので、だいたいの読みになる
- ヘブライ語・ウルドゥー語は、アラビア語・ペルシア語と同じく、短い母音を書かない文字なので扱わない
"""

from __future__ import annotations

import re
import unicodedata
from collections.abc import Callable

from .more_kana import (
    _CYRILLIC_BASE, _DEVANAGARI_WORD, _HR, _ID, Tokens, SpellingRules, _deva_tokens, _latin, _latin_converter,
    _word_converter, tokens_to_kana,
)

# --- ラテン文字 ---
_AZ = _latin(
    {"ə": ["e"], "ı": ["u"], "ö": ["o"], "ü": ["y", "u"], "c": ["j"], "ç": ["ch"], "ş": ["sh"], "ğ": ["g"],
     "x": ["x"], "q": ["g"], "j": ["zh"], "y": ["y"], "kö": ["k", "y", "o"], "gö": ["g", "y", "o"]},
    geminate="bcçdfgkmnpqrsştvxz",
)
_CA = _latin(
    {"ny": ["ny"], "ll": ["ly"], "l·l": ["r"], "ç": ["s"], "tx": ["ch"], "ix": ["sh"], "^x": ["sh"], "x": ["sh"],
     "ig#": ["ch"], "qu": ["k", "w"], "gu": ["g", "w"], "h": [], "j": ["zh"], "v": ["b"], "rr": ["r"], "tg": ["j"], "tj": ["j"],
     "ss": ["s"], "y": ["i"]},
    [("c", "eiéèí", ["s"]), ("g", "eiéèí", ["zh"]), ("gu", "eiéèí", ["g"]), ("qu", "eiéèí", ["k"])],
)
_MGA = {"^mga#": ["m", "a", "ng", "a"]}  # タガログ語・セブアノ語の「mga」（複数の印）は「マガ」ではなく「マンガ」
_CEB = _latin({**_MGA, "ng": ["ng"], "c": ["k"], "j": ["h"], "y": ["y"], "ñ": ["ny"]})
_TL = _latin({**_MGA, "ng": ["ng"], "c": ["k"], "j": ["h"], "y": ["y"], "ñ": ["ny"]})
_EU = _latin(
    {"tx": ["ch"], "ts": ["ch"], "tz": ["ts"], "x": ["sh"], "z": ["s"], "j": ["y"], "ñ": ["ny"], "ll": ["ly"], "il": ["i", "r"],
     "rr": ["r"], "h": [], "tt": ["ty"], "dd": ["dy"], "y": ["y"], "gu": ["g"], "ai": ["a", "i"], "ei": ["e", "i"]},
)
_JV = _latin(
    {"c": ["ch"], "j": ["j"], "y": ["y"], "ng": ["ng"], "ny": ["ny"], "dh": ["d"], "th": ["t"], "é": ["e"], "è": ["e"],
     "k#": ["!ッ"]},
)
_SW = _latin(
    {"ch": ["ch"], "sh": ["sh"], "ny": ["ny"], "ng'": ["ng"], "ng": ["N", "g"], "dh": ["z"], "th": ["s"], "gh": ["g"],
     "j": ["j"], "y": ["y"], "^m": ["m"], "^n": ["n"]},
)

# --- キリル文字 ---
_CYRILLIC_MORE = re.compile(r"[а-яёґєіїўәғқңөұүһђћљњџј]+(?:['’][а-яёґєіїўәғқңөұүһђћљњџј]+)*", re.IGNORECASE)
_SERBIAN_LATIN_WORD = re.compile(r"[^\W\d_]+")
_BE = SpellingRules({
    **_CYRILLIC_BASE, "г": ["h"], "ў": ["w"], "і": ["i"], "ы": ["i"], "э": ["e"], "ё": ["y", "o"], "ь": [],
    "е": ["e"], "^е": ["y", "e"], "ць": ["ts"], "дзь": ["j"], "нь": ["ny"], "ль": ["ly"], "сь": ["sh"], "зь": ["zh"],
    "в#": ["f"],
})
_SR = SpellingRules({
    **_CYRILLIC_BASE, "ђ": ["j"], "ћ": ["ch"], "љ": ["ly"], "њ": ["ny"], "џ": ["j"], "ј": ["y"],
})
_KK = SpellingRules({
    **_CYRILLIC_BASE, "ә": ["e"], "ғ": ["g"], "қ": ["k"], "ң": ["ng"], "ө": ["o"], "ұ": ["u"], "ү": ["y", "u"],
    "һ": ["h"], "і": ["i"], "ы": ["u"], "ё": ["y", "o"], "э": ["e"], "ь": [], "ъ": [], "щ": ["sh"], "^е": ["y", "e"],
})


def _cyrillic_and_latin(cyrillic: SpellingRules, latin: SpellingRules | None = None) -> Callable[[str], str]:
    to_kana = _word_converter(_CYRILLIC_MORE, cyrillic.tokens)
    if latin is None:
        return to_kana
    latin_kana = _latin_converter(latin)
    # セルビア語はラテン文字でも書く（PLaMo がラテン文字で訳すこともある）
    return lambda text: latin_kana(to_kana(text))


# --- インドの文字（デーヴァナーガリーの同じ位置の字に置き換えて読む） ---
_DEVA_START = 0x0900
_ZWJ, _ZWNJ = "‍", "‌"
_MALAYALAM_CHILLU = {  # 母音の付かない終わりの子音の字（語末でも「ウ」を付けない）
    "ൺ": "ण्" + _ZWJ, "ൻ": "न्" + _ZWJ, "ർ": "र्" + _ZWJ,
    "ൽ": "ल्" + _ZWJ, "ൾ": "ळ्" + _ZWJ, "ൿ": "क्" + _ZWJ,
}


def _to_devanagari(word: str, start: int) -> str:
    out = []
    for ch in unicodedata.normalize("NFC", word):
        code = ord(ch)
        out.append(chr(code - start + _DEVA_START) if start <= code < start + 0x80 else ch)
    return "".join(out)


def _bn_tokens(word: str) -> Tokens:
    deva = _to_devanagari(word, 0x0980).replace("ॎ", "त्")  # ৎ（খণ্ড ত）は、母音の無い t
    # য は、単独なら「ジャ」の音（যদি → ジョディ）。子音に付いた য（্য）と、য়（য + ়）は、そのまま
    deva = re.sub(r"(?<!्)य(?!़)", "ज", deva)
    return _deva_tokens(deva, medial_schwa=True, inherent="o")


def _pa_tokens(word: str) -> Tokens:
    word = unicodedata.normalize("NFD", word).replace("ੰ", "ਂ")  # ਁ ੰ（ティッピ）は ਂ と同じ「ン」
    word = re.sub("ੱ(.)", lambda m: m.group(1) + "੍" + m.group(1), word)  # ੱ（アッダク）は、次の子音が重なる
    return _deva_tokens(_to_devanagari(word, 0x0a00), medial_schwa=True)


def _ml_tokens(word: str) -> Tokens:
    word = word.replace(_ZWJ, "").replace(_ZWNJ, "").replace("റ്റ", "ട്ട")  # റ്റ は「ッタ」の音（സ്റ്റേഷൻ → ステーシャン）
    for chillu, deva in _MALAYALAM_CHILLU.items():
        word = word.replace(chillu, deva)
    return _deva_tokens(_to_devanagari(word, 0x0d00), medial_schwa=False, final_schwa=False,
                        final_virama_vowel="u", final_anusvara="m", ai_vowel="ai")


def _indic(start: int, **options) -> Callable[[str], Tokens]:
    return lambda word: _deva_tokens(_to_devanagari(word, start), **options)


def _indic_word(start: int, extra: str = "") -> re.Pattern[str]:
    return re.compile(f"[{chr(start)}-{chr(start + 0x7f)}{extra}]+")


# --- アルメニア文字 ---
_HY_LETTERS = {
    "ա": ["a"], "բ": ["b"], "գ": ["g"], "դ": ["d"], "ե": ["e"], "զ": ["z"], "է": ["e"], "ը": ["u"], "թ": ["t"],
    "ժ": ["zh"], "ի": ["i"], "լ": ["r"], "խ": ["x"], "ծ": ["ts"], "կ": ["k"], "հ": ["h"], "ձ": ["dz"], "ղ": ["g"],
    "ճ": ["ch"], "մ": ["m"], "յ": ["y"], "ն": ["n"], "շ": ["sh"], "ո": ["o"], "չ": ["ch"], "պ": ["p"], "ջ": ["j"],
    "ռ": ["r"], "ս": ["s"], "վ": ["v"], "տ": ["t"], "ր": ["r"], "ց": ["ts"], "ւ": ["v"], "փ": ["p"], "ք": ["k"],
    "օ": ["o"], "ֆ": ["f"], "ու": ["u"], "աա": ["a", "a"], "եե": ["e", "e"], "իի": ["i", "i"], "օօ": ["o", "o"], "և": ["e", "v"], "^ե": ["y", "e"], "^ո": ["v", "o"], "^և": ["y", "e", "v"],
    "^": [], "#": [],
}
_HY = SpellingRules(_HY_LETTERS)
_ARMENIAN_WORD = re.compile(r"[Ա-և]+")

# --- ジョージア文字 ---
_KA_LETTERS = {
    "ა": ["a"], "ბ": ["b"], "გ": ["g"], "დ": ["d"], "ე": ["e"], "ვ": ["v"], "ზ": ["z"], "თ": ["t"], "ი": ["i"],
    "კ": ["k"], "ლ": ["r"], "მ": ["m"], "ნ": ["n"], "ო": ["o"], "პ": ["p"], "ჟ": ["zh"], "რ": ["r"], "ს": ["s"],
    "ტ": ["t"], "უ": ["u"], "ფ": ["p"], "ქ": ["k"], "ღ": ["g"], "ყ": ["k"], "შ": ["sh"], "ჩ": ["ch"], "ც": ["ts"],
    "ძ": ["dz"], "წ": ["ts"], "ჭ": ["ch"], "ხ": ["x"], "ჯ": ["j"], "ჰ": ["h"], "^": [], "#": [],
    # 同じ母音が 2 つ続くときは、2 つとも読む（SpellingRules は、同じ字が続くと 1 つにする）
    "აა": ["a", "a"], "ეე": ["e", "e"], "იი": ["i", "i"], "ოო": ["o", "o"], "უუ": ["u", "u"],
}
_KA = SpellingRules(_KA_LETTERS)
_GEORGIAN_WORD = re.compile(r"[ა-ჿᲐ-Ჿ]+")


# --- ミャンマー文字 ---
_MY_CONSONANTS = {
    "က": "k", "ခ": "k", "ဂ": "g", "ဃ": "g", "င": "ng", "စ": "s", "ဆ": "s", "ဇ": "z", "ဈ": "z", "ဉ": "ny", "ည": "ny",
    "ဋ": "t", "ဌ": "t", "ဍ": "d", "ဎ": "d", "ဏ": "n", "တ": "t", "ထ": "t", "ဒ": "d", "ဓ": "d", "န": "n", "ပ": "p",
    "ဖ": "p", "ဗ": "b", "ဘ": "b", "မ": "m", "ယ": "y", "ရ": "y", "လ": "r", "ဝ": "w", "သ": "t", "ဟ": "h", "ဠ": "r",
    "အ": "",
}
_MY_VOWEL_LETTERS = {"ဣ": "i", "ဤ": "i", "ဥ": "u", "ဦ": "u", "ဧ": "e", "ဩ": "o", "ဪ": "o"}
_MY_SIGNS = {"ာ": "a", "ါ": "a", "ိ": "i", "ီ": "i", "ု": "u", "ူ": "u", "ေ": "e", "ဲ": "e"}
_MY_ASAT, _MY_STACK, _MY_ANUSVARA = "်", "္", "ံ"
_MY_STOPS, _MY_NASALS = {"k", "s", "t", "p"}, {"ng", "ny", "n", "m"}


def _my_vowel(signs: str) -> str:
    """母音の記号の組み合わせ → 母音（ော・ေါ = o、ို = o）。"""
    if "ေ" in signs and ("ာ" in signs or "ါ" in signs):
        return "o"
    if "ိ" in signs and "ု" in signs:
        return "o"
    for sign in signs:
        if sign in _MY_SIGNS:
            return _MY_SIGNS[sign]
    return "a"


def _my_tokens(word: str) -> Tokens:
    """ミャンマー文字の語を、音の並びにする（子音 + 重なる印 + 母音の記号 + 終わりの子音 ်）。"""
    syllables: list[dict] = []
    text = unicodedata.normalize("NFC", word)
    i = 0
    while i < len(text):
        ch = text[i]
        if ch in _MY_CONSONANTS:
            # 終わりの子音（次に ် が付く。重なる印 ္ のときも、前の音節の終わり）
            if i + 1 < len(text) and text[i + 1] in (_MY_ASAT, _MY_STACK) and syllables:
                syllables[-1]["final"] = _MY_CONSONANTS[ch]
                i += 2
                continue
            syllables.append({"onset": _MY_CONSONANTS[ch], "medial": "", "signs": "", "final": ""})
        elif ch in _MY_VOWEL_LETTERS:
            syllables.append({"onset": "", "medial": "", "signs": "", "final": "", "vowel": _MY_VOWEL_LETTERS[ch]})
        elif syllables and ch in "ျြ":
            syllables[-1]["medial"] += "y"
        elif syllables and ch == "ွ":
            syllables[-1]["medial"] += "w"
        elif syllables and (ch in _MY_SIGNS or ch == _MY_ANUSVARA):
            syllables[-1]["signs"] += ch
        i += 1
    tokens: Tokens = []
    for s in syllables:
        onset, medial, final = s["onset"], s["medial"], s["final"]
        vowel = s.get("vowel") or _my_vowel(s["signs"])
        if "y" in medial:
            onset = {"k": "ch", "g": "j", "": "y"}.get(onset, onset)
            if onset not in ("ch", "j", "y"):
                tokens.append(onset)
                onset = "y"
        if onset:
            tokens.append(onset)
        if "w" in medial:
            tokens.append("w")
        if _MY_ANUSVARA in s["signs"]:
            final = "m"
        # 終わりの子音で、母音の音が変わる（ကက် → ケッ、ကင် → キン、ကုန် → コウン、ကောင် → カウン、ကိုင် → カイン）
        if final:
            if final == "y":  # ယ်（တယ် → テ）は、母音を e にして、終わりの子音は読まない
                vowel, final = "e", ""
            elif vowel == "a":
                vowel = {"k": "e", "ng": "i", "s": "i", "ny": "i"}.get(final, "a")
            elif vowel == "i" and final in ("t", "n", "p", "m"):
                vowel = "ei"
            elif vowel == "u" and final in ("t", "n", "p", "m"):
                vowel = "ou"
            elif vowel == "o" and final in ("k", "ng"):
                vowel = "au" if "ေ" in s["signs"] else "ai"
        tokens.extend(list(vowel))
        if final in _MY_STOPS:
            tokens.append("!ッ")
        elif final in _MY_NASALS:
            tokens.append("N")
        tokens.append("|")
    return tokens


# --- クメール文字 ---
_KM_FIRST = {  # 第 1 組（母音は a の側）
    "ក": "k", "ខ": "k", "ច": "ch", "ឆ": "ch", "ដ": "d", "ឋ": "t", "ណ": "n", "ត": "t", "ថ": "t", "ប": "b", "ផ": "p",
    "ស": "s", "ហ": "h", "ឡ": "r", "អ": "",
}
_KM_SECOND = {  # 第 2 組（母音は o の側）
    "គ": "k", "ឃ": "k", "ង": "ng", "ជ": "ch", "ឈ": "ch", "ញ": "ny", "ឌ": "d", "ឍ": "t", "ន": "n", "ទ": "t", "ធ": "t",
    "ព": "p", "ភ": "p", "ម": "m", "យ": "y", "រ": "r", "ល": "r", "វ": "v",
}
_KM_SIGNS = {  # 母音の記号: (第 1 組の読み, 第 2 組の読み)
    "ា": ("a", "ea"), "ិ": ("e", "i"), "ី": ("ei", "i"), "ឹ": ("e", "e"), "ឺ": ("e", "e"), "ុ": ("o", "u"),
    "ូ": ("ou", "u"), "ួ": ("uo", "uo"), "ើ": ("ae", "e"), "ឿ": ("ea", "ea"), "ៀ": ("ie", "ie"), "េ": ("e", "e"),
    "ែ": ("ae", "e"), "ៃ": ("ai", "ei"), "ោ": ("ao", "o"), "ៅ": ("au", "ou"), "ំ": ("om", "um"), "ះ": ("ah", "eah"),
    "ុំ": ("om", "um"), "ាំ": ("am", "oam"), "ុះ": ("oh", "uh"), "េះ": ("eh", "ih"), "ោះ": ("aoh", "uoh"),
}
_KM_COENG = "្"
_KM_FINAL = {"k": "!ッ", "ch": "!ッ", "t": "!ッ", "d": "!ッ", "p": "!ッ", "b": "!ッ", "ng": "N", "ny": "N", "n": "N",
             "m": "N", "y": "i", "v": "u", "s": "s", "h": "", "r": "", "": ""}
_KM_INDEPENDENT = {"ឥ": "e", "ឦ": "ei", "ឧ": "o", "ឩ": "ou", "ឪ": "au", "ឫ": "rue", "ឬ": "rue", "ឭ": "rue",
                   "ឮ": "rue", "ឯ": "ae", "ឰ": "ai", "ឱ": "ao", "ឲ": "ao", "ឳ": "au"}


def _km_tokens(word: str) -> Tokens:
    """クメール文字の語を、音の並びにする（だいたいの読み）。

    子音（+ ្ で下に付く子音）に母音の記号が付けば 1 音節。母音の記号の付かない子音は、前の音節に終わりの子音が無ければ、
    その終わりの子音にする（語の最後の子音も）。そうでなければ、子音の組の母音（a / o）で読む。
    """
    text = unicodedata.normalize("NFC", word)
    items: list[tuple[str, str, str]] = []  # (種類, 音, 組) 種類 = C 子音・V 母音の記号・I 母音の字
    i = 0
    while i < len(text):
        ch = text[i]
        if ch == _KM_COENG and i + 1 < len(text):
            following = text[i + 1]
            sound = _KM_FIRST.get(following, _KM_SECOND.get(following))
            if sound is not None and items and items[-1][0] == "C":
                kind, onset, series = items[-1]
                # 下に付く子音の組が第 2 組なら、母音もそちらで読む（ស្រ → sr、ល្ម など）
                second = following in _KM_SECOND and following not in "ងញនមយរលវ"
                items[-1] = ("C", onset + "|" + sound, "2" if second else series)
            i += 2
            continue
        if ch in _KM_FIRST or ch in _KM_SECOND:
            items.append(("C", _KM_FIRST.get(ch, _KM_SECOND.get(ch, "")), "1" if ch in _KM_FIRST else "2"))
        elif ch in _KM_INDEPENDENT:
            items.append(("I", _KM_INDEPENDENT[ch], ""))
        else:
            two = text[i:i + 2]
            if two in _KM_SIGNS:
                items.append(("V", two, ""))
                i += 2
                continue
            if ch in _KM_SIGNS:
                items.append(("V", ch, ""))
        i += 1
    syllables: list[dict] = []
    for index, (kind, value, series) in enumerate(items):
        following = items[index + 1] if index + 1 < len(items) else None
        if kind == "I":
            syllables.append({"onset": "", "vowel": value, "final": None})
        elif kind == "V" and syllables:
            last = syllables[-1]
            first, second = _KM_SIGNS[value]
            last["vowel"] = first if last["series"] == "1" else second
        elif kind == "C":
            has_sign = following is not None and following[0] == "V"
            if not has_sign and syllables and syllables[-1]["final"] is None and "|" not in value:
                syllables[-1]["final"] = value
            else:
                syllables.append({"onset": value, "series": series, "vowel": "a" if series == "1" else "o", "final": None})
    tokens: Tokens = []
    for s in syllables:
        for part in s.get("onset", "").split("|"):
            if part:
                tokens.append(part)
        vowel = s["vowel"]
        tail = ""
        if vowel.endswith(("m", "h")) and len(vowel) > 1:
            vowel, tail = vowel[:-1], vowel[-1]
        tokens.extend(list(vowel))
        if tail == "m":
            tokens.append("N")
        final = s["final"] or ""
        kana_final = _KM_FINAL.get(final, "")
        if kana_final in ("i", "u"):
            tokens.append(kana_final)
        elif kana_final:
            tokens.append(kana_final)
        tokens.append("|")
    return tokens


def _without_joiners(convert: Callable[[str], str]) -> Callable[[str], str]:
    """語の中の見えない字（ZWNJ・ZWJ）を、カタカナに残さない（テルグ語の స్టేషన్‌లో など）。"""
    return lambda text: convert(text).replace(_ZWNJ, "").replace(_ZWJ, "")


CONVERTERS: dict[str, Callable[[str], str]] = {
    "az": _latin_converter(_AZ), "ca": _latin_converter(_CA), "ceb": _latin_converter(_CEB),
    "eu": _latin_converter(_EU), "jv": _latin_converter(_JV), "ms": _latin_converter(_ID),
    "sw": _latin_converter(_SW), "tl": _latin_converter(_TL),
    "be": _cyrillic_and_latin(_BE), "kk": _cyrillic_and_latin(_KK), "sr": _cyrillic_and_latin(_SR, _HR),
    "mr": _word_converter(_DEVANAGARI_WORD, lambda word: _deva_tokens(word, medial_schwa=True)),
    "bn": _word_converter(_indic_word(0x0980), _bn_tokens),
    "gu": _word_converter(_indic_word(0x0a80), _indic(0x0a80, medial_schwa=True)),
    "pa": _word_converter(_indic_word(0x0a00), _pa_tokens),
    "ta": _word_converter(_indic_word(0x0b80), _indic(0x0b80, medial_schwa=False, final_schwa=False, ai_vowel="ai")),
    "te": _word_converter(_indic_word(0x0c00), _indic(0x0c00, medial_schwa=False, final_schwa=False, ai_vowel="ai")),
    "ml": _word_converter(_indic_word(0x0d00, _ZWJ + _ZWNJ), _ml_tokens),
    "hy": _word_converter(_ARMENIAN_WORD, lambda word: _HY.tokens(word.lower())),
    "ka": _word_converter(_GEORGIAN_WORD, _KA.tokens),
    "my": _word_converter(re.compile(r"[က-႟ꩠ-ꩿ]+"), _my_tokens),
    "km": _word_converter(re.compile(r"[ក-៿]+"), _km_tokens),
}
CONVERTERS = {lang: _without_joiners(convert) for lang, convert in CONVERTERS.items()}
