"""PC で通訳機の画面を動かす（エミュレーター）と、取扱説明書用のスクリーンショットを撮る。

モデルや Pi は要らない。翻訳・認識・読み上げの代わりに、決まった例文を出す。画面の描き方・ボタンの位置・
キーボードの組み立ては、実機と同じプログラム（translator/ui.py）を使う。

  python tools/emulator.py                     # ウィンドウで動かす（マウスのクリック = タッチ、PC のキーボードも使える）
  python tools/emulator.py --shots docs/shots  # すべての画面を PNG にして保存する（ウィンドウは出ない）

準備: pip install pygame（フォントは tools/fonts に入っている）
"""

from __future__ import annotations

import argparse
import dataclasses
import os
import random
import sys
import tempfile
import time
from datetime import datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
FONTS = Path(__file__).resolve().parent / "fonts"
# 「使い方」の動画・スライドの置き場所（tools/make_guide_slides.py が見本のスライドを書き出す）
GUIDES = ROOT / "guides"
DEMO_PHRASES = ROOT / "tools" / "demo_phrases.json"  # 実機の最初の定型文（Web 版にも入れる）
# 暗証番号の最初の番号（実機は config.toml の [security]。エミュレーターでも同じ。変えた番号は、終わると消える）
GENERAL_PIN, ADMIN_PIN = "1234", "3957"
sys.path.insert(0, str(ROOT))

import pygame  # noqa: E402

from translator import guide  # noqa: E402
from translator import screen_keyboard as skb  # noqa: E402
from translator import ui  # noqa: E402
from translator.auto_off import AutoOff  # noqa: E402
from translator.bluetooth import BluetoothDevice  # noqa: E402
from translator.chinese import TRADITIONAL  # noqa: E402
from translator.config import DisplayConfig  # noqa: E402
from translator.industries import IndustrySelection  # noqa: E402
from translator.langs import EN, FR, FUK, HOK, JA, KO, OSA, PT, RU, TH, YUE, ZH, Mode  # noqa: E402
from translator.phrases import Phrase, PhraseBook  # noqa: E402
from translator.pins import PinStore  # noqa: E402
from translator.system_monitor import Reading  # noqa: E402
from translator.usage_log import UsageLog  # noqa: E402
from translator.ui_state import UiState  # noqa: E402
from translator.wifi import WifiNetwork  # noqa: E402

# 実機では本物のモデルが出す文の代わりに、例文を出す: 話した言語 → (話した文, 発音, 相手の言語 → (訳文, 発音))
SAMPLES = {
    JA: (
        "トイレはあちらにあります",
        "",
        {
            KO: ("화장실은 저쪽에 있어요.", "ファジャンシルン チョッチョゲ イッソヨ"),
            EN: ("The restroom is over there.", ""),
            ZH: ("洗手间在那边。", "xǐshǒujiān zài nàbiān"),
            YUE: ("洗手間喺嗰邊。", ""),
            TH: ("ห้องน้ำอยู่ทางนั้นค่ะ", ""),
            FR: ("Les toilettes sont par là.", ""),
            RU: ("Туалет там.", "トゥアレート タム"),
            PT: ("O banheiro fica ali.", "ウ バニェイル フィカ アリ"),
            HOK: ("トイレはあっちだべさ", ""),
            OSA: ("トイレはあっちでっせ", ""),
            FUK: ("トイレはあっちばい", ""),
        },
    ),
    KO: ("카드로 계산할 수 있어요?", "カドゥロ ケサナル ス イッソヨ", {JA: ("カードで支払えますか？", "")}),
    EN: ("Can I pay by card?", "", {JA: ("カードで支払えますか？", "")}),
    ZH: ("可以刷卡吗？", "kěyǐ shuākǎ ma", {JA: ("カードで支払えますか？", "")}),
    YUE: ("可以碌卡嗎？", "", {JA: ("カードで支払えますか？", "")}),
    TH: ("จ่ายด้วยบัตรได้ไหมคะ", "", {JA: ("カードで支払えますか？", "")}),
    FR: ("Puis-je payer par carte ?", "", {JA: ("カードで支払えますか？", "")}),
    RU: ("Можно оплатить картой?", "", {JA: ("カードで支払えますか？", "")}),
    PT: ("Posso pagar com cartão?", "", {JA: ("カードで支払えますか？", "")}),
    HOK: ("カードでいいんでないかい", "", {JA: ("カードでいいんじゃないですか", "")}),
    OSA: ("カードでええんちゃう？", "", {JA: ("カードでいいんじゃない？", "")}),
    FUK: ("カードでよかね？", "", {JA: ("カードでいいですね？", "")}),
}


# 台湾の繁体字（中国語（台灣）を選んでいるとき）の例文。繁体字への変換（OpenCC）が無い環境でも、台湾の字で出るように
TRADITIONAL = {"洗手间在那边。": "洗手間在那邊。", "可以刷卡吗？": "可以刷卡嗎？"}


def make_display(visible: bool) -> DisplayConfig:
    """画面の設定。実機の config.toml と同じ大きさ・同じ書体（Noto Sans CJK / Noto Sans Thai）にする。"""
    return DisplayConfig(
        width=800,
        height=480,
        fullscreen=False,
        video_driver="" if visible else "dummy",
        font=str(FONTS / "NotoSansCJK-Regular.ttc"),
        show_japanese_source=True,
        show_pronunciation=True,
        show_back_translation=True,
        phonetic_font="",
        thai_font=str(FONTS / "NotoSansThai.ttf"),
    )


CJK_FACES = 10  # NotoSansCJK-Regular.ttc に入っている書体の数


def _guard_font_index() -> None:
    """load_fonts は、書体の番号を 0 から増やして「開けなくなるまで」読む。Linux の pygame は範囲外の番号で
    エラーを返すが、Windows の pygame は落ちてしまう（アクセス違反）ので、範囲外はこちらでエラーにする。"""
    real = pygame.freetype.Font

    def guarded(file, size=0, font_index=0, *args, **kwargs):
        if font_index >= CJK_FACES:
            raise OSError("font_index out of range")
        return real(file, size, font_index, *args, **kwargs)

    ui.pygame.freetype.Font = guarded


class MemorySettings:
    """user_settings.json の代わり（ファイルに書かず、終わると消える）。"""

    def __init__(self) -> None:
        self._values: dict[str, object] = {}

    def get_str(self, key: str, default: str = "") -> str:
        value = self._values.get(key)
        return value if isinstance(value, str) else default

    def set(self, key: str, value: object) -> None:
        self._values[key] = value


class Emulator:
    """TranslatorScreen に、本物の代わりのハンドラー（例文を出す）をつないだもの。"""

    def __init__(self, visible: bool) -> None:
        # 実機では DejaVu（キーの文字）が /usr/share/fonts にある。PC では tools/fonts のものを使う
        _guard_font_index()
        ui.KEY_FONT = str(FONTS / "DejaVuSans.ttf")
        ui.PASSWORD_FONT = str(FONTS / "DejaVuSansMono.ttf")
        self.state = UiState(Mode(KO, JA), speech_enabled=True, denoise_enabled=True, denoise_available=True, back_translation_enabled=True)
        self.state.set_audio_route("マイク（ReSpeaker 2-Mics）・スピーカー（USB）", True)
        self.screen = ui.TranslatorScreen(make_display(visible), self.state)
        # 実機に最初から入れてある定型文（業種ごとの 476 文。tools/demo_phrases.json）があれば、それを使う
        preset = PhraseBook(DEMO_PHRASES).phrases if DEMO_PHRASES.is_file() else ()
        self.phrases = list(preset) or [
            Phrase(JA, "いらっしゃいませ", {KO: "어서 오세요", EN: "Welcome", ZH: "欢迎光临"}, "2026-10-01 09:30", 3),
            Phrase(JA, "こちらのお席へどうぞ", {KO: "이쪽 자리로 오세요", EN: "This way, please", ZH: "请坐这边"}, "2026-10-01 09:32", 2),
            Phrase(JA, "お会計は1,500円です", {KO: "계산은 1,500엔입니다", EN: "That will be 1,500 yen", ZH: "一共1,500日元"}, "2026-10-01 09:40", 1),
            Phrase(JA, "少々お待ちください", {KO: "잠시만 기다려 주세요", EN: "Please wait a moment", ZH: "请稍等"}, "2026-10-01 09:41", 0),
        ]
        self.wifi_connected = "Shop-WiFi"
        self._due: list[tuple[float, object]] = []
        s = self.screen
        s.set_mode_handler(self.state.set_mode)
        s.set_listen_handlers(self._start_listening, lambda: self.state.set_listening_armed(False))
        s.set_play_handler(lambda: self.state.set_target_played(True))
        s.set_text_handler(self._translate_text)
        s.set_phrase_handlers(lambda: tuple(self.phrases), self._add_phrase, lambda i: self.phrases.pop(i), self._use_phrase)
        s.set_wifi_handlers(self._wifi_open, self._wifi_open, self._wifi_connect, self._wifi_disconnect)
        s.set_bluetooth_handlers(lambda: None, lambda device: None, lambda: None, lambda: None, lambda: None)
        s.set_input_device_handlers(lambda: None, lambda device: None, lambda: None, lambda: None)
        s.set_guide_handlers(lambda: guide.read_guides(GUIDES), self._play_guide_video, self._stop_guide_video)
        s.set_pin_store(PinStore(MemorySettings(), GENERAL_PIN, ADMIN_PIN))
        s.set_system_handler(self._readings)
        s.set_usage_log(self._demo_usage())  # 管理者の画面の「利用状況」: それらしい見本の 30 日分
        s.set_power_handlers(lambda: False, lambda: False)
        s.set_auto_off(AutoOff(), lambda: None)
        s.set_industries(IndustrySelection(()), lambda: None)
        # ハングル学習: 読み上げは何もせず、発音チェックは 1.2 秒後に、手本どおりに言ったことにする
        s.set_study_handlers(lambda text: True, self._study_check, lambda: None, lambda: None, language=lambda lang: None)
        # 時計設定: 体験版では、本体の時計は変えない（自動合わせのオン・オフだけ切り替えられる）
        self._clock_ntp = True
        s.set_clock_handlers(self._clock_set, self._clock_set_ntp, lambda: self._clock_ntp)
        # 訂正の一覧: 体験版では、メモリの中だけに覚える（ページを開き直すと消える）
        self.fixes: list = []
        s.set_fix_handlers(
            lambda: tuple(self.fixes), self._fix_keep, self._fix_last, self._fix_save, lambda i: self.fixes.pop(i),
            voice=self._fix_voice, cancel_voice=lambda: None,
        )
        self.state.set_bluetooth(
            devices=(BluetoothDevice("AA:BB:CC:00:11:22", "ワイヤレスイヤホン", True, False), BluetoothDevice("AA:BB:CC:33:44:55", "Bluetooth スピーカー", True, True)),
            status="",
        )
        self._wifi_open()

    # --- 本物の代わりの処理 ---

    def show_sample(self, speaker: str | None = None) -> None:
        """今のモードで、例文の発話を出す（話した文と、訳文）。"""
        mode = self.state.mode
        speaker = speaker or mode.speaker
        text, pron, targets = SAMPLES[speaker if speaker == JA else mode.partner]
        target = mode.listener
        translated, target_pron = targets.get(target, next(iter(targets.values())))
        if self.state.snapshot().zh_traditional:
            text, translated = TRADITIONAL.get(text, text), TRADITIONAL.get(translated, translated)
        self.state.begin_utterance(speaker, text, target, pron)
        self.state.set_target_text(translated)
        self.state.set_target_pron(target_pron)
        if speaker == JA:
            self.state.set_back_translation(JA, text)

    def _later(self, delay_sec: float, action) -> None:
        """delay_sec 秒あとに action を行う（tick() が呼ばれたときに実行する。ブラウザでは裏のスレッドが使えないので、これで動かす）。"""
        self._due.append((time.monotonic() + delay_sec, action))

    def tick(self) -> None:
        """時間が来た予約（聞き取りの終わり、動画の終わり）を実行する。"""
        now = time.monotonic()
        ready = [item for item in self._due if item[0] <= now]
        self._due = [item for item in self._due if item[0] > now]
        for _, action in sorted(ready, key=lambda item: item[0]):
            action()

    def _start_listening(self) -> bool:
        self.state.set_listening_armed(True)

        def finish() -> None:
            self.state.set_listening_armed(False)
            self.show_sample()

        self._later(1.2, finish)
        return True

    def _study_check(self, on_heard) -> bool:
        target = self.screen._study_target
        self._later(1.2, lambda: on_heard(target))
        return True

    def _translate_text(self, text: str) -> bool:
        mode = self.state.mode
        self.state.begin_utterance(mode.speaker, text, mode.listener)
        self.state.set_target_text(f"（{mode.listener} の訳文の例）")
        return True

    def _add_phrase(self) -> str:
        snap = self.state.snapshot()
        if not snap.source_text:
            return "登録できる文がありません / Nothing to save"
        self.phrases.append(Phrase(snap.source_lang, snap.source_text, {snap.target_lang: snap.target_text}, datetime.now().strftime("%Y-%m-%d %H:%M")))
        return "登録しました / Saved"

    def _use_phrase(self, index: int) -> bool:
        phrase = self.phrases[index]
        target = self.state.mode.listener
        text = phrase.translations.get(target) or next(iter(phrase.translations.values()))
        self.state.begin_utterance(phrase.lang, phrase.text, target)
        self.state.set_target_text(text)
        return True

    def _play_guide_video(self, path: Path) -> bool:
        """動画の代わり: 3 秒だけ「再生中」にする（PC には mpv も DRM も無いので、実際には再生しない）。"""
        self.state.set_guide_playing(True)
        self._later(3.0, lambda: self.state.set_guide_playing(False))
        return True

    def _stop_guide_video(self) -> None:
        self.state.set_guide_playing(False)

    def _wifi_open(self) -> None:
        self.state.set_wifi(
            status="",
            networks=(
                WifiNetwork("Shop-WiFi", 82, True, True, True),
                WifiNetwork("Guest-5G", 64, True, False, False),
                WifiNetwork("cafe_free", 41, False, False, False),
                WifiNetwork("HOME-A1B2", 23, True, False, False),
            ),
            current=self.wifi_connected,
            address="192.168.1.20",
            busy=False,
        )

    def _wifi_disconnect(self) -> None:
        """「すべて切断」の代わり: つないでいる Wi-Fi を、なしにする（一覧の「接続中」も消える）。"""
        self.wifi_connected = ""
        self.state.set_wifi(status="すべて切断しました / Disconnected", current="", address="")

    def _clock_set(self, moment) -> str | None:
        return "体験版では、時計は変えられません / The clock cannot be changed in the demo"

    def _clock_set_ntp(self, enabled: bool) -> str | None:
        self._clock_ntp = enabled
        return None

    def _fix_last(self):
        snap = self.state.snapshot()
        if not snap.source_text or not snap.target_text:
            return None
        return (snap.source_lang, snap.source_text, snap.target_lang, snap.target_text)

    def _fix_save(self, source: str, text: str, target: str, translation: str) -> str:
        from translator.corrections import Correction

        self.fixes = [f for f in self.fixes if (f.source, f.text, f.target) != (source, text, target)]
        self.fixes.append(Correction(source, text, target, translation.strip(), datetime.now().strftime("%Y-%m-%d %H:%M")))
        return "覚えました / Saved"

    def _fix_voice(self, target: str, on_heard) -> bool:
        """音声入力: 体験版は聞き取れないので、1.2 秒後に、見本の訳を聞き取ったことにする。"""
        self._later(1.2, lambda: on_heard("（音声で入力した訳の例）"))
        return True

    def _fix_keep(self) -> str:
        last = self._fix_last()
        return self._fix_save(*last) if last else "先に、通訳をしてください（直したい文を訳したあとに押します）"

    def _wifi_connect(self, network: WifiNetwork, password: str | None) -> None:
        self.wifi_connected = network.ssid
        self.state.set_wifi(status=f"{network.ssid} につなぎました / Connected", current=network.ssid)

    @staticmethod
    def _demo_usage() -> UsageLog:
        """管理者の画面の「利用状況」に出す、それらしい見本のデータ（今日までの 30 日分。毎回、同じ形で作る）。"""
        path = Path(tempfile.gettempdir()) / "usage_log_demo.json"
        path.unlink(missing_ok=True)
        now = datetime.now().replace(hour=14, minute=5, second=0, microsecond=0)
        clock = [now]
        seed = UsageLog(path, now=lambda: clock[0])
        rng = random.Random(2026)
        languages = (KO, EN, ZH, YUE, TH, FR, RU, PT, HOK, OSA, FUK)
        weights = (10, 8, 6, 3, 3, 2, 1, 2, 2, 1, 1)
        for days_ago in range(29, -1, -1):
            clock[0] = now - timedelta(days=days_ago)
            for _ in range(rng.randint(4, 38)):
                seed.record_translation(rng.choices(languages, weights)[0])
            for _ in range(rng.randint(0, 4)):
                seed.record_correction(rng.choices(languages, weights)[0])
            for _ in range(rng.randint(0, 3)):
                seed.record_phrase()
            seed.record_temperature(58 + rng.random() * 26)
        return UsageLog(path)  # 本物の時計で、続けて数える

    @staticmethod
    def _readings(hours: int) -> list[Reading]:
        """管理者の画面のグラフ用の、それらしい温度・電圧の記録。"""
        now = datetime.now().replace(second=0, microsecond=0)
        points = []
        for i in range(hours * 6, -1, -1):
            wobble = ((i * 37) % 11) / 11
            # 温度・5V 入力電圧（Pi 5・CM5）・CPU クロック・CPU 電圧（クロックが下がると、電圧も下がる）
            clock = 600 if (i // 18) % 3 == 1 else 2400
            points.append(
                Reading(
                    now - timedelta(minutes=10 * i), 48 + 6 * wobble, 5.08 - 0.05 * wobble, 5.02 - 0.05 * wobble,
                    clock=float(clock), cpu_volt=0.75 if clock == 600 else 0.88, clock_min=float(clock),
                )
            )
        return points

    # --- 画面の操作 ---

    def tick_after(self, seconds: float) -> None:
        """時間が来た予約を、すぐに実行する（スクリーンショット用。実際には待たない）。"""
        self._due = [(0.0, action) for _, action in self._due]
        self.tick()
        self.settle()

    def settle(self) -> None:
        """状態を反映して、画面を描き直す。"""
        self.screen._needs_redraw = True
        self.screen._redraw_if_changed()

    def tap(self, x: int, y: int) -> None:
        self.screen._last_tap = 0.0
        self.screen._tap(x, y)
        self.settle()

    def go(self, page: str) -> None:
        self.screen._set_page(page)
        self.settle()

    def save(self, folder: Path, name: str) -> None:
        self.settle()
        pygame.image.save(self.screen._surface, str(folder / f"{name}.png"))
        print("  保存:", name)

    def run(self) -> None:
        self.screen.open_menu()
        screen = self.screen
        while screen._running:
            # 入力は最大 0.05 秒待つ。そのあと、時間が来た予約を実行して、変わっていれば描き直す
            screen._handle_input(0.05)
            self.tick()
            screen._redraw_if_changed()
        screen.close()


def take_shots(folder: Path) -> None:
    """取扱説明書に載せる画面を、すべて保存する。"""
    folder.mkdir(parents=True, exist_ok=True)
    emu = Emulator(visible=False)
    s, st = emu.screen, emu.state

    # メニュー
    emu.go(ui.MENU_PAGE)
    emu.save(folder, "01_menu")

    # 通訳の画面: 待機中 → 聞き取り中 → 結果
    st.set_mode(Mode(KO, JA))
    emu.go(ui.MAIN_PAGE)
    emu.save(folder, "02_main_standby")
    st.set_listening_armed(True)
    st.set_hearing(True)
    emu.save(folder, "03_main_listening")
    st.set_hearing(False)
    st.set_listening_armed(False)
    emu.show_sample()
    emu.save(folder, "04_main_result_ja_ko")
    st.set_mode(Mode(KO, KO))
    emu.show_sample()
    emu.save(folder, "05_main_result_ko_ja")
    st.set_mode(Mode(ZH, JA))
    emu.show_sample(JA)
    emu.save(folder, "06_main_result_ja_zh")
    st.set_mode(Mode(KO, JA))
    emu.show_sample(JA)

    # 翻訳の組み合わせ・音の設定
    emu.go(ui.LANGUAGE_PAGE)
    emu.save(folder, "07_language")
    emu.go(ui.SOUND_PAGE)
    st.set_input_level(0.45)
    emu.save(folder, "08_sound")

    # 定型文
    emu.go(ui.PHRASES_PAGE)
    emu.save(folder, "09_phrases")

    # 業種（用語集）: メニューの「業種」→ 区分 → 業種（居酒屋とメイドカフェを選んだ状態）
    s._industries.toggle("izakaya")
    s._industries.toggle("maid_cafe")
    emu.go(ui.MENU_PAGE)
    emu.save(folder, "36_menu_industry_selected")
    emu.go(ui.INDUSTRY_PAGE)
    emu.save(folder, "34_industry")
    s._industry_category = "nightlife"
    emu.go(ui.INDUSTRY_SUB_PAGE)
    emu.save(folder, "35_industry_nightlife")
    s._industries.clear()

    # ハングル学習: 最初の画面 → 文字 → フレーズ（発音チェックの結果つき）→ クイズ
    emu.go(ui.GUIDE_PAGE)
    emu.save(folder, "37_guide_with_study")
    emu.go(ui.STUDY_PAGE)
    emu.save(folder, "38_study")
    emu.tap(*s._study_tiles[0].center)
    s._study_group, s._study_letter = 0, 2
    emu.save(folder, "39_study_letters")
    emu.tap(*s._study_letters_row[1].center)  # 話してみる
    emu.tick_after(1.3)
    emu.save(folder, "40_study_letters_checked")
    emu.go(ui.STUDY_PAGE)
    emu.tap(*s._study_tiles[1].center)
    s._study_card = 3
    emu.save(folder, "41_study_phrase")
    emu.tap(*s._study_phrases_row[3].center)
    emu.save(folder, "42_study_phrase_listening")
    emu.tick_after(1.3)
    s._study_heard = "작시만 기다려 주세요"
    emu.save(folder, "43_study_phrase_result")
    emu.go(ui.STUDY_PAGE)
    emu.tap(*s._study_tiles[2].center)
    emu.save(folder, "44_study_quiz")
    emu.tap(*s._study_choices[s._study_question.answer].center)
    emu.save(folder, "45_study_quiz_answered")
    emu.go(ui.GUIDE_PAGE)

    # Wi-Fi の画面: つないでいるとき、「すべて切断」を 1 回押した確かめの表示
    st.set_wifi(current="Home-5G", address="192.168.3.74", status="3 件 / 3 found")
    emu.go(ui.WIFI_PAGE)
    emu.save(folder, "58_wifi_connected")
    s._wifi_disconnect_armed_at = time.monotonic()
    emu.go(ui.WIFI_PAGE)
    emu.save(folder, "59_wifi_disconnect_confirm")
    s._wifi_disconnect_armed_at = -float("inf")

    # 通訳の画面の「訂正」ボタンから開く、訂正の画面（2026-10-23 に、管理者の画面のタブから移した）
    from translator.corrections import Correction

    demo = (
        Correction("ja", "何か買って来て欲しいものがありますか？", "ko", "뭐 사다 드릴까요?", "2026-10-13 09:30"),
        Correction("ja", "お席料は1時間2,000円です。", "en", "The seating charge is 2,000 yen per hour.", "2026-10-13 09:41"),
        Correction("ja", "ご一緒に萌え萌えキュンをお願いします。", "zh", "请和我们一起说“萌萌哒”。", "2026-10-13 10:02"),
    )
    s.set_fix_handlers(
        items=lambda: demo, keep=lambda: "覚えました / Saved", last=lambda: ("ja", "こんにちは", "ko", "안녕하세요"),
        save=lambda *a: "", remove=lambda i: None,
    )
    s._fix_first = 0
    s._fix_message = "覚えました / Saved"
    emu.go(ui.FIX_PAGE)
    emu.save(folder, "60_fix")
    s._fix_message = ""
    s._admin_range = ui.ADMIN_DEFAULT_RANGE
    s._admin_loaded_at = -float("inf")  # グラフの記録を読み直す
    emu.go(ui.ADMIN_PAGE)
    emu.save(folder, "61_admin_graph")
    # 管理者の画面の「利用状況」タブ: 翻訳（言語別の積み上げ棒グラフ）と、最高温度
    s._admin_range = ui.ADMIN_USAGE_VIEW
    s._usage_kind, s._usage_days = ui.TRANSLATIONS, 14
    emu.go(ui.ADMIN_PAGE)
    emu.save(folder, "63_usage_translations")
    s._usage_kind, s._usage_days = ui.MAX_TEMP, 14
    emu.go(ui.ADMIN_PAGE)
    emu.save(folder, "64_usage_temperature")
    s._usage_kind, s._usage_days = ui.TRANSLATIONS, 14
    s._admin_range = ui.ADMIN_DEFAULT_RANGE
    # 起動中の画面（ロゴ、製品名、起動の進み具合の棒グラフ）
    st.set_ready(False)
    st.set_message("翻訳サーバーの起動を待っています（4/4）")
    st.set_startup_progress(0.6)
    emu.go(ui.MAIN_PAGE)
    emu.save(folder, "62_opening")
    st.set_ready(True)
    st.set_message(None)
    emu.go(ui.MAIN_PAGE)

    # 英語学習（「ガイド」の「英語学習」）
    s._open_study(ui.EN)
    emu.go(ui.STUDY_PAGE)
    emu.save(folder, "47_english_study")
    s._study_group = s._study_letter = 0
    emu.go(ui.STUDY_LETTERS_PAGE)
    emu.save(folder, "48_english_letters")
    s._study_group, s._study_letter = 2, 2
    emu.go(ui.STUDY_LETTERS_PAGE)
    emu.save(folder, "49_english_spellings")
    s._study_cards = s._course.phrase_deck(())
    s._study_card = 3
    emu.go(ui.STUDY_PHRASE_PAGE)
    emu.save(folder, "50_english_phrase")
    s._study_start_quiz("words")
    emu.save(folder, "51_english_quiz")
    # 中国語学習
    s._open_study(ui.ZH)
    emu.go(ui.STUDY_PAGE)
    emu.save(folder, "53_chinese_study")
    s._study_group, s._study_letter = 0, 1
    emu.go(ui.STUDY_LETTERS_PAGE)
    emu.save(folder, "54_chinese_tones")
    s._study_group, s._study_letter = 1, 14
    emu.go(ui.STUDY_LETTERS_PAGE)
    emu.save(folder, "55_chinese_initials")
    s._study_cards = s._course.phrase_deck(())
    s._study_card = 6
    emu.go(ui.STUDY_PHRASE_PAGE)
    emu.save(folder, "56_chinese_phrase")
    s._study_start_quiz("words")
    emu.save(folder, "57_chinese_quiz")
    s._open_study(ui.KO)  # 以降の画面は、ハングル学習の状態に戻す
    emu.go(ui.GUIDE_PAGE)
    emu.save(folder, "52_guide_with_two_study_buttons")

    # 時計設定（メニューの右上の日付・時刻を押して開く）
    s._open_clock()
    s._clock_fields.hour, s._clock_fields.minute = 6, 30
    emu.go(ui.CLOCK_PAGE)
    emu.save(folder, "46_clock")

    # 画面のキーボード: 日本語（ローマ字）・韓国語・タイ語・ロシア語・中国語（打てない）
    def type_labels(labels) -> None:
        for label in labels:
            for rect, key in s._kb_keys(st.mode.speaker):
                if key.label == label and key.action == skb.KEY:
                    s._tap_keyboard(*rect.center)
                    break

    st.set_mode(Mode(KO, JA))
    s._entry.clear()
    emu.go(ui.KEYBOARD_PAGE)
    emu.save(folder, "10_keyboard_empty")
    type_labels("konnichiha")
    emu.save(folder, "11_keyboard_ja")
    s._kb_symbols = True
    emu.save(folder, "12_keyboard_symbols")
    s._kb_symbols = False
    st.set_mode(Mode(KO, KO))
    s._entry.clear()
    type_labels("ㅇㅏㄴㄴㅕㅇㅎㅏㅅㅔㅇㅛ")
    emu.save(folder, "13_keyboard_ko")
    st.set_mode(Mode(TH, TH))
    s._entry.clear()
    type_labels(["ส", "ว", "◌ั", "ส", "ด", "◌ี"])
    emu.save(folder, "14_keyboard_th")
    st.set_mode(Mode(RU, RU))
    s._entry.clear()
    type_labels("привет")
    emu.save(folder, "15_keyboard_ru")
    st.set_mode(Mode(ZH, ZH))
    emu.save(folder, "16_keyboard_zh")
    st.set_mode(Mode(KO, JA))
    s._entry.clear()

    # Wi-Fi・Bluetooth・マウス/キーボード・電源・管理者
    emu.go(ui.WIFI_PAGE)
    emu.save(folder, "17_wifi")
    s._wifi_target = emu.state.snapshot().wifi_networks[1]
    s._wifi_password = "pass1234"
    emu.go(ui.WIFI_PASSWORD_PAGE)
    emu.save(folder, "18_wifi_password")
    emu.go(ui.BLUETOOTH_PAGE)
    emu.save(folder, "19_bluetooth")
    emu.go(ui.INPUT_PAGE)
    emu.save(folder, "20_input_devices")
    emu.go(ui.POWER_PAGE)
    emu.save(folder, "21_power")

    # 使い方（動画・スライド）: お客様用 / 店舗用 → 一覧 → スライド・動画
    s._open_guide()
    emu.settle()
    emu.save(folder, "22_guide")
    # 店舗用は、4 桁の番号を入れてから開く
    emu.tap(*s._guide_audience_buttons[guide.STORE].center)
    for digit in "12":
        emu.tap(*s._pin_keys[digit].center)
    emu.save(folder, "28_guide_pin")
    for digit in "34":
        emu.tap(*s._pin_keys[digit].center)
    emu.settle()
    emu.save(folder, "23_guide_store")
    s._guide_category = next(c for c in s._guides[guide.STORE].categories if c.key == "admin")
    emu.settle()
    emu.save(folder, "24_guide_store_admin")
    s._guide_audience, s._guide_category = guide.CUSTOMER, None
    emu.settle()
    emu.save(folder, "25_guide_customer")
    s._open_guide_item(s._guide_entries()[0][1])
    emu.settle()
    emu.save(folder, "26_guide_slide")
    # 動画の画面（再生の前。再生中は mpv が画面を使うので、アプリは何も描かない）
    s._guide_item = guide.Item("ご利用案内", guide.VIDEO, Path("01_ご利用案内.mp4"))
    s._guide_was_started = False
    emu.settle()
    emu.save(folder, "27_guide_video")

    # 一般の番号: 音の設定・電源・再起動も、番号を入れてから開く
    def press(digits):
        for digit in digits:
            emu.tap(*s._pin_keys[digit].center)

    emu.go(ui.MENU_PAGE)
    emu.tap(*s._sound_button.center)
    press("12")
    emu.save(folder, "29_pin_sound")
    press("34")
    assert s._page == ui.SOUND_PAGE
    # 管理者: 電源・再起動 →「管理者」→ 5 秒以内に左上の角 → 管理者の番号 → 管理者の画面 →「暗証番号」のタブ
    emu.go(ui.POWER_PAGE)
    emu.tap(*s._admin_button.center)
    emu.tap(40, 40)
    press("39")
    emu.save(folder, "30_pin_admin")
    press("57")
    assert s._page == ui.ADMIN_PAGE
    emu.tap(*s._admin_range_buttons[ui.ADMIN_PIN_VIEW].center)
    emu.save(folder, "31_admin_pin")
    # 一般の番号を変える: 新しい番号を 2 回
    emu.tap(*s._admin_pin_change_buttons[ui.GENERAL].center)
    press("5678")
    emu.save(folder, "32_pin_set_again")
    press("5678")
    assert s._page == ui.ADMIN_PAGE
    emu.save(folder, "33_admin_pin_changed")
    print(f"{len(list(folder.glob('*.png')))} 枚を {folder} に保存しました")
    s.close()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--shots", metavar="FOLDER", help="画面を PNG にして保存する先のフォルダ（ウィンドウは出さない）")
    args = parser.parse_args()
    if args.shots:
        os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
        take_shots(Path(args.shots))
    else:
        Emulator(visible=True).run()


if __name__ == "__main__":
    main()

